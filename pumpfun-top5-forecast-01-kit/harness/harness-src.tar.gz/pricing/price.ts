// List-price cost of one transcript line, against the frozen rows in pricing/rows.json (ported
// from cosmos src/shared/model-pricing.ts by pricing/port-from-cosmos.ts, with the cited OpenAI
// rows of pricing/overrides.json merged in; the commit is `PRICING_ROWS.source.sha`, the override
// file's hash `PRICING_ROWS.source.overrides`). Every line is priced at its OWN timestamp — `at` is required and
// there is no clock fallback — and a model with no row prices to null, never 0n.
//
//   priceUsage({ model: 'claude-opus-5-5', at: line.timestamp, format: 'anthropic', usage: message.usage })
//   priceUsage({ model, at: event.timestamp, format: 'openai', usage: payload.info.last_token_usage })
//
// `pricingRev` names the rows a figure was priced under; store it beside every figure.

import rowsJson from './rows.json' with { type: 'json' };
import { createPricer, type PriceUsageArgs, type PricedUsage } from './engine.ts';

export {
  createPricer,
  normalizeUsage,
  pricingRevOf,
  PricingRowsDoc,
  PRICING_ROWS_SCHEMA,
  RATE_UNIT,
  type NormalizedUsage,
  type PeriodT,
  type PriceUsageArgs,
  type PricedUsage,
  type Pricer,
  type PricingRowsDocT,
  type RatesT,
  type TokenCounts,
  type UsageFormat,
} from './engine.ts';

const bundled = createPricer(rowsJson);

/** The bundled rows document, validated. */
export const PRICING_ROWS = bundled.doc;

/** sha256 hex of the bundled rows' canonical JSON (provenance excluded); see pricingRevOf. */
export const pricingRev: string = bundled.pricingRev;

/** Price one request's usage at the bundled rows. */
export function priceUsage(args: PriceUsageArgs): PricedUsage {
  return bundled.priceUsage(args);
}

/** The bundled row index `model` bills on, or null when it is unpriced. */
export function resolveRow(model: string): number | null {
  return bundled.resolveRow(model);
}
