// One scrape/v1 trial (contracts/scrape.ts): an entry run once, timed by the house launcher
// (grader/scrape/launch.ts), with only the recording TLS gateway (grader/scrape/gateway.ts) to reach
// the network through. runScrapeTrial runs it and says how it ended: a run the heat lists (with the
// fault the house saw, or none, which leaves the verdict to the sealed scorer), or a void (an
// infrastructure fault: never listed, the heat re-runs it). scrapeTrialRecord turns a run and the
// scorer's verdict into the trials manifest's record.
//
// A trial, on the docker driver (grader/sandbox/network.ts has the networks and the two roles):
//   1. what a grader that died mid-trial left of this trial removed (network.ts reapTrial) under its
//      owner `scrape-<heat>.<entry>.<round>` (scrapeTrialOwner), told to onReap
//   2. the engine's isolation required (network.ts EngineIsolation.require) before anything is made,
//      so it fails closed: a refusal rejects the call with IsolationRefusal (never a void: the heat
//      stops, as the agent pipeline does), a probe that could not finish is a Docker error (void
//      sandbox), and neither makes a network or starts a program; then the trial's internal network,
//      labelled with the owner (createTrialNetwork), and the host's egress bridge (ensureEgressNetwork)
//   3. the gateway on it under one alias per listed host, then the egress bridge (scrapeAttachment):
//      its bundle's directory at /bot read-only (grader/scrape/bundle.ts scrapeGatewayBundle), /config
//      read-only holding gateway.json (scrapeGatewayConfig: the heat's leaf and resolved addresses per
//      host, the harness's routes, request caps, connection and byte caps and upstream mode, the house
//      User-Agent, listen port 443), a fresh /record writable, SERVICE_LIMITS. It is ready when it
//      writes /record/ready.json, within SCRAPE_READY_MS
//   4. the entry on it as `agent` under the house launcher (a spec with a `launcher`: docker.ts runs
//      the launcher as PID 1, root with SETUID/SETGID/KILL): the snapshot at /bot read-only, the house
//      at /house read-only (the runtime's launcher, launch.json from launch.ts launchConfig at the
//      heat's cap_ms dropping the entry to 65534, and ca.pem, the heat CA's certificate), a fresh
//      /output writable, the competition's limits. The launcher says `ready` within SCRAPE_READY_MS
//   5. `go` (launch.ts LauncherSession), and the launcher's one result line within cap_ms +
//      SCRAPE_RESULT_SLACK_MS; its container then exits 0 within SCRAPE_EXIT_MS
//   6. /output held to program.ts's output caps while the entry runs (its walkOutputs watch every
//      OUTPUT_WATCH_MS and, on docker, the sandbox's meter, read by program.ts outputCapBroken) and
//      collected after with program.ts collectOutputs into the blob store. On docker a cap broken
//      mid-run removes the entry's container at once, the only way to stop the writes; its result
//      then has the host's clock from `go` to the kill as wall_ns, exit null and signal SIGKILL
//   7. SIGTERM to the gateway (`docker kill --signal TERM`), which settles what is open, writes the
//      cassette and the decoded bodies to /record and exits 0 within SCRAPE_STOP_MS. The cassette must
//      be canonical JSON and a ScrapeCassette, and every body it names present with its sha256 and
//      size; the cassette's bytes and each body go into the blob store, the cassette as stored is
//      cassette_sha256
//   8. torn down whatever happened (an abort and a throw included): the meter and the watch
//      stopped, every program still running killed, the trial network removed, the scratch deleted
//      (grade.ts removeScratch; held from its mkdtemp, grade.ts holdScratch, so that removal releases it)
// The gateway is SIGTERMed once the entry has ended, before /output is collected, so the trial's end
// in the cassette is the entry's own and not however long the collection took.
//
// The process driver (tests, a kit's local run) runs the same two programs as host processes with no
// network of their own and isolates nothing: no reap, no isolation, no network. The gateway listens
// on 127.0.0.1 at a port it picks (listen_port 0, MAKEFUN_GATEWAY_HOST), under agent.ts's service
// launcher, which turns the end of its stdin into the SIGTERM. The process sandbox runs no launcher
// spec (there is no root to drop the entry from), so the house's launch.ts runs as the program itself
// (codeDir the house, script launch.ts, launch.json with uid null): the entry gets
// MAKEFUN_OUTPUT_DIR for /output and MAKEFUN_SCRAPE_GATEWAY (SCRAPE_GATEWAY_ENV), the gateway's
// 127.0.0.1:<port>, since no DNS here leads a host name to the gateway; it dials that with the host
// as SNI and authority. leftover is null there (no sandbox user to sweep): no leftover_process.
//
// The node22 house's launch.ts is the caller's text (ScrapeTrialOptions.launcherSource), never read
// here through launch.ts's own import.meta.url (launch.ts launcherSource): inside the kit's one-file
// command line every module's import.meta is the bundle's (tests/unit/kit-cli-launcher.test.ts), so the
// kit hands in the copy it carries. For the same reason nothing here imports gateway-main.ts, which
// starts itself when it is the file node runs: its file names are GATEWAY_FILES (a test holds them
// equal).
//
// How a trial ends (in this order; the first that holds decides):
//   void upstream_error  the cassette holds an upstream_error other than `unfinished` (the upstream's
//                        own 429 or 5xx, one it could not reach, a reset, a header it would not
//                        forward): the measurement is spoiled whatever the entry did. An `unfinished`
//                        one (the trial stopped before the upstream answered: the entry left, or ran
//                        out its cap, without its answer) is the entry's doing and voids nothing, so an
//                        entry cannot void its own slow trial by leaving a request open
//   void gateway         the gateway exited before it was ready or while the trial ran, was not ready
//                        in time, did not exit 0 on its SIGTERM, wrote error.json, or wrote no cassette,
//                        one that is not canonical or not a ScrapeCassette, or a body missing or wrong
//   void launcher        the launcher refused ({"error"}), printed a line that is not its protocol,
//                        closed its stdout first, gave no ready or no result in time, or its container
//                        did not exit 0 after its result
//   void sandbox         a Docker error: a SandboxError anywhere (preflight, a network, a spawn, the
//                        meter), or the driver's own failure exit (docker run's 125). Not a NodeRoomError
//                        (k8s: the node had no room for one of the trial's pods, its /output meter's
//                        included, so it never ran): that is
//                        thrown, its heat's job handed back for later (server/jobs.ts `node room`)
//   off_route            a request the gateway refused as off the routes (refused_route), or a
//                        connection it refused before TLS as no listed host's (not_tls,
//                        bad_client_hello, no_sni, unknown_sni)
//   over_cap             a request refused at a cap (refused_cap), or a connection refused or destroyed
//                        by one (max_connections, max_bytes_up, max_bytes_down, max_entries)
//   invalid_output       /output broke program.ts's output caps, while the entry ran or after
//   timeout              the launcher SIGKILLed it at cap_ms
//   crashed              a non-zero exit, or a signal that was not the cap's
//   leftover_process     it exited 0 within the cap but left processes of the sandbox user behind
//                        (the launcher killed and counted them)
//   no fault             it exited 0 within the cap breaking nothing: the scorer decides correct or
//                        incorrect (scrapeTrialRecord takes its verdict)
// The house's own observations rank first: a request off the routes or over a cap is the entry's rule
// break whatever followed (the 403 or 429 it got often makes it crash or time out). Leftovers rank
// last: an entry killed at the cap or crashed leaves its children behind by being killed, while an
// entry that exits 0 and leaves a daemon is what leftover_process is for.
//
// Abort (opts.signal): every program of the trial is killed at once, the trial torn down, and
// runScrapeTrial rejects with the signal's reason.
//
// Entry secrets (ScrapeTrialOptions.secrets: the entrant's env-lane ones, contracts/entry-secrets.ts,
// grader/worker.ts opens them; the heat hands each entry its own, the house's reference read none):
//   in        variables of the entry's own process, nobody else's: their NAMEs in launch.json
//             (launch.ts launchConfig's secret_names), their values on the launcher's stdin before
//             `ready` (LauncherSession), so no value is in any file of the house, the gateway's config
//             or a sandbox spec, on any driver. They are checked as a sandbox's are
//             (sandbox/types.ts checkSandboxSecrets: names the contract takes and the env lane's alone)
//   masked    every form of every value (grader/run.ts entrySecretForms; secret-mask.ts SECRET_MARK,
//             the same mark in every round) out of the record the gateway wrote, before any of it is
//             stored (gateway.ts maskScrapeRecording: the cassette, the scrape answer key, and its
//             bodies), out of both launcher tails (maskLaunchTail: a tail cut at its start keeps no end
//             of a value the cut split), and out of a void's message and a fault's detail (run.ts
//             redactSecrets, REDACTED_MARK)
//   scanned   /output is scored byte for byte, so it is scanned, never masked: every file the trial
//             stores, as it is stored, and every path, for the forms of each value by NAME (agent.ts
//             secretScanIndex). Where one turns up, the outcome's secret_hits names the secret and the
//             file (`output/<path>`, its path masked), never the value; grader/worker.ts flags the run
//             secret_in_output. A void that collected /output first (upstream_error) says so too

import { randomBytes, X509Certificate } from 'node:crypto';
import { chmod, lstat, mkdir, mkdtemp, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import type { Readable } from 'node:stream';
import type { z } from 'zod';
import { TRIAL_OUTPUTS_FORMAT, type TrialOutputsT } from '../../contracts/agent.ts';
import type { ScrapeHarnessT } from '../../contracts/competition.ts';
import {
  SCRAPE_HEAT_STAGES,
  ScrapeCassette,
  ScrapeEntryId,
  ScrapeHeatConfig,
  ScrapeHeatId,
  ScrapeNetwork,
  ScrapeResolution,
  ScrapeTrialRecord,
  type ScrapeCassetteT,
  type ScrapeNetworkT,
  type ScrapeTrialRecordT,
  type ScrapeTrialStatusT,
} from '../../contracts/scrape.ts';
import { compareCodeUnits, isCanonicalJson, sha256Hex } from '../../sim/canonical.ts';
import { GATEWAY_CONFIG_DIR_MODE, GATEWAY_CONFIG_FILE_MODES, LAUNCHER_SCRIPT, PRIVATE_DIR_MODE, launcherSource as serviceLauncherSource, secretScanIndex, type SecretOutputHit } from '../agent.ts';
import { findForms, FormSet, maskBytes, maskText, SECRET_MARK, TextMasker, type FormIndex } from '../gateway/secret-mask.ts';
import { holdScratch, removeScratch } from '../grade.ts';
import {
  collectOutputs,
  MAX_OUTPUT_BYTES,
  MAX_OUTPUT_DEPTH,
  MAX_OUTPUT_FILES,
  MAX_OUTPUT_PATH_BYTES,
  OUTPUT_WATCH_MS,
  outputCapBroken,
  walkOutputs,
  type OutputBlobs,
} from '../program.ts';
import { driverFailure, entrySecretForms, redactSecrets } from '../run.ts';
import { DockerSandbox } from '../sandbox/docker.ts';
import { describeExit } from '../sandbox/io.ts';
import { k8sTerminate, meterFailure, NodeRoomError } from '../sandbox/k8s.ts';
import {
  dockerExec,
  isolationCheck,
  SCRAPE_GATEWAY_PORT,
  scrapeAttachment,
  SERVICE_LIMITS,
  trialNetworkName,
  trialNetworksOf,
  TRIAL_OWNER_RE,
  type DockerExec,
  type IsolationCheck,
  type NetworkOptions,
  type ReapResult,
} from '../sandbox/network.ts';
import {
  checkSandboxSecrets,
  containerized,
  MOUNT_POINTS,
  SandboxError,
  type Runtime,
  type Sandbox,
  type SandboxExit,
  type SandboxLimits,
  type SandboxProcess,
  type SandboxSpec,
  type TreeMeter,
  type TrialNetworks,
} from '../sandbox/types.ts';
import { cassetteJson, maskScrapeRecording, parseScrapeGatewayConfig, SCRAPE_GATEWAY_CONFIG_FORMAT, type ScrapeCassette as GatewayCassette, type ScrapeGatewayConfig, type ScrapeRecordingMask } from './gateway.ts';
import { CA_FILE, LAUNCH_CONFIG, launchConfig, LAUNCHER_FILES, LauncherError, LauncherSession, PYTHON_LAUNCHER_SOURCE, SANDBOX_UID, writeHouse, type LaunchConfig, type LaunchResult } from './launch.ts';

// ---------------------------------------------------------------- constants

/** The containers' name stems (docker.ts containerName: makefun-<label>-<hex>). */
export const SCRAPE_TRIAL_LABELS = Object.freeze({ gateway: 'scrape-gateway', entry: 'scrape-entry' } as const);
/** A trial owner's stem: `scrape-<heat>.<entry>.<round>` (scrapeTrialOwner). */
export const SCRAPE_OWNER_PREFIX = 'scrape-';
/** How long the gateway has to write its ready file, and the launcher to say `ready`. */
export const SCRAPE_READY_MS = 30_000;
/** How long past cap_ms the launcher has for its result: its sweep, its pipes' close grace (launch.ts CLOSE_GRACE_MS), the line. */
export const SCRAPE_RESULT_SLACK_MS = 15_000;
/** How long the gateway has to exit after its SIGTERM (it writes the cassette and the bodies). */
export const SCRAPE_STOP_MS = 30_000;
/** How long the launcher's container has to exit after its result. */
export const SCRAPE_EXIT_MS = 10_000;
/** The port the gateway listens on in its container (the real hosts' HTTPS port; network.ts holds it, the k8s driver's entry dials it), and the port it dials upstream. */
export { SCRAPE_GATEWAY_PORT };
export const SCRAPE_UPSTREAM_PORT = 443;
/** The process driver's entry variable naming the gateway's 127.0.0.1:<port> (the header's process driver). */
export const SCRAPE_GATEWAY_ENV = 'MAKEFUN_SCRAPE_GATEWAY';
/** The house User-Agent every upstream request carries in place of the entry's (Roblox's Terms ask API users not to mask who they are). */
export const SCRAPE_USER_AGENT = 'makefun-scrape-gateway/1 (the make.fun scrape contest; +https://make.fun)';
/**
 * grader/scrape/gateway-main.ts's file names: CONFIG_FILE, READY_FILE, CASSETTE_FILE, BODIES_DIR and
 * ERROR_FILE there (a test holds them equal). Not imported: gateway-main.ts starts itself when it is
 * the file node runs, which inside the kit's one-file command line every module is.
 */
export const GATEWAY_FILES = Object.freeze({ config: 'gateway.json', ready: 'ready.json', cassette: 'cassette.json', bodies: 'bodies', error: 'error.json' } as const);
/** The largest cassette read back (MAX_ENTRIES entries are far below it). */
export const MAX_CASSETTE_BYTES = 64 * 1024 * 1024;
/** How long a launcher that broke its protocol has to exit, so a driver failure (125) is told from the launcher's own. */
const SETTLE_EXIT_MS = 2_000;
const POLL_MS = 50;
/** A program's stdout and stderr kept for a fault's message: the last this many bytes. */
const LOG_BYTES = 16 * 1024;

/** The faults the house sees, in the order they rank (the header's How a trial ends). */
export const SCRAPE_FAULT_ORDER = Object.freeze(['off_route', 'over_cap', 'invalid_output', 'timeout', 'crashed', 'leftover_process'] as const);
export type ScrapeFaultStatus = (typeof SCRAPE_FAULT_ORDER)[number];
/** Why a trial is void (the header). */
export const SCRAPE_VOID_REASONS = Object.freeze(['upstream_error', 'gateway', 'launcher', 'sandbox'] as const);
export type ScrapeVoidReason = (typeof SCRAPE_VOID_REASONS)[number];

/** Connections the gateway refused before TLS as no listed host's: off the routes. */
const ROUTE_CONNECTION_REFUSALS: ReadonlySet<string> = new Set(['not_tls', 'bad_client_hello', 'no_sni', 'unknown_sni']);
/** Connections refused or destroyed by a trial cap. */
const CAP_CONNECTION_REFUSALS: ReadonlySet<string> = new Set(['max_connections', 'max_bytes_up', 'max_bytes_down', 'max_entries']);

const EMPTY_OUTPUTS: TrialOutputsT = Object.freeze({ format: TRIAL_OUTPUTS_FORMAT, files: [] }) as TrialOutputsT;

// ---------------------------------------------------------------- types

type ScrapeHeatStageT = (typeof SCRAPE_HEAT_STAGES)[number];
type ScrapeResolutionT = z.infer<typeof ScrapeResolution>;

/** Which trial of the heat this is. */
export interface ScrapeTrialRef {
  /** The heat (contracts/scrape.ts ScrapeHeatId) and the entry (its submission id, ScrapeEntryId). */
  heat: string;
  entry: string;
  /** A warm-up trial runs like any other and is never listed. */
  stage: ScrapeHeatStageT;
  /** 0-based within its stage. */
  round: number;
  /** The entry's 0-based place in the round's order. */
  position: number;
}

/** What the heat holds for every trial (one CA and one host resolution per heat). */
export interface ScrapeTrialHeat {
  /** The heat CA's certificate, PEM (ca.ts HeatCa.cert): the house's ca.pem, what the entry trusts. Never its key. */
  caCert: string;
  /** One leaf per listed host (ca.ts hostLeaves): what the gateway answers that host's ClientHello with. */
  leaves: Readonly<Record<string, { readonly cert: string; readonly key: string }>>;
  /** Each listed host's addresses as the heat resolved them (ScrapeResolution), in order: the gateway dials only a host's last. */
  upstream: readonly ScrapeResolutionT[];
}

/** Where the trial's records go (server/blobstore.ts BlobStore fits). */
export type ScrapeTrialBlobs = Pick<OutputBlobs, 'put'>;

export interface ScrapeTrialOptions {
  sandbox: Sandbox;
  trial: ScrapeTrialRef;
  /** The snapshot mounted read-only at /bot, its runtime, and the image digest to run it in (default the pinned one). */
  entry: { dir: string; runtime: Runtime; imageDigest?: string | null };
  /** The bundle's harness: what the gateway lets through (network) and the per-trial cap (heat.cap_ms). */
  harness: Pick<ScrapeHarnessT, 'network' | 'heat'>;
  /** The competition's limits for the entry. */
  limits: SandboxLimits;
  heat: ScrapeTrialHeat;
  /** The gateway's bundle (grader/scrape/bundle.ts scrapeGatewayBundle): its directory and script. */
  gateway: { dir: string; script: string };
  /** The node22 house's launch.ts, as text (the header): launch.ts launcherSource() in the grader's tree, the kit's own copy in the kit. A python3.13 house takes launch.ts PYTHON_LAUNCHER_SOURCE. */
  launcherSource: string;
  /** A directory the trial may use: its scratch is made in it and deleted before runScrapeTrial settles. */
  workDir: string;
  blobs: ScrapeTrialBlobs;
  /** The docker CLI for the networks and the gateway's SIGTERM (default: the docker sandbox's own CLI). */
  docker?: NetworkOptions;
  /** Docker: the engine's isolation check (default the sandbox's own, isolationCheck of its Sandbox.networks: on a DockerSandbox this process's EngineIsolation of its engine; required for a sandbox with none). */
  isolation?: IsolationCheck;
  /** Told what the reap took (and could not), each time it ran. */
  onReap?: (reaped: ReapResult) => void;
  /** Aborting it kills every program of the trial, and runScrapeTrial rejects with its reason. */
  signal?: AbortSignal;
  /** The port the gateway dials upstream and the CA bundle it trusts there (default SCRAPE_UPSTREAM_PORT and Node's roots; a test's own). */
  upstreamPort?: number;
  upstreamCa?: string | null;
  /** The house User-Agent (default SCRAPE_USER_AGENT); it must name make.fun. */
  userAgent?: string;
  /** The process driver: the entry's interpreter (default this node). */
  interpreter?: string;
  /** Tests: the waits (defaults SCRAPE_READY_MS, SCRAPE_RESULT_SLACK_MS, SCRAPE_STOP_MS, SCRAPE_EXIT_MS). */
  timing?: { readyMs?: number; resultSlackMs?: number; stopMs?: number; exitMs?: number };
  /**
   * The entry's env-lane entry secrets, NAME to value (the header's entry secrets): its own process's variables, masked
   * out of what the trial stores and says, its /output scanned for them. Absent or empty: none, and the trial is what it
   * always was.
   */
  secrets?: Readonly<Record<string, string>>;
}

/** What the trial stored, by sha256. */
export interface ScrapeTrialBlobRefs {
  /** The cassette's bytes as the gateway wrote them: cassette_sha256. */
  cassette: string;
  /** Each decoded body the cassette names, sorted. */
  bodies: string[];
  /** Each output file (the outputs manifest's), sorted, once each. */
  outputs: string[];
  /** The launcher's tails of the entry's stdout and stderr; null when the entry was killed for its output (no result). */
  stdout_tail: string | null;
  stderr_tail: string | null;
}

/** A trial the heat lists: how it ran, and the fault the house saw (or none: the scorer decides). */
export interface ScrapeTrialRun {
  kind: 'run';
  trial: ScrapeTrialRef;
  owner: string;
  /** The house's verdict (the header), or null: it exited 0 within the cap breaking nothing, and the scorer says correct or incorrect. */
  fault: ScrapeFaultStatus | null;
  /** Why, with a fault. */
  detail: string | null;
  /** The launcher's clock from spawn to exit, ns (the host's from `go` to the kill for an entry killed for its output). */
  wall_ns: number;
  exit: number | null;
  signal: string | null;
  timed_out: boolean;
  /** Processes of the sandbox user it left, all killed; null without one (the process driver) or when it was killed for its output. */
  leftover: number | null;
  /** /output as program outputs (empty when it broke the caps). */
  outputs: TrialOutputsT;
  /** The trial's cassette, as the scorer reads it, and the sha256 of its stored bytes. */
  cassette: ScrapeCassetteT;
  cassette_sha256: string;
  blobs: ScrapeTrialBlobRefs;
  /**
   * With entry secrets (ScrapeTrialOptions.secrets), where its /output held a form of one (the header's entry secrets):
   * the secret's NAME and `output/<path>` (the path masked), in file order then name order, [] when nowhere. Absent
   * without secrets.
   */
  secret_hits?: SecretOutputHit[];
}

/** A trial that does not count: an infrastructure fault (the header). */
export interface ScrapeTrialVoid {
  kind: 'void';
  trial: ScrapeTrialRef;
  owner: string;
  reason: ScrapeVoidReason;
  message: string;
  /** The cassette, when the gateway wrote one (an upstream_error void's holds the upstream's rate-limit headers, which the heat paces by); else null. */
  cassette: ScrapeCassetteT | null;
  cassette_sha256: string | null;
  /** With entry secrets, as a run's (ScrapeTrialRun.secret_hits): what the /output it collected before it was void held ([] when it collected none). */
  secret_hits?: SecretOutputHit[];
}

export type ScrapeTrialOutcome = ScrapeTrialRun | ScrapeTrialVoid;

/** An infrastructure fault met on the way: the trial is void. */
class ScrapeVoid extends Error {
  readonly reason: ScrapeVoidReason;

  constructor(reason: ScrapeVoidReason, message: string) {
    super(message);
    this.name = 'ScrapeVoid';
    this.reason = reason;
  }
}

/** The entry's container was removed for its output: what its launcher's broken protocol then means. */
class KilledForOutput extends Error {}

/** Why waiting stopped: the trial was aborted. */
class TrialAborted extends Error {
  constructor() {
    super('the scrape trial was aborted');
    this.name = 'AbortError';
  }
}

// ---------------------------------------------------------------- pure parts

/**
 * The trial's owner `scrape-<heat>.<entry>.<round>` (network.ts TRIAL_OWNER_RE), its parts checked. The heat
 * records it as it is; it runs past a Kubernetes label value's 63 characters (a practice heat's reference read,
 * `scrape-practice-<31 hex>.house-reference.0`, is 65), so the k8s driver labels its objects by k8s.ts ownerLabel
 * of it (a hash of one that long) and keeps it whole in their makefun.io/trial-owner annotation.
 */
export function scrapeTrialOwner(t: Pick<ScrapeTrialRef, 'heat' | 'entry' | 'round'>): string {
  if (!ScrapeHeatId.safeParse(t.heat).success) throw new TypeError(`heat ${JSON.stringify(t.heat)} is not a heat id (1..40 of a-z 0-9 -)`);
  if (!ScrapeEntryId.safeParse(t.entry).success) throw new TypeError(`entry ${JSON.stringify(t.entry)} is not an entry id (1..40 of a-z 0-9 -)`);
  if (!Number.isSafeInteger(t.round) || t.round < 0) throw new TypeError(`round ${String(t.round)} is not a 0-based integer`);
  const owner = `${SCRAPE_OWNER_PREFIX}${t.heat}.${t.entry}.${t.round}`;
  if (!TRIAL_OWNER_RE.test(owner)) throw new TypeError(`trial owner ${JSON.stringify(owner)} is not a trial owner (network.ts TRIAL_OWNER_RE)`);
  return owner;
}

/**
 * The gateway's /config/gateway.json for a trial (gateway.ts ScrapeGatewayConfig, checked by its
 * parseScrapeGatewayConfig, which throws ScrapeGatewayConfigError): each listed host's leaf and its
 * last resolved addresses, the harness's routes, caps and upstream mode, the house User-Agent, and
 * listen port 443 in a container or 0 (any) on the host.
 */
export function scrapeGatewayConfig(
  o: { network: ScrapeNetworkT; heat: Pick<ScrapeTrialHeat, 'leaves' | 'upstream'>; kind: Sandbox['kind']; upstreamPort?: number; upstreamCa?: string | null; userAgent?: string },
  now: number = Date.now(),
): ScrapeGatewayConfig {
  const resolved = new Map<string, string[]>();
  for (const r of o.heat.upstream) resolved.set(r.host, [...r.ips]);
  const hosts: ScrapeGatewayConfig['hosts'] = {};
  for (const host of o.network.hosts) {
    const leaf = Object.hasOwn(o.heat.leaves, host) ? o.heat.leaves[host] : undefined;
    if (leaf === undefined) throw new TypeError(`the heat has no leaf for ${host}`);
    const ips = resolved.get(host);
    if (ips === undefined) throw new TypeError(`the heat resolved no address for ${host}`);
    hosts[host] = { ips, cert: leaf.cert, key: leaf.key };
  }
  return parseScrapeGatewayConfig(
    {
      format: SCRAPE_GATEWAY_CONFIG_FORMAT,
      hosts,
      routes: o.network.routes.map((r) => ({ id: r.id, host: r.host, method: r.method, path: r.path, query: { ...r.query } })),
      request_caps: { ...o.network.request_caps },
      max_connections: o.network.max_connections,
      max_concurrent: o.network.max_concurrent,
      max_bytes_down: o.network.max_bytes_down,
      max_bytes_up: o.network.max_bytes_up,
      upstream: o.network.upstream,
      upstream_port: o.upstreamPort ?? SCRAPE_UPSTREAM_PORT,
      upstream_ca: o.upstreamCa ?? null,
      user_agent: o.userAgent ?? SCRAPE_USER_AGENT,
      listen_port: containerized(o.kind) ? SCRAPE_GATEWAY_PORT : 0,
    },
    now,
  );
}

/** The upstream error that voids a trial (the header), as a line; null when none does. */
export function scrapeUpstreamVoid(cassette: Pick<ScrapeCassetteT, 'entries'>): string | null {
  const e = cassette.entries.find((x) => x.outcome === 'upstream_error' && x.reason !== 'unfinished');
  if (e === undefined) return null;
  return `request ${e.seq} (route ${e.route ?? 'none'}) met an upstream error: ${e.reason ?? 'no reason'}${e.status === null ? '' : `, status ${e.status}`}`;
}

/** What the launcher said of the entry's run. */
export interface ScrapeLaunchFacts {
  exit: number | null;
  signal: string | null;
  timed_out: boolean;
  leftover: number | null;
}

/** The fault the house saw (the header's order, after the voids), or null: the scorer decides. */
export function scrapeTrialFault(o: { launch: ScrapeLaunchFacts; violation: string | null; cassette: Pick<ScrapeCassetteT, 'entries' | 'connections'> }): { status: ScrapeFaultStatus; detail: string } | null {
  const request = (e: ScrapeCassetteT['entries'][number]): string => `request ${e.seq} (${e.method} ${e.authority ?? '(no authority)'}${e.path ?? ''})`;
  const connection = (c: ScrapeCassetteT['connections'][number]): string => `connection ${c.id} (SNI ${c.sni ?? 'none'})`;
  const route = o.cassette.entries.find((e) => e.outcome === 'refused_route');
  if (route !== undefined) return { status: 'off_route', detail: `${request(route)} is off the routes: ${route.reason ?? 'refused'}` };
  const unknown = o.cassette.connections.find((c) => c.refused !== null && ROUTE_CONNECTION_REFUSALS.has(c.refused));
  if (unknown !== undefined) return { status: 'off_route', detail: `${connection(unknown)} was refused as no listed host's: ${unknown.refused}` };
  const capped = o.cassette.entries.find((e) => e.outcome === 'refused_cap');
  if (capped !== undefined) return { status: 'over_cap', detail: `${request(capped)} was over a cap: ${capped.reason ?? 'refused'}` };
  const over = o.cassette.connections.find((c) => c.refused !== null && CAP_CONNECTION_REFUSALS.has(c.refused));
  if (over !== undefined) return { status: 'over_cap', detail: `${connection(over)} was refused at a cap: ${over.refused}` };
  if (o.violation !== null) return { status: 'invalid_output', detail: `output violation: ${o.violation}` };
  const l = o.launch;
  if (l.timed_out) return { status: 'timeout', detail: 'the launcher killed it at the cap' };
  if (l.exit !== 0) return { status: 'crashed', detail: l.exit === null ? `a signal ended it (${l.signal ?? 'none named'})` : `it exited with code ${l.exit}` };
  if (l.leftover !== null && l.leftover > 0) return { status: 'leftover_process', detail: `it left ${l.leftover} process${l.leftover === 1 ? '' : 'es'} behind (killed)` };
  return null;
}

/**
 * The trials manifest's record of a listed run (contracts/scrape.ts ScrapeTrialRecord): the fault as
 * its status, else the scorer's verdict (correct or incorrect); scores_sha256 the scorer's
 * scores.json, or null when it did not run on the trial. A warm-up trial is never listed (TypeError),
 * and a run with no fault needs the verdict.
 */
export function scrapeTrialRecord(run: ScrapeTrialRun, verdict: { correct: boolean; scores_sha256: string } | null): ScrapeTrialRecordT {
  const stage = run.trial.stage;
  if (stage !== 'main' && stage !== 'playoff') throw new TypeError(`a ${stage} trial is never listed`);
  if (run.fault === null && verdict === null) throw new TypeError("a trial with no fault takes the scorer's verdict: correct or incorrect");
  const status: ScrapeTrialStatusT = run.fault ?? (verdict!.correct ? 'correct' : 'incorrect');
  return ScrapeTrialRecord.parse({
    round: run.trial.round,
    stage,
    position: run.trial.position,
    status,
    wall_ns: run.wall_ns,
    exit: run.exit,
    outputs: run.outputs,
    cassette_sha256: run.cassette_sha256,
    scores_sha256: verdict?.scores_sha256 ?? null,
  });
}

// ---------------------------------------------------------------- the trial's programs

/** A program of the trial: its process, its exit once it has one, and the tail of what it printed on `streams`. */
class Program {
  readonly proc: SandboxProcess;
  readonly exited: Promise<SandboxExit>;
  exit: SandboxExit | null = null;
  #log: Buffer = Buffer.alloc(0);

  constructor(proc: SandboxProcess, streams: readonly Readable[]) {
    this.proc = proc;
    for (const s of streams) {
      s.on('data', (b: Buffer | string) => this.#keep(typeof b === 'string' ? Buffer.from(b) : b));
      s.on('error', () => undefined);
    }
    proc.stdin.on('error', () => undefined);
    this.exited = proc.exited.then((e) => {
      this.exit = e;
      return e;
    });
  }

  #keep(b: Buffer): void {
    const all = Buffer.concat([this.#log, b]);
    this.#log = all.length > LOG_BYTES ? Buffer.from(all.subarray(all.length - LOG_BYTES)) : all;
  }

  /** The last of what it printed, for a fault's message ('' when nothing). */
  logTail(): string {
    const text = this.#log.toString('utf8').trim();
    return text.length <= 500 ? text : `…${text.slice(-500)}`;
  }
}

function abortReasonOf(signal: AbortSignal): unknown {
  return signal.reason ?? new TrialAborted();
}

/** `p`'s value, or null when `ms` passes first. */
async function settleWithin<T>(p: Promise<T>, ms: number): Promise<T | null> {
  let timer: NodeJS.Timeout | undefined;
  try {
    return await Promise.race([p, new Promise<null>((resolve) => (timer = setTimeout(() => resolve(null), ms)))]);
  } finally {
    clearTimeout(timer);
  }
}

/** One trial's state: what it started, what it made, and what went wrong outside the step being waited on. */
class Pass {
  readonly sandbox: Sandbox;
  /** The docker CLI the gateway's SIGTERM goes through. */
  readonly net: NetworkOptions & { exec: DockerExec };
  /** The trial's networks (network.ts trialNetworksOf); null on the process driver. */
  readonly networks: TrialNetworks | null;
  readonly name: string;
  readonly procs = new Set<SandboxProcess>();
  readonly stop = new AbortController();
  /** The trial network was made and is not removed yet. */
  network = false;
  watch: { stop(): Promise<void> } | null = null;
  /** The cassette, once read (a void reports it too). */
  cassette: ScrapeCassetteT | null = null;
  cassetteSha: string | null = null;
  /** With entry secrets, what /output held once it was collected (a void reports it too). */
  secretHits: SecretOutputHit[] = [];
  readonly #trouble: Promise<never>;
  #fail: (err: unknown) => void = () => undefined;

  constructor(sandbox: Sandbox, net: NetworkOptions & { exec: DockerExec }, networks: TrialNetworks | null, name: string) {
    this.sandbox = sandbox;
    this.net = net;
    this.networks = networks;
    this.name = name;
    this.#trouble = new Promise<never>((_, reject) => {
      this.#fail = reject;
    });
    this.#trouble.catch(() => undefined);
  }

  /** Something went wrong outside the step being waited on (the gateway died, the meter failed): the first one is the trial's. */
  fail(err: unknown): void {
    this.#fail(err);
  }

  spawn(spec: SandboxSpec): SandboxProcess {
    const p = this.sandbox.spawn(spec);
    this.procs.add(p);
    void p.exited.then(() => this.procs.delete(p));
    return p;
  }

  /** `p`, or a rejection: the trial's trouble, the abort, or with `ms` the `late` error. */
  async wait<T>(p: Promise<T>, ms: number | null = null, late?: () => Error): Promise<T> {
    p.catch(() => undefined);
    const signal = this.stop.signal;
    if (signal.aborted) throw new TrialAborted();
    let timer: NodeJS.Timeout | undefined;
    let onAbort: (() => void) | undefined;
    const racers: Promise<T>[] = [p, this.#trouble];
    racers.push(
      new Promise<never>((_, reject) => {
        onAbort = () => reject(new TrialAborted());
        signal.addEventListener('abort', onAbort, { once: true });
      }),
    );
    if (ms !== null) racers.push(new Promise<never>((_, reject) => (timer = setTimeout(() => reject(late!()), ms))));
    try {
      return await Promise.race(racers);
    } finally {
      clearTimeout(timer);
      if (onAbort !== undefined) signal.removeEventListener('abort', onAbort);
    }
  }

  /** Stop at once: every wait rejects, every program is killed. */
  abort(): void {
    this.stop.abort();
    for (const p of this.procs) void p.kill().catch(() => undefined);
  }

  /** The header's step 8, but the scratch (runScrapeTrial's). Never throws. */
  async teardown(): Promise<void> {
    this.stop.abort();
    await this.watch?.stop().catch(() => undefined);
    this.watch = null;
    await Promise.all([...this.procs].map((p) => p.kill().catch(() => undefined)));
    if (this.network && this.networks !== null) {
      await this.networks.remove(this.name).catch(() => undefined);
      this.network = false;
    }
  }
}

function checkOptions(o: ScrapeTrialOptions): { network: ScrapeNetworkT; capMs: number } {
  const t = o.trial;
  scrapeTrialOwner(t);
  if (!(SCRAPE_HEAT_STAGES as readonly string[]).includes(t.stage)) throw new TypeError(`stage ${JSON.stringify(t.stage)} is not one of ${SCRAPE_HEAT_STAGES.join(', ')}`);
  if (!Number.isSafeInteger(t.position) || t.position < 0) throw new TypeError(`position ${String(t.position)} is not a 0-based integer`);
  const network = ScrapeNetwork.parse(o.harness.network);
  const capMs = ScrapeHeatConfig.parse(o.harness.heat).cap_ms;
  if (o.entry.runtime === 'node22' && (typeof o.launcherSource !== 'string' || o.launcherSource.length === 0)) throw new TypeError('a node22 house needs the launcher source (launch.ts launcherSource, or the kit\'s copy)');
  // The process driver's house runs its launch.ts as the program, on this node: a python3.13 entry runs only inside Docker.
  if (o.sandbox.kind === 'process' && o.entry.runtime !== 'node22') throw new TypeError(`the process driver runs node22 entries only (${o.entry.runtime} runs only inside Docker)`);
  for (const r of o.heat.upstream) {
    const checked = ScrapeResolution.safeParse(r);
    if (!checked.success) throw new TypeError(`the heat's resolution ${JSON.stringify(r).slice(0, 200)} is not one: ${checked.error.issues[0]!.message}`);
  }
  // Checked as a sandbox's secrets are (the header's entry secrets); its words name a secret, never quote a value.
  try {
    checkSandboxSecrets({ secrets: o.secrets });
  } catch (err) {
    throw new TypeError(`the entry's secrets: ${(err as Error).message}`);
  }
  return { network, capMs };
}

// ---------------------------------------------------------------- entry secrets

/** A trial's entry secrets, compiled once (the header's entry secrets): their values for the launcher, every form to mask, and the scan by NAME. */
interface TrialSecrets {
  values: Readonly<Record<string, string>>;
  forms: FormSet;
  scan: FormIndex;
  mask: ScrapeRecordingMask;
}

function trialSecretsOf(secrets: Readonly<Record<string, string>> | undefined): TrialSecrets | null {
  const forms = entrySecretForms(secrets);
  if (forms === null || secrets === undefined) return null;
  return { values: secrets, forms, scan: secretScanIndex(secrets), mask: { text: (s) => maskText(s, forms), body: (b) => maskBytes(b, forms) } };
}

/** Each form set's forms with their UTF-8 bytes reversed, one byte a code unit (latin1): a matcher over a tail read backwards. */
const reversedForms = new WeakMap<FormSet, FormSet>();

function reversedFormsOf(forms: FormSet): FormSet {
  let r = reversedForms.get(forms);
  if (r === undefined) {
    r = new FormSet(forms.forms.map((f) => Buffer.from(f, 'utf8').reverse().toString('latin1')));
    reversedForms.set(forms, r);
  }
  return r;
}

/**
 * How many of `tail`'s first bytes could be the end of a form a cut at its start split: the longest prefix of `tail` that
 * is a proper suffix of one of `forms`, in bytes (0: none). Read backwards, that prefix is the live suffix a streaming
 * masker holds back at the end, waiting for the rest of a form (secret-mask.ts TextMasker.held).
 */
export function formEndAtStart(tail: Uint8Array, forms: FormSet): number {
  if (forms.forms.length === 0 || tail.length === 0) return 0;
  const reversed = reversedFormsOf(forms);
  const span = Math.min(tail.length, reversed.maxChars - 1);
  if (span <= 0) return 0;
  const masker = new TextMasker(reversed);
  masker.push(Buffer.from(tail.subarray(0, span)).reverse().toString('latin1'));
  return masker.held;
}

/**
 * One of the launcher's tails of the entry's stdout or stderr (its stream's last `tailBytes`) as it may be stored, every
 * form of `forms` masked (SECRET_MARK). A tail as long as tailBytes may be a stream cut at its start, which would keep the
 * end of a value the cut split, and no whole form matches an end: its first bytes that could be one (formEndAtStart) go,
 * one SECRET_MARK in their place. A tail's end is its stream's own, never cut. `forms` null: the tail as it is.
 */
export function maskLaunchTail(tail: Buffer, forms: FormSet | null, tailBytes: number): Buffer {
  if (forms === null || tail.length === 0) return tail;
  const lead = tail.length >= tailBytes ? formEndAtStart(tail, forms) : 0;
  const masked = maskBytes(tail.subarray(lead), forms);
  return lead === 0 ? masked : Buffer.concat([Buffer.from(SECRET_MARK, 'utf8'), masked]);
}

/** `blobs`, every file it stores scanned as it is stored for the forms of the secrets by NAME (`found`: its sha256 to the NAMEs). */
function scanningBlobs(blobs: ScrapeTrialBlobs, scan: FormIndex, found: Map<string, ReadonlySet<string>>): ScrapeTrialBlobs {
  return {
    async put(data) {
      const put = await blobs.put(data);
      if (!found.has(put.sha256)) found.set(put.sha256, new Set(findForms(data, scan, { limit: 1 }).map((h) => h.name)));
      return put;
    },
  };
}

/** Where /output held a form of a secret (the header's entry secrets): a file's bytes (`found`) or its path, as `output/<path>` with the path masked; file order, then name order. */
function outputSecretHits(outputs: TrialOutputsT, found: ReadonlyMap<string, ReadonlySet<string>>, s: TrialSecrets): SecretOutputHit[] {
  const hits: SecretOutputHit[] = [];
  for (const f of outputs.files) {
    const names = new Set(found.get(f.sha256) ?? []);
    for (const h of findForms(f.path, s.scan, { limit: 1 })) names.add(h.name);
    const file = `output/${maskText(f.path, s.forms)}`;
    for (const name of [...names].sort(compareCodeUnits)) hits.push({ name, file });
  }
  return hits;
}

/** The heat CA's certificate for the house: one PEM certificate of a CA, nothing else (no key). */
function checkCaCert(pem: string): string {
  const blocks = typeof pem === 'string' ? (pem.match(/-----BEGIN CERTIFICATE-----\r?\n[A-Za-z0-9+/=\r\n]+-----END CERTIFICATE-----/g) ?? []) : [];
  if (blocks.length !== 1 || pem.replace(blocks[0]!, '').trim() !== '') throw new TypeError("the heat CA's certificate is one PEM certificate and nothing else");
  let cert: X509Certificate;
  try {
    cert = new X509Certificate(blocks[0]!);
  } catch {
    throw new TypeError("the heat CA's certificate does not parse");
  }
  if (!cert.ca) throw new TypeError("the heat CA's certificate is not a CA's");
  return pem.endsWith('\n') ? pem : `${pem}\n`;
}

/** The house's files (launch.ts houseFor's three), the node22 launcher from the caller's text (the header). */
function houseFiles(runtime: Runtime, config: LaunchConfig, launcher: string, caCert: string): Record<string, string> {
  return {
    [LAUNCHER_FILES[runtime]]: runtime === 'node22' ? launcher : PYTHON_LAUNCHER_SOURCE,
    [LAUNCH_CONFIG]: `${JSON.stringify(config, null, 2)}\n`,
    [CA_FILE]: checkCaCert(caCert),
  };
}

/**
 * Write the gateway's config as <parent>/config/gateway.json and return that directory: `parent`
 * 0700, the directory 0711, the file 0444 in a container (the gateway runs as 65534) or 0400 on the
 * host, as agent.ts writes its forwarder's (gateway-main.ts refuses one group or others may write).
 */
async function writeGatewayConfig(parent: string, config: ScrapeGatewayConfig, kind: Sandbox['kind']): Promise<string> {
  await mkdir(parent, { recursive: true, mode: PRIVATE_DIR_MODE });
  await chmod(parent, PRIVATE_DIR_MODE);
  const dir = join(parent, 'config');
  await mkdir(dir, { mode: GATEWAY_CONFIG_DIR_MODE });
  await chmod(dir, GATEWAY_CONFIG_DIR_MODE);
  const file = join(dir, GATEWAY_FILES.config);
  await writeFile(file, `${JSON.stringify(config)}\n`, { flag: 'wx', mode: 0o600 });
  await chmod(file, GATEWAY_CONFIG_FILE_MODES[kind]);
  return dir;
}

/** The process driver's gateway: agent.ts's service launcher around the bundle's script, in its own directory. */
async function writeServiceLauncher(dir: string, target: string): Promise<{ codeDir: string; script: string }> {
  await mkdir(dir, { recursive: true, mode: 0o700 });
  await writeFile(join(dir, LAUNCHER_SCRIPT), serviceLauncherSource(target), { mode: 0o444 });
  return { codeDir: dir, script: LAUNCHER_SCRIPT };
}

/** A JSON file a program wrote whole: its value, null when it is not there, or `{unparsable}`. */
async function readJson(file: string): Promise<unknown> {
  let text: string;
  try {
    text = await readFile(file, 'utf8');
  } catch (err) {
    if ((err as NodeJS.ErrnoException).code === 'ENOENT') return null;
    throw err;
  }
  try {
    return JSON.parse(text) as unknown;
  } catch {
    return { unparsable: text.slice(0, 200) };
  }
}

/** What the gateway said went wrong (/record/error.json), as `: <message>`, or ''. */
async function gatewaySaid(recordDir: string, gw: Program): Promise<string> {
  const doc = await readJson(join(recordDir, GATEWAY_FILES.error)).catch(() => null);
  const error = doc !== null && typeof doc === 'object' && typeof (doc as { error?: unknown }).error === 'string' ? (doc as { error: string }).error : null;
  const said = [error, gw.logTail()].filter((s) => s !== null && s !== '').join('; ');
  return said === '' ? '' : `: ${said}`;
}

/** The gateway's death as the trial's fault: the sandbox's when the driver failed to run it, else the gateway's own, with what it said. */
async function gatewayDeath(sandbox: Sandbox, recordDir: string, gw: Program, exit: SandboxExit, when: string): Promise<Error> {
  const said = await gatewaySaid(recordDir, gw);
  return sandbox.isDriverFailure(exit) ? driverFailure(gw.proc, `the sandbox failed running the gateway (${describeExit(exit)})${said}`) : new ScrapeVoid('gateway', `the gateway exited ${when} (${describeExit(exit)})${said}`);
}

/** The gateway's ready file's port, polled until it is there, the gateway exits, or `ms` pass. */
async function gatewayReady(sandbox: Sandbox, recordDir: string, gw: Program, ms: number, signal: AbortSignal): Promise<number> {
  const deadline = performance.now() + ms;
  for (;;) {
    const doc = await readJson(join(recordDir, GATEWAY_FILES.ready));
    if (doc !== null) {
      const port = (doc as { port?: unknown }).port;
      if (typeof port !== 'number' || !Number.isSafeInteger(port) || port < 1 || port > 65_535) throw new ScrapeVoid('gateway', `the gateway's ready file names no port: ${JSON.stringify(doc).slice(0, 200)}`);
      return port;
    }
    if (gw.exit !== null) throw await gatewayDeath(sandbox, recordDir, gw, gw.exit, 'before it was ready');
    if (performance.now() > deadline) throw new ScrapeVoid('gateway', `the gateway was not ready within ${ms} ms${await gatewaySaid(recordDir, gw)}`);
    if (signal.aborted) throw new TrialAborted();
    await new Promise((r) => setTimeout(r, POLL_MS));
  }
}

/** SIGTERM to the gateway in its container: `docker kill --signal TERM` on the one container of its label on the trial's network. */
async function dockerTerm(exec: DockerExec, network: string, label: string): Promise<void> {
  const ps = await exec(['ps', '--no-trunc', '--filter', `network=${network}`, '--format', '{{.ID}} {{.Names}}']);
  if (ps.code !== 0) throw new SandboxError(`docker could not list the containers on ${network}: ${(ps.error ?? ps.stderr).trim().split('\n')[0] ?? ''}`);
  const name = new RegExp(`^makefun-${label}-[0-9a-f]{12}$`);
  const ids = ps.stdout
    .split('\n')
    .map((l) => l.trim().split(' '))
    .filter((p) => p.length === 2 && name.test(p[1]!))
    .map((p) => p[0]!);
  // A container that went meanwhile refuses the kill; its exit is the check.
  if (ids.length > 0) await exec(['kill', '--signal', 'TERM', ...ids]);
}

/** Store bytes and check the store named them by their sha256. */
async function putChecked(blobs: ScrapeTrialBlobs, bytes: Uint8Array): Promise<string> {
  const sha256 = sha256Hex(bytes);
  const put = await blobs.put(bytes);
  if (put.sha256 !== sha256) throw new Error(`the blob store named bytes of sha256 ${sha256} ${put.sha256}`);
  return sha256;
}

/**
 * The gateway's record (the header's step 7), checked as the gateway wrote it, masked of the entry's secrets with `mask`
 * (gateway.ts maskScrapeRecording; the header's entry secrets) when there are any, and stored: the cassette, its stored
 * sha256, and its bodies'. Nothing of the record is stored unmasked.
 */
async function storeRecording(recordDir: string, blobs: ScrapeTrialBlobs, mask: ScrapeRecordingMask | null): Promise<{ cassette: ScrapeCassetteT; sha256: string; bodies: string[] }> {
  const file = join(recordDir, GATEWAY_FILES.cassette);
  const st = await lstat(file).catch((err: NodeJS.ErrnoException) => {
    if (err.code === 'ENOENT') return null;
    throw err;
  });
  if (st === null) throw new ScrapeVoid('gateway', 'the gateway wrote no cassette');
  if (!st.isFile() || st.size > MAX_CASSETTE_BYTES) throw new ScrapeVoid('gateway', `the gateway's cassette is not a regular file of at most ${MAX_CASSETTE_BYTES} bytes`);
  const bytes = await readFile(file);
  const text = bytes.toString('utf8');
  if (!isCanonicalJson(text)) throw new ScrapeVoid('gateway', "the gateway's cassette is not canonical JSON");
  const parsed = ScrapeCassette.safeParse(JSON.parse(text));
  if (!parsed.success) {
    const issue = parsed.error.issues[0]!;
    throw new ScrapeVoid('gateway', `the gateway's cassette is not a scrape cassette: ${issue.path.join('.') || '(root)'}: ${issue.message}`);
  }
  let cassette = parsed.data;
  const sizes = new Map<string, number>();
  for (const e of cassette.entries) {
    if (e.body_sha256 === null) continue;
    const size = sizes.get(e.body_sha256);
    if (size !== undefined && size !== e.body_bytes) throw new ScrapeVoid('gateway', `the cassette names body ${e.body_sha256} with two sizes`);
    sizes.set(e.body_sha256, e.body_bytes!);
  }
  let bodies = new Map<string, Buffer>();
  for (const [sha256, size] of [...sizes].sort(([a], [b]) => compareCodeUnits(a, b))) {
    const at = join(recordDir, GATEWAY_FILES.bodies, sha256);
    const body = await lstat(at).then(
      (s) => (s.isFile() ? readFile(at) : null),
      () => null,
    );
    if (body === null) throw new ScrapeVoid('gateway', `the gateway wrote no body ${sha256}, which its cassette names`);
    if (body.length !== size || sha256Hex(body) !== sha256) throw new ScrapeVoid('gateway', `the gateway's body ${sha256} is not the one its cassette names (${body.length} bytes, ${size} named)`);
    bodies.set(sha256, body);
  }
  let stored: Buffer = bytes;
  if (mask !== null) {
    // Checked above as a ScrapeCassette, so it is the gateway's own shape.
    const masked = maskScrapeRecording({ cassette: JSON.parse(text) as GatewayCassette, bodies }, mask);
    const maskedText = cassetteJson(masked.cassette);
    // A body masked is named again, so a record whose text is unchanged has every body unchanged too.
    if (maskedText !== text) {
      const again = ScrapeCassette.safeParse(JSON.parse(maskedText));
      if (!again.success) {
        const issue = again.error.issues[0]!;
        throw new Error(`the cassette masked of the entry's secrets is no scrape cassette: ${issue.path.join('.') || '(root)'}: ${issue.message}`);
      }
      cassette = again.data;
      stored = Buffer.from(maskedText, 'utf8');
      bodies = masked.bodies;
    }
  }
  const named: string[] = [];
  for (const [, body] of [...bodies].sort(([a], [b]) => compareCodeUnits(a, b))) named.push(await putChecked(blobs, body));
  return { cassette, sha256: await putChecked(blobs, stored), bodies: named };
}

/**
 * Hold /output to program.ts's output caps while the entry runs (the header's step 6): its walkOutputs
 * watch and, where the sandbox has one, its meter read by outputCapBroken. onBreak takes the first cap
 * broken, onFault a meter that failed (with the scheduler's words when the node had no room for its pod:
 * TreeMeterOptions.onFault); neither is called once stop() is.
 */
function watchOutputs(
  o: { sandbox: Sandbox; outputDir: string; runtime: Runtime; imageDigest: string | null; budgetMs: number },
  onBreak: (message: string) => void,
  onFault: (message: string, noRoom: string | null) => void,
): { stop(): Promise<void> } {
  let stopped = false;
  let walking = false;
  let broke = false;
  const broken = (message: string): void => {
    if (stopped || broke) return;
    broke = true;
    onBreak(message);
  };
  const timer = setInterval(() => {
    if (stopped || walking || broke) return;
    walking = true;
    void walkOutputs(o.outputDir, true)
      .then((w) => {
        if ('violation' in w) broken(w.violation);
      })
      .catch(() => undefined)
      .finally(() => {
        walking = false;
      });
  }, OUTPUT_WATCH_MS);
  let meter: TreeMeter | null = null;
  try {
    meter =
      o.sandbox.meterTree?.(o.outputDir, {
        runtime: o.runtime,
        imageDigest: o.imageDigest,
        label: SCRAPE_TRIAL_LABELS.entry,
        budgetMs: o.budgetMs,
        intervalMs: OUTPUT_WATCH_MS,
        maxEntries: MAX_OUTPUT_FILES,
        maxBytes: MAX_OUTPUT_BYTES,
        maxDepth: MAX_OUTPUT_DEPTH,
        maxPathBytes: MAX_OUTPUT_PATH_BYTES,
        onUsage: (u) => {
          const why = outputCapBroken(u);
          if (why !== null) broken(why);
        },
        onFault: (why, noRoom) => {
          if (!stopped) onFault(why, noRoom ?? null);
        },
      }) ?? null;
  } catch (err) {
    clearInterval(timer);
    throw err;
  }
  let stopping: Promise<void> | null = null;
  return {
    stop() {
      stopped = true;
      clearInterval(timer);
      stopping ??= meter === null ? Promise.resolve() : meter.stop();
      return stopping;
    },
  };
}

// ---------------------------------------------------------------- the trial

/**
 * Run one scrape trial (see the header). An infrastructure fault is a `void` outcome, never thrown, but for a node with
 * no room for one of its pods (a NodeRoomError, thrown as it is: the header's `void sandbox`); a
 * malformed option is a TypeError (or the gateway config's ScrapeGatewayConfigError), an engine that
 * does not keep trials apart rejects with network.ts IsolationRefusal, an abort with the signal's
 * reason, and anything else thrown is this process's own fault (its blob store, a bug).
 */
export async function runScrapeTrial(opts: ScrapeTrialOptions): Promise<ScrapeTrialOutcome> {
  const { network, capMs } = checkOptions(opts);
  const secrets = trialSecretsOf(opts.secrets);
  const owner = scrapeTrialOwner(opts.trial);
  const isolation = isolationOf(opts);
  const external = opts.signal;
  if (external?.aborted) throw abortReasonOf(external);
  const exec = opts.docker?.exec ?? dockerExec(opts.docker?.docker ?? (opts.sandbox instanceof DockerSandbox ? opts.sandbox.docker : 'docker'));
  const pass = new Pass(opts.sandbox, { exec }, trialNetworksOf(opts.sandbox, exec, opts.docker !== undefined), `scrape-${randomBytes(6).toString('hex')}`);
  const onAbort = (): void => pass.abort();
  external?.addEventListener('abort', onAbort, { once: true });
  let scratch: string | null = null;
  try {
    scratch = await mkdtemp(join(opts.workDir, 'scrape-trial-'));
    // Held (../grade.ts holdScratch, its header's Releasing): its removal below, once the pass is torn down, releases it
    // in one go, unless its caller holds a root above it (a heat's, a CLI's), whose own release takes it.
    holdScratch(scratch);
    return await runPass(opts, pass, { scratch, owner, network, capMs, isolation, secrets });
  } catch (err) {
    if (external?.aborted) throw abortReasonOf(external);
    // The node had no room for a pod of the trial's (a preflight's, the gateway's or the entry's: run.ts driverFailure),
    // so nothing of it ran: backpressure, not the trial's fault. Thrown, so its heat's job is handed back for later
    // (server/jobs.ts `node room`) instead of voiding trial after trial on a full node.
    if (err instanceof NodeRoomError) throw err;
    const reason: ScrapeVoidReason | null = err instanceof ScrapeVoid ? err.reason : err instanceof LauncherError ? 'launcher' : err instanceof SandboxError ? 'sandbox' : null;
    if (reason === null) throw err;
    const said = err instanceof ScrapeVoid ? err.message : `${(err as Error).name}: ${(err as Error).message}`;
    // What a program printed may hold a value (a launcher's or a gateway's log tail): redacted (the header's entry secrets).
    const message = secrets === null ? said : redactSecrets(said, secrets.forms);
    return { kind: 'void', trial: { ...opts.trial }, owner, reason, message, cassette: pass.cassette, cassette_sha256: pass.cassetteSha, ...(secrets === null ? {} : { secret_hits: pass.secretHits }) };
  } finally {
    external?.removeEventListener('abort', onAbort);
    await pass.teardown();
    if (scratch !== null) await removeScratch(opts.sandbox, scratch);
  }
}

/** The engine check a docker trial requires (the header's step 2); null on the process driver, which makes no network. */
function isolationOf(o: ScrapeTrialOptions): IsolationCheck | null {
  if (!containerized(o.sandbox.kind)) return null;
  if (o.isolation !== undefined && o.isolation !== null) return o.isolation;
  if (o.sandbox.networks !== undefined) return isolationCheck(o.sandbox.networks);
  throw new TypeError("a docker scrape trial requires its engine's isolation: pass `isolation` (grader/sandbox/network.ts EngineIsolation)");
}

interface PassPlan {
  scratch: string;
  owner: string;
  network: ScrapeNetworkT;
  capMs: number;
  isolation: IsolationCheck | null;
  /** The entry's secrets, compiled (trialSecretsOf); null with none. */
  secrets: TrialSecrets | null;
}

async function runPass(o: ScrapeTrialOptions, p: Pass, plan: PassPlan): Promise<ScrapeTrialRun> {
  const { sandbox } = o;
  const { scratch, owner, network, capMs, secrets } = plan;
  const kind = sandbox.kind;
  const onHost = kind === 'process';
  const readyMs = o.timing?.readyMs ?? SCRAPE_READY_MS;
  const resultSlackMs = o.timing?.resultSlackMs ?? SCRAPE_RESULT_SLACK_MS;
  const stopMs = o.timing?.stopMs ?? SCRAPE_STOP_MS;
  const exitMs = o.timing?.exitMs ?? SCRAPE_EXIT_MS;
  const imageDigest = o.entry.imageDigest ?? null;

  await p.wait(sandbox.preflight('node22'));
  await p.wait(sandbox.preflight(o.entry.runtime, imageDigest));

  // The scratch: /record and /output writable for the sandbox user, the house, the gateway's config.
  const recordDir = join(scratch, 'record');
  const outputDir = join(scratch, 'output');
  const houseDir = join(scratch, 'house');
  for (const d of [recordDir, outputDir]) {
    await mkdir(d, { mode: 0o700 });
    await chmod(d, 0o777);
  }
  await mkdir(houseDir, { mode: 0o755 });
  const configDir = await writeGatewayConfig(join(scratch, 'private'), scrapeGatewayConfig({ network, heat: o.heat, kind, upstreamPort: o.upstreamPort, upstreamCa: o.upstreamCa, userAgent: o.userAgent }), kind);

  // Steps 1 and 2: what a dead grader left of this trial, the engine's isolation, the networks.
  if (p.networks !== null) {
    const reaped = await p.wait(p.networks.reap(owner));
    o.onReap?.(reaped);
    await p.wait(plan.isolation!.require());
    await p.wait(p.networks.create(p.name, { owner }));
    p.network = true;
    await p.wait(p.networks.ensureEgress());
  }
  const trialNetwork = trialNetworkName(p.name);

  // Step 3: the gateway.
  const gwCode = onHost ? await writeServiceLauncher(join(scratch, 'launch'), join(o.gateway.dir, o.gateway.script)) : { codeDir: o.gateway.dir, script: o.gateway.script };
  const gwProc = p.spawn({
    runtime: 'node22',
    ...gwCode,
    mounts: [
      { host: configDir, at: '/config', readOnly: true },
      { host: recordDir, at: '/record', readOnly: false },
    ],
    limits: SERVICE_LIMITS,
    label: SCRAPE_TRIAL_LABELS.gateway,
    network: scrapeAttachment(p.name, 'gateway', network.hosts),
    ...(onHost ? { env: { MAKEFUN_GATEWAY_HOST: '127.0.0.1' } } : {}),
  });
  const gw = new Program(gwProc, [gwProc.stdout, gwProc.stderr]);
  let gatewayStopping = false;
  let gatewayReadyYet = false;
  void gw.exited.then(async (exit) => {
    if (!gatewayStopping) p.fail(await gatewayDeath(sandbox, recordDir, gw, exit, gatewayReadyYet ? 'while the trial ran' : 'before it was ready'));
  });
  const port = await p.wait(gatewayReady(sandbox, recordDir, gw, readyMs, p.stop.signal));
  gatewayReadyYet = true;

  // Step 4: the house and the entry under its launcher: the secrets' NAMEs in launch.json, their values for its stdin alone.
  const config = launchConfig(o.entry.runtime, {
    capMs,
    user: onHost ? null : SANDBOX_UID,
    ...(onHost
      ? {
          codeDir: o.entry.dir,
          houseDir,
          interpreter: o.interpreter ?? process.execPath,
          env: { [MOUNT_POINTS['/output']]: outputDir, [SCRAPE_GATEWAY_ENV]: `127.0.0.1:${port}` },
        }
      : {}),
    ...(secrets === null ? {} : { secrets: secrets.values }),
  });
  writeHouse(houseDir, { files: houseFiles(o.entry.runtime, config, o.launcherSource, o.heat.caCert) });
  const outputMount = { host: outputDir, at: '/output' as const, readOnly: false };
  const entryLimits: SandboxLimits = { cpus: o.limits.cpus, memory_mb: o.limits.memory_mb, pids: o.limits.pids };
  const entrySpec: SandboxSpec = onHost
    ? { runtime: o.entry.runtime, codeDir: houseDir, script: LAUNCHER_FILES.node22, mounts: [outputMount], limits: entryLimits, label: SCRAPE_TRIAL_LABELS.entry, network: scrapeAttachment(p.name, 'entry', network.hosts) }
    : {
        runtime: o.entry.runtime,
        codeDir: o.entry.dir,
        mounts: [outputMount],
        limits: entryLimits,
        label: SCRAPE_TRIAL_LABELS.entry,
        imageDigest,
        network: scrapeAttachment(p.name, 'entry', network.hosts),
        launcher: { houseDir },
      };
  const entryProc = p.spawn(entrySpec);
  const entry = new Program(entryProc, [entryProc.stderr]);
  const session = new LauncherSession({ stdin: entryProc.stdin, stdout: entryProc.stdout }, { secrets: secrets?.values ?? null });
  let stdoutEnded = false;
  for (const ev of ['end', 'close'] as const) entryProc.stdout.once(ev, () => (stdoutEnded = true));

  // Step 6's watch, from the start: a cap broken on docker removes the entry's container at once.
  const broke: { message: string | null; at: bigint | null } = { message: null, at: null };
  const watch = watchOutputs(
    { sandbox, outputDir, runtime: o.entry.runtime, imageDigest, budgetMs: readyMs + capMs + resultSlackMs },
    (message) => {
      broke.message = message;
      broke.at = process.hrtime.bigint();
      if (!onHost) void entryProc.kill().catch(() => undefined);
    },
    // A meter pod the node had no room for is a NodeRoomError (k8s.ts meterFailure), thrown as runScrapeTrial throws one.
    (why, noRoom) => p.fail(meterFailure(`the sandbox could not meter /output: ${why}`, noRoom)),
  );
  p.watch = watch;

  /**
   * A launcher step, its LauncherError told apart: the entry's container removed for its output (on
   * `go` only: before it nothing of the entry's ran), the driver's failure, or the launcher's own. A
   * launcher whose stdout closed is going: its exit, which comes at once, says whose failure it was;
   * one that printed what is not its protocol is still running, and is the launcher's.
   */
  const launcherStep = async <T>(step: Promise<T>, killable: boolean): Promise<T> => {
    try {
      return await step;
    } catch (err) {
      if (!(err instanceof LauncherError)) throw err;
      if (killable && broke.message !== null && !onHost) throw new KilledForOutput();
      const exit = stdoutEnded ? await settleWithin(entry.exited, SETTLE_EXIT_MS) : entry.exit;
      const tail = entry.logTail();
      if (exit !== null && sandbox.isDriverFailure(exit)) throw driverFailure(entryProc, `the sandbox failed running the launcher (${describeExit(exit)})${tail === '' ? '' : `: ${tail}`}`);
      throw new ScrapeVoid('launcher', `${err.message}${exit === null ? '' : ` (${describeExit(exit)})`}${tail === '' ? '' : `: ${tail}`}`);
    }
  };
  await p.wait(launcherStep(session.ready(), false), readyMs, () => new ScrapeVoid('launcher', `the launcher did not say ready within ${readyMs} ms`));

  // Step 5: go, and the result.
  const goAt = process.hrtime.bigint();
  let result: LaunchResult;
  let killed = false;
  try {
    result = await p.wait(launcherStep(session.go(), true), capMs + resultSlackMs, () => new ScrapeVoid('launcher', `the launcher gave no result within ${capMs + resultSlackMs} ms of go`));
  } catch (err) {
    if (!(err instanceof KilledForOutput)) throw err;
    killed = true;
    result = { wallNs: (broke.at ?? process.hrtime.bigint()) - goAt, exit: null, signal: 'SIGKILL', timedOut: false, leftover: null, stdoutTail: Buffer.alloc(0), stderrTail: Buffer.alloc(0) };
  }
  if (!entryProc.stdin.destroyed && !entryProc.stdin.writableEnded) entryProc.stdin.end();
  if (killed) {
    await p.wait(entryProc.kill());
  } else {
    const exit = await p.wait(settleWithin(entry.exited, exitMs));
    if (exit === null) {
      await p.wait(entryProc.kill());
      throw new ScrapeVoid('launcher', `the launcher's container did not exit within ${exitMs} ms of its result`);
    }
    if (sandbox.isDriverFailure(exit)) throw driverFailure(entryProc, `the sandbox failed running the launcher (${describeExit(exit)})`);
    if (exit.code !== 0) throw new ScrapeVoid('launcher', `the launcher exited with ${describeExit(exit)} after its result`);
  }
  await watch.stop();
  p.watch = null;
  const wallNs = Number(result.wallNs);
  if (!Number.isSafeInteger(wallNs)) throw new ScrapeVoid('launcher', `the launcher's wall_ns ${result.wallNs} is past a safe integer`);

  // Step 7: the gateway's SIGTERM, and its record.
  gatewayStopping = true;
  if (gw.exit === null) {
    if (onHost) gwProc.stdin.end();
    else if (kind === 'k8s') await p.wait(k8sTerminate(gwProc));
    else await p.wait(dockerTerm(p.net.exec, trialNetwork, SCRAPE_TRIAL_LABELS.gateway));
  }
  const gwExit = await p.wait(settleWithin(gw.exited, stopMs));
  if (gwExit === null) {
    await p.wait(gwProc.kill());
    throw new ScrapeVoid('gateway', `the gateway did not exit within ${stopMs} ms of its SIGTERM${await gatewaySaid(recordDir, gw)}`);
  }
  if (sandbox.isDriverFailure(gwExit)) throw driverFailure(gwProc, `the sandbox failed running the gateway (${describeExit(gwExit)})${await gatewaySaid(recordDir, gw)}`);
  if (gwExit.code !== 0) throw new ScrapeVoid('gateway', `the gateway exited with ${describeExit(gwExit)} on its SIGTERM${await gatewaySaid(recordDir, gw)}`);
  const errorDoc = await readJson(join(recordDir, GATEWAY_FILES.error));
  if (errorDoc !== null) throw new ScrapeVoid('gateway', `the gateway wrote ${GATEWAY_FILES.error}: ${JSON.stringify(errorDoc).slice(0, 300)}`);
  const recording = await p.wait(storeRecording(recordDir, o.blobs, secrets?.mask ?? null));
  p.cassette = recording.cassette;
  p.cassetteSha = recording.sha256;

  // Step 6's collection: what a cap broken mid-run left is not kept. With secrets, every file scanned as it is stored.
  let violation: string | null = broke.message;
  let outputs: TrialOutputsT = EMPTY_OUTPUTS;
  if (violation === null) {
    const found = new Map<string, ReadonlySet<string>>();
    const collected = await p.wait(collectOutputs(outputDir, secrets === null ? o.blobs : scanningBlobs(o.blobs, secrets.scan, found)));
    if ('violation' in collected) violation = collected.violation;
    else outputs = collected.outputs;
    if (secrets !== null) p.secretHits = outputSecretHits(outputs, found, secrets);
  }
  const stdoutTail = killed ? null : await p.wait(putChecked(o.blobs, maskLaunchTail(result.stdoutTail, secrets?.forms ?? null, config.tail_bytes)));
  const stderrTail = killed ? null : await p.wait(putChecked(o.blobs, maskLaunchTail(result.stderrTail, secrets?.forms ?? null, config.tail_bytes)));

  // How it ended.
  const upstream = scrapeUpstreamVoid(recording.cassette);
  if (upstream !== null) throw new ScrapeVoid('upstream_error', upstream);
  const launch: ScrapeLaunchFacts = { exit: result.exit, signal: result.signal, timed_out: result.timedOut, leftover: result.leftover };
  const fault = scrapeTrialFault({ launch, violation, cassette: recording.cassette });
  // A violation names /output's paths: redacted (the cassette's paths are masked already).
  const detail = fault === null ? null : secrets === null ? fault.detail : redactSecrets(fault.detail, secrets.forms);
  return {
    kind: 'run',
    trial: { ...o.trial },
    owner,
    fault: fault?.status ?? null,
    detail,
    wall_ns: wallNs,
    ...launch,
    outputs,
    cassette: recording.cassette,
    cassette_sha256: recording.sha256,
    blobs: {
      cassette: recording.sha256,
      bodies: recording.bodies,
      outputs: [...new Set(outputs.files.map((f) => f.sha256))].sort(),
      stdout_tail: stdoutTail,
      stderr_tail: stderrTail,
    },
    ...(secrets === null ? {} : { secret_hits: p.secretHits }),
  };
}
