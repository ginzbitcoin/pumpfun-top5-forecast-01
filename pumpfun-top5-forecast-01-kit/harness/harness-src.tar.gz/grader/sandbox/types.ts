// The sandbox contract the harnesses drive: start one entry (or scorer) program with its code
// mounted read-only at /bot, talk to it over stdin/stdout, read its stderr, kill it. Two drivers:
//
//   docker.ts    production: `docker run` with the hardened flag set, an image pinned by digest
//   process.ts   tests only: `node <dir>/<script>` on the host with the same explicit environment
//
// A program sees exactly: its code at /bot (read-only), the extra mounts below at fixed container
// paths, a writable /tmp, and the environment TZ=UTC, PYTHONHASHSEED=0, LANG=C.UTF-8 (never the
// host's) plus what its spec's `env` adds from a short allowlist (checkSandboxEnv) and its spec's
// `secrets` (checkSandboxSecrets: an entrant's env-lane entry secrets, contracts/entry-secrets.ts). The
// process driver stands the mounts in with MAKEFUN_<NAME>_DIR variables, which the program/v1 entries
// and scorers read when set.
//
// A secret is a variable like any other to the program, and nowhere else: every driver carries it out
// of band, never on an argv, in a pod spec or in a message. docker.ts writes the spawn's secrets to an
// --env-file (0600, in a 0700 directory of its own) and removes it once docker has created the
// container; k8s.ts puts them in the pod's own Secret, read by secretKeyRef and deleted with the pod;
// process.ts sets them in the child's environment. A secret never shares a name with anything else a
// sandbox sets, because Docker and Kubernetes both let the later of two variables of one name win
// (#3341): checkSandboxSecrets refuses the collision, and every driver refuses what any driver could
// not carry, so a secret never runs on one driver and not another. No SandboxError quotes a value.
//
// A driver may also meter a program's writable mount while it runs (Sandbox.meterTree, docker.ts's
// meter container), so a harness holds the program to its output caps whatever modes it sets there.
//
// No network, unless the spec names a trial's network (grader/sandbox/network.ts): then the
// container sits on that trial's internal network only, under the aliases the spec gives it (an
// agent trial's `agent`, `store`, `llm`; a scrape trial's gateway also under the real host names it
// stands in for, `hosts`), and the forwarder or gateway alone also on the host's egress bridge. A
// containerized driver makes and removes those networks itself (Sandbox.networks, TrialNetworks). The
// process driver shares the host's loopback instead and isolates nothing.
//
// A scrape trial's entry runs under the house launcher (grader/scrape/launch.ts, a spec's
// `launcher`): the container's PID 1 is the launcher, which times the entry and drops it to the
// sandbox user; docker.ts gives that container the launcher privilege set. A `launcher` spec is the
// docker driver's alone: the process driver has no root to drop from, so there the launcher runs as
// the program itself (its script launch.ts, launch.json with no uid).
//
// A race's racer (grader/race.ts runRacer, a spec's `race`) is one program kept for a whole race
// window, which runs far past any grade's wall budget: a containerized driver ends it by its own
// deadline, never by the age at which the sweeps take what a crashed grader left (network.ts
// STALE_AFTER_MS). So its container carries no grader mark (docker.ts CONTAINER_LABEL, which every
// sweep and reap lists by) and is marked a race's instead: k8s.ts's pod `makefun.io/sandbox=race`
// with activeDeadlineSeconds its lifetime, docker.ts's container `makefun.race=<deadline>`, which
// network.ts sweepExpiredRaces (TrialNetworks.sweepRaces) removes once that deadline has passed. A
// race spec runs one lockstep bot alone: its code at /bot, no network, mount, env, secret or launcher.
//
// A patch/v1 run (a spec's `image`) runs in the competition's own repository image, pinned by digest,
// instead of a runtime's: the house runner at /bot, the sealed tree at /base and the owner's tests at
// /tests (both read-only), and the entrant's work in RAM at /work (a spec's `work`: a tmpfs of its
// size, counted in the container's memory limit, never on the grader's disk). The docker driver runs
// the image's argv in place of a runtime's interpreter, with no network; the process driver runs the
// spec's script under the host's /bin/sh, a fresh scratch directory standing in for /work
// (WORK_DIR_ENV); the k8s driver refuses it (SandboxError code `repo_image_unsupported`).

import type { Readable, Writable } from 'node:stream';
import type { RUNTIMES } from '../../contracts/competition.ts';
import { checkSecretName, checkSecretValue, ENTRY_SECRET_MAX_COUNT, ENTRY_SECRET_TOTAL_MAX_BYTES, providerOfSecretName, utf8Bytes } from '../../contracts/entry-secrets.ts';

/** A sandbox runtime (contracts/competition.ts RUNTIMES). */
export type Runtime = (typeof RUNTIMES)[number];

/** The container paths a harness may mount besides /bot, and the variable the process driver uses instead. */
export const MOUNT_POINTS = {
  '/input': 'MAKEFUN_INPUT_DIR',
  '/output': 'MAKEFUN_OUTPUT_DIR',
  '/reference': 'MAKEFUN_REFERENCE_DIR',
  '/scores': 'MAKEFUN_SCORES_DIR',
  // An agent trial's services (grader/sandbox/network.ts): the store env's code, its seed and its
  // state; the forwarder's config and what it records.
  '/env': 'MAKEFUN_ENV_DIR',
  '/env-data': 'MAKEFUN_ENV_DATA_DIR',
  '/state': 'MAKEFUN_STATE_DIR',
  '/config': 'MAKEFUN_CONFIG_DIR',
  '/record': 'MAKEFUN_RECORD_DIR',
  // A patch/v1 run (a spec's `image`): the sealed upstream tree and the owner's tests.
  '/base': 'MAKEFUN_BASE_DIR',
  '/tests': 'MAKEFUN_TESTS_DIR',
} as const;
export type MountPoint = keyof typeof MOUNT_POINTS;

/** Where a spec's `work` tmpfs sits in the container, and the variable the process driver names its scratch directory by instead. */
export const WORK_DIR = '/work';
export const WORK_DIR_ENV = 'MAKEFUN_WORK_DIR';

/** The only environment a sandboxed program gets. */
export const SANDBOX_ENV: Readonly<Record<string, string>> = Object.freeze({ TZ: 'UTC', PYTHONHASHSEED: '0', LANG: 'C.UTF-8' });

/**
 * The variables a spec's `env` may set besides MAKEFUN_* ones: the base URLs and the dummy keys an
 * agent's SDKs read. Never a proxy, PATH, NODE_OPTIONS or anything the loader reads.
 */
export const SPEC_ENV_NAMES: ReadonlySet<string> = new Set(['ANTHROPIC_BASE_URL', 'OPENAI_BASE_URL', 'ANTHROPIC_API_KEY', 'OPENAI_API_KEY']);
const SPEC_ENV_MAKEFUN_RE = /^MAKEFUN_[A-Z0-9_]+$/;

/** The name stem of an agent trial's internal network (`makefun-net-<trial>`, network.ts trialNetworkName). */
export const TRIAL_NETWORK_PREFIX = 'makefun-net-';
/** A trial's label: lowercase [a-z0-9-], at most 41 characters (like a container label). */
export const TRIAL_RE = /^[a-z0-9][a-z0-9-]{0,40}$/;
/** The host's one egress bridge, which only a forwarder joins besides its trial network. */
export const EGRESS_NETWORK = 'makefun-egress';
const ALIAS_RE = /^[a-z][a-z0-9-]{0,62}$/;
/** One label of a host name: lowercase letters, digits and inner hyphens, 1 to 63 characters. */
const HOST_LABEL_RE = /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/;
/** A host name's length cap (RFC 1035's 253 characters, no trailing dot). */
const HOST_NAME_MAX = 253;

/** The fixed interpreter command per runtime (the script path is appended). */
export const RUNTIME_COMMANDS: Readonly<Record<Runtime, readonly string[]>> = Object.freeze({
  node22: Object.freeze(['node']),
  // -P keeps /bot off sys.path, -s the user site; not -I, which implies -E and would ignore PYTHONHASHSEED.
  'python3.13': Object.freeze(['python3', '-P', '-s']),
});

/** The entry script per runtime, relative to /bot. */
export const ENTRY_SCRIPTS: Readonly<Record<Runtime, string>> = Object.freeze({ node22: 'main.ts', 'python3.13': 'main.py' });

export interface SandboxLimits {
  cpus: number;
  memory_mb: number;
  pids: number;
}

export interface SandboxMount {
  /** Absolute host directory. */
  host: string;
  at: MountPoint;
  readOnly: boolean;
}

export interface SandboxSpec {
  runtime: Runtime;
  /** Absolute host directory mounted read-only at /bot (a materialized snapshot, or a scorer's directory). */
  codeDir: string;
  /** Script under /bot to run; default ENTRY_SCRIPTS[runtime]. Relative POSIX path, no `..`. */
  script?: string;
  mounts?: readonly SandboxMount[];
  limits: SandboxLimits;
  /** Container name stem (a random suffix is added). */
  label: string;
  /** Run this image digest instead of the pinned one (an L2 regrade re-runs the stored digest). */
  imageDigest?: string | null;
  /** A trial's network to sit on (checkSandboxNetwork); absent, the program has no network at all. */
  network?: SandboxNetwork;
  /** Variables set after SANDBOX_ENV: MAKEFUN_* and SPEC_ENV_NAMES only (checkSandboxEnv). Never with a `launcher`. */
  env?: Readonly<Record<string, string>>;
  /**
   * An entrant's env-lane entry secrets (contracts/entry-secrets.ts), NAME to value: variables of the
   * program like `env`'s, carried by every driver out of band (the header) and never sharing a name with
   * anything else the sandbox sets (checkSandboxSecrets). Never with a `launcher` or a `race`.
   */
  secrets?: Readonly<Record<string, string>>;
  /**
   * Run the house launcher as the container's PID 1 instead of the script (a scrape trial's entry):
   * the docker driver's launcher privilege set, the house read-only at /house, and the entry the
   * launcher starts is launch.json's argv with launch.json's env. No `script` and no `env` with it.
   * The docker driver's alone (the process driver cannot drop privileges).
   */
  launcher?: SandboxLauncher;
  /**
   * A race's racer (the header; grader/race.ts runRacer): kept for its whole window and ended by the
   * driver at its own lifetime, never by the stale sweeps. No network, mount, env, secret or launcher
   * with it (checkSandboxRace).
   */
  race?: SandboxRace;
  /**
   * Run this repository image instead of the runtime's pinned one (a patch/v1 run, the header): its
   * argv in place of the interpreter and the script, no network, launcher, race or imageDigest with it
   * (checkSandboxImage). The process driver runs `/bin/sh <codeDir>/<script>` instead, so a spec it runs
   * names its script.
   */
  image?: SandboxImage;
  /** A writable tmpfs at WORK_DIR of this size (checkSandboxWork); the process driver gives a fresh scratch directory instead. */
  work?: SandboxWork;
  /**
   * `limits.cpus` is a ceiling the platform chose for a house role (the trial's env, network.ts ENV_LIMITS), never an
   * entrant's program, which gets exactly its contest's CPUs or the daemon's refusal. The docker driver then grants at
   * most the host's CPU count (docker.ts grantedCpus), so a host with fewer CPUs still starts it; k8s and process ignore it.
   */
  cpusCeiling?: boolean;
}

/** A spec's repository image (a competition's patch/v1 image, contracts/patch.ts). */
export interface SandboxImage {
  /** Lowercase `[registry[:port]/]path`, no tag and no `@`. */
  repository: string;
  /** `sha256:<64 hex>`: the image always runs by digest, never pulled. */
  digest: string;
  /** The container's command: argv[0] its entrypoint (a path or a command name), the rest its arguments. */
  argv: readonly string[];
}

/** A spec's /work tmpfs. */
export interface SandboxWork {
  /** Its size in MiB, a positive integer: what the program writes there counts in its memory limit. */
  mb: number;
}

/** A repository a spec's image names: docker's reference grammar, lowercase, an optional registry host (and port) first. */
const REPOSITORY_RE = /^(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)*(?::[0-9]{1,5})?\/)?[a-z0-9]+(?:(?:[._]|__|-+)[a-z0-9]+)*(?:\/[a-z0-9]+(?:(?:[._]|__|-+)[a-z0-9]+)*)*$/;
/** docker's cap on a repository name. */
const REPOSITORY_MAX = 255;
const DIGEST_RE = /^sha256:[0-9a-f]{64}$/;
/** An image argv's entrypoint: a path or a command name, never an option (docker's `--entrypoint` takes it whole). */
const ENTRYPOINT_RE = /^[A-Za-z0-9_./][A-Za-z0-9_./+-]*$/;
/** The most arguments an image argv carries (a house runner's command, never data). */
export const MAX_IMAGE_ARGV = 64;

/**
 * `<repository>@<digest>`, checked: a lowercase repository (REPOSITORY_RE, at most REPOSITORY_MAX
 * characters, so no tag and no `@`) and a sha256 digest.
 */
export function repoImageRef(repository: string, digest: string): string {
  if (typeof repository !== 'string' || repository.length > REPOSITORY_MAX || !REPOSITORY_RE.test(repository)) {
    throw new SandboxError(`image repository ${JSON.stringify(repository)} must be a lowercase [registry/]path of at most ${REPOSITORY_MAX} characters, no tag and no @`);
  }
  if (typeof digest !== 'string' || !DIGEST_RE.test(digest)) throw new SandboxError(`image digest ${JSON.stringify(digest)} must be sha256:<64 hex>`);
  return `${repository}@${digest}`;
}

/**
 * The spec's image, checked: its reference (repoImageRef), and an argv of 1 to MAX_IMAGE_ARGV strings
 * without NUL whose first is an entrypoint (ENTRYPOINT_RE); and a spec with no launcher (the house's
 * runtime image), race (one lockstep bot), network (the run is offline) or imageDigest (the digest is
 * the image's own).
 */
export function checkSandboxImage(spec: Pick<SandboxSpec, 'image' | 'launcher' | 'race' | 'network' | 'imageDigest'>): SandboxImage {
  const image = spec.image;
  if (typeof image !== 'object' || image === null) throw new SandboxError(`image must be {repository, digest, argv}, not ${JSON.stringify(image)}`);
  repoImageRef(image.repository, image.digest);
  const argv = image.argv;
  if (!Array.isArray(argv) || argv.length === 0 || argv.length > MAX_IMAGE_ARGV) throw new SandboxError(`image argv must be a list of 1 to ${MAX_IMAGE_ARGV} strings, not ${JSON.stringify(argv)}`);
  for (const a of argv) {
    if (typeof a !== 'string' || a.includes('\0')) throw new SandboxError(`image argv ${JSON.stringify(a)} must be a string without NUL`);
  }
  if (!ENTRYPOINT_RE.test(argv[0]!)) throw new SandboxError(`image argv[0] ${JSON.stringify(argv[0])} must be a path or a command name`);
  if (spec.launcher !== undefined) throw new SandboxError('an image spec runs its own argv: it has no launcher');
  if (spec.race !== undefined) throw new SandboxError('an image spec is never a race spec');
  if (spec.network !== undefined) throw new SandboxError('an image spec runs offline: it sits on no network');
  if (spec.imageDigest !== undefined && spec.imageDigest !== null) throw new SandboxError("an image spec runs its image's own digest, never an imageDigest");
  return image;
}

/** The spec's work tmpfs, checked: {mb} with mb a positive safe integer. */
export function checkSandboxWork(work: SandboxWork): SandboxWork {
  if (typeof work !== 'object' || work === null || !Number.isSafeInteger(work.mb) || work.mb <= 0) {
    throw new SandboxError(`work must be {mb} with mb a positive integer of MiB, not ${JSON.stringify(work)}`);
  }
  return work;
}

/** A race spec's lifetime (grader/race.ts raceLifetimeMs: the window still ahead, the think budget and RACE_DEADLINE_SLACK_MS). */
export interface SandboxRace {
  /**
   * How long the program may live, in ms from its spawn: past it a containerized driver ends it whatever
   * became of the harness (k8s: the pod's activeDeadlineSeconds; docker: the deadline label
   * sweepExpiredRaces reads). A positive safe integer, at most MAX_RACE_LIFETIME_MS.
   */
  lifetimeMs: number;
}

/** The longest a race spec may live: a race window is at most 72 h (contracts/competition.ts), so a week is ample for its slack. */
export const MAX_RACE_LIFETIME_MS = 7 * 24 * 60 * 60 * 1000;

/**
 * The spec's race, checked: a lifetime that is a positive safe integer of ms, at most
 * MAX_RACE_LIFETIME_MS, and a spec with no network, mount, env, secret or launcher (a racer is one
 * lockstep bot with its code at /bot and nothing else, so nothing of it is a trial's for a reap to take,
 * and the racer holds no seal key to open a secret with).
 */
export function checkSandboxRace(spec: Pick<SandboxSpec, 'race' | 'network' | 'mounts' | 'env' | 'secrets' | 'launcher' | 'work'>): SandboxRace {
  const race = spec.race;
  if (typeof race !== 'object' || race === null) throw new SandboxError(`race must be {lifetimeMs}, not ${JSON.stringify(race)}`);
  const ms = race.lifetimeMs;
  if (!Number.isSafeInteger(ms) || ms <= 0 || ms > MAX_RACE_LIFETIME_MS) throw new SandboxError(`a race's lifetime ${JSON.stringify(ms)} must be a positive integer of ms, at most ${MAX_RACE_LIFETIME_MS}`);
  if (spec.network !== undefined) throw new SandboxError('a race spec runs its bot alone: it sits on no network');
  if (spec.launcher !== undefined) throw new SandboxError('a race spec runs its bot alone: it has no launcher');
  if (spec.mounts !== undefined && spec.mounts.length > 0) throw new SandboxError('a race spec runs its bot alone: nothing is mounted but its code at /bot');
  if (spec.env !== undefined && Object.keys(spec.env).length > 0) throw new SandboxError('a race spec runs its bot alone: it takes no env beyond SANDBOX_ENV');
  if (hasSecrets(spec.secrets)) throw new SandboxError('a race spec runs its bot alone: it takes no secrets');
  if (spec.work !== undefined) throw new SandboxError('a race spec runs its bot alone: it has no /work');
  return race;
}

/** Whether a spec's `secrets` holds any (anything but undefined or an empty map: a malformed one counts, for checkSandboxSecrets to refuse). */
function hasSecrets(secrets: SandboxSpec['secrets']): boolean {
  if (secrets === undefined) return false;
  return typeof secrets !== 'object' || secrets === null || Array.isArray(secrets) || Object.keys(secrets).length > 0;
}

/** A container's place on a trial's network (grader/sandbox/network.ts). */
export interface SandboxNetwork {
  /** The trial's internal network, `makefun-net-<trial>` (network.ts trialNetworkName). */
  name: string;
  /** Names the trial's other containers reach this one by (`agent`, `store`, `llm`): DNS labels. */
  aliases?: readonly string[];
  /**
   * Real host names this container answers for on the trial network (a scrape trial's gateway:
   * `apis.roblox.com`, network.ts scrapeAttachment): dotted lowercase DNS names, given to docker as
   * more aliases after `aliases`.
   */
  hosts?: readonly string[];
  /** Also on the host's egress bridge, EGRESS_NETWORK: the forwarder or the gateway only. */
  egress?: true;
}

/** The house launcher of a spec (grader/scrape/launch.ts). */
export interface SandboxLauncher {
  /**
   * Absolute host directory mounted read-only at /house: the runtime's launcher (launch.ts or
   * launch.py), launch.json and ca.pem, as launch.ts houseFor makes them (writeHouse writes it
   * 0755 with 0644 files: the launcher is root without CAP_DAC_OVERRIDE).
   */
  houseDir: string;
}

/**
 * A host name, checked: dotted lowercase DNS labels, at least two, at most 253 characters, no
 * trailing dot, and a last label that is not all digits (never an IPv4 address).
 */
export function checkHostName(name: string): string {
  const labels = typeof name === 'string' ? name.split('.') : [];
  if (
    typeof name !== 'string' ||
    name.length > HOST_NAME_MAX ||
    labels.length < 2 ||
    !labels.every((l) => HOST_LABEL_RE.test(l)) ||
    /^\d+$/.test(labels.at(-1)!)
  ) {
    throw new SandboxError(`host name ${JSON.stringify(name)} must be a dotted lowercase DNS name (two labels or more, at most ${HOST_NAME_MAX} characters)`);
  }
  return name;
}

/**
 * The spec's network, checked: a trial network by name (never `none`, `host`, `bridge`, the egress
 * bridge or a container's namespace), DNS-label aliases and dotted host names (checkHostName)
 * without repeats among them, and `egress` true or absent.
 */
export function checkSandboxNetwork(network: SandboxNetwork): SandboxNetwork {
  const trial = network.name.startsWith(TRIAL_NETWORK_PREFIX) ? network.name.slice(TRIAL_NETWORK_PREFIX.length) : '';
  if (!TRIAL_RE.test(trial)) throw new SandboxError(`network ${JSON.stringify(network.name)} is not a trial network (${TRIAL_NETWORK_PREFIX}<trial>)`);
  const aliases = network.aliases ?? [];
  for (const a of aliases) {
    if (!ALIAS_RE.test(a)) throw new SandboxError(`network alias ${JSON.stringify(a)} must be a lowercase DNS label`);
  }
  if (new Set(aliases).size !== aliases.length) throw new SandboxError(`network aliases ${JSON.stringify(aliases)} repeat`);
  const hosts = network.hosts ?? [];
  if (!Array.isArray(hosts)) throw new SandboxError(`network hosts must be a list, not ${JSON.stringify(hosts)}`);
  for (const h of hosts) checkHostName(h);
  if (new Set([...aliases, ...hosts]).size !== aliases.length + hosts.length) throw new SandboxError(`network hosts ${JSON.stringify(hosts)} repeat`);
  if (network.egress !== undefined && network.egress !== true) throw new SandboxError(`network egress must be true or absent, not ${JSON.stringify(network.egress)}`);
  return network;
}

/**
 * The spec's launcher, checked: a house directory safe for a `-v` argument (checkHostPath), and a
 * spec with no `script`, no `env` and no `secrets` (the entry the launcher starts takes its argv and env
 * from launch.json, and the launcher itself runs as root with the container's environment).
 */
export function checkSandboxLauncher(spec: Pick<SandboxSpec, 'launcher' | 'script' | 'env' | 'secrets'>): SandboxLauncher {
  const launcher = spec.launcher;
  if (typeof launcher !== 'object' || launcher === null) throw new SandboxError(`launcher must be {houseDir}, not ${JSON.stringify(launcher)}`);
  if (spec.script !== undefined) throw new SandboxError(`a launcher spec runs launch.json's argv; it takes no script (${JSON.stringify(spec.script)})`);
  if (spec.env !== undefined && Object.keys(spec.env).length > 0) throw new SandboxError("a launcher spec's entry gets launch.json's env (grader/scrape/launch.ts houseFor), not the spec's");
  if (hasSecrets(spec.secrets)) throw new SandboxError("a launcher spec's entry gets launch.json's env (grader/scrape/launch.ts houseFor): it takes no secrets");
  checkHostPath(launcher.houseDir);
  return launcher;
}

/**
 * The spec's extra environment, checked: only MAKEFUN_* names and SPEC_ENV_NAMES, never a mount
 * variable (MOUNT_POINTS and WORK_DIR_ENV: the process driver sets those), no NUL in a value. Its entries in name
 * order, so the argv does not depend on how the object was built.
 */
export function checkSandboxEnv(env: Readonly<Record<string, string>> | undefined): Array<[string, string]> {
  if (env === undefined) return [];
  const mountVars = new Set<string>([...Object.values(MOUNT_POINTS), WORK_DIR_ENV]);
  const out: Array<[string, string]> = [];
  for (const [name, value] of Object.entries(env)) {
    if (!SPEC_ENV_MAKEFUN_RE.test(name) && !SPEC_ENV_NAMES.has(name)) throw new SandboxError(`environment variable ${JSON.stringify(name)} is not allowed in a sandbox (MAKEFUN_* or ${[...SPEC_ENV_NAMES].join(', ')})`);
    if (mountVars.has(name)) throw new SandboxError(`environment variable ${name} is the process driver's mount variable`);
    if (typeof value !== 'string' || value.includes('\0')) throw new SandboxError(`environment variable ${name} must be a string without NUL`);
    out.push([name, value]);
  }
  return out.sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0));
}

/** An English ordinal: 1st, 2nd, 3rd, 4th, 11th, 21st. */
function ordinal(n: number): string {
  const tens = n % 100;
  const suffix = tens >= 11 && tens <= 13 ? 'th' : (['th', 'st', 'nd', 'rd'][n % 10] ?? 'th');
  return `${n}${suffix}`;
}

/**
 * The spec's secrets, checked: none on a race or launcher spec; at most ENTRY_SECRET_MAX_COUNT; each
 * named by the contract's rule and on none of its reserved lists (checkSecretName; its sandbox group
 * holds the names these drivers' own processes read or set: k8s.ts's wrapper variables, KUBERNETES_*,
 * PERL*, LOCPATH and the docker CLI's proxy variables), on the env lane (a provider-lane value reaches a
 * model only through a trial's gateway forwarder, never a sandbox), and sharing no name with
 * SANDBOX_ENV, SPEC_ENV_NAMES, the spec's env or the process driver's mount variables (MOUNT_POINTS),
 * since Docker and Kubernetes both let the later of two variables of one name win (#3341); each value one the contract takes (checkSecretValue: 8 characters
 * to 8192 bytes of UTF-8, no NUL), and ENTRY_SECRET_TOTAL_MAX_BYTES of names and values in all. Its
 * entries in name order. A SandboxError names a secret by its name, or by its place for a name that
 * fails the name rule (which may be a value pasted where its name belongs), and never quotes a value.
 */
export function checkSandboxSecrets(spec: Pick<SandboxSpec, 'secrets' | 'env' | 'race' | 'launcher'>): Array<[string, string]> {
  const secrets = spec.secrets;
  if (!hasSecrets(secrets)) return [];
  if (typeof secrets !== 'object' || secrets === null || Array.isArray(secrets)) throw new SandboxError('secrets must be a {NAME: value} map');
  if (spec.race !== undefined) throw new SandboxError('a race spec runs its bot alone: it takes no secrets');
  if (spec.launcher !== undefined) throw new SandboxError("a launcher spec's entry gets launch.json's env (grader/scrape/launch.ts houseFor): it takes no secrets");
  const entries = Object.entries(secrets);
  if (entries.length > ENTRY_SECRET_MAX_COUNT) throw new SandboxError(`a sandbox takes at most ${ENTRY_SECRET_MAX_COUNT} secrets, not ${entries.length}`);
  const env = spec.env ?? {};
  const mountVars = new Set<string>(Object.values(MOUNT_POINTS));
  let total = 0;
  const out: Array<[string, string]> = [];
  for (const [i, [name, value]] of entries.entries()) {
    const named = checkSecretName(name, i + 1);
    if (named?.check === 'secret_name') throw new SandboxError(`the ${ordinal(i + 1)} secret's name is not a secret name (letters, digits and _, starting with a letter or _, at most 128 characters)`);
    if (Object.hasOwn(SANDBOX_ENV, name)) throw new SandboxError(`secret ${name} is a SANDBOX_ENV variable, which every sandbox sets`);
    if (SPEC_ENV_NAMES.has(name)) throw new SandboxError(`secret ${name} is one of the variables a spec's env sets for an agent's SDKs (SPEC_ENV_NAMES)`);
    if (Object.hasOwn(env, name)) throw new SandboxError(`secret ${name} is also in the spec's env: Docker and Kubernetes let the later of the two win`);
    if (mountVars.has(name)) throw new SandboxError(`secret ${name} is the process driver's mount variable`);
    if (named !== null) throw new SandboxError(`secret ${named.reason}`);
    if (providerOfSecretName(name) !== null) throw new SandboxError(`secret ${name} is a provider-lane name: its value reaches a model only through a trial's gateway forwarder, never a sandbox`);
    const limits = checkSecretValue(value);
    if (limits !== null) throw new SandboxError(`secret ${name}'s value is no secret value: ${limits.reason}`);
    total += utf8Bytes(name) + utf8Bytes(value);
    out.push([name, value]);
  }
  if (total > ENTRY_SECRET_TOTAL_MAX_BYTES) throw new SandboxError(`the spec's secrets hold ${total} bytes of names and values: a sandbox takes at most ${ENTRY_SECRET_TOTAL_MAX_BYTES}`);
  return out.sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0));
}

export interface SandboxExit {
  code: number | null;
  signal: NodeJS.Signals | null;
  /** Set when the driver could not start the program at all (e.g. the docker CLI is missing). */
  error?: string;
}

export interface SandboxProcess {
  readonly stdin: Writable;
  readonly stdout: Readable;
  readonly stderr: Readable;
  /** Settles once the program has exited and its stdio has closed. */
  readonly exited: Promise<SandboxExit>;
  /**
   * Set by a driver whose program begins well after spawn (k8s: a pod to create and see Ready, then the
   * exec): resolves as the program itself starts, which is when its wall budget starts (Supervisor). It
   * never rejects, and never resolves for a program that never ran (`exited` says why). Absent, the
   * program runs from spawn.
   */
  readonly started?: Promise<void>;
  /** Stop it now (idempotent); resolves once it is gone. */
  kill(): Promise<void>;
}

export interface Sandbox {
  /** The driver: `docker` and `k8s` run each program in a container (containerized), `process` on the host. */
  readonly kind: 'docker' | 'process' | 'k8s';
  /** `sha256:<hex>` of the image a runtime runs in (null for the process driver). */
  imageDigest(runtime: Runtime): string | null;
  /** Fail early (missing image, unreachable daemon, refused driver) before anything is executed. */
  preflight(runtime: Runtime, imageDigest?: string | null): Promise<void>;
  spawn(spec: SandboxSpec): SandboxProcess;
  /**
   * True when a non-zero exit code means the driver itself failed (docker run's 125: the daemon
   * refused or the container could not start), so the harness throws instead of blaming the entry.
   */
  isDriverFailure(exit: SandboxExit): boolean;
  /**
   * Delete a directory a sandboxed program could write into. What the program created there may
   * belong to the sandbox user (65534) rather than to this process, or sit deeper than this process
   * can reach by path (ENAMETOOLONG), so the docker driver falls back to deleting it from inside a
   * container running as that user.
   */
  removeTree(dir: string): Promise<void>;
  /**
   * Count what a program writes into `dir`, one of its writable mounts, while it starts and runs,
   * whatever modes it leaves there (docker.ts meterTree: a meter container). Throws SandboxError on a
   * malformed argument, before anything starts. Absent on a driver with no such view (the process
   * driver): the harness then has only its own watch over what it can read.
   */
  meterTree?(dir: string, opts: TreeMeterOptions): TreeMeter;
  /**
   * The driver's trial networks (TrialNetworks below): absent on the process driver, which makes no
   * network and shares the host's loopback.
   */
  readonly networks?: TrialNetworks;
}

/** True when a driver runs each program in a container of its own (a trial's services reached by alias, its input at /input). */
export function containerized(kind: Sandbox['kind']): boolean {
  return kind !== 'process';
}

/**
 * A containerized driver's trial networks (docker.ts's on grader/sandbox/network.ts): what an agent
 * or scrape trial makes before its programs start and removes after them, and the engine check it
 * requires first. A trial makes its network (`create`), and the egress bridge when it goes live
 * (`ensureEgress`), before it spawns any of its programs, and spawns its services (an agent trial's
 * store env and forwarder, a scrape trial's gateway) before its entry, each attached by
 * SandboxSpec.network: a driver may make a service's alias resolvable only once that service is
 * spawned, and only to programs spawned after it (k8s's hostAliases, docker's /etc/hosts under
 * runsc-netstack: docker.ts NetstackNames), and the entry finds them by alias from its first
 * instruction.
 */
export interface TrialNetworks {
  /** Make trial `trial`'s internal network, labelled with its owner when one is given; its name. Refuses one that exists. */
  create(trial: string, opts: { owner: string | null }): Promise<string>;
  /** Remove trial `trial`'s network; one already gone is fine. */
  remove(trial: string): Promise<void>;
  /** Remove what a grader that died mid-pass left of trial `owner`; never throws for what it could not remove (the result says). */
  reap(owner: string): Promise<ReapResult>;
  /** Make the egress bridge a live trial's forwarder or gateway reaches the internet on, unless it exists. */
  ensureEgress(): Promise<void>;
  /** Remove the grader containers and trial networks a crashed grader left; never throws for one it could not remove. */
  sweepStale(): Promise<SweepResult>;
  /**
   * Remove the race containers (a spec's `race`) whose deadline has passed: what a racer that died left
   * of its bot, which sweepStale never takes (the header). Absent where the driver ends a race's program
   * itself (k8s: its pod's activeDeadlineSeconds). Never throws for one it could not remove.
   */
  sweepRaces?(): Promise<SweepResult>;
  /** The engine's verdict on keeping trials apart (kept per process); rejects with SandboxError when it could not find out. */
  isolation(): Promise<IsolationVerdict>;
}

/** What TrialNetworks.reap removed of one trial, and what it could not. */
export interface ReapResult {
  /** The trial's owner (the OWNER_LABEL value it reaped by). */
  owner: string;
  /** The containers removed, by name. */
  containers: string[];
  /** The networks removed, by name. */
  networks: string[];
  /** What could not be listed or removed (the reap goes on past each). */
  errors: string[];
}

/** What TrialNetworks.sweepStale removed, and what it could not. */
export interface SweepResult {
  /** Container ids removed. */
  containers: string[];
  /** Network names removed. */
  networks: string[];
  /** What could not be listed, dated or removed (the sweep goes on past each). */
  errors: string[];
}

/** What an isolation probe found not enforced (network.ts IsolationRefusal.fault): the docker driver's probe's, then the k8s driver's (k8s-network.ts). */
export type IsolationFault =
  /** The egress bridge carries enable_icc=false and a container there reached another: the daemon writes no iptables rule, or bridged traffic skips them. */
  | 'egress_icc_off'
  /** A container on the egress bridge reached another, and the bridge was made without enable_icc=false. */
  | 'egress_icc_unset'
  /** A container on an internal network made as a trial's had a default route, or reached the egress bridge. */
  | 'internal_route'
  /** A pod under the namespace's egress policy reached another: the cluster enforces none of the namespace's NetworkPolicies. */
  | 'policy_not_enforced'
  /** A pod on a trial's network (its NetworkPolicy) reached an egress pod or the world past it. */
  | 'trial_pod_escapes';

/** An engine's verdict: trials kept apart (what was tried), or not (what, and what fixes it). */
export type IsolationVerdict =
  | { enforced: true; engine: string; detail: string }
  | { enforced: false; engine: string; fault: IsolationFault; reason: string; fix: string };

/** What one meter pass counted under a writable mount. */
export interface TreeUsage {
  /** Its entries, every inode (files, directories, links, FIFOs; the directory itself not counted). */
  entries: number;
  /** Its regular files' size: the larger of their apparent total and their allocated total (512-byte blocks), so neither a sparse nor a preallocated file hides disk. */
  bytes: number;
  /** Its deepest entry's depth: 1 for one directly in it, 0 when it is empty. */
  depth: number;
  /** How many entries' paths, relative to it, are longer than maxPathBytes (a pass stops at the first). */
  longPaths: number;
}

export interface TreeMeterOptions {
  /** The program's runtime, and the image digest it runs (default: the runtime's pinned one): the meter runs in that image. */
  runtime: Runtime;
  imageDigest?: string | null;
  /** The program's container name stem: the meter is `makefun-<label>-<hex>-meter`. */
  label: string;
  /** The program's wall budget: a meter nobody stops goes by itself METER_SLACK_MS after it. */
  budgetMs: number;
  /** ms between the end of one pass and the start of the next. */
  intervalMs: number;
  /** A pass stops counting once past any cap (or at the first long path): its reading is then over that cap. */
  maxEntries: number;
  maxBytes: number;
  maxDepth: number;
  maxPathBytes: number;
  /** Each pass's reading. */
  onUsage(usage: TreeUsage): void;
  /**
   * The meter failed before stop() was called (it could not start, it exited, it printed something that is not a reading); called at most once.
   * `noRoom` is the scheduler's or the API's words when the meter is a pod the node had no room for, so it never ran
   * (k8s.ts K8sMeter, the header's Room on the node): backpressure, which its caller throws as k8s.ts meterFailure
   * makes it (a NodeRoomError), so the job is handed back. Absent for any other fault, and from any other driver.
   */
  onFault(message: string, noRoom?: string): void;
}

export interface TreeMeter {
  /** Stop metering (idempotent): nothing is reported once it is called; resolves once the meter is gone. */
  stop(): Promise<void>;
}

/**
 * What a SandboxError's `code` names, for a caller that acts on the kind of failure:
 * `repo_image_unsupported`, a driver that cannot run a spec's `image` (k8s.ts).
 */
export type SandboxErrorCode = 'repo_image_unsupported';

/** The sandbox could not do its job (an infrastructure failure, never the entry's fault). */
export class SandboxError extends Error {
  /** The kind of failure when a caller acts on it (SandboxErrorCode); null for any other. */
  readonly code: SandboxErrorCode | null;

  constructor(message: string, options?: { cause?: unknown; code?: SandboxErrorCode }) {
    super(message, options);
    this.name = 'SandboxError';
    this.code = options?.code ?? null;
  }
}

/**
 * removeTree's failure when the driver deleted as the sandbox user and still could not delete what
 * the program left in `dir` (docker.ts: the reclaim container ran): the program's doing, not the
 * driver's (a SandboxError all the same, for a caller that cannot tell them apart).
 */
export class LeftoverError extends SandboxError {
  readonly dir: string;

  constructor(dir: string, message: string) {
    super(message);
    this.name = 'LeftoverError';
    this.dir = dir;
  }
}

const SCRIPT_RE = /^[A-Za-z0-9_][A-Za-z0-9._-]*(\/[A-Za-z0-9_][A-Za-z0-9._-]*)*$/;
const HOST_PATH_RE = /^\/[A-Za-z0-9._/-]*$/;

/** The script path, checked: relative, POSIX, no `..`, no dot-files (the bundle path rule). */
export function scriptOf(spec: Pick<SandboxSpec, 'runtime' | 'script'>): string {
  const script = spec.script ?? ENTRY_SCRIPTS[spec.runtime];
  if (!SCRIPT_RE.test(script)) throw new SandboxError(`script ${JSON.stringify(script)} is not a relative path inside /bot`);
  return script;
}

/** A host path safe to put in a `-v` argument: absolute, and nothing a mount spec would split on (`:` or `,`). */
export function checkHostPath(path: string): string {
  if (!HOST_PATH_RE.test(path) || path.split('/').includes('..')) throw new SandboxError(`host path ${JSON.stringify(path)} must be absolute and use only [A-Za-z0-9._/-]`);
  return path;
}
