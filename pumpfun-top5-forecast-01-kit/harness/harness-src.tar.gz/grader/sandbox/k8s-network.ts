// The k8s driver's trial networks (MAKEFUN_SANDBOX=k8s, K8sSandbox.networks): network.ts's docker networks
// in NetworkPolicy form. A trial's network is one NetworkPolicy in the worker's namespace, made before any
// of the trial's pods (deploy/k8s/README.md d4: a fresh pod's first connect can get out before Ready):
//
//   makefun-net-<trial>   labels makefun.grader=1, makefun.net=<trial>[, makefun.trial=<ownerLabel(owner)>]
//     [annotation makefun.io/trial-owner=<owner>]
//     podSelector makefun.net=<trial>; policyTypes Ingress and Egress;
//     ingress from and egress to podSelector makefun.net=<trial>
//
// NetworkPolicies only add allows to the namespace's own (deploy/k8s/base/networkpolicies.yaml):
// makefun-sandbox-deny selects every sandbox pod and allows nothing, makefun-sandbox-egress lets a pod
// labelled makefun.egress=1 out to the world minus every private range and the fleet's servers. So a
// trial's pods reach one another, its forwarders (`llm`, and `house` with a target) or scrape gateway the
// world besides (and a forwarder its LLM gateway: k8s.ts gatewayPolicy), and nothing reaches a trial's pod
// from outside its trial; within it the forwarders admit their callers by a credential
// (grader/gateway/server.ts GatewayClient). The names its pods answer to are K8sSandbox's PodNames
// (hostAliases); its owner is what its pods are labelled with:
// k8s.ts ownerLabel of it (the owner itself when it is a label value, else a hash of it: a label value is at
// most 63 characters, an owner up to 128), the owner whole in the annotation makefun.io/trial-owner.
//
// remove deletes the trial's pods (makefun.net=<trial>), then its policy; reap every pod and policy of an
// owner (makefun.trial=<ownerLabel(owner)>), listed again REAP_ROUNDS times while any is left; sweepStale every grader
// pod and policy (makefun.grader=1) older than STALE_AFTER_MS. Secrets need none of it: an env Secret is
// owned by its pod (k8s.ts ownedByPod) and Kubernetes deletes it with the pod. ensureEgress only checks that
// makefun-sandbox-egress is there: the worker's Role may not write the namespace's own policies, and
// `makefun-k8s.sh bootstrap` applies them.
//
// Isolation (probeK8sIsolation) is network.ts's probe in pod form, four roles in three node22 pods made at
// once with the probe trial's policy, each reach run by exec once its pod is Ready:
//
//   listener  an egress pod running ISOLATION_LISTENER_SCRIPT on SERVICE_PORT (as a forwarder is)
//   control   the listener reaches its own address: the probe works at all
//   sibling   another egress pod must not reach the listener: the egress pods of concurrent trials are
//             kept apart (docker's enable_icc=false), so the namespace's policies are enforced at all
//   inside    a pod on the probe trial's network (as an entry is) must reach neither the listener nor the
//             world (ISOLATION_WORLD)
//
// The control runs again after the sibling, so a listener that died is not taken for a kept-apart pair. Its
// verdict is kept as docker's is (an EngineIsolation of this probe): one that holds for the process, a
// refusal for ISOLATION_RECHECK_MS; a probe that could not run rejects with a SandboxError and is run again
// by the next ask. A refusal's faults are the k8s driver's own (types.ts IsolationFault): policy_not_enforced (an
// egress pod reached another) and trial_pod_escapes (a pod on a trial's network got past it); its verdicts say
// driver k8s.
//
// k8s.ts imports this module for K8sSandbox and this one k8s.ts for its kubectl helpers: nothing here reads
// a k8s.ts binding as the module loads, only once called.

import { randomBytes } from 'node:crypto';
import { imageFor, type ImageTableT } from '../images.ts';
import { CONTAINER_LABEL } from './docker.ts';
import {
  awaitPod,
  CONTAINER,
  deleteObjects,
  isolationPodSpec,
  kubectl,
  labelValue,
  ownerAnnotations,
  ownerLabel,
  POD_PREFIX,
  podName,
  readPod,
  why,
  type K8sContext,
  type K8sObject,
  type KubectlResult,
  type PodPlacement,
} from './k8s.ts';
import {
  EGRESS_LABEL,
  EngineIsolation,
  ISOLATION_LISTENER_S,
  ISOLATION_LISTENER_SCRIPT,
  ISOLATION_PROBE_MS,
  ISOLATION_REACH_SCRIPT,
  ISOLATION_RECHECK_MS,
  NETWORK_EXISTS_HINT,
  NETWORK_LABEL,
  OWNER_LABEL,
  parseDockerTime,
  readReach,
  REAP_ROUNDS,
  SERVICE_PORT,
  STALE_AFTER_MS,
  trialNetworkName,
  type DriverVerdict,
  type Reach,
} from './network.ts';
import { SandboxError, TRIAL_NETWORK_PREFIX, type IsolationVerdict, type ReapResult, type SweepResult, type TrialNetworks } from './types.ts';

/** The namespace's egress policy (deploy/k8s/base/networkpolicies.yaml): what ensureEgress checks is there. */
export const EGRESS_POLICY = 'makefun-sandbox-egress';
/** Where the isolation probe's inside pod must not get to: an address the world answers on (README e1). */
export const ISOLATION_WORLD: Readonly<{ host: string; port: number }> = Object.freeze({ host: '1.1.1.1', port: 443 });
/** The kubectl resource name of a NetworkPolicy, as `-o name` prints it. */
const POLICY_RESOURCE = 'networkpolicy.networking.k8s.io';
const NOT_FOUND_RE = /\(NotFound\)|not found/i;
const EXISTS_RE = /\(AlreadyExists\)|already exists/i;

/**
 * Trial `trial`'s NetworkPolicy (the header's): its pods reach one another, both ways, and nothing else it
 * allows. Labelled with its owner's label when one is given (ownerLabel: what reap finds it by), and
 * annotated with the owner whole.
 */
export function trialPolicy(trial: string, opts: { namespace: string; owner: string | null }): K8sObject {
  const name = trialNetworkName(trial);
  const net = labelValue(trial, 'trial');
  const [graderKey, graderValue] = CONTAINER_LABEL.split('=') as [string, string];
  const labels: Record<string, string> = { [graderKey]: graderValue, [NETWORK_LABEL]: net };
  if (opts.owner !== null) labels[OWNER_LABEL] = ownerLabel(opts.owner);
  const annotations = ownerAnnotations(opts.owner);
  const peers = () => ({ podSelector: { matchLabels: { [NETWORK_LABEL]: net } } });
  return {
    apiVersion: 'networking.k8s.io/v1',
    kind: 'NetworkPolicy',
    metadata: { name, namespace: opts.namespace, labels, ...(annotations === undefined ? {} : { annotations }) },
    spec: {
      podSelector: { matchLabels: { [NETWORK_LABEL]: net } },
      policyTypes: ['Ingress', 'Egress'],
      ingress: [{ from: [peers()] }],
      egress: [{ to: [peers()] }],
    },
  };
}

export interface K8sTrialNetworksOptions {
  /** kubectl in the sandbox's namespace, and its PodNames (K8sSandbox's). */
  ctx: K8sContext;
  /** Where the isolation probe's pods run: the sandbox's own placement. */
  placement: PodPlacement;
  /** The image table the probe's node22 image comes from. */
  images: ImageTableT;
  /** Age past which sweepStale removes a grader pod or policy (default STALE_AFTER_MS). */
  staleAfterMs?: number;
  /** The clock (default Date.now). */
  now?: () => number;
  /** Each reach's budget in the isolation probe (default ISOLATION_PROBE_MS). */
  probeMs?: number;
  /** How long a refusal is kept before the probe runs again (default ISOLATION_RECHECK_MS). */
  recheckMs?: number;
  /** Where the probe's inside pod must not get to (default ISOLATION_WORLD). */
  world?: { host: string; port: number };
}

/** The k8s driver's TrialNetworks (the header's). */
export class K8sTrialNetworks implements TrialNetworks {
  readonly #opts: K8sTrialNetworksOptions;
  readonly #isolation: EngineIsolation;

  constructor(opts: K8sTrialNetworksOptions) {
    this.#opts = opts;
    this.#isolation = new EngineIsolation({ probe: () => this.#probe(), recheckMs: opts.recheckMs, now: opts.now });
  }

  get #ctx(): K8sContext {
    return this.#opts.ctx;
  }

  async create(trial: string, opts: { owner: string | null }): Promise<string> {
    const policy = trialPolicy(trial, { namespace: this.#ctx.namespace, owner: opts.owner });
    const name = policy.metadata.name;
    const r = await kubectl(this.#ctx, ['create', '-f', '-'], { input: JSON.stringify(policy) });
    if (failed(r)) {
      const hint = r.error === undefined && EXISTS_RE.test(r.stderr) ? NETWORK_EXISTS_HINT : '';
      throw new SandboxError(`kubectl could not create network policy ${name}: ${why(r)}${hint}`);
    }
    this.#ctx.names.forget(name);
    if (opts.owner !== null) this.#ctx.names.setOwner(name, opts.owner);
    return name;
  }

  /** Every pod still on the trial's network first (the harness kills its own: this is the backstop), then its policy; either gone already is fine. */
  async remove(trial: string): Promise<void> {
    const name = trialNetworkName(trial);
    const net = labelValue(trial, 'trial');
    const pods = await kubectl(this.#ctx, ['delete', 'pods', '-l', `${NETWORK_LABEL}=${net}`, '--ignore-not-found', '--grace-period=0', '--force', '--wait=false']);
    const policy = await kubectl(this.#ctx, ['delete', `networkpolicy/${name}`, '--ignore-not-found']);
    this.#ctx.names.forget(name);
    const problems = [...(failed(pods) ? [`its pods: ${why(pods)}`] : []), ...(failed(policy) ? [`its policy: ${why(policy)}`] : [])];
    if (problems.length > 0) throw new SandboxError(`kubectl could not remove network ${name} (${problems.join('; ')})`);
  }

  /**
   * Every pod and policy labelled makefun.trial=<ownerLabel(owner)> (an exact match, the label every object of
   * the owner's was made with; what is no trial owner is a SandboxError), listed, deleted, and listed again:
   * REAP_ROUNDS deletes in all while any is left (one made meanwhile). Never throws for what it could not list
   * or delete: the result says.
   */
  async reap(owner: string): Promise<ReapResult> {
    const selector = `${OWNER_LABEL}=${ownerLabel(owner)}`;
    const res: ReapResult = { owner, containers: [], networks: [], errors: [] };
    for (let round = 0; ; round++) {
      const ls = await kubectl(this.#ctx, ['get', 'pods,networkpolicies', '-l', selector, '-o', 'name']);
      if (failed(ls)) {
        res.errors.push(`kubectl get pods,networkpolicies -l ${selector}: ${why(ls)}`);
        return res;
      }
      const left = lines(ls.stdout);
      if (left.length === 0) return res;
      if (round === REAP_ROUNDS) {
        res.errors.push(`${left.join(' ')} still there (after ${REAP_ROUNDS} tries)`);
        return res;
      }
      const del = await kubectl(this.#ctx, ['delete', 'pods,networkpolicies', '-l', selector, '--ignore-not-found', '--grace-period=0', '--force', '--wait=false', '-o', 'name']);
      record(res, lines(del.stdout));
      if (failed(del)) res.errors.push(`kubectl delete pods,networkpolicies -l ${selector}: ${why(del)}`);
    }
  }

  /** The namespace's egress policy is there and is the grader's; the worker never makes it (its Role may not). */
  async ensureEgress(): Promise<void> {
    await ensureEgressPolicy(this.#ctx);
  }

  /**
   * Every grader pod (makefun-sbx-*) and grader policy (a trial's, or a forwarder's makefun-sbx-*-llm) older
   * than staleAfterMs: what a crashed grader left. Never throws for one it could not remove.
   */
  async sweepStale(): Promise<SweepResult> {
    const res: SweepResult = { containers: [], networks: [], errors: [] };
    const cutoff = (this.#opts.now ?? Date.now)() - (this.#opts.staleAfterMs ?? STALE_AFTER_MS);
    const ls = await kubectl(this.#ctx, ['get', 'pods,networkpolicies', '-l', CONTAINER_LABEL, '-o', 'json']);
    if (failed(ls)) {
      res.errors.push(`kubectl get pods,networkpolicies -l ${CONTAINER_LABEL}: ${why(ls)}`);
      return res;
    }
    let items: unknown;
    try {
      items = (JSON.parse(ls.stdout) as { items?: unknown }).items;
    } catch {
      items = undefined;
    }
    if (!Array.isArray(items)) {
      res.errors.push(`kubectl get pods,networkpolicies printed no list: ${JSON.stringify(ls.stdout.slice(0, 200))}`);
      return res;
    }
    const stale: string[] = [];
    for (const item of items as Array<{ kind?: unknown; metadata?: { name?: unknown; creationTimestamp?: unknown } }>) {
      const name = item?.metadata?.name;
      const ref = item?.kind === 'Pod' ? 'pod' : item?.kind === 'NetworkPolicy' ? 'networkpolicy' : null;
      if (ref === null || typeof name !== 'string') continue;
      if (!name.startsWith(POD_PREFIX) && !(ref === 'networkpolicy' && name.startsWith(TRIAL_NETWORK_PREFIX))) continue;
      const created = parseDockerTime(item.metadata?.creationTimestamp);
      if (created === null) res.errors.push(`${ref}/${name}: no creation time`);
      else if (created < cutoff) stale.push(`${ref}/${name}`);
    }
    if (stale.length === 0) return res;
    const del = await kubectl(this.#ctx, ['delete', ...stale, '--ignore-not-found', '--grace-period=0', '--force', '--wait=false', '-o', 'name']);
    record(res, lines(del.stdout));
    if (failed(del)) res.errors.push(`kubectl delete ${stale.join(' ')}: ${why(del)}`);
    return res;
  }

  isolation(): Promise<IsolationVerdict> {
    return this.#isolation.verdict();
  }

  #probe(): Promise<DriverVerdict> {
    const { image, digest } = imageFor('node22', this.#opts.images);
    return probeK8sIsolation({
      ctx: this.#ctx,
      placement: this.#opts.placement,
      image,
      digest,
      probeMs: this.#opts.probeMs ?? ISOLATION_PROBE_MS,
      world: this.#opts.world ?? ISOLATION_WORLD,
    });
  }
}

/** The namespace's egress policy, checked (ensureEgress); a SandboxError naming the bootstrap when it is missing or not the grader's. */
export async function ensureEgressPolicy(ctx: K8sContext): Promise<void> {
  const r = await kubectl(ctx, ['get', `networkpolicy/${EGRESS_POLICY}`, '-o', 'json']);
  if (failed(r)) {
    if (r.error === undefined && NOT_FOUND_RE.test(r.stderr)) {
      throw new SandboxError(`network policy ${EGRESS_POLICY} is missing from namespace ${ctx.namespace}, so no forwarder or gateway can reach out: run \`makefun-k8s.sh bootstrap\` (deploy/k8s/base/networkpolicies.yaml)`);
    }
    throw new SandboxError(`kubectl could not read network policy ${EGRESS_POLICY}: ${why(r)}`);
  }
  type Policy = { spec?: { podSelector?: { matchLabels?: Record<string, unknown> }; policyTypes?: unknown } };
  let policy: Policy | null = null;
  try {
    policy = JSON.parse(r.stdout) as Policy | null;
  } catch {
    policy = null;
  }
  const [key, value] = EGRESS_LABEL.split('=') as [string, string];
  const types = policy?.spec?.policyTypes;
  if (policy?.spec?.podSelector?.matchLabels?.[key] !== value || !Array.isArray(types) || !types.includes('Egress')) {
    throw new SandboxError(
      `network policy ${EGRESS_POLICY} exists but is not the grader's egress policy (podSelector ${JSON.stringify(policy?.spec?.podSelector ?? null)}, policyTypes ${JSON.stringify(types ?? null)}): run \`makefun-k8s.sh bootstrap\` (deploy/k8s/base/networkpolicies.yaml)`,
    );
  }
}

export interface K8sIsolationOptions {
  ctx: K8sContext;
  placement: PodPlacement;
  /** The probe's node22 image and its digest. */
  image: string;
  digest: string;
  /** Each reach's budget. */
  probeMs: number;
  /** Where the inside pod must not get to. */
  world: { host: string; port: number };
}

/**
 * The cluster's verdict on keeping trials apart (the header's four roles); a SandboxError when it could not
 * find out. Removes what it made, whatever happens.
 */
export async function probeK8sIsolation(o: K8sIsolationOptions): Promise<DriverVerdict> {
  const ctx = o.ctx;
  const engine = await clusterEngine(ctx, o.placement.runtimeClass);
  await ensureEgressPolicy(ctx);
  const trial = `isolation-${randomBytes(4).toString('hex')}`;
  const pods = { listener: podName('isolation'), sibling: podName('isolation'), inside: podName('isolation') };
  const sleep = ['sleep', 'infinity'];
  const spec = (name: string, trialOf: string | null, egress: boolean, command: readonly string[]) =>
    isolationPodSpec({ ...o.placement, name, image: o.image, digest: o.digest, trial: trialOf, egress, command });
  const objects = [
    trialPolicy(trial, { namespace: ctx.namespace, owner: null }),
    spec(pods.listener, null, true, ['node', '-e', ISOLATION_LISTENER_SCRIPT, String(ISOLATION_LISTENER_S)]),
    spec(pods.sibling, null, true, sleep),
    spec(pods.inside, trial, false, sleep),
  ];
  const refs = [`pod/${pods.listener}`, `pod/${pods.sibling}`, `pod/${pods.inside}`, `networkpolicy/${trialNetworkName(trial)}`];
  try {
    const made = await kubectl(ctx, ['create', '-f', '-'], { input: JSON.stringify({ apiVersion: 'v1', kind: 'List', items: objects }) });
    if (failed(made)) throw new SandboxError(`kubectl could not create the isolation probe's pods: ${why(made)}`);
    const roles = Object.entries(pods);
    const ready = await Promise.all(roles.map(([, pod]) => awaitPod(ctx, pod, 'Ready', ctx.readyTimeoutMs)));
    ready.forEach((w, i) => {
      if (!w.ok) throw new SandboxError(`the isolation probe's ${roles[i]![0]} pod ${roles[i]![1]} never became ready: ${w.why}`);
    });
    const ip = await podIp(ctx, pods.listener);
    const at = `${ip}:${SERVICE_PORT}`;
    const reach = (pod: string, host: string, port: number, what: string) => reachIn(ctx, pod, host, port, o.probeMs, what);
    const fix = 'enforce NetworkPolicies on the cluster (k3s: its embedded network policy controller, never --disable-network-policy; or a CNI that enforces them) and apply deploy/k8s/base/networkpolicies.yaml (makefun-k8s.sh bootstrap)';

    const control = await reach(pods.listener, ip, SERVICE_PORT, 'control');
    if (!control.reached) throw new SandboxError(`the isolation probe's listener did not answer at its own address ${at} (${control.how}): the probe proves nothing`);
    const sibling = await reach(pods.sibling, ip, SERVICE_PORT, 'sibling');
    if (sibling.reached) {
      return {
        enforced: false,
        driver: 'k8s',
        engine,
        fault: 'policy_not_enforced',
        reason: `a pod under ${EGRESS_POLICY} reached another (${at}), so concurrent trials' forwarders and gateways reach one another: the namespace's NetworkPolicies are not enforced`,
        fix,
      };
    }
    const again = await reach(pods.listener, ip, SERVICE_PORT, 'control');
    if (!again.reached) throw new SandboxError(`the isolation probe's listener stopped answering at ${at} (${again.how}): the sibling's result proves nothing`);
    const inside = await reach(pods.inside, ip, SERVICE_PORT, 'inside');
    const world = inside.reached ? null : await reach(pods.inside, o.world.host, o.world.port, 'inside');
    if (inside.reached || world?.reached === true) {
      const where = inside.reached ? `an egress pod (${at})` : `${o.world.host}:${o.world.port}`;
      return {
        enforced: false,
        driver: 'k8s',
        engine,
        fault: 'trial_pod_escapes',
        reason: `a pod on a trial's network (NetworkPolicy ${trialNetworkName(trial)}) reached ${where} past it, so a trial's entry is not kept to its trial`,
        fix,
      };
    }
    return {
      enforced: true,
      driver: 'k8s',
      engine,
      detail: `an egress pod did not reach another (${at}: ${sibling.how}); a pod on a trial's network reached neither it (${inside.how}) nor ${o.world.host}:${o.world.port} (${world!.how})`,
    };
  } finally {
    await deleteObjects(ctx, refs);
  }
}

/** One reach of the probe, by exec in `pod` (ISOLATION_REACH_SCRIPT): what it found, or a SandboxError when it did not run. */
async function reachIn(ctx: K8sContext, pod: string, host: string, port: number, ms: number, what: string): Promise<Reach> {
  const r = await kubectl(ctx, ['exec', pod, '-c', CONTAINER, '--', 'node', '-e', ISOLATION_REACH_SCRIPT, host, String(port), String(ms)]);
  if (failed(r)) throw new SandboxError(`the isolation probe's ${what} did not run: ${why(r)}`);
  return readReach(r.stdout, what);
}

/** The listener's pod address, once Ready. */
async function podIp(ctx: K8sContext, pod: string): Promise<string> {
  const read = await readPod(ctx, pod);
  const ip = 'pod' in read ? read.pod.status?.podIP : undefined;
  if (typeof ip !== 'string' || ip === '') throw new SandboxError(`the isolation probe's listener pod ${pod} is ready without an IP (${'pod' in read ? 'none in its status' : 'gone' in read ? read.gone : read.error})`);
  return ip;
}

/** What the verdict calls the cluster: its server version and the pods' RuntimeClass. */
async function clusterEngine(ctx: K8sContext, runtimeClass: string | null): Promise<string> {
  const r = await kubectl(ctx, ['version', '-o', 'json']);
  let version: unknown;
  try {
    version = (JSON.parse(r.stdout) as { serverVersion?: { gitVersion?: unknown } }).serverVersion?.gitVersion;
  } catch {
    version = undefined;
  }
  if (failed(r) || typeof version !== 'string') throw new SandboxError(`kubectl version gave no server version: ${failed(r) ? why(r) : JSON.stringify(r.stdout.slice(0, 200))}`);
  return `${version}, RuntimeClass ${runtimeClass ?? 'none'}`;
}

/** Each `kind/name` kubectl printed into the result: pods as containers, policies as networks. */
function record(res: { containers: string[]; networks: string[] }, refs: readonly string[]): void {
  for (const ref of refs) {
    const slash = ref.indexOf('/');
    const [kind, name] = [ref.slice(0, slash), ref.slice(slash + 1)];
    if (slash < 0 || name === '') continue;
    if (kind === 'pod' && !res.containers.includes(name)) res.containers.push(name);
    else if (kind === POLICY_RESOURCE && !res.networks.includes(name)) res.networks.push(name);
  }
}

function failed(r: KubectlResult): boolean {
  return r.code !== 0 || r.error !== undefined;
}

function lines(s: string): string[] {
  return s
    .split('\n')
    .map((l) => l.trim())
    .filter((l) => l !== '');
}
