// The Kubernetes sandbox (MAKEFUN_SANDBOX=k8s): docker.ts's twin on a cluster. Every program is a
// one-shot pod in the worker's namespace, under the gVisor RuntimeClass, driven through kubectl with the
// worker's own service-account token (in-cluster: no kubeconfig) and the Role in deploy/k8s/base/rbac.yaml.
// A program is three calls (five at most), then one delete:
//
//   kubectl -n <ns> create -f -                        the pod (sandboxPodSpec) as a List, after the
//                                                      forwarder's gateway policy when it has one
//   kubectl -n <ns> create -f -                        its env Secret when it has one, after the pod and
//                                                      owned by it (ownedByPod: the pod's uid, which the
//                                                      first create printed, -o CREATED_JSONPATH)
//   kubectl -n <ns> wait --for=condition=Ready pod/<pod>
//   kubectl -n <ns> exec <pod> -c main -- <POLICY_WAIT_ARGV> ...   an entry's policy wait (below)
//   kubectl -n <ns> exec -i <pod> -c main -- /bin/sh -c <EXEC_WRAPPER> sh <pids> <argv...>
//                                                      (a timed pod's TIMED_EXEC_WRAPPER: Timing, below)
//   kubectl -n <ns> delete pod/<pod> [secret/<pod>-env] [networkpolicy/<pod>-llm] --grace-period=0 --force
//
// The Secret comes second so a worker that dies between the two creates leaves nothing it could not find:
// the Role may create and delete Secrets but not list them (a list returns their data), and Kubernetes'
// garbage collector deletes an owned Secret with its pod. Until it exists the pod waits in
// CreateContainerConfigError, which the Ready wait sees through. The Secret holds the spec's *_API_KEY env
// values and every one of its secrets (sandboxEnvSecret); its values reach kubectl on stdin alone, and a
// failure to create it is said with every value taken out (withoutValues).
//
// The pod's own command is `sleep infinity` (a served pod's is the policy listener, below): the program arrives
// by exec into a pod already Ready, never as the pod's command, so it never runs before the namespace's
// default-deny policy holds (deploy/k8s/README.md, measured on k3s+gVisor: a fresh pod's first connect got
// out in 2 of 9 starts before Ready, none of 2623 after it) and nothing races an attach (containerd#14476).
// Never `kubectl run` (its --rm prints `pod "x" deleted` on stdout) and never `attach`. kubectl's stderr is
// never read as a failure: the API server's Pod Security warnings land there for the root meter and launcher
// pods; exit codes and the sentinel below are the only verdicts.
//
// The pod (sandboxPodSpec) is dockerRunArgs in pod form:
//
//   name makefun-sbx-<label>-<8 hex> (at most 62 characters: a pod name is also its hostname)
//   labels makefun.grader=1, makefun.io/role=sandbox (the namespace's default-deny selects it),
//     makefun.pod=<name>, makefun.io/sandbox=program|meter|reclaim|preflight|isolation|race, and when networked
//     makefun.net=<trial>, makefun.trial=<ownerLabel(owner)> (PodNames), makefun.egress=1 (the egress policy
//     selects it); with an owner, the annotation makefun.io/trial-owner=<owner> (OWNER_ANNOTATION); made by a process
//     that names its own pod (K8sSandboxOptions.creator, POD_NAME), the annotation makefun.io/creator=<that pod>
//     (CREATOR_ANNOTATION: Reaping, below)
//   runtimeClassName <runtime class>, nodeSelector, serviceAccountName <sandbox account> with
//     automountServiceAccountToken false, enableServiceLinks false, restartPolicy Never,
//     activeDeadlineSeconds STALE_AFTER_MS (the backstop for a pod no delete reached; a race pod's its lifetime, below),
//     terminationGracePeriodSeconds 0
//   dnsPolicy None, nameserver 127.0.0.1, ndots 0: no DNS at all (`--network none`'s twin); an egress pod
//     ClusterFirst with ndots 0 (Docker's embedded resolver sets it too); a networked pod's peers by
//     hostAliases (PodNames: every other registered name of its network, Docker's aliases; a pod registers
//     once Ready, so the harnesses' order, services before their entry, gives the entry all of them)
//   runAsUser/Group 65534, runAsNonRoot, seccomp RuntimeDefault; a launcher's or a timed pod's 0:0 with SETUID
//     SETGID KILL (Timing, below)
//   one container `main`: <image>@<digest>, imagePullPolicy Never, `sleep infinity` (a served pod's
//     POLICY_LISTENER_COMMAND), env SANDBOX_ENV then the spec's env (any *_API_KEY from the Secret <pod>-env by
//     secretKeyRef, so no key sits in the pod spec), then every one of the spec's secrets from that Secret the
//     same way (types.ts checkSandboxSecrets: no value sits in the pod spec, a kubectl argv or a message),
//     limits cpu <cpus>, memory <memory_mb>Mi; requests memory = limit, cpu min(limit, 250m) (a timed pod's the limit);
//     allowPrivilegeEscalation false, readOnlyRootFilesystem, capabilities drop ALL
//   /bot (the code dir, ro), the spec's mounts at their MOUNT_POINTS, /house (a launcher's, ro): each a
//     subPath of the data PVC, which the worker mounts at the data root (a host path outside it is refused:
//     a bundle's own trees, read from the image's competitions/, are staged onto the claim first,
//     bundle-trees.ts); /tmp an emptyDir of medium Memory, 256Mi (a gVisor-internal tmpfs; ENOSPC at its size)
//
// A race's racer (a spec's `race`, grader/race.ts runRacer: one program for a whole race window, types.ts's header)
// differs in four places, everything else kept: labels makefun.pod=<name>, makefun.io/role=sandbox and
// makefun.io/sandbox=race only, no makefun.grader=1, so no sweep or reap that lists the grader's objects by it
// (k8s-network.ts sweepStale's STALE_AFTER_MS, `makefun-k8s.sh reap`) ever takes it; activeDeadlineSeconds its
// lifetime (race.lifetimeMs, rounded up to whole seconds) in place of STALE_AFTER_MS, so the kubelet ends it there
// whatever became of its racer; requests cpu min(limit, RACE_CPU_REQUEST_MILLI) (it idles between bars), memory the
// limit as ever. It has no network, mount, env, secret or Secret (types.ts checkSandboxRace), and is never a timed pod.
//
// Docker's --pids-limit has no pod twin (the kubelet's pids cgroup is per node, not per pod), so the wrapper
// sets `ulimit -u` to the program's pids plus the pod's own two tasks (PID 1 and the wrapper): measured to
// hold under gVisor, whose kernel is the pod's alone. Under no RuntimeClass (runc) a uid's process count is
// the node's, shared by every sandbox pod, so there is no cap there (pids 0).
//
// The exec (EXEC_WRAPPER, dash as the images' /bin/sh) reads a 128-bit nonce from the first line of its
// stdin, so the program can read it from no argv, environment or file; unsets the eight KUBERNETES_*
// variables the kubelet sets in every container even with enableServiceLinks false, so the program's
// environment is docker's (the image's own, SANDBOX_ENV, the spec's); caps processes; traps TERM (so
// terminate()'s `kill -TERM -1` reaches the program and not the wrapper); prints the start line
// `RS<nonce>\n` (RS the byte 036) as the first bytes of its stdout; runs the program in a subshell with the
// real stderr (the wrapper's own, dash's "Killed" included, goes to /dev/null); then kills everything else
// in the pod, as a container's end kills what its program left, and prints `RS<nonce><status>\n`. The
// status is the program's (128+n for a signal, as docker reports it). stdout is passed on through
// SentinelScanner, which strips the start line and the sentinel (even with no newline before it) and holds
// back only output that ends in what could start the sentinel (RS and the nonce's first digits), so a
// service's `ready` line is never held; stdin written before the exec opens is held until it does. The
// start line is the process's `started`: the program's wall budget (Supervisor) runs from it, not from the
// pod's create, its Ready or the exec's handshake, none of which is the program's time; an exec that has
// not printed it EXEC_START_TIMEOUT_MS after its spawn is a driver failure.
//
// No sentinel (the exec cut off, kubernetes#142461, or the pod gone): the pod is read. OOMKilled is 137
// (gVisor ends the whole sandbox when the pod's limit is hit; under runc the kernel kills the program and
// the sentinel says 137), so is a program kill() ended, and anything else (ErrImageNeverPull, Unschedulable,
// no Ready in time, the exec lost) is K8S_DRIVER_FAILURE with an error naming the pod and what its status
// says. kill() kills the local exec, everything in the pod (`kill -KILL -1`, so nothing of the program
// outlives the kill), then deletes; every pod is deleted once its program has exited.
//
// Room on the node. A pod the scheduler finds no room for stays Pending, PodScheduled False with reason
// Unschedulable and words naming what ran out (`Too many pods`: the kubelet's maxPods, which every namespace's pods
// share, prod's, dev's and the races' alike; `Insufficient cpu|memory|…`: the requests); a create a ResourceQuota
// refuses says `exceeded quota`. Such a pod waits for room within the same ready budget (readyTimeoutMs) as any
// Pending pod, and one still short of room at its end fails as any driver failure does, its process marked
// (K8sProcess.noRoom, noRoomOf; a preflight's NodeRoomError; a /output meter's, handed to TreeMeterOptions.onFault and
// thrown as meterFailure makes it) so that a caller can tell backpressure from a fault: grader/agent.ts makes it a node_capacity void, which grader/worker.ts never counts as a pass, handing the trial back.
// Before a job takes its pods at all, the node's free pod slots are read (K8sSandbox.nodePodRoom: each node the
// selector picks, its status.allocatable.pods less the pods bound to it in every namespace): server/jobs.ts waits on
// it before a job takes its sandbox pod budget, and the trial handler hands a trial on while the node lacks room for
// it. That read needs get/list on nodes and list on pods across namespaces, which the namespaced Role in
// deploy/k8s/base/rbac.yaml does not grant: refused, it says so once and answers unknown, and only the scheduler's
// verdict on each pod holds the node.
//
// Reaping a dead creator's pods. A pod outlives the process that made it when that process dies with it running (a
// rollout's old grader killed past its grace, a crash, an eviction): `sleep infinity` holds its node slot until
// activeDeadlineSeconds, six hours, or until the stale sweep (k8s-network.ts sweepStale, STALE_AFTER_MS) at some grader's
// next start. A namespace holds several such processes at once (two graders, the worker, the racer), so none may take
// what it did not make on that ground alone: each pod names its maker instead. A process given its own pod's name
// (K8sSandboxOptions.creator: server/config.ts reads POD_NAME, which deploy/k8s/base's grader, worker and racer set from
// the downward API) annotates every pod it makes with it, CREATOR_ANNOTATION, and reaps (K8sSandbox.reapOrphans) at
// its start and every ORPHAN_REAP_EVERY_MS after: it lists the namespace's sandbox pods (makefun.io/role=sandbox, as
// JSON) and the namespace's pods not finished (`-o name`, phase neither Succeeded nor Failed: an evicted pod's object
// stays, its process gone), and deletes (deleteObjects: the pod, its `<pod>-env` Secret and `<pod>-llm` policy, and its
// trial's makefun-net-<trial> policy when no pod kept is on that trial) every sandbox pod whose creator is not among
// them and that is older than ORPHAN_GRACE_MS, so a pod whose maker is still starting is never taken. A pod with no
// creator annotation (made by a process with no POD_NAME, or by a release from before it) is never taken, and only
// this namespace is ever listed. A listing that does not hold the reaping process's own pod is not trusted (its
// POD_NAME is no pod of this namespace's) and reaps nothing. It is an annotation, not a label: the cluster kit's
// admission policy (deploy/k8s/cluster/admission-policy.yaml) admits podLabels' keys and no other on a worker's pod.
// The trial's own reap by owner (k8s-network.ts reap) is never used here: a dead grader's trial may already be graded
// again under the same owner by a live one. What this cannot see: a process whose container restarted inside the same
// pod keeps its name, so what its first run left waits for the stale sweep. The six-hour sweep stays the backstop.
//
// Its own pod's deletion deadline. A grader that drains on SIGTERM (server/server.ts drainJobsInHand) asks, every
// DRAIN_DEADLINE_READ_MS while it drains, when its own pod (the creator) is to be gone (K8sSandbox.ownDeletion: `kubectl
// get pod/<creator> -o jsonpath={.metadata.deletionTimestamp}`, the Role's `get` on pods): a rollout's delete sets it
// the pod's grace on, a deploy's cut (makefun-k8s.sh GRADER_STOP_GRACE) moves it to 30 s on, and the drain ends in time
// for its shutdown before it (server/server.ts watchOwnDeletion). An answer that the token is refused (TOKEN_REFUSED_RE:
// kubectl's `You must be logged in to the server (Unauthorized)`, which the API server answers a pod's token from a
// minute past that deadline) says nothing more can be done through the API, and ends the drain at once.
//
// The forwarder of an agent trial reaches masq (MAKEFUN_LLM_GATEWAY_SANDBOX_URL) as docker's does from the
// egress bridge. The namespace's egress policy keeps a sandbox off the fleet's own servers and every
// private range, where masq may sit, so a forwarder pod also gets a NetworkPolicy of its own,
// <pod>-llm (gatewayPolicy): egress to the gateway's addresses on its port and nothing else.
//
// A trial's owner (network.ts TRIAL_OWNER_RE: up to 128 characters, a scrape trial's
// `scrape-<heat>.<entry>.<round>` 65 and more) need not be a label value, which is at most 63 characters,
// alphanumeric at both ends. Its makefun.trial label is ownerLabel(owner): the owner itself when it is one
// (every agent trial's), else `h-` and the first 40 hex of its sha256. Every object of the trial's (its
// policy, its pods, a pod's Secret and gateway policy) and the reap's selector take that one function, so
// what is labelled is what is found, and an owner short enough keeps the label it had before; each object
// carries the owner whole as the annotation makefun.io/trial-owner (OWNER_ANNOTATION), for whoever reads it.
//
// A trial's network is a NetworkPolicy, makefun-net-<trial> (k8s-network.ts K8sTrialNetworks, made before
// any of the trial's pods): its pods (makefun.net=<trial>) reach one another and nothing else beyond what the
// namespace's policies allow. Before an entry's program runs, the policy wait measures that it holds for the
// pod: from inside it, in its own interpreter (POLICY_WAIT_ARGV), each service its hostAliases name (the
// served peers: PodNames.served) takes a connection within POLICY_WAIT_MS, or the spawn is the driver's
// failure. Only the entry waits: it is spawned once its services are ready (listening), and it dials them
// as it starts. It dials each one's POLICY_PORT, never the port its program serves: a served pod's PID 1 is
// the policy listener there (POLICY_LISTENER_COMMAND: accept, close), so the wait is no connection of the
// program's (a scrape gateway records every connection it accepts in its cassette, and counts it against
// max_connections; docker has no wait). The trial policy names no port, so the listener answering is the
// served port being allowed too.
//
// The meter (meterTree) and the reclaim (removeTree) are docker.ts's scripts exec'd the same way: the
// meter as root with only DAC_OVERRIDE (Pod Security baseline refuses docker's DAC_READ_SEARCH;
// DAC_OVERRIDE reads a mode-000 tree as well, measured), its tree mounted read-only at /measure; the
// reclaim as 65534 with its tree read-write at /reclaim. preflight is a pod that runs `true` in the image
// under the same RuntimeClass, account and node selector, once per runtime and digest per process, and
// `kubectl auth can-i create pods --subresource=exec`.
//
// Timing (a program/v1 timing heat, grader/code-heat.ts; docker.ts's header has docker's clock): openCpuClock hands
// back a clock (K8sCpuClock) and a timed sandbox (K8sTimedSandbox), whose every program pod is a timed pod
// (SandboxPodOptions.timed): root with the launcher's SETUID, SETGID and KILL, as a scrape launcher's pod is, and its
// CPU limit (CODE_HEAT_CPUS, one) its request too, so the node reserves the whole CPU the run is held to. Its meter and
// reclaim pods are untimed, as docker's never take the timing parent. The program arrives by exec as every program
// does (never the pod's command: the default-deny race above), under TIMED_EXEC_WRAPPER, which is EXEC_WRAPPER with
// the house's CPU launcher (CPU_LAUNCHER_SCRIPT: perl, as perl-base is in both pinned images) between it and the
// program. The launcher makes itself the child subreaper of its tree (prctl PR_SET_CHILD_SUBREAPER), so whatever the
// program orphans is reparented to it and never escapes; forks the program as 65534:65534 with no supplementary group;
// waits for it; then SIGKILLs every descendant still alive (found by /proc's parent links) in rounds until it has
// reaped them all, and reports getrusage(RUSAGE_CHILDREN), user plus system in µs, on descriptor 4: the CPU of every
// process the program started, forked, detached or outliving it, each folded in as it was reaped. Descriptor 4 is the
// wrapper's command substitution, close-on-exec so the program never holds it, and the wrapper, root, prints the
// reading as `RS<nonce>c<µs>\n` before the sentinel. The program, 65534, can read neither the root wrapper's nonce nor
// the root launcher's descriptors, so it cannot forge the line. The launcher exits with the program's status (128+n
// for a signal). A launcher that cannot do its part (no subreaper, no report descriptor, a drop or exec that fails, a
// process that will not die) reports nothing and exits 125, and a timed exit with a sentinel and no reading is the
// driver's failure. gVisor counts each user's tasks apart (kernel.go UserCounters), and a timed pod's own tasks are
// root's, so the wrapper's cap (pids plus POD_OWN_TASKS, as for any pod) leaves the program, alone as 65534, its pids
// and those two more, as a scrape launcher's entry is left; root's own count reaches TIMED_ROOT_TASKS (PID 1, the
// wrapper, the launcher, the program before it drops), so a timed spawn under a RuntimeClass needs pids of at least
// TIMED_ROOT_TASKS less POD_OWN_TASKS.
//
// The clock is the sum of the readings of its timed sandbox's pods, each added once its process has exited; settled()
// waits for every one in flight (docker.ts CPU_CLOCK_READ_MS at most). A timed pod whose program ran and reported no
// reading (the exec lost, a kill that could not wait for it) faults the clock: every read after it throws SandboxError,
// so the heat stops rather than rank on a run counted short. One whose program never started adds 0. kill() of a timed
// process whose program runs first SIGKILLs every process of 65534 in its pod (TIMED_KILL_ARGV: what docker kill does
// to a container, the launcher aside), so the launcher still reaps and reports what the program spent up to its kill,
// as a docker timing parent keeps a killed container's CPU; only when no sentinel comes within TIMED_KILL_MS is the
// exec cut, as an untimed kill cuts it at once. The clock's source is `rusage-children k8s <runtime class|default>
// cpu-<12 hex>`, so code-heat.ts codeHeatClockKind's kind is its first three words.
//
// What gVisor reports, read from its source (google/gvisor master, 2026-11-06; no gVisor pod was run for this):
// getrusage RUSAGE_CHILDREN (pkg/sentry/syscalls/linux/sys_rusage.go, ThreadGroup.JoinedChildCPUStats, folded in at
// each wait in pkg/sentry/kernel/task_exit.go) and PR_SET_CHILD_SUBREAPER (sys_prctl.go; task_exit.go reparents an
// orphan to its nearest subreaper) behave as Linux's. The CPU times themselves are gVisor's estimate, not the host's:
// every 10 ms tick (linux.ClockTick) credits a whole tick to each of up to applicationCores tasks it finds running
// application or Sentry code (pkg/sentry/kernel/task_sched.go runCPUClockTicker), applicationCores being the pod's
// CPU quota rounded up but at least 2 (runsc --cpu-num-from-quota, on by default). So a reading is a multiple of 10 ms,
// a task the host preempted still accrues ticks, and two threads running at once both accrue them under a one-CPU
// quota. The cgroup would not read better: gVisor's cgroupfs is v1, its cpu controller's files are stubs (no cpu.stat
// usage_usec), and cpuacct.usage sums the same task estimates (fsimpl/cgroupfs/cpuacct.go); it would also need a
// cgroup of the launcher's own, which a read-only mount and no CAP_SYS_ADMIN deny. Under no RuntimeClass (runc) the
// reading is the host kernel's own accounting, to the µs. Every entry and the null-entry control are counted the same
// way on the same kind of clock, so the control still takes the fixed cost out of every run.

import { spawn } from 'node:child_process';
import { createHash, randomBytes } from 'node:crypto';
import { lookup as dnsLookup } from 'node:dns/promises';
import { rm } from 'node:fs/promises';
import { isIP } from 'node:net';
import { posix } from 'node:path';
import { PassThrough, type Readable, type Writable } from 'node:stream';
import { setTimeout as sleep } from 'node:timers/promises';
import { ENTRY_SECRET_VALUE_MIN_CHARS } from '../../contracts/entry-secrets.ts';
import { IMAGES, imageFor, imageRef, type ImageTableT } from '../images.ts';
import { HOUSE_DIR, LAUNCHER_ARGV } from '../scrape/launch.ts';
import {
  checkSandboxLabel,
  CONTAINER_LABEL,
  CPU_CLOCK_READ_MS,
  type CpuClock,
  formatCpus,
  houseFilesMissing,
  LAUNCHER_CAPS,
  METER_SLACK_MS,
  METER_STDERR_BYTES,
  METER_STOP_MS,
  MeterReadings,
  meterScript,
  positiveInt,
  RECLAIM_REFUSED,
  RECLAIM_SCRIPT,
  RECLAIM_TIMEOUT_MS,
  settlesWithin,
} from './docker.ts';
import { K8sTrialNetworks } from './k8s-network.ts';
import { checkTrialOwner, EGRESS_LABEL, NETWORK_LABEL, OWNER_LABEL, parseDockerTime, ROLE_ALIASES, SCRAPE_GATEWAY_PORT, SERVICE_PORT, STALE_AFTER_MS, trialNetworkName } from './network.ts';
import {
  checkHostPath,
  checkSandboxEnv,
  checkSandboxLauncher,
  checkSandboxNetwork,
  checkSandboxRace,
  checkSandboxSecrets,
  LeftoverError,
  MOUNT_POINTS,
  RUNTIME_COMMANDS,
  SANDBOX_ENV,
  SandboxError,
  scriptOf,
  TRIAL_NETWORK_PREFIX,
  type Runtime,
  type Sandbox,
  type SandboxExit,
  type SandboxNetwork,
  type SandboxProcess,
  type SandboxSpec,
  type SweepResult,
  type TreeMeter,
  type TreeMeterOptions,
} from './types.ts';

/** The exit code of a program the cluster could not run (docker run's own 125, DOCKER_RUN_FAILURE). */
export const K8S_DRIVER_FAILURE = 125;
/** The exit code of a program kill() ended, or the pod's memory limit did (OOMKilled): a SIGKILL's 128 + 9, as docker reports it. */
export const K8S_KILLED = 137;
/** Every sandbox pod's name starts so. */
export const POD_PREFIX = 'makefun-sbx-';
/** The one container of a sandbox pod. */
export const CONTAINER = 'main';
/** The label the namespace's sandbox policies select (deploy/k8s/base/networkpolicies.yaml). */
export const ROLE_LABEL = 'makefun.io/role';
/** The label naming a pod by its own name: what a pod's own policy (gatewayPolicy) selects it by. */
export const POD_LABEL = 'makefun.pod';
/** The label naming what a sandbox pod is for. */
export const SANDBOX_KIND_LABEL = 'makefun.io/sandbox';
/** The annotation holding a trial's owner whole on every object labelled with it (OWNER_LABEL holds ownerLabel of it). */
export const OWNER_ANNOTATION = 'makefun.io/trial-owner';
/** The annotation naming the pod of the process that made a sandbox pod (the header's Reaping): what reapOrphans reads. */
export const CREATOR_ANNOTATION = 'makefun.io/creator';
/** How old a sandbox pod whose creator is gone must be before reapOrphans takes it: a creator still starting is never short of its pods. */
export const ORPHAN_GRACE_MS = 2 * 60_000;
/** How often a process with a creator reaps (and once at its start). */
export const ORPHAN_REAP_EVERY_MS = 3 * 60_000;
/** An owner label that is a hash (ownerLabel): this, then the first OWNER_LABEL_HASH_HEX hex of the owner's sha256. */
export const OWNER_LABEL_HASH_PREFIX = 'h-';
export const OWNER_LABEL_HASH_HEX = 40;
export type SandboxPodKind = 'program' | 'meter' | 'reclaim' | 'preflight' | 'isolation' | 'race';
/** The CPU a race's pod asks to be scheduled with, at most (the header: it waits for each bar far longer than it thinks). */
export const RACE_CPU_REQUEST_MILLI = 50;
/** The env Secret's name is the pod's plus this; the gateway policy's, GATEWAY_POLICY_SUFFIX. */
export const ENV_SECRET_SUFFIX = '-env';
export const GATEWAY_POLICY_SUFFIX = '-llm';
/** A spec env variable whose value goes in the env Secret, never in the pod spec (every one of a spec's `secrets` does too). */
export const SECRET_ENV_RE = /_API_KEY$/;
/** /tmp's size, docker.ts's TMPFS_SIZE. */
export const TMP_SIZE = '256Mi';
/** The CPU a program's pod asks to be scheduled with, at most (its limit is the competition's). */
export const CPU_REQUEST_MAX_MILLI = 250;
/** The meter's, reclaim's, preflight's and the isolation probe's own limits: docker.ts's METER_CPUS and METER_MEMORY. */
export const AUX_CPU_MILLI = 500;
export const AUX_MEMORY = '256Mi';
/** The tasks of a pod's that count against the wrapper's process cap besides the program's: PID 1 (`sleep`, or the single-threaded policy listener) and the wrapper. */
export const POD_OWN_TASKS = 2;
/** Each kubectl call's budget (not the exec, which runs as long as its program). */
export const KUBECTL_TIMEOUT_MS = 60_000;
/** How long a pod may take to be Ready: its scheduling included (a node short of the requests holds it Pending). */
export const READY_TIMEOUT_MS = 120_000;
/** One `kubectl wait`'s budget, in seconds: between two, the pod is read for a failure that will never be Ready. */
export const WAIT_SLICE_S = 5;
/** The least time between two waits (one that failed at once: the pod read since). */
export const WAIT_PAUSE_MS = 500;
/** How long a pod whose exec ended without its sentinel is re-read for its status to settle (an OOM is reported a moment later). */
export const POD_SETTLE_MS = 3_000;
const POD_SETTLE_POLL_MS = 500;
/** How long the exec may stay open after the sentinel before it is cut off: the wrapper has nothing left to say. */
export const EXEC_DRAIN_MS = 5_000;
/**
 * How long the exec has, from its spawn, to print the wrapper's start line (the API server, the kubelet and
 * the runtime's exec in between): the program's budget only runs from it, so this bounds the wait instead.
 */
export const EXEC_START_TIMEOUT_MS = KUBECTL_TIMEOUT_MS;
/** How long a streamed kubectl's stdio may stay open after it exited (a child of its holding them) before they are closed. */
export const STDIO_GRACE_MS = 2_000;
/** The budget of the exec that signals everything in a pod (terminate, kill). */
export const SIGNAL_TIMEOUT_MS = 10_000;
/** How many times a delete is tried, DELETE_BACKOFF_MS apart and doubling, before it is warned of. */
export const DELETE_ATTEMPTS = 3;
export const DELETE_BACKOFF_MS = 250;
/** The preflight pod's budget, from create to Succeeded. */
export const PREFLIGHT_TIMEOUT_MS = 120_000;
/**
 * What a Pending pod's PodScheduled False message (reason Unschedulable), or a refused create's words, says when the node
 * had no room for it (the header's Room on the node): its pod slots (the kubelet's maxPods), a resource its requests
 * name, or a ResourceQuota. Anything else Unschedulable (a selector no node matches, a volume's node affinity) is not room.
 */
export const NO_ROOM_RE = /\bToo many pods\b|\bInsufficient [A-Za-z0-9./_-]+|\bexceeded quota\b/;
/** How long a node-wide pod room read (K8sSandbox.nodePodRoom) is answered from what it last read. */
export const NODE_ROOM_CACHE_MS = 2_000;
/** How long a refused node-wide read (no RBAC for nodes, or for pods across namespaces) is not tried again. */
export const NODE_ROOM_REFUSED_MS = 10 * 60_000;
/**
 * How long a trial's entry pod has, once Ready, to reach every peer it dials as it starts (its trial policy
 * enforced for it) before its program runs: deploy/k8s/README.md e3 measured a fresh pod's first allowed
 * connect 7-59 ms after its container started, so already by Ready; this is thirty times the slowest.
 */
export const POLICY_WAIT_MS = 2_000;
/**
 * Where a served pod's PID 1 takes the policy wait's connections (POLICY_LISTENER_COMMAND): a port no served
 * program uses (SERVICE_PORT, SCRAPE_GATEWAY_PORT), below the ephemeral range, unprivileged.
 */
export const POLICY_PORT = 9009;
/**
 * A served pod's own command in place of `sleep infinity`: perl (perl-base, in every image the table pins),
 * one thread, accepting on POLICY_PORT and closing each connection at once, forever; a listen that fails ends
 * it, and the pod with it. IPv4, as pod IPs are here.
 */
export const POLICY_LISTENER_COMMAND: readonly string[] = Object.freeze([
  'perl',
  '-e',
  `use IO::Socket::INET; my $s = IO::Socket::INET->new(LocalPort => ${POLICY_PORT}, Listen => 64, ReuseAddr => 1) or die "policy listener: $!\\n"; while (1) { my $c = $s->accept or next; close $c }`,
]);
/** `kubectl create`'s output when the env Secret follows its pod: kind, name and uid per object made. */
export const CREATED_JSONPATH = 'jsonpath={.kind} {.metadata.name} {.metadata.uid}{"\\n"}';

/** What the kubelet sets in every container whatever enableServiceLinks says (kubelet_pods.go; deploy/k8s/README.md check i). */
export const KUBERNETES_ENV = Object.freeze([
  'KUBERNETES_SERVICE_HOST',
  'KUBERNETES_SERVICE_PORT',
  'KUBERNETES_SERVICE_PORT_HTTPS',
  'KUBERNETES_PORT',
  'KUBERNETES_PORT_443_TCP',
  'KUBERNETES_PORT_443_TCP_PROTO',
  'KUBERNETES_PORT_443_TCP_PORT',
  'KUBERNETES_PORT_443_TCP_ADDR',
] as const);

/**
 * The exec's shell script (the header): `sh <pids> <argv...>` after `-c`, the nonce on stdin's first line.
 * A wrapper that cannot cap processes exits without the start line or the sentinel, which is the driver's failure.
 */
export const EXEC_WRAPPER = [
  'trap : TERM',
  'IFS= read -r n || exit 125',
  'exec 3>&2 2>/dev/null',
  `unset ${KUBERNETES_ENV.join(' ')}`,
  // dash exports PWD to what it runs; docker sets none.
  'unset PWD',
  '[ "$1" = 0 ] || ulimit -u "$1" || ulimit -p "$1" || { echo "sandbox: could not cap processes at $1" >&3; exit 125; }',
  'shift',
  'printf \'\\036%s\\n\' "$n"',
  '( exec "$@" 2>&3 3>&- )',
  's=$?',
  'kill -s KILL -- -1',
  'printf \'\\036%s%d\\n\' "$n" "$s"',
].join('\n');

/** The start line's and the sentinel's first byte (RS, octal 036 in the wrapper's printf): what output must end in for any of it to be held back. */
export const SENTINEL_MARK = '\x1e';

/** The user and group a timed pod's launcher drops the program to (the sandbox user, every other pod's). */
export const TIMED_UID = 65534;
export const TIMED_GID = 65534;
/** A timed pod's root tasks under the wrapper's process cap: PID 1, the wrapper, the launcher, and the program until it drops (the header's Timing). */
export const TIMED_ROOT_TASKS = 4;
/** The most digits a CPU reading may have (µs, below 2^63). */
export const CPU_READING_DIGITS = 19;
/** How long a timed kill() waits for the launcher's reading once it has killed the program's processes, before it cuts the exec. */
export const TIMED_KILL_MS = 15_000;
/** The prefix of a timed sandbox's clock source: `rusage-children k8s <runtime class|default> cpu-<12 hex>`. */
export const K8S_CPU_CLOCK_SOURCE = 'rusage-children k8s';

/**
 * The house's CPU launcher (the header's Timing), perl with perl-base's modules alone, run as
 * `perl -e CPU_LAUNCHER_SCRIPT -- <uid|-> <gid|-> <argv...>` with descriptor 4 its report: it makes itself the child
 * subreaper, forks argv (dropped to uid:gid with no supplementary group; `-` drops nothing, a host run's: the unit
 * tests), waits for it, SIGKILLs every live descendant (by /proc's parent links) and reaps until it has no child left,
 * then writes getrusage(RUSAGE_CHILDREN) user plus system µs and a newline on descriptor 4 and exits with the program's
 * status (128+n for a signal). A failure of its own goes to stderr as `cpu launcher: ...`, nothing on descriptor 4, and
 * exit 125. SIGTERM (terminate()'s) is the program's: the launcher catches it and goes on. The syscalls are raw, so
 * their numbers are named per machine (x86_64, aarch64: the pinned images' two).
 */
export const CPU_LAUNCHER_SCRIPT = [
  'use strict;',
  'use warnings;',
  'use POSIX ();',
  'use Fcntl ();',
  '$SIG{TERM} = sub {};',
  'sub fail { print STDERR "cpu launcher: $_[0]\\n"; exit 125 }',
  'my ($uid, $gid, @argv) = @ARGV;',
  "fail('usage: perl -e <launcher> -- <uid|-> <gid|-> <argv...>') unless defined $gid && @argv;",
  "open(my $report, '>&=', 4) or fail(\"no report descriptor 4: $!\");",
  'my $fl = fcntl($report, Fcntl::F_GETFD(), 0);',
  '(defined $fl && fcntl($report, Fcntl::F_SETFD(), $fl | Fcntl::FD_CLOEXEC())) or fail("descriptor 4: $!");',
  'my $machine = (POSIX::uname())[4];',
  'my %NR = (x86_64 => [157, 98], aarch64 => [167, 165]);',
  'my $nr = $NR{$machine} or fail("no syscall numbers for $machine");',
  'syscall($nr->[0], 36, 1, 0, 0, 0) == 0 or fail("prctl(PR_SET_CHILD_SUBREAPER): $!");',
  'pipe(my $er, my $ew) or fail("pipe: $!");',
  'my $pid = fork();',
  'defined $pid or fail("fork: $!");',
  'if ($pid == 0) {',
  '  close $er;',
  '  my $why = sub { syswrite($ew, $_[0]); POSIX::_exit(125) };',
  "  if ($uid ne '-') {",
  '    $) = "$gid $gid";',
  '    POSIX::setgid($gid) or $why->("setgid($gid): $!");',
  '    POSIX::setuid($uid) or $why->("setuid($uid): $!");',
  '    $why->("the program is not $uid:$gid alone") unless POSIX::getuid() == $uid && POSIX::geteuid() == $uid && POSIX::getgid() == $gid && POSIX::getegid() == $gid && $) eq "$gid $gid";',
  '  }',
  "  { no warnings 'exec'; exec { $argv[0] } @argv; }",
  '  $why->("exec $argv[0]: $!");',
  '}',
  'close $ew;',
  "my $said = '';",
  'for (;;) { my $n = sysread($er, my $b, 4096); if (!defined $n) { next if $!{EINTR}; last } last if $n == 0; $said .= $b }',
  'close $er;',
  "if ($said ne '') { waitpid($pid, 0); fail($said) }",
  'waitpid($pid, 0) == $pid or fail("waitpid: $!");',
  'my $status = $?;',
  'sub descendants {',
  '  my %kids;',
  "  opendir(my $d, '/proc') or fail(\"/proc: $!\");",
  '  for my $p (readdir $d) {',
  '    next unless $p =~ /^[0-9]+$/;',
  "    open(my $f, '<', \"/proc/$p/stat\") or next;",
  '    my $s = <$f>;',
  '    close $f;',
  '    next unless defined $s;',
  "    my $at = rindex($s, ')');",
  '    next if $at < 0;',
  "    my ($state, $ppid) = (split ' ', substr($s, $at + 1))[0, 1];",
  '    next unless defined $ppid;',
  '    push @{ $kids{$ppid} }, [$p, $state];',
  '  }',
  '  closedir $d;',
  '  my @live;',
  '  my @todo = ($$);',
  '  while (@todo) {',
  '    my $q = shift @todo;',
  '    for my $k (@{ $kids{$q} || [] }) {',
  '      push @todo, $k->[0];',
  "      push @live, $k->[0] unless $k->[1] eq 'Z' || $k->[1] eq 'X';",
  '    }',
  '  }',
  '  return @live;',
  '}',
  'my $done = 0;',
  'for (1 .. 400) {',
  '  my @live = descendants();',
  "  kill 'KILL', @live if @live;",
  '  my $w;',
  '  do { $w = waitpid(-1, POSIX::WNOHANG()) } while $w > 0;',
  '  if ($w < 0) { fail("waitpid: $!") unless $!{ECHILD}; $done = 1; last }',
  '  select(undef, undef, undef, 0.005);',
  '}',
  "fail('the program left processes that would not die') unless $done;",
  'my $ru = "\\0" x 144;',
  'syscall($nr->[1], -1, $ru) == 0 or fail("getrusage(RUSAGE_CHILDREN): $!");',
  "my ($us, $uu, $ss, $su) = unpack('q4', $ru);",
  'syswrite($report, (($us + $ss) * 1000000 + $uu + $su) . "\\n") or fail("descriptor 4: $!");',
  'close $report;',
  'exit(POSIX::WIFEXITED($status) ? POSIX::WEXITSTATUS($status) : 128 + POSIX::WTERMSIG($status));',
].join('\n');

/** The argv a timed pod's wrapper runs for `program`: the CPU launcher, dropping it to TIMED_UID:TIMED_GID. */
export function cpuLauncherArgv(program: readonly string[]): string[] {
  return ['perl', '-e', CPU_LAUNCHER_SCRIPT, '--', String(TIMED_UID), String(TIMED_GID), ...program];
}

/**
 * A timed pod's exec script (the header's Timing): EXEC_WRAPPER, but the program, its argv the CPU launcher's
 * (cpuLauncherArgv), runs in a command substitution holding descriptor 4, its stdout and stderr the real ones, and the
 * launcher's reading, digits alone, is printed as `RS<nonce>c<µs>\n` after everything is killed and before the sentinel.
 */
export const TIMED_EXEC_WRAPPER = [
  'trap : TERM',
  'IFS= read -r n || exit 125',
  'exec 3>&2 2>/dev/null',
  `unset ${KUBERNETES_ENV.join(' ')}`,
  'unset PWD',
  '[ "$1" = 0 ] || ulimit -u "$1" || ulimit -p "$1" || { echo "sandbox: could not cap processes at $1" >&3; exit 125; }',
  'shift',
  'printf \'\\036%s\\n\' "$n"',
  'exec 5>&1',
  'c=$(exec "$@" 4>&1 1>&5 5>&- 2>&3 3>&-)',
  's=$?',
  'kill -s KILL -- -1',
  'case $c in \'\'|*[!0-9]*) ;; *) printf \'\\036%sc%s\\n\' "$n" "$c" ;; esac',
  'printf \'\\036%s%d\\n\' "$n" "$s"',
].join('\n');

/**
 * A timed kill's first step (the header's Timing), exec'd in the pod as its root: drop to the program's user and
 * SIGKILL every process of it (kill -1 spares the caller), every 50 ms for 5 s, so one the launcher had yet to fork
 * dies too; the launcher, root, reaps them and reports. The wrapper's own `kill -1` ends it once the launcher has.
 */
export const TIMED_KILL_ARGV: readonly string[] = Object.freeze([
  'perl',
  '-e',
  [
    'use POSIX ();',
    'my ($uid, $gid) = @ARGV;',
    '$) = "$gid $gid";',
    'POSIX::setgid($gid) or exit 1;',
    'POSIX::setuid($uid) or exit 1;',
    'exit 1 unless POSIX::getuid() == $uid && POSIX::geteuid() == $uid;',
    "for (1 .. 100) { kill 'KILL', -1; select(undef, undef, undef, 0.05) }",
  ].join('\n'),
  '--',
  String(TIMED_UID),
  String(TIMED_GID),
]);

/**
 * The policy wait (POLICY_WAIT_MS) in an entry's own interpreter, argv: ms, then host and port per peer.
 * Each peer is dialled until it takes a connection (250 ms an attempt, 20 ms apart; a refusal is what an
 * unprogrammed policy gives); exit 0 once all did, else exit 1 at the deadline with one line, `host:port why`.
 */
export const POLICY_WAIT_ARGV: Readonly<Record<Runtime, readonly string[]>> = Object.freeze({
  node22: Object.freeze([
    'node',
    '-e',
    [
      "const net = require('node:net');",
      'const [ms, ...rest] = process.argv.slice(1);',
      'const deadline = Date.now() + Number(ms);',
      'const once = (host, port) => new Promise((done) => {',
      '  const s = net.connect({ host, port });',
      "  const timer = setTimeout(() => { s.destroy(); done('TIMEOUT'); }, 250);",
      "  s.once('connect', () => { clearTimeout(timer); s.destroy(); done(null); });",
      "  s.once('error', (e) => { clearTimeout(timer); done(e.code || e.message); });",
      '});',
      '(async () => {',
      '  for (let i = 0; i + 1 < rest.length; i += 2) {',
      '    const host = rest[i];',
      '    const port = Number(rest[i + 1]);',
      '    for (;;) {',
      '      const failed = await once(host, port);',
      '      if (failed === null) break;',
      '      if (Date.now() >= deadline) { process.stdout.write(`${host}:${port} ${failed}\\n`); process.exit(1); }',
      '      await new Promise((r) => setTimeout(r, 20));',
      '    }',
      '  }',
      '})();',
    ].join('\n'),
  ]),
  'python3.13': Object.freeze([
    'python3',
    '-c',
    [
      'import socket, sys, time',
      'ms, rest = int(sys.argv[1]), sys.argv[2:]',
      'deadline = time.monotonic() + ms / 1000',
      'for i in range(0, len(rest) - 1, 2):',
      '    host, port = rest[i], int(rest[i + 1])',
      '    while True:',
      '        try:',
      '            socket.create_connection((host, port), 0.25).close()',
      '            break',
      '        except OSError as e:',
      '            if time.monotonic() >= deadline:',
      "                print(f'{host}:{port} {type(e).__name__}: {e}')",
      '                sys.exit(1)',
      '            time.sleep(0.02)',
    ].join('\n'),
  ]),
});

const [GRADER_LABEL_KEY, GRADER_LABEL_VALUE] = CONTAINER_LABEL.split('=') as [string, string];
const [EGRESS_LABEL_KEY, EGRESS_LABEL_VALUE] = EGRESS_LABEL.split('=') as [string, string];
const DATA_VOLUME = 'data';
const TMP_VOLUME = 'tmp';
const NOBODY_ID = 65534;
const METER_CAPS = Object.freeze(['DAC_OVERRIDE']);
const NDOTS_0 = Object.freeze({ name: 'ndots', value: '0' });
/**
 * A waiting container's reasons that never end in Ready: the pod is failed at once, not after READY_TIMEOUT_MS.
 * Not CreateContainerConfigError: a pod waits in it until its env Secret, made after it, exists.
 */
const NEVER_READY = new Set(['ErrImageNeverPull', 'InvalidImageName', 'ErrImagePull', 'ImagePullBackOff', 'CreateContainerError', 'RunContainerError', 'CrashLoopBackOff']);
const DNS_LABEL_RE = /^[a-z0-9]([-a-z0-9]{0,61}[a-z0-9])?$/;
const DNS_SUBDOMAIN_RE = /^[a-z0-9]([-a-z0-9.]{0,251}[a-z0-9])?$/;
const LABEL_KEY_RE = /^(?:[a-z0-9]([-a-z0-9.]{0,251}[a-z0-9])?\/)?[A-Za-z0-9]([-A-Za-z0-9_.]{0,61}[A-Za-z0-9])?$/;
const LABEL_VALUE_RE = /^(?:[A-Za-z0-9]([-A-Za-z0-9_.]{0,61}[A-Za-z0-9])?)?$/;
const NONCE_RE = /^[0-9a-f]{32}$/;
/** After RS and the nonce: a timed wrapper's CPU line whole (`c<µs>\n`), and one cut short at the end of what came. */
const CPU_LINE_RE = new RegExp(`^c([0-9]{1,${CPU_READING_DIGITS}})\\n`);
const CPU_LINE_SO_FAR_RE = new RegExp(`^c[0-9]{0,${CPU_READING_DIGITS}}$`);
const UID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const EMPTY = Buffer.alloc(0);

// ---------------------------------------------------------------- kubectl

/** One kubectl call's outcome. `error` is set when it could not run or was cut off. */
export interface KubectlResult {
  code: number | null;
  stdout: string;
  stderr: string;
  error?: string;
}

export interface KubectlCallOptions {
  /** Its stdin (none: closed at once). */
  input?: string;
  /** Cut it off (SIGKILL) when this aborts. */
  signal?: AbortSignal;
  /** Its budget (default the KubectlExec's). */
  timeoutMs?: number;
}

/** Runs kubectl with an argv (no leading `kubectl`), to its end. */
export type KubectlExec = (args: readonly string[], opts?: KubectlCallOptions) => Promise<KubectlResult>;

/** How a streamed kubectl (the exec) ended: `error` when it never started. */
export interface KubectlEnd {
  code: number | null;
  signal: NodeJS.Signals | null;
  error?: string;
}

/** A streamed kubectl: its stdio, its end (after its stdout and stderr ended), and a SIGKILL. */
export interface KubectlChild {
  readonly stdin: Writable;
  readonly stdout: Readable;
  readonly stderr: Readable;
  readonly closed: Promise<KubectlEnd>;
  kill(): void;
}

/** Starts kubectl with an argv (no leading `kubectl`) and its stdio piped: `kubectl exec -i`. */
export type KubectlStream = (args: readonly string[]) => KubectlChild;

const KUBECTL_ENV = ['PATH', 'KUBERNETES_SERVICE_HOST', 'KUBERNETES_SERVICE_PORT', 'KUBECONFIG'] as const;

/**
 * What kubectl itself needs (docker.ts dockerCliEnv's twin): PATH, the API server's in-cluster address
 * (its token and CA are the mounted service account's), KUBECONFIG when one is named (a run from outside
 * the cluster), and HOME=/tmp for its cache. None of it reaches a pod.
 */
export function kubectlEnv(env: NodeJS.ProcessEnv = process.env): Record<string, string> {
  const out: Record<string, string> = { HOME: '/tmp' };
  for (const k of KUBECTL_ENV) {
    const v = env[k];
    if (v !== undefined) out[k] = v;
  }
  return out;
}

/** kubectl as a KubectlExec: kubectlEnv only, its input on stdin, SIGKILLed after `timeoutMs` or on abort. */
export function kubectlExec(kubectl = 'kubectl', timeoutMs = KUBECTL_TIMEOUT_MS): KubectlExec {
  return (args, opts = {}) =>
    new Promise<KubectlResult>((resolve) => {
      const child = spawn(kubectl, args, { stdio: ['pipe', 'pipe', 'pipe'], env: kubectlEnv() });
      const out: Buffer[] = [];
      const err: Buffer[] = [];
      child.stdout.on('data', (b: Buffer) => out.push(b));
      child.stderr.on('data', (b: Buffer) => err.push(b));
      child.stdin.on('error', () => undefined);
      child.stdin.end(opts.input ?? '');
      const limit = opts.timeoutMs ?? timeoutMs;
      let cut: string | null = null;
      const stop = (why: string): void => {
        cut ??= why;
        child.kill('SIGKILL');
      };
      const timer = setTimeout(() => stop(`no answer within ${limit} ms`), limit);
      timer.unref();
      const onAbort = (): void => stop('cut off');
      opts.signal?.addEventListener('abort', onAbort, { once: true });
      if (opts.signal?.aborted === true) onAbort();
      const settle = (res: KubectlResult): void => {
        clearTimeout(timer);
        opts.signal?.removeEventListener('abort', onAbort);
        resolve(res);
      };
      child.once('error', (e) => {
        // An 'error' with a pid is a kill or a write that failed: the close still comes.
        if (child.pid === undefined) settle({ code: null, stdout: '', stderr: '', error: `kubectl: ${e.message}` });
      });
      child.once('exit', () => {
        const grace = setTimeout(() => {
          child.stdout.destroy();
          child.stderr.destroy();
        }, STDIO_GRACE_MS);
        grace.unref();
        child.once('close', () => clearTimeout(grace));
      });
      child.once('close', (code) => {
        const res: KubectlResult = { code, stdout: Buffer.concat(out).toString('utf8'), stderr: Buffer.concat(err).toString('utf8') };
        if (cut !== null) res.error = `kubectl ${args.filter((a) => !a.startsWith('-')).slice(1, 3).join(' ')}: ${cut}`;
        settle(res);
      });
    });
}

/**
 * kubectl as a KubectlStream, on kubectlEnv. Its end is its 'close'; a kubectl that exited while something it
 * started still holds its stdout (a wrapper's child) is closed STDIO_GRACE_MS after, so a kill always ends it.
 */
export function kubectlStream(kubectl = 'kubectl'): KubectlStream {
  return (args) => {
    const child = spawn(kubectl, args, { stdio: ['pipe', 'pipe', 'pipe'], env: kubectlEnv() });
    const closed = new Promise<KubectlEnd>((resolve) => {
      child.once('error', (e) => {
        if (child.pid === undefined) resolve({ code: null, signal: null, error: `kubectl: ${e.message}` });
      });
      child.once('exit', () => {
        const grace = setTimeout(() => {
          child.stdout.destroy();
          child.stderr.destroy();
          child.stdin.destroy();
        }, STDIO_GRACE_MS);
        grace.unref();
        child.once('close', () => clearTimeout(grace));
      });
      child.once('close', (code, signal) => resolve({ code, signal }));
    });
    return { stdin: child.stdin, stdout: child.stdout, stderr: child.stderr, closed, kill: () => void child.kill('SIGKILL') };
  };
}

/** What a failed call said: the first line of its stderr that is not a warning (Pod Security's), else why it ended. */
export function why(r: KubectlResult): string {
  const said = r.stderr
    .split('\n')
    .map((l) => l.trim())
    .find((l) => l !== '' && !l.startsWith('Warning:'));
  return r.error ?? said ?? (r.code === null ? 'no answer' : `exit ${r.code}`);
}

// ---------------------------------------------------------------- the pod

/** A Kubernetes object as `kubectl create` takes it. */
export interface K8sObject {
  apiVersion: string;
  kind: string;
  metadata: { name: string; namespace: string; labels: Record<string, string>; annotations?: Record<string, string>; ownerReferences?: Array<Record<string, unknown>> };
  [field: string]: unknown;
}

/** What an object of the driver's is marked with besides its name: its labels and, with a trial owner, its annotations (ownerAnnotations). */
export interface ObjectMarks {
  labels: Record<string, string>;
  annotations?: Record<string, string>;
}

/** An object's metadata: its name and namespace, copies of its marks (no `annotations` key without any). */
function metadataOf(name: string, namespace: string, marks: ObjectMarks): K8sObject['metadata'] {
  return { name, namespace, labels: { ...marks.labels }, ...(marks.annotations === undefined ? {} : { annotations: { ...marks.annotations } }) };
}

/** One hostAliases entry: an address and the names it answers to there. */
export interface HostAlias {
  ip: string;
  hostnames: string[];
}

/** Where every sandbox pod goes and what it runs as (K8sSandboxOptions, checked). */
export interface PodPlacement {
  namespace: string;
  /** The ReadWriteOnce PVC every mount is a subPath of. */
  dataPvc: string;
  /** Where the worker mounts that PVC: every host path a pod mounts lies under it. */
  dataRoot: string;
  /** The RuntimeClass (gvisor), or null for the node's default runtime. */
  runtimeClass: string | null;
  /** The account the pods run as (no token mounted). */
  serviceAccount: string;
  nodeSelector: Readonly<Record<string, string>> | null;
  /** The pod of the process making the pods (CREATOR_ANNOTATION on each, the header's Reaping); absent or null: none. */
  creator?: string | null;
}

/** A program pod's own: its name, image and digest, its peers' addresses, its trial's owner. */
export interface SandboxPodOptions extends PodPlacement {
  name: string;
  image: string;
  digest: string;
  hostAliases?: readonly HostAlias[];
  owner?: string | null;
  /**
   * A timed pod's (the header's Timing): root with LAUNCHER_CAPS, for the CPU launcher, and its CPU limit its request.
   * Never with a spec's launcher.
   */
  timed?: boolean;
}

/** An aux pod's own (meter, reclaim, preflight). */
export interface AuxPodOptions extends PodPlacement {
  name: string;
  image: string;
  digest: string;
}

/** A fresh pod name for a label: makefun-sbx-<label>-<8 hex>, at most 62 characters. */
export function podName(label: string): string {
  return `${POD_PREFIX}${checkSandboxLabel(label)}-${randomBytes(4).toString('hex')}`;
}

/**
 * Whether `host` lies below the data root (never the root itself): what a pod can mount as a subPath of the data
 * PVC. What is not (a bundle's own trees in the image's competitions/) the grader stages onto it first
 * (bundle-trees.ts, grader/worker.ts stageProgramSetup).
 */
export function underDataRoot(dataRoot: string, host: string): boolean {
  const rel = posix.relative(dataRoot, host);
  return !(rel === '' || rel === '..' || rel.startsWith('../') || posix.isAbsolute(rel));
}

/**
 * `host`'s path inside the data PVC, the subPath that mounts it: SandboxError when it is not under the
 * data root (outside it, the root itself, or not a host path checkHostPath takes).
 */
export function subPathOf(dataRoot: string, host: string): string {
  checkHostPath(host);
  if (!underDataRoot(dataRoot, host)) {
    throw new SandboxError(`host path ${JSON.stringify(host)} is not under the data root ${dataRoot}, the only tree a sandbox pod mounts (MAKEFUN_K8S_DATA_ROOT)`);
  }
  return posix.relative(dataRoot, host);
}

/** The env Secret's name for a pod. */
export function envSecretName(pod: string): string {
  return `${pod}${ENV_SECRET_SUFFIX}`;
}

/** A CPU limit in millicores (formatCpus's range and rounding; at least 1m). */
function cpuMilli(cpus: number): number {
  const milli = Math.round(Number(formatCpus(cpus)) * 1000);
  if (milli < 1) throw new SandboxError(`cpus ${cpus} is out of range`);
  return milli;
}

/** `value` as a label value: at most 63 characters, alphanumeric at both ends (what a docker label need not be). */
export function labelValue(value: string, what: string): string {
  if (!LABEL_VALUE_RE.test(value)) throw new SandboxError(`${what} ${JSON.stringify(value)} is not a Kubernetes label value (at most 63 characters, alphanumeric at both ends)`);
  return value;
}

/**
 * A trial owner's OWNER_LABEL value (the header): the owner itself when it is a label value, else
 * OWNER_LABEL_HASH_PREFIX and the first OWNER_LABEL_HASH_HEX hex of its sha256 (42 characters). What labels every
 * object of the owner's and what the reap selects by, so the two always agree; a SandboxError for what is no trial
 * owner (checkTrialOwner).
 */
export function ownerLabel(owner: string): string {
  checkTrialOwner(owner);
  if (LABEL_VALUE_RE.test(owner)) return owner;
  return `${OWNER_LABEL_HASH_PREFIX}${createHash('sha256').update(owner).digest('hex').slice(0, OWNER_LABEL_HASH_HEX)}`;
}

/** The annotations of an object of trial owner `owner`'s: the owner whole (OWNER_ANNOTATION), whatever its label is; none without one. */
export function ownerAnnotations(owner: string | null): Record<string, string> | undefined {
  return owner === null ? undefined : { [OWNER_ANNOTATION]: checkTrialOwner(owner) };
}

/** The trial a trial network is for (checkSandboxNetwork took its name). */
function trialOf(network: SandboxNetwork): string {
  return labelValue(network.name.slice(TRIAL_NETWORK_PREFIX.length), 'trial');
}

/** The labels of a pod's Secret and policy: the grader's mark, the pod's name, its trial's. */
function objectLabels(name: string, network: SandboxNetwork | null, owner: string | null): Record<string, string> {
  return {
    [GRADER_LABEL_KEY]: GRADER_LABEL_VALUE,
    [POD_LABEL]: name,
    ...(network === null ? {} : { [NETWORK_LABEL]: trialOf(network) }),
    ...(network === null || owner === null ? {} : { [OWNER_LABEL]: ownerLabel(owner) }),
  };
}

/** The marks of a pod's Secret and policy: objectLabels, and the owner whole when it is on a trial with one. */
function objectMarks(name: string, network: SandboxNetwork | null, owner: string | null): ObjectMarks {
  const annotations = network === null ? undefined : ownerAnnotations(owner);
  return { labels: objectLabels(name, network, owner), ...(annotations === undefined ? {} : { annotations }) };
}

function podLabels(name: string, kind: SandboxPodKind, network: SandboxNetwork | null, owner: string | null): Record<string, string> {
  return {
    ...objectLabels(name, network, owner),
    [ROLE_LABEL]: 'sandbox',
    [SANDBOX_KIND_LABEL]: kind,
    ...(network?.egress === true ? { [EGRESS_LABEL_KEY]: EGRESS_LABEL_VALUE } : {}),
  };
}

/** A race pod's labels (the header): its name, the sandbox role and kind race, and no grader mark, so no stale sweep lists it. */
function racePodLabels(name: string): Record<string, string> {
  return { [POD_LABEL]: name, [ROLE_LABEL]: 'sandbox', [SANDBOX_KIND_LABEL]: 'race' };
}

interface VolumeMount {
  name: string;
  mountPath: string;
  subPath?: string;
  readOnly?: boolean;
}

interface PodShape {
  name: string;
  placement: PodPlacement;
  labels: Record<string, string>;
  /** A trial pod's owner whole (ownerAnnotations); none otherwise. */
  annotations?: Record<string, string>;
  /** `none`: no resolver at all; `cluster`: the cluster's DNS (an egress pod). */
  dns: 'none' | 'cluster';
  hostAliases: readonly HostAlias[];
  root: boolean;
  caps: readonly string[];
  image: string;
  command: readonly string[];
  env: Array<Record<string, unknown>>;
  cpuMilli: number;
  /** The CPU it asks to be scheduled with (default min(cpuMilli, CPU_REQUEST_MAX_MILLI)); a timed pod's is its limit. */
  cpuRequestMilli?: number;
  memory: string;
  mounts: VolumeMount[];
  tmp: boolean;
  /** Its activeDeadlineSeconds (default STALE_AFTER_MS's): a race pod's lifetime. */
  deadlineSeconds?: number;
}

function podObject(o: PodShape): K8sObject {
  const p = o.placement;
  const spec: Record<string, unknown> = {};
  if (p.runtimeClass !== null) spec.runtimeClassName = p.runtimeClass;
  if (p.nodeSelector !== null && Object.keys(p.nodeSelector).length > 0) spec.nodeSelector = { ...p.nodeSelector };
  spec.serviceAccountName = p.serviceAccount;
  spec.automountServiceAccountToken = false;
  spec.enableServiceLinks = false;
  spec.restartPolicy = 'Never';
  spec.activeDeadlineSeconds = o.deadlineSeconds ?? STALE_AFTER_MS / 1000;
  spec.terminationGracePeriodSeconds = 0;
  spec.dnsPolicy = o.dns === 'none' ? 'None' : 'ClusterFirst';
  spec.dnsConfig = o.dns === 'none' ? { nameservers: ['127.0.0.1'], options: [{ ...NDOTS_0 }] } : { options: [{ ...NDOTS_0 }] };
  if (o.hostAliases.length > 0) spec.hostAliases = o.hostAliases.map((a) => ({ ip: a.ip, hostnames: [...a.hostnames] }));
  spec.securityContext = {
    runAsUser: o.root ? 0 : NOBODY_ID,
    runAsGroup: o.root ? 0 : NOBODY_ID,
    runAsNonRoot: !o.root,
    seccompProfile: { type: 'RuntimeDefault' },
  };
  const container: Record<string, unknown> = {
    name: CONTAINER,
    image: o.image,
    imagePullPolicy: 'Never',
    command: [...o.command],
  };
  if (o.env.length > 0) container.env = o.env;
  container.resources = {
    limits: { cpu: `${o.cpuMilli}m`, memory: o.memory },
    requests: { cpu: `${o.cpuRequestMilli ?? Math.min(o.cpuMilli, CPU_REQUEST_MAX_MILLI)}m`, memory: o.memory },
  };
  container.securityContext = {
    allowPrivilegeEscalation: false,
    readOnlyRootFilesystem: true,
    capabilities: o.caps.length > 0 ? { drop: ['ALL'], add: [...o.caps] } : { drop: ['ALL'] },
  };
  const mounts = [...o.mounts, ...(o.tmp ? [{ name: TMP_VOLUME, mountPath: '/tmp' }] : [])];
  if (mounts.length > 0) container.volumeMounts = mounts;
  spec.containers = [container];
  const volumes: Array<Record<string, unknown>> = [];
  if (o.mounts.length > 0) volumes.push({ name: DATA_VOLUME, persistentVolumeClaim: { claimName: p.dataPvc } });
  if (o.tmp) volumes.push({ name: TMP_VOLUME, emptyDir: { medium: 'Memory', sizeLimit: TMP_SIZE } });
  if (volumes.length > 0) spec.volumes = volumes;
  const creator = p.creator === undefined || p.creator === null ? null : checkName(p.creator, DNS_SUBDOMAIN_RE, 'creator pod');
  const marks: ObjectMarks = creator === null ? o : { labels: o.labels, annotations: { ...o.annotations, [CREATOR_ANNOTATION]: creator } };
  return { apiVersion: 'v1', kind: 'Pod', metadata: metadataOf(o.name, p.namespace, marks), spec };
}

/**
 * The pod a program runs in (the header): pure, so its every field is unit-tested exactly, the twin of
 * dockerRunArgs. A spec with a launcher gets the launcher's user and capabilities and the house; a timed pod
 * (opts.timed) the same user and capabilities for the CPU launcher, no house, and its CPU limit as its request; a race
 * spec (its `race`) a race pod's labels, deadline and CPU request (the header); a host path outside the data root is a
 * SandboxError naming it. A patch/v1 spec is refused (the docker driver's alone, as deploy/prod runs it): one with an
 * `image` by a SandboxError of code `repo_image_unsupported`, one with a `work` tmpfs by a plain one.
 */
export function sandboxPodSpec(spec: SandboxSpec, opts: SandboxPodOptions): K8sObject {
  if (spec.image !== undefined) throw new SandboxError("the k8s driver runs no repository image (a patch/v1 run is the docker driver's)", { code: 'repo_image_unsupported' });
  if (spec.work !== undefined) throw new SandboxError("the k8s driver gives no /work tmpfs (a patch/v1 run is the docker driver's)");
  scriptOf(spec);
  const timed = opts.timed === true;
  if (timed && spec.launcher !== undefined) throw new SandboxError("a timed pod runs a program/v1 entry under the CPU launcher, never a spec's own launcher");
  const race = spec.race === undefined ? null : checkSandboxRace(spec);
  if (timed && race !== null) throw new SandboxError("a timed pod runs a program/v1 timing heat's entry, never a race's racer");
  const launcher = spec.launcher === undefined ? null : checkSandboxLauncher(spec);
  const memory = `${positiveInt(spec.limits.memory_mb, 'memory_mb')}Mi`;
  const milli = cpuMilli(spec.limits.cpus);
  positiveInt(spec.limits.pids, 'pids');
  const network = spec.network === undefined ? null : checkSandboxNetwork(spec.network);
  const secret = envSecretName(opts.name);
  const env: Array<Record<string, unknown>> = Object.entries(SANDBOX_ENV).map(([name, value]) => ({ name, value }));
  for (const [name, value] of checkSandboxEnv(spec.env)) {
    env.push(SECRET_ENV_RE.test(name) ? { name, valueFrom: { secretKeyRef: { name: secret, key: name } } } : { name, value });
  }
  for (const [name] of checkSandboxSecrets(spec)) env.push({ name, valueFrom: { secretKeyRef: { name: secret, key: name } } });
  const mounts: VolumeMount[] = [{ name: DATA_VOLUME, mountPath: '/bot', subPath: subPathOf(opts.dataRoot, spec.codeDir), readOnly: true }];
  if (launcher !== null) mounts.push({ name: DATA_VOLUME, mountPath: HOUSE_DIR, subPath: subPathOf(opts.dataRoot, launcher.houseDir), readOnly: true });
  const seen = new Set<string>();
  for (const m of spec.mounts ?? []) {
    if (!Object.hasOwn(MOUNT_POINTS, m.at)) throw new SandboxError(`${JSON.stringify(m.at)} is not a mount point (${Object.keys(MOUNT_POINTS).join(', ')})`);
    if (seen.has(m.at)) throw new SandboxError(`${m.at} is mounted twice`);
    seen.add(m.at);
    mounts.push({ name: DATA_VOLUME, mountPath: m.at, subPath: subPathOf(opts.dataRoot, m.host), readOnly: m.readOnly });
  }
  const owner = network === null ? null : (opts.owner ?? null);
  const annotations = ownerAnnotations(owner);
  return podObject({
    name: opts.name,
    placement: opts,
    labels: race === null ? podLabels(opts.name, 'program', network, owner) : racePodLabels(opts.name),
    ...(annotations === undefined ? {} : { annotations }),
    dns: network?.egress === true ? 'cluster' : 'none',
    hostAliases: network === null ? [] : (opts.hostAliases ?? []),
    root: launcher !== null || timed,
    caps: launcher === null && !timed ? [] : LAUNCHER_CAPS,
    image: imageRef({ image: opts.image }, opts.digest),
    command: network !== null && servedPort(network) !== null ? POLICY_LISTENER_COMMAND : ['sleep', 'infinity'],
    env,
    cpuMilli: milli,
    ...(timed ? { cpuRequestMilli: milli } : race !== null ? { cpuRequestMilli: Math.min(milli, RACE_CPU_REQUEST_MILLI) } : {}),
    memory,
    mounts,
    tmp: true,
    ...(race === null ? {} : { deadlineSeconds: raceDeadlineSeconds(race.lifetimeMs) }),
  });
}

/** A race pod's activeDeadlineSeconds: its lifetime in whole seconds, rounded up (at least 1). */
export function raceDeadlineSeconds(lifetimeMs: number): number {
  return Math.max(1, Math.ceil(lifetimeMs / 1000));
}

/**
 * The Secret holding a spec's *_API_KEY env values (SECRET_ENV_RE) and every one of its secrets (types.ts
 * checkSandboxSecrets, which keeps their names apart), in name order, which its pod reads by secretKeyRef; null when
 * it has none.
 */
export function sandboxEnvSecret(spec: Pick<SandboxSpec, 'env' | 'secrets' | 'race' | 'launcher'>, opts: { name: string; namespace: string } & ObjectMarks): K8sObject | null {
  const keys = [...checkSandboxEnv(spec.env).filter(([name]) => SECRET_ENV_RE.test(name)), ...checkSandboxSecrets(spec)].sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0));
  if (keys.length === 0) return null;
  return {
    apiVersion: 'v1',
    kind: 'Secret',
    metadata: metadataOf(envSecretName(opts.name), opts.namespace, opts),
    type: 'Opaque',
    stringData: Object.fromEntries(keys),
  };
}

/**
 * `text` (what kubectl said) with every value of `secret`'s (sandboxEnvSecret's) taken out, each whole and each line
 * of one of at least ENTRY_SECRET_VALUE_MIN_CHARS characters, as `[secret <NAME>]`: what a failure to create it may
 * say, never a value.
 */
export function withoutValues(text: string, secret: K8sObject | null): string {
  const data = (secret?.stringData ?? {}) as Record<string, string>;
  const forms: Array<[string, string]> = [];
  for (const [name, value] of Object.entries(data)) {
    if (value !== '') forms.push([value, name]);
    for (const line of value.split(/\r?\n|\r/)) if (line !== value && line.length >= ENTRY_SECRET_VALUE_MIN_CHARS) forms.push([line, name]);
  }
  // The longest first, so a value never leaves part of itself behind a shorter one's mark.
  forms.sort(([a], [b]) => b.length - a.length);
  let out = text;
  for (const [form, name] of forms) out = out.split(form).join(`[secret ${name}]`);
  return out;
}

/**
 * `obj` owned by pod `owner` (metadata.ownerReferences, blocking nothing): Kubernetes' garbage collector deletes
 * it with the pod, or at once when the pod is gone already. The env Secret is made so, after its pod, so a
 * worker that dies between the two leaves no Secret it could never find again (the Role may not list them).
 */
export function ownedByPod(obj: K8sObject, owner: { name: string; uid: string }): K8sObject {
  if (!UID_RE.test(owner.uid)) throw new SandboxError(`pod ${owner.name}'s uid ${JSON.stringify(owner.uid)} is not a uid`);
  return { ...obj, metadata: { ...obj.metadata, ownerReferences: [{ apiVersion: 'v1', kind: 'Pod', name: owner.name, uid: owner.uid, blockOwnerDeletion: false }] } };
}

/** Pod `pod`'s uid in what `kubectl create -o CREATED_JSONPATH` printed (one line per object made), or null. */
export function createdUid(stdout: string, pod: string): string | null {
  for (const line of stdout.split('\n')) {
    const [kind, name, uid, ...rest] = line.trim().split(' ');
    if (kind === 'Pod' && name === pod && uid !== undefined && rest.length === 0 && UID_RE.test(uid)) return uid;
  }
  return null;
}

/** The meter's pod over `dir` (docker.ts meterArgs's twin): root with only DAC_OVERRIDE, `dir` read-only at /measure. */
export function meterPodSpec(dir: string, opts: AuxPodOptions): K8sObject {
  return podObject({
    name: opts.name,
    placement: opts,
    labels: podLabels(opts.name, 'meter', null, null),
    dns: 'none',
    hostAliases: [],
    root: true,
    caps: METER_CAPS,
    image: imageRef({ image: opts.image }, opts.digest),
    command: ['sleep', 'infinity'],
    env: [],
    cpuMilli: AUX_CPU_MILLI,
    memory: AUX_MEMORY,
    mounts: [{ name: DATA_VOLUME, mountPath: '/measure', subPath: subPathOf(opts.dataRoot, dir), readOnly: true }],
    tmp: false,
  });
}

/** The reclaim's pod over `dir` (docker.ts reclaimArgs's twin): the sandbox user, `dir` read-write at /reclaim. */
export function reclaimPodSpec(dir: string, opts: AuxPodOptions): K8sObject {
  return podObject({
    name: opts.name,
    placement: opts,
    labels: podLabels(opts.name, 'reclaim', null, null),
    dns: 'none',
    hostAliases: [],
    root: false,
    caps: [],
    image: imageRef({ image: opts.image }, opts.digest),
    command: ['sleep', 'infinity'],
    env: [],
    cpuMilli: AUX_CPU_MILLI,
    memory: AUX_MEMORY,
    mounts: [{ name: DATA_VOLUME, mountPath: '/reclaim', subPath: subPathOf(opts.dataRoot, dir), readOnly: false }],
    tmp: false,
  });
}

/** preflight's pod: `true` in the image, as the sandbox user, nothing mounted. */
export function preflightPodSpec(opts: AuxPodOptions): K8sObject {
  return podObject({
    name: opts.name,
    placement: opts,
    labels: podLabels(opts.name, 'preflight', null, null),
    dns: 'none',
    hostAliases: [],
    root: false,
    caps: [],
    image: imageRef({ image: opts.image }, opts.digest),
    command: ['true'],
    env: [],
    cpuMilli: AUX_CPU_MILLI,
    memory: AUX_MEMORY,
    mounts: [],
    tmp: false,
  });
}

/**
 * An isolation probe's pod (k8s-network.ts probeK8sIsolation): the image as the sandbox user, nothing mounted,
 * no DNS, under the egress policy when `egress` (the listener and the sibling, as a forwarder is) and on trial
 * `trial`'s network when one is named (the inside one, as an entry is), running `command`.
 */
export function isolationPodSpec(opts: AuxPodOptions & { trial: string | null; egress: boolean; command: readonly string[] }): K8sObject {
  const network: SandboxNetwork | null = opts.trial === null ? null : { name: trialNetworkName(opts.trial) };
  return podObject({
    name: opts.name,
    placement: opts,
    labels: { ...podLabels(opts.name, 'isolation', network, null), ...(opts.egress ? { [EGRESS_LABEL_KEY]: EGRESS_LABEL_VALUE } : {}) },
    dns: 'none',
    hostAliases: [],
    root: false,
    caps: [],
    image: imageRef({ image: opts.image }, opts.digest),
    command: opts.command,
    env: [],
    cpuMilli: AUX_CPU_MILLI,
    memory: AUX_MEMORY,
    mounts: [],
    tmp: false,
  });
}

/** Where the LLM gateway is, from its origin: its host (an address or a name) and port. */
export function gatewayTarget(origin: string): { host: string; port: number } {
  let url: URL;
  try {
    url = new URL(origin);
  } catch {
    throw new SandboxError(`LLM gateway ${JSON.stringify(origin)} is not a URL`);
  }
  if (url.protocol !== 'http:' && url.protocol !== 'https:') throw new SandboxError(`LLM gateway ${JSON.stringify(origin)} is not http(s)`);
  const host = url.hostname.replace(/^\[(.*)\]$/, '$1');
  return { host, port: url.port === '' ? (url.protocol === 'https:' ? 443 : 80) : Number(url.port) };
}

/** A forwarder pod's own egress to the LLM gateway (the header): its addresses on its port, nothing else. */
export function gatewayPolicy(opts: { name: string; namespace: string; addresses: readonly string[]; port: number } & ObjectMarks): K8sObject {
  if (opts.addresses.length === 0) throw new SandboxError('the LLM gateway has no address');
  return {
    apiVersion: 'networking.k8s.io/v1',
    kind: 'NetworkPolicy',
    metadata: metadataOf(`${opts.name}${GATEWAY_POLICY_SUFFIX}`, opts.namespace, opts),
    spec: {
      podSelector: { matchLabels: { [POD_LABEL]: opts.name } },
      policyTypes: ['Egress'],
      egress: [
        {
          to: opts.addresses.map((a) => {
            if (isIP(a) === 0) throw new SandboxError(`LLM gateway address ${JSON.stringify(a)} is not an IP address`);
            return { ipBlock: { cidr: `${a}/${isIP(a) === 6 ? 128 : 32}` } };
          }),
          ports: [{ protocol: 'TCP', port: opts.port }],
        },
      ],
    },
  };
}

/** True for an agent trial's forwarder, the entry's or the house lane's: on the egress policy, under its alias (network.ts trialAttachment). */
function isForwarder(network: SandboxNetwork | null): boolean {
  const aliases = network?.aliases ?? [];
  return network !== null && network.egress === true && (aliases.includes(ROLE_ALIASES.forwarder) || aliases.includes(ROLE_ALIASES.house));
}

// ---------------------------------------------------------------- the name registry

/**
 * The trial networks of one K8sSandbox: each network's owner (TrialNetworks.create's, whole: its pods carry
 * ownerLabel of it as OWNER_LABEL and it as OWNER_ANNOTATION) and, for each of its pods once Ready, the pod's
 * IP and the names it answers to there (its aliases, then its hosts) and the port it serves the trial on (a service's; null for the entry). A networked spawn's pod
 * gets every other registered pod's names as hostAliases, in the order the pods registered (Docker's aliases
 * on a trial network); an entry's dials the served ones before its program runs (POLICY_WAIT_MS).
 */
export class PodNames {
  readonly #pods = new Map<string, Map<string, { ip: string; names: readonly string[]; port: number | null }>>();
  readonly #owners = new Map<string, string>();

  /** Record the network's owner (a SandboxError for what is no trial owner): its pods are labelled ownerLabel of it. */
  setOwner(network: string, owner: string): void {
    ownerLabel(owner);
    this.#owners.set(network, owner);
  }

  ownerOf(network: string): string | null {
    return this.#owners.get(network) ?? null;
  }

  register(network: string, pod: string, ip: string, names: readonly string[], port: number | null = null): void {
    if (isIP(ip) === 0) throw new SandboxError(`pod ${pod}'s IP ${JSON.stringify(ip)} is not an address`);
    if (port !== null && (!Number.isInteger(port) || port < 1 || port > 65535)) throw new SandboxError(`pod ${pod}'s port ${port} is out of range`);
    let pods = this.#pods.get(network);
    if (pods === undefined) this.#pods.set(network, (pods = new Map()));
    pods.set(pod, { ip, names: [...names], port });
  }

  unregister(network: string, pod: string): void {
    const pods = this.#pods.get(network);
    if (pods === undefined) return;
    pods.delete(pod);
    if (pods.size === 0) this.#pods.delete(network);
  }

  /** Drop a network: its owner and every pod of it. */
  forget(network: string): void {
    this.#pods.delete(network);
    this.#owners.delete(network);
  }

  hostAliases(network: string): HostAlias[] {
    return [...(this.#pods.get(network)?.values() ?? [])].filter((p) => p.names.length > 0).map((p) => ({ ip: p.ip, hostnames: [...p.names] }));
  }

  /** The network's pods that serve it, in the order they registered: each one's address, port and names. */
  served(network: string): ServedPeer[] {
    return [...(this.#pods.get(network)?.values() ?? [])].flatMap((p) => (p.port === null ? [] : [{ ip: p.ip, port: p.port, names: [...p.names] }]));
  }
}

/** A registered pod that serves its trial (PodNames.served). */
export interface ServedPeer {
  ip: string;
  port: number;
  names: string[];
}

/**
 * The port a pod on `network` serves its trial on: a scrape gateway's (it answers for real hosts) or an agent
 * trial's store or forwarder (the house lane's too); null for the entry, which serves nothing.
 */
export function servedPort(network: SandboxNetwork): number | null {
  if ((network.hosts ?? []).length > 0) return SCRAPE_GATEWAY_PORT;
  const aliases = network.aliases ?? [];
  return aliases.includes(ROLE_ALIASES.env) || aliases.includes(ROLE_ALIASES.forwarder) || aliases.includes(ROLE_ALIASES.house) ? SERVICE_PORT : null;
}

/** True for a trial's entry (network.ts trialAttachment, scrapeAttachment): the pod that dials the others as it starts. */
export function isEntry(network: SandboxNetwork | null): boolean {
  return network !== null && (network.aliases ?? []).includes(ROLE_ALIASES.entry);
}

// ---------------------------------------------------------------- the exit sentinel

/**
 * The exec's stdout with the wrapper's start line `RS<nonce>\n` and its sentinel `RS<nonce><status>\n` taken
 * out (the header): push() returns what can be passed on now, and nothing once the sentinel came. All of a
 * chunk is passed on at once unless it ends in what could start either (RS and the nonce's first digits), so
 * a line a service prints is never held back; end() returns what is still held when the stream ends without
 * a sentinel (one cut short is dropped: it is the wrapper's). `started` is set once the start line came (the
 * first only: the program runs after it), `rc` is the status once the sentinel came. A timed pod's wrapper
 * (TIMED_EXEC_WRAPPER) prints `RS<nonce>c<µs>\n` between the two, the CPU launcher's reading: taken out too, the first
 * after the start line kept as `cpuUs`.
 */
export class SentinelScanner {
  /** RS and the nonce: what starts the start line and the sentinel. */
  readonly #nonce: Buffer;
  #held: Buffer = EMPTY;
  #started = false;
  #rc: number | null = null;
  #cpu: bigint | null = null;

  constructor(nonce: string) {
    if (!NONCE_RE.test(nonce)) throw new SandboxError('an exec nonce is 32 lowercase hex digits');
    this.#nonce = Buffer.from(`${SENTINEL_MARK}${nonce}`, 'latin1');
  }

  get started(): boolean {
    return this.#started;
  }

  get rc(): number | null {
    return this.#rc;
  }

  /** The CPU launcher's reading, µs, once its line came (a timed pod's: TIMED_EXEC_WRAPPER); null before or without one. */
  get cpuUs(): bigint | null {
    return this.#cpu;
  }

  push(chunk: Buffer): Buffer {
    if (this.#rc !== null) return EMPTY;
    const buf = this.#held.length === 0 ? chunk : Buffer.concat([this.#held, chunk]);
    const out: Buffer[] = [];
    let from = 0;
    for (;;) {
      const at = buf.indexOf(this.#nonce, from);
      if (at < 0) {
        const keep = this.#startAtEnd(buf, from);
        out.push(buf.subarray(from, buf.length - keep));
        this.#held = Buffer.from(buf.subarray(buf.length - keep));
        return Buffer.concat(out);
      }
      const after = at + this.#nonce.length;
      // Enough for the longest of the three lines: `c`, the reading's digits and the newline.
      const tail = buf.subarray(after, after + CPU_READING_DIGITS + 2).toString('latin1');
      const m = /^(\d{1,3})\n/.exec(tail);
      if (m !== null && Number(m[1]) <= 255) {
        out.push(buf.subarray(from, at));
        this.#rc = Number(m[1]);
        this.#held = EMPTY;
        return Buffer.concat(out);
      }
      if (!this.#started && tail.startsWith('\n')) {
        out.push(buf.subarray(from, at));
        this.#started = true;
        from = after + 1;
        continue;
      }
      const cpu = this.#started ? CPU_LINE_RE.exec(tail) : null;
      if (cpu !== null) {
        out.push(buf.subarray(from, at));
        this.#cpu ??= BigInt(cpu[1]!);
        from = after + cpu[0].length;
        continue;
      }
      if ((/^\d{0,3}$/.test(tail) || (this.#started && CPU_LINE_SO_FAR_RE.test(tail))) && after + tail.length === buf.length) {
        // The start line, the CPU line or the sentinel so far: held until its newline.
        out.push(buf.subarray(from, at));
        this.#held = Buffer.from(buf.subarray(at));
        return Buffer.concat(out);
      }
      // The nonce, but not the wrapper's line: the program's bytes after all.
      out.push(buf.subarray(from, at + 1));
      from = at + 1;
    }
  }

  /** How many of `buf`'s last bytes (from `from` on) could start the sentinel: the longest suffix that is a prefix of it. */
  #startAtEnd(buf: Buffer, from: number): number {
    const mark = this.#nonce[0]!;
    for (let i = Math.max(from, buf.length - this.#nonce.length + 1); i < buf.length; i++) {
      if (buf[i] === mark && buf.subarray(i).equals(this.#nonce.subarray(0, buf.length - i))) return buf.length - i;
    }
    return 0;
  }

  end(): Buffer {
    if (this.#rc !== null) return EMPTY;
    const held = this.#held;
    this.#held = EMPTY;
    if (held.length >= this.#nonce.length && held.subarray(0, this.#nonce.length).equals(this.#nonce)) return EMPTY;
    return held;
  }
}

/**
 * Pass `src` on to `dst` (through `scanner` when given) with its backpressure, until `src` ends; then end
 * `dst`. A `dst` its reader destroyed stops nothing: the rest is drained unread. `onStart` runs once the
 * scanner has the start line, `onSentinel` once it has the status.
 */
function forward(src: Readable, dst: PassThrough, scanner: SentinelScanner | null, onSentinel: () => void, onStart: () => void = () => undefined): Promise<void> {
  return new Promise<void>((resolve) => {
    let paused = false;
    const put = (b: Buffer): void => {
      if (b.length === 0 || dst.destroyed || dst.writableEnded) return;
      if (!dst.write(b) && !paused) {
        paused = true;
        src.pause();
        dst.once('drain', () => {
          paused = false;
          src.resume();
        });
      }
    };
    dst.once('close', () => src.resume());
    src.on('data', (b: Buffer) => {
      if (scanner === null) return put(b);
      const had = scanner.rc !== null;
      const began = scanner.started;
      const out = scanner.push(b);
      if (!began && scanner.started) onStart();
      put(out);
      if (!had && scanner.rc !== null) onSentinel();
    });
    let ended = false;
    const end = (): void => {
      if (ended) return;
      ended = true;
      if (scanner !== null) put(scanner.end());
      if (!dst.writableEnded && !dst.destroyed) dst.end();
      resolve();
    };
    src.once('end', end);
    src.once('close', end);
    src.once('error', end);
  });
}

/**
 * Settles once `r`'s reader has had everything (its 'end'), as a child process's 'close' waits for its stdio:
 * a stream nobody reads is resumed first (Node's flushStdio), so it never holds the exit back.
 */
function delivered(r: Readable): Promise<void> {
  if (r.readableEnded || r.destroyed) return Promise.resolve();
  if (r.listenerCount('data') === 0 && r.listenerCount('readable') === 0) r.resume();
  return new Promise<void>((resolve) => {
    r.once('end', () => resolve());
    r.once('close', () => resolve());
  });
}

// ---------------------------------------------------------------- reading a pod

interface ContainerStateJson {
  waiting?: { reason?: string; message?: string };
  running?: unknown;
  terminated?: { reason?: string; message?: string; exitCode?: number };
}

/** The part of `kubectl get pod -o json` the driver reads. */
export interface PodJson {
  status?: {
    phase?: string;
    reason?: string;
    message?: string;
    podIP?: string;
    conditions?: Array<{ type?: string; status?: string; reason?: string; message?: string }>;
    containerStatuses?: Array<{ name?: string; state?: ContainerStateJson; lastState?: ContainerStateJson }>;
  };
}

export type PodRead = { pod: PodJson } | { gone: string } | { error: string };

/** The part of `kubectl get nodes -o json`'s items K8sSandbox.nodePodRoom reads. */
interface NodeJson {
  metadata?: { name?: string };
  spec?: { unschedulable?: boolean };
  status?: { allocatable?: { pods?: string } };
}

/** The common shape of the kubectl calls below (and k8s-network.ts's): always in the namespace. */
export interface K8sContext {
  namespace: string;
  exec: KubectlExec;
  stream: KubectlStream;
  names: PodNames;
  warn: (line: string) => void;
  readyTimeoutMs: number;
  /** How long an exec has for the wrapper's start line (default EXEC_START_TIMEOUT_MS). */
  execStartTimeoutMs?: number;
  /** How long a timed kill() waits for the launcher's reading before it cuts the exec (default TIMED_KILL_MS). */
  timedKillMs?: number;
}

export function kubectl(ctx: K8sContext, args: readonly string[], opts?: KubectlCallOptions): Promise<KubectlResult> {
  return ctx.exec(['-n', ctx.namespace, ...args], opts);
}

export async function readPod(ctx: K8sContext, name: string): Promise<PodRead> {
  const r = await kubectl(ctx, ['get', `pod/${name}`, '-o', 'json']);
  if (r.code === 0 && r.error === undefined) {
    try {
      return { pod: JSON.parse(r.stdout) as PodJson };
    } catch {
      return { error: 'kubectl get printed no pod' };
    }
  }
  if (/\(NotFound\)|not found/i.test(r.stderr)) return { gone: why(r) };
  return { error: why(r) };
}

function mainOf(pod: PodJson): { state?: ContainerStateJson; lastState?: ContainerStateJson } | undefined {
  return pod.status?.containerStatuses?.find((c) => c.name === CONTAINER);
}

function reasonText(reason: string | undefined, message: string | undefined): string {
  return `${reason ?? 'no reason'}${message === undefined || message === '' ? '' : `: ${message}`}`;
}

/** What a pod's status says, one line: its phase, reason and message, and its container's state. */
function describePod(pod: PodJson): string {
  const s = pod.status ?? {};
  const parts = [`phase ${s.phase ?? 'unknown'}`];
  if (s.reason !== undefined || s.message !== undefined) parts.push(reasonText(s.reason, s.message));
  const unscheduled = s.conditions?.find((c) => c.type === 'PodScheduled' && c.status === 'False');
  if (unscheduled !== undefined) parts.push(reasonText(unscheduled.reason, unscheduled.message));
  const state = mainOf(pod)?.state;
  if (state?.waiting !== undefined) parts.push(`waiting ${reasonText(state.waiting.reason, state.waiting.message)}`);
  if (state?.terminated !== undefined) parts.push(`terminated ${reasonText(state.terminated.reason, state.terminated.message)} (exit ${state.terminated.exitCode ?? '?'})`);
  return parts.join('; ');
}

function oomKilled(pod: PodJson): boolean {
  const main = mainOf(pod);
  return main?.state?.terminated?.reason === 'OOMKilled' || main?.lastState?.terminated?.reason === 'OOMKilled' || pod.status?.reason === 'OOMKilled';
}

/** True once the pod's container can no longer run anything: the pod finished, or its container did. */
function stopped(pod: PodJson): boolean {
  return pod.status?.phase === 'Failed' || pod.status?.phase === 'Succeeded' || mainOf(pod)?.state?.terminated !== undefined;
}

/**
 * The scheduler's words when it found no room on the node for `pod` (the header's Room on the node): its PodScheduled
 * condition False, reason Unschedulable, with a message NO_ROOM_RE matches. Null for a pod scheduled, or unschedulable
 * for anything else.
 */
export function noRoomIn(pod: PodJson): string | null {
  const c = pod.status?.conditions?.find((x) => x.type === 'PodScheduled' && x.status === 'False');
  if (c === undefined || c.reason !== 'Unschedulable' || c.message === undefined || !NO_ROOM_RE.test(c.message)) return null;
  return c.message;
}

/** A wait's end: Ready (or Succeeded), or why not, with `noRoom` the scheduler's words when the pod was last seen held for room on the node (noRoomIn). */
export type PodWait = { ok: true } | { ok: false; reason: string | null; why: string; noRoom?: string };

/**
 * Wait for a pod to be Ready (a program's) or Succeeded (preflight's), within `budgetMs`: `kubectl wait` in
 * WAIT_SLICE_S slices, the pod read between two, so one that will never get there (NEVER_READY, a
 * finished pod, one gone) fails at once while one only Pending (a node short of the requests, or of pod
 * slots) waits on. One the budget ends on while the scheduler still finds no room for it says so (`noRoom`).
 */
export async function awaitPod(ctx: K8sContext, name: string, target: 'Ready' | 'Succeeded', budgetMs: number, signal?: AbortSignal): Promise<PodWait> {
  const deadline = Date.now() + budgetMs;
  const condition = target === 'Ready' ? '--for=condition=Ready' : '--for=jsonpath={.status.phase}=Succeeded';
  let last = 'no answer yet';
  let noRoom: string | null = null;
  const cut = (): boolean => signal?.aborted === true;
  for (;;) {
    if (cut()) return { ok: false, reason: null, why: 'cut off' };
    const slice = Math.max(1, Math.min(WAIT_SLICE_S, Math.ceil((deadline - Date.now()) / 1000)));
    const started = Date.now();
    const w = await kubectl(ctx, ['wait', condition, `pod/${name}`, `--timeout=${slice}s`], { signal, timeoutMs: (slice + 30) * 1000 });
    if (w.code === 0 && w.error === undefined) return { ok: true };
    if (cut()) return { ok: false, reason: null, why: 'cut off' };
    const read = await readPod(ctx, name);
    if ('gone' in read) return { ok: false, reason: null, why: `the pod is gone (${read.gone})` };
    if ('error' in read) last = `could not read it: ${read.error}`;
    else {
      const s = read.pod.status ?? {};
      if (target === 'Succeeded' && s.phase === 'Succeeded') return { ok: true };
      if (target === 'Ready' && s.phase === 'Running' && s.conditions?.some((c) => c.type === 'Ready' && c.status === 'True') === true) return { ok: true };
      const waiting = mainOf(read.pod)?.state?.waiting;
      if (waiting?.reason !== undefined && NEVER_READY.has(waiting.reason)) return { ok: false, reason: waiting.reason, why: describePod(read.pod) };
      if (s.phase === 'Failed' || s.phase === 'Succeeded') return { ok: false, reason: s.reason ?? null, why: describePod(read.pod) };
      last = describePod(read.pod);
      noRoom = noRoomIn(read.pod);
    }
    if (Date.now() >= deadline) return { ok: false, reason: null, why: `not ${target} within ${budgetMs} ms (${last})`, ...(noRoom === null ? {} : { noRoom }) };
    const pause = Math.min(WAIT_PAUSE_MS - (Date.now() - started), deadline - Date.now());
    if (pause > 0) {
      try {
        await sleep(pause, undefined, { signal });
      } catch {
        return { ok: false, reason: null, why: 'cut off' };
      }
    }
  }
}

/** Delete objects by `kind/name`, at once and without a get (the Role has no get on secrets); warned of when it never succeeds. */
export async function deleteObjects(ctx: K8sContext, refs: readonly string[]): Promise<void> {
  let last = '';
  for (let i = 0; i < DELETE_ATTEMPTS; i++) {
    const r = await kubectl(ctx, ['delete', ...refs, '--ignore-not-found', '--grace-period=0', '--force', '--wait=false']);
    if (r.code === 0 && r.error === undefined) return;
    last = why(r);
    if (i < DELETE_ATTEMPTS - 1) await sleep(DELETE_BACKOFF_MS * 2 ** i);
  }
  ctx.warn(`k8s sandbox: ${refs.join(' ')} may still be there: no kubectl delete succeeded in ${DELETE_ATTEMPTS} tries (${last}); its activeDeadlineSeconds ends the pod within ${STALE_AFTER_MS / 3_600_000} h (a race pod at its lifetime)`);
}

function failure(error: string): SandboxExit {
  return { code: K8S_DRIVER_FAILURE, signal: null, error: `kubernetes: ${error}` };
}

function killedExit(): SandboxExit {
  return { code: K8S_KILLED, signal: null };
}

// ---------------------------------------------------------------- one program in one pod

/** What one K8sProcess runs: its pod, what is made with it, and the command. */
interface Launch {
  name: string;
  /** What `kubectl create` makes, the pod last: built as the process starts (the gateway's addresses are looked up). */
  objects: () => Promise<K8sObject[]>;
  /** The env Secret, made once the pod is (ownedByPod), or null for none. */
  secret?: K8sObject | null;
  /** `kind/name` of everything `objects` and `secret` make, the pod first: deleted once the program is done. */
  refs: readonly string[];
  argv: readonly string[];
  /** The wrapper's process cap; 0 for none. */
  pids: number;
  /** The trial network the pod joins, the names it answers to there and the port it serves on (servedPort), or null. */
  network: { name: string; names: readonly string[]; port?: number | null } | null;
  /**
   * An entry's policy wait (POLICY_WAIT_MS): its interpreter's POLICY_WAIT_ARGV and the peers it dials, as of
   * when `objects` built its hostAliases. Absent for any other pod.
   */
  reach?: { argv: readonly string[]; peers: () => readonly ServedPeer[] };
  /**
   * A timed pod's (the header's Timing): `argv` is the CPU launcher's (cpuLauncherArgv), the exec runs it under
   * TIMED_EXEC_WRAPPER, its reading is the process's cpuUs, and kill() lets the launcher report before the exec is cut.
   */
  timed?: boolean;
}

/**
 * A program in its pod (the header), returned before anything reached the cluster, as a DockerProcess is
 * before its container exists.
 */
export class K8sProcess implements SandboxProcess {
  readonly stdin = new PassThrough();
  readonly stdout = new PassThrough();
  readonly stderr = new PassThrough();
  readonly exited: Promise<SandboxExit>;
  /** The wrapper's start line came: the program runs now, after its pod's create, Ready and policy wait. */
  readonly started: Promise<void>;
  /** The pod's name. */
  readonly pod: string;
  readonly #markStarted: () => void;
  readonly #ctx: K8sContext;
  readonly #launch: Launch;
  readonly #abort = new AbortController();
  /** The create was sent: the pod (and what came with it) is deleted at the end. */
  #created = false;
  /** The pod's IP is in PodNames. */
  #registered = false;
  /** The sentinel came: the wrapper has already ended everything the program started. */
  #reported = false;
  #killed = false;
  #done = false;
  #child: KubectlChild | null = null;
  #killing: Promise<void> | null = null;
  /** The wrapper's start line came: the program was handed to the shell to run. */
  #began = false;
  /** The sentinel came: the wrapper has nothing left to run. */
  #ended = false;
  /** A timed pod's launcher reading, once its exec ended with it. */
  #cpu: bigint | null = null;
  /** Why the node had no room for the pod, when that is why its program never ran (noRoom). */
  #noRoom: string | null = null;

  constructor(ctx: K8sContext, launch: Launch) {
    this.#ctx = ctx;
    this.#launch = launch;
    this.pod = launch.name;
    let mark: () => void = () => undefined;
    this.started = new Promise<void>((resolve) => {
      mark = resolve;
    });
    this.#markStarted = mark;
    this.exited = this.#run();
  }

  /** Whether the wrapper's start line came: the program ran, or was handed to the shell to run. */
  get programStarted(): boolean {
    return this.#began;
  }

  /** A timed pod's CPU launcher reading in µs (the header's Timing), once it exited with one; null otherwise. */
  get cpuUs(): bigint | null {
    return this.#cpu;
  }

  /**
   * Once it exited as the driver's failure because the node had no room for its pod (the header's Room on the node: the
   * scheduler held it Pending for room through its whole ready budget, or a quota refused its create), the scheduler's or
   * the API's words; null otherwise. Its program never ran then.
   */
  get noRoom(): string | null {
    return this.#noRoom;
  }

  kill(): Promise<void> {
    this.#killing ??= (async () => {
      this.#killed = true;
      this.#abort.abort();
      const child = this.#child;
      if (this.#launch.timed === true && child !== null && this.#began && !this.#ended && !this.#done) await this.#killTimed(child);
      else child?.kill();
      await this.exited;
    })();
    return this.#killing;
  }

  /**
   * A timed program's kill (the header's Timing): every process of its user SIGKILLed in the pod (TIMED_KILL_ARGV), the
   * launcher left to reap them and print its reading and the sentinel; the exec cut once those came, or at
   * TIMED_KILL_MS without them (no reading then: the clock faults).
   */
  async #killTimed(child: KubectlChild): Promise<void> {
    const stop = new AbortController();
    const soft = kubectl(this.#ctx, ['exec', this.pod, '-c', CONTAINER, '--', ...TIMED_KILL_ARGV], { signal: stop.signal, timeoutMs: SIGNAL_TIMEOUT_MS });
    if (!(await settlesWithin(child.closed, this.#ctx.timedKillMs ?? TIMED_KILL_MS))) child.kill();
    // Its own loop ends with the wrapper's `kill -1`, or with the pod's delete.
    stop.abort();
    await soft;
  }

  /**
   * SIGTERM to the program and everything it started (`kill -TERM -1` in its pod; the wrapper ignores it):
   * docker kill --signal TERM's twin for a service's orderly stop. A no-op before the program runs or once it
   * has exited.
   */
  async terminate(): Promise<void> {
    if (this.#child === null || this.#done) return;
    await this.#signal('TERM');
  }

  async #signal(sig: 'TERM' | 'KILL'): Promise<void> {
    // kill(-1) spares the caller and the pod's PID 1 (`sleep`, the policy listener); its status says nothing (none left to signal is fine).
    await kubectl(this.#ctx, ['exec', this.pod, '-c', CONTAINER, '--', '/bin/sh', '-c', `kill -s ${sig} -- -1`], { timeoutMs: SIGNAL_TIMEOUT_MS });
  }

  async #run(): Promise<SandboxExit> {
    let exit: SandboxExit;
    try {
      exit = await this.#start();
    } catch (err) {
      exit = failure(`pod ${this.pod}: ${err instanceof Error ? err.message : String(err)}`);
    }
    this.#done = true;
    // Nothing reads stdin any more: what is written now is dropped, never left blocking its writer.
    this.stdin.unpipe();
    this.stdin.resume();
    if (!this.stdout.writableEnded) this.stdout.end();
    if (!this.stderr.writableEnded) this.stderr.end();
    await this.#cleanup();
    await Promise.all([delivered(this.stdout), delivered(this.stderr)]);
    return exit;
  }

  async #start(): Promise<SandboxExit> {
    const objects = await this.#launch.objects();
    if (this.#killed) return killedExit();
    this.#created = true;
    const secret = this.#launch.secret ?? null;
    const made = await kubectl(this.#ctx, ['create', '-f', '-', ...(secret === null ? [] : ['-o', CREATED_JSONPATH])], { input: JSON.stringify({ apiVersion: 'v1', kind: 'List', items: objects }) });
    if (made.code !== 0 || made.error !== undefined) {
      if (this.#killed) return killedExit();
      const said = why(made);
      if (made.error === undefined && NO_ROOM_RE.test(said)) this.#noRoom = said;
      return failure(`kubectl could not create pod ${this.pod}: ${said}`);
    }
    if (this.#killed) return killedExit();
    if (secret !== null) {
      // The pod waits in CreateContainerConfigError until its Secret exists; the ready wait below sees it through.
      const uid = createdUid(made.stdout, this.pod);
      if (uid === null) return failure(`kubectl create did not say pod ${this.pod}'s uid, which its env Secret is owned by (${JSON.stringify(made.stdout.slice(0, 200))})`);
      const owned = await kubectl(this.#ctx, ['create', '-f', '-'], { input: JSON.stringify(ownedByPod(secret, { name: this.pod, uid })) });
      if (owned.code !== 0 || owned.error !== undefined) return this.#killed ? killedExit() : failure(`kubectl could not create pod ${this.pod}'s env Secret: ${withoutValues(why(owned), secret)}`);
      if (this.#killed) return killedExit();
    }
    const ready = await awaitPod(this.#ctx, this.pod, 'Ready', this.#ctx.readyTimeoutMs, this.#abort.signal);
    if (this.#killed) return killedExit();
    if (!ready.ok) {
      this.#noRoom = ready.noRoom ?? null;
      return failure(`pod ${this.pod} never became ready: ${ready.why}`);
    }
    const net = this.#launch.network;
    if (net !== null) {
      const read = await readPod(this.#ctx, this.pod);
      const ip = 'pod' in read ? read.pod.status?.podIP : undefined;
      if (typeof ip !== 'string' || isIP(ip) === 0) return failure(`pod ${this.pod} is ready without an IP (${'pod' in read ? 'none in its status' : 'gone' in read ? read.gone : read.error})`);
      this.#ctx.names.register(net.name, this.pod, ip, net.names, net.port ?? null);
      this.#registered = true;
    }
    if (this.#killed) return killedExit();
    const reach = this.#launch.reach;
    if (reach !== undefined) {
      const missed = await this.#reachPeers(reach.argv, reach.peers());
      if (this.#killed) return killedExit();
      if (missed !== null) return failure(`pod ${this.pod} could not reach its trial's services within ${POLICY_WAIT_MS} ms of Ready, so its trial policy is not enforced for it (${missed})`);
    }
    return await this.#exec();
  }

  /**
   * The policy wait: from inside the pod, each peer takes a connection (POLICY_WAIT_ARGV) on its POLICY_PORT
   * before the program runs, measured, never assumed from Ready. Null once all did (or there are none), else
   * what failed.
   */
  async #reachPeers(argv: readonly string[], peers: readonly ServedPeer[]): Promise<string | null> {
    if (peers.length === 0) return null;
    const targets = peers.flatMap((p) => [p.ip, String(POLICY_PORT)]);
    const r = await kubectl(this.#ctx, ['exec', this.pod, '-c', CONTAINER, '--', ...argv, String(POLICY_WAIT_MS), ...targets], { signal: this.#abort.signal, timeoutMs: POLICY_WAIT_MS + KUBECTL_TIMEOUT_MS });
    if (r.code === 0 && r.error === undefined) return null;
    const said = r.stdout.trim().split('\n').at(-1) ?? '';
    const [at] = said.split(' ');
    const peer = peers.find((p) => `${p.ip}:${POLICY_PORT}` === at);
    if (r.code === 1 && r.error === undefined && peer !== undefined) return `${peer.names[0] ?? 'a peer'} at ${said}`;
    return `the wait did not run: ${why(r)}`;
  }

  async #exec(): Promise<SandboxExit> {
    const nonce = randomBytes(16).toString('hex');
    const scanner = new SentinelScanner(nonce);
    const timed = this.#launch.timed === true;
    const wrapper = timed ? TIMED_EXEC_WRAPPER : EXEC_WRAPPER;
    const child = this.#ctx.stream(['-n', this.#ctx.namespace, 'exec', '-i', this.pod, '-c', CONTAINER, '--', '/bin/sh', '-c', wrapper, 'sh', String(this.#launch.pids), ...this.#launch.argv]);
    this.#child = child;
    child.stdin.on('error', () => undefined);
    child.stdout.on('error', () => undefined);
    child.stderr.on('error', () => undefined);
    // The nonce on a line of its own, before anything of the program's: the wrapper reads it, the program never sees it.
    child.stdin.write(`${nonce}\n`);
    this.stdin.pipe(child.stdin);
    let drain: NodeJS.Timeout | undefined;
    // The program's budget runs from the start line only, so the exec's handshake is bounded here instead.
    const startMs = this.#ctx.execStartTimeoutMs ?? EXEC_START_TIMEOUT_MS;
    let unstarted = false;
    const startCut = setTimeout(() => {
      unstarted = true;
      child.kill();
    }, startMs);
    const out = forward(
      child.stdout,
      this.stdout,
      scanner,
      () => {
        this.#ended = true;
        drain = setTimeout(() => child.kill(), EXEC_DRAIN_MS);
        drain.unref();
      },
      () => {
        clearTimeout(startCut);
        this.#began = true;
        this.#markStarted();
      },
    );
    const err = forward(child.stderr, this.stderr, null, () => undefined);
    const end = await child.closed;
    clearTimeout(drain);
    clearTimeout(startCut);
    await Promise.all([out, err]);
    this.stdin.unpipe(child.stdin);
    if (scanner.rc !== null) {
      this.#reported = true;
      if (timed) {
        // The wrapper prints the reading only when the launcher wrote one: without it the run cannot be counted.
        this.#cpu = scanner.cpuUs;
        if (this.#cpu === null) return failure(`pod ${this.pod}: the CPU launcher reported no CPU time (the wrapper's status ${scanner.rc}; its own words, if any, end the program's stderr)`);
      }
      return { code: scanner.rc, signal: null };
    }
    if (this.#killed) return killedExit();
    if (unstarted) return failure(`pod ${this.pod}: the exec did not start the program within ${startMs} ms`);
    return await this.#unexplained(end);
  }

  /** The exec ended without the sentinel: the pod says why (the header). */
  async #unexplained(end: KubectlEnd): Promise<SandboxExit> {
    const exec = end.error ?? (end.signal === null ? `kubectl exec exited ${end.code}` : `kubectl exec ended by ${end.signal}`);
    const lost = `pod ${this.pod}: the program ended without its exit status (${exec})`;
    const deadline = Date.now() + POD_SETTLE_MS;
    for (;;) {
      const read = await readPod(this.#ctx, this.pod);
      if ('gone' in read) return failure(`${lost}; the pod is gone`);
      if ('pod' in read) {
        if (oomKilled(read.pod)) return { code: K8S_KILLED, signal: null };
        if (stopped(read.pod) || Date.now() >= deadline) return failure(`${lost}; the pod: ${describePod(read.pod)}`);
      } else if (Date.now() >= deadline) return failure(`${lost}; the pod could not be read: ${read.error}`);
      await sleep(POD_SETTLE_POLL_MS);
    }
  }

  async #cleanup(): Promise<void> {
    if (this.#registered) this.#ctx.names.unregister(this.#launch.network!.name, this.pod);
    if (!this.#created) return;
    // A program cut off (killed, or its exec lost) may still run in the pod: everything there dies before
    // kill() returns, as everything in a removed container does.
    if (!this.#reported && this.#child !== null) await this.#signal('KILL');
    await deleteObjects(this.#ctx, this.#launch.refs);
  }
}

/**
 * SIGTERM to a k8s sandbox's program and what it started (K8sProcess.terminate): the harnesses' orderly stop
 * of a service (agent.ts, scrape/trial.ts), docker kill --signal TERM's twin.
 */
export async function k8sTerminate(proc: SandboxProcess): Promise<void> {
  if (!(proc instanceof K8sProcess)) throw new SandboxError('a k8s sandbox\'s process is no K8sProcess: it cannot be sent SIGTERM');
  await proc.terminate();
}

/**
 * Why the node had no room for a process's pod, when that is why it never ran (K8sProcess.noRoom: the header's Room on
 * the node); null for any other end, and for any other driver's process, which no node holds back.
 */
export function noRoomOf(proc: SandboxProcess): string | null {
  return proc instanceof K8sProcess ? proc.noRoom : null;
}

/** A preflight pod the node had no room for (the header's Room on the node): backpressure, never a fault of the image or the RBAC. */
export class NodeRoomError extends SandboxError {
  /** The scheduler's or the API's words. */
  readonly noRoom: string;
  constructor(message: string, noRoom: string) {
    super(message);
    this.name = 'NodeRoomError';
    this.noRoom = noRoom;
  }
}

// ---------------------------------------------------------------- the meter

/** The meter's pod (the header) behind TreeMeter, its readings parsed as DockerMeter's. */
class K8sMeter implements TreeMeter {
  readonly #proc: K8sProcess;
  readonly #opts: TreeMeterOptions;
  /** stop() was called, or the fault reported: nothing more is reported. */
  #quiet = false;
  #stopping: Promise<void> | null = null;
  #stderr = '';

  constructor(proc: K8sProcess, opts: TreeMeterOptions) {
    this.#proc = proc;
    this.#opts = opts;
    const readings = new MeterReadings({ onUsage: (u) => opts.onUsage(u), fault: (m) => this.#fault(m), quiet: () => this.#quiet });
    proc.stdout.setEncoding('utf8').on('data', (s: string) => readings.push(s));
    proc.stderr.setEncoding('utf8').on('data', (s: string) => {
      if (this.#stderr.length < METER_STDERR_BYTES) this.#stderr += s.slice(0, METER_STDERR_BYTES - this.#stderr.length);
    });
    void proc.exited.then((exit) => {
      const said = this.#stderr.trim().split('\n')[0] ?? '';
      const how = exit.error ?? (exit.signal === null ? `code ${exit.code}` : `signal ${exit.signal}`);
      // A meter pod the node had no room for never ran (K8sProcess.noRoom): its caller hands the job back (meterFailure).
      this.#fault(`the meter pod exited (${how})${said === '' ? '' : `: ${said}`}`, proc.noRoom ?? undefined);
    });
  }

  stop(): Promise<void> {
    this.#stopping ??= (async () => {
      this.#quiet = true;
      // Its stdin closing is what ends it (the script's watcher), even when its exec has not opened yet.
      this.#proc.stdin.end();
      if (await settlesWithin(this.#proc.exited, METER_STOP_MS)) return;
      await this.#proc.kill();
    })();
    return this.#stopping;
  }

  /** Report the meter's failure (once, never after stop()), with the scheduler's words when its pod found no room, then make sure it is gone. */
  #fault(message: string, noRoom?: string): void {
    if (this.#quiet) return;
    this.#quiet = true;
    if (noRoom === undefined) this.#opts.onFault(message);
    else this.#opts.onFault(message, noRoom);
    void this.stop();
  }
}

/**
 * A /output meter's fault (TreeMeterOptions.onFault) as its caller throws it: a NodeRoomError when the node had no room
 * for the meter's pod (`noRoom`, the header's Room on the node: backpressure, its job handed back), else a SandboxError.
 */
export function meterFailure(message: string, noRoom: string | null | undefined): SandboxError {
  return noRoom === null || noRoom === undefined ? new SandboxError(message) : new NodeRoomError(message, noRoom);
}

// ---------------------------------------------------------------- the CPU clock

/** What the clock reads of a timed process (K8sProcess): its pod, its end, whether its program started, its reading. */
export type TimedProcess = Pick<K8sProcess, 'pod' | 'exited' | 'programStarted' | 'cpuUs'>;

/**
 * A timed sandbox's clock (the header's Timing): the sum of its pods' launcher readings, in µs, each added once its
 * process has exited. A pod whose program started and that exited with no reading faults it: read() and settled()
 * throw SandboxError from then on. One whose program never started adds 0.
 */
export class K8sCpuClock implements CpuClock {
  readonly source: string;
  readonly #settleMs: number;
  readonly #pending = new Set<Promise<void>>();
  #usage = 0n;
  #fault: string | null = null;
  #closed = false;

  /** `settleMs`: how long settled() waits for the processes in flight (default docker.ts CPU_CLOCK_READ_MS). */
  constructor(source: string, opts: { settleMs?: number } = {}) {
    this.source = source;
    this.#settleMs = opts.settleMs ?? CPU_CLOCK_READ_MS;
  }

  /** Count `proc`, a process of the timed sandbox's, once it has exited. */
  track(proc: TimedProcess): void {
    const counted = proc.exited.then(
      (exit) => {
        const us = proc.cpuUs;
        if (us !== null) this.#usage += us;
        else if (proc.programStarted) this.#fault ??= `pod ${proc.pod} ran its program and its CPU launcher reported no CPU time (${exit.error ?? (exit.signal === null ? `exit ${exit.code}` : `signal ${exit.signal}`)})`;
      },
      (err: unknown) => {
        this.#fault ??= `pod ${proc.pod}'s end could not be read: ${err instanceof Error ? err.message : String(err)}`;
      },
    );
    this.#pending.add(counted);
  }

  /** The readings of every timed process that has exited, summed (0 before any). SandboxError once closed or faulted. */
  async read(): Promise<bigint> {
    if (this.#closed) throw new SandboxError(`the CPU clock ${this.source} is closed`);
    if (this.#fault !== null) throw new SandboxError(`CPU time is unreadable: ${this.#fault}`);
    return this.#usage;
  }

  /** read() once every timed process in flight has exited and been counted (SandboxError past `settleMs`). */
  async settled(): Promise<bigint> {
    const deadline = Date.now() + this.#settleMs;
    while (this.#pending.size > 0) {
      const now = [...this.#pending];
      if (!(await settlesWithin(Promise.all(now), Math.max(0, deadline - Date.now())))) {
        throw new SandboxError(`CPU time is unreadable: ${this.#pending.size} timed ${this.#pending.size === 1 ? 'pod is' : 'pods are'} still running after ${this.#settleMs} ms (something else runs on the clock)`);
      }
      for (const p of now) this.#pending.delete(p);
    }
    return this.read();
  }

  /** Whether close() was called: its sandbox spawns nothing more. */
  get closed(): boolean {
    return this.#closed;
  }

  /** Stop the clock (idempotent): there is nothing of it to remove. */
  async close(): Promise<void> {
    this.#closed = true;
  }
}

/**
 * A timed sandbox (K8sSandbox.openCpuClock): its base's in every way but spawn, whose every program is a timed pod
 * counted on the clock. Its meter and reclaim pods are its base's, untimed.
 */
export class K8sTimedSandbox implements Sandbox {
  readonly kind = 'k8s' as const;
  readonly clock: K8sCpuClock;
  readonly #base: K8sSandbox;
  readonly #spawn: (spec: SandboxSpec) => K8sProcess;

  constructor(base: K8sSandbox, spawnTimed: (spec: SandboxSpec) => K8sProcess, clock: K8sCpuClock) {
    this.#base = base;
    this.#spawn = spawnTimed;
    this.clock = clock;
  }

  /** The base's data root (bundle-trees.ts k8sDataRoot reads it). */
  get dataRoot(): string {
    return this.#base.dataRoot;
  }

  get networks(): K8sTrialNetworks {
    return this.#base.networks;
  }

  imageDigest(runtime: Runtime): string {
    return this.#base.imageDigest(runtime);
  }

  preflight(runtime: Runtime, imageDigest: string | null = null): Promise<void> {
    return this.#base.preflight(runtime, imageDigest);
  }

  isDriverFailure(exit: SandboxExit): boolean {
    return this.#base.isDriverFailure(exit);
  }

  removeTree(dir: string): Promise<void> {
    return this.#base.removeTree(dir);
  }

  meterTree(dir: string, opts: TreeMeterOptions): TreeMeter {
    return this.#base.meterTree(dir, opts);
  }

  /** The program in a timed pod, counted on the clock once it exits. A SandboxError once the clock is closed. */
  spawn(spec: SandboxSpec): SandboxProcess {
    if (this.clock.closed) throw new SandboxError(`the CPU clock ${this.clock.source} is closed: its sandbox times nothing more`);
    const proc = this.#spawn(spec);
    this.clock.track(proc);
    return proc;
  }
}

/** A timed sandbox and its clock (K8sSandbox.openCpuClock): docker.ts TimedDockerSandbox's twin. */
export interface TimedK8sSandbox {
  clock: K8sCpuClock;
  sandbox: K8sTimedSandbox;
}

// ---------------------------------------------------------------- the sandbox

export interface K8sSandboxOptions {
  /** The namespace every pod goes in (the worker's own). */
  namespace: string;
  /** The data PVC and where the worker mounts it (PodPlacement). */
  dataPvc: string;
  dataRoot: string;
  /** The pods' RuntimeClass (gvisor), or null for the node's default (runc: no process cap, the header). */
  runtimeClass: string | null;
  /** The pods' service account. */
  serviceAccount: string;
  nodeSelector?: Readonly<Record<string, string>> | null;
  /** masq's origin as a forwarder reaches it (config.llmGatewaySandboxUrl), or null: no forwarder gets a gateway policy. */
  llmGateway?: string | null;
  /** The kubectl CLI (default `kubectl`); ignored for what `exec` and `stream` are given for. */
  kubectl?: string;
  /** How to run kubectl to its end (default kubectlExec(kubectl)); tests pass a fake. */
  exec?: KubectlExec;
  /** How to start `kubectl exec -i` (default kubectlStream(kubectl)); tests pass a fake. */
  stream?: KubectlStream;
  /** A host name's addresses (default the system resolver's). */
  lookup?: (host: string) => Promise<string[]>;
  /** removeTree's own delete before the reclaim pod (default fs rm, recursive and forced). */
  rm?: (dir: string) => Promise<void>;
  images?: ImageTableT;
  /** How long a pod may take to be Ready (default READY_TIMEOUT_MS). */
  readyTimeoutMs?: number;
  /** How long a program's exec has, from its spawn, for the wrapper's start line (default EXEC_START_TIMEOUT_MS). */
  execStartTimeoutMs?: number;
  /** How long a timed program's kill() waits for its launcher's reading before it cuts the exec (default TIMED_KILL_MS). */
  timedKillMs?: number;
  /** Where a pod no delete removed is reported. */
  warn?: (line: string) => void;
  /**
   * This process's own pod in the namespace (POD_NAME, from the downward API), a DNS subdomain: every pod it makes is
   * annotated with it (CREATOR_ANNOTATION) and it reaps the pods of creators gone (reapOrphans, the header's Reaping).
   * Absent or null: no annotation and no reap, the driver as before.
   */
  creator?: string | null;
  /**
   * With a creator, how often it reaps (default ORPHAN_REAP_EVERY_MS), once at once and then on an unref'd timer, one
   * reaper per namespace and creator in the process however many sandboxes it builds; 0 starts none (reapOrphans still
   * runs when called).
   */
  orphanReapEveryMs?: number;
  /** The clock reapOrphans dates pods against (default Date.now). */
  now?: () => number;
}

/** How long one read of this process's own pod's deletion deadline may take (K8sSandbox.ownDeletion): inside the drain's 10 s between reads. */
export const OWN_POD_READ_TIMEOUT_MS = 8_000;

/**
 * kubectl's words for a token the API server no longer takes: `error: You must be logged in to the server
 * (Unauthorized)`, an HTTP 401. A 403 (Forbidden: the Role's) is a refusal of the verb, not of the token, and is not this.
 */
export const TOKEN_REFUSED_RE = /\bUnauthorized\b/;

/**
 * When this process's own pod is to be gone (K8sSandbox.ownDeletion): `none` while no deletion is asked (no
 * metadata.deletionTimestamp), `deleting` with the deadline a deletion set (its grace on from the delete; a later delete
 * with a shorter grace moves it earlier), `refused` when the API server refuses the process's token (TOKEN_REFUSED_RE),
 * `unread` when the read failed any other way or printed no time (`why` says how).
 */
export type OwnPodDeletion = { state: 'none' } | { state: 'deleting'; deadline: Date } | { state: 'refused'; why: string } | { state: 'unread'; why: string };

/** The namespaces and creators a reaper already runs for in this process (K8sSandbox's constructor). */
const ORPHAN_REAPERS = new Set<string>();

function checkName(value: string, re: RegExp, what: string): string {
  if (typeof value !== 'string' || !re.test(value)) throw new SandboxError(`${what} ${JSON.stringify(value)} is not a Kubernetes name`);
  return value;
}

function checkNodeSelector(selector: Readonly<Record<string, string>> | null | undefined): Readonly<Record<string, string>> | null {
  if (selector === undefined || selector === null) return null;
  for (const [k, v] of Object.entries(selector)) {
    if (!LABEL_KEY_RE.test(k) || typeof v !== 'string' || !LABEL_VALUE_RE.test(v)) throw new SandboxError(`node selector ${JSON.stringify(k)}=${JSON.stringify(v)} is not a label`);
  }
  return Object.freeze({ ...selector });
}

export class K8sSandbox implements Sandbox {
  readonly kind = 'k8s' as const;
  readonly namespace: string;
  readonly dataPvc: string;
  readonly dataRoot: string;
  readonly runtimeClass: string | null;
  readonly serviceAccount: string;
  readonly nodeSelector: Readonly<Record<string, string>> | null;
  /** The LLM gateway a forwarder pod may reach, or null. */
  readonly llmGateway: { host: string; port: number } | null;
  readonly images: ImageTableT;
  readonly warn: (line: string) => void;
  /** This process's own pod, which annotates every pod it makes and reaps for (K8sSandboxOptions.creator), or null. */
  readonly creator: string | null;
  /** Its trial networks' owners, pods and names (what its TrialNetworks fills and clears). */
  readonly names = new PodNames();
  /** Its trial networks: per-trial NetworkPolicies over its pods (k8s-network.ts). */
  readonly networks: K8sTrialNetworks;
  readonly #ctx: K8sContext;
  readonly #lookup: (host: string) => Promise<string[]>;
  readonly #rm: (dir: string) => Promise<void>;
  /** preflight's probe per runtime and digest: kept once it passed, dropped when it failed. */
  readonly #preflights = new Map<string, Promise<void>>();
  /** nodePodRoom's last read (null: unknown) and when; when a read was last refused; the read in flight. */
  #room: { at: number; value: number | null } | null = null;
  #roomRefusedAt: number | null = null;
  #roomRead: Promise<number | null> | null = null;
  readonly #now: () => number;

  constructor(opts: K8sSandboxOptions) {
    this.namespace = checkName(opts.namespace, DNS_LABEL_RE, 'namespace');
    this.dataPvc = checkName(opts.dataPvc, DNS_SUBDOMAIN_RE, 'data PVC');
    const root = posix.normalize(checkHostPath(opts.dataRoot)).replace(/(.)\/$/, '$1');
    if (root === '/') throw new SandboxError('the data root cannot be /');
    this.dataRoot = root;
    this.runtimeClass = opts.runtimeClass === null ? null : checkName(opts.runtimeClass, DNS_SUBDOMAIN_RE, 'RuntimeClass');
    this.serviceAccount = checkName(opts.serviceAccount, DNS_SUBDOMAIN_RE, 'service account');
    this.nodeSelector = checkNodeSelector(opts.nodeSelector);
    this.llmGateway = opts.llmGateway === undefined || opts.llmGateway === null ? null : gatewayTarget(opts.llmGateway);
    this.images = opts.images ?? IMAGES;
    this.warn = opts.warn ?? ((line) => console.warn(line));
    this.creator = opts.creator === undefined || opts.creator === null ? null : checkName(opts.creator, DNS_SUBDOMAIN_RE, 'creator pod');
    this.#now = opts.now ?? Date.now;
    const reapEveryMs = opts.orphanReapEveryMs ?? ORPHAN_REAP_EVERY_MS;
    if (!Number.isFinite(reapEveryMs) || reapEveryMs < 0) throw new SandboxError(`orphan reap interval ${reapEveryMs} is out of range`);
    const kubectlCli = opts.kubectl ?? 'kubectl';
    this.#ctx = {
      namespace: this.namespace,
      exec: opts.exec ?? kubectlExec(kubectlCli),
      stream: opts.stream ?? kubectlStream(kubectlCli),
      names: this.names,
      warn: this.warn,
      readyTimeoutMs: opts.readyTimeoutMs ?? READY_TIMEOUT_MS,
      execStartTimeoutMs: opts.execStartTimeoutMs ?? EXEC_START_TIMEOUT_MS,
      timedKillMs: opts.timedKillMs ?? TIMED_KILL_MS,
    };
    this.#lookup = opts.lookup ?? (async (host) => (await dnsLookup(host, { all: true })).map((a) => a.address));
    this.#rm = opts.rm ?? ((dir) => rm(dir, { recursive: true, force: true }));
    this.networks = new K8sTrialNetworks({ ctx: this.#ctx, placement: this.placement, images: this.images });
    if (this.creator !== null && reapEveryMs > 0) this.#startOrphanReap(reapEveryMs);
  }

  /** Where its pods go and what they run as; with a creator, who makes them (no `creator` key without one). */
  get placement(): PodPlacement {
    return {
      namespace: this.namespace,
      dataPvc: this.dataPvc,
      dataRoot: this.dataRoot,
      runtimeClass: this.runtimeClass,
      serviceAccount: this.serviceAccount,
      nodeSelector: this.nodeSelector,
      ...(this.creator === null ? {} : { creator: this.creator }),
    };
  }

  /**
   * reapOrphans now and every `everyMs` after, on an unref'd timer, a pass never started while one runs: once per
   * namespace and creator in the process. What it reaped is said; a failure is said once until it changes.
   */
  #startOrphanReap(everyMs: number): void {
    const key = `${this.namespace}\n${this.creator}`;
    if (ORPHAN_REAPERS.has(key)) return;
    ORPHAN_REAPERS.add(key);
    let running = false;
    let lastProblem = '';
    const pass = (): void => {
      if (running) return;
      running = true;
      this.reapOrphans()
        .then(
          (r) => {
            const problem = r.errors.join('; ');
            if (problem !== '' && problem !== lastProblem) this.warn(`k8s sandbox: the orphan reap in namespace ${this.namespace}: ${problem}`);
            lastProblem = problem;
          },
          (err: unknown) => this.warn(`k8s sandbox: the orphan reap in namespace ${this.namespace} failed: ${(err as Error).message}`),
        )
        .finally(() => {
          running = false;
        });
    };
    setTimeout(pass, 0).unref();
    setInterval(pass, everyMs).unref();
  }

  /**
   * Delete every sandbox pod in the namespace whose creator (CREATOR_ANNOTATION) is no pod of the namespace's still
   * running and that is older than ORPHAN_GRACE_MS, with its env Secret and gateway policy, and the trial policy of
   * each trial none of whose pods is kept (the header's Reaping). Never a pod with no creator, never another
   * namespace; nothing without a creator of its own, or when the namespace's pods do not list it. Never throws: the
   * result says what it deleted (`containers` the pods, `networks` the trial policies) and what it could not read.
   */
  async reapOrphans(): Promise<SweepResult> {
    const res: SweepResult = { containers: [], networks: [], errors: [] };
    const self = this.creator;
    if (self === null) return res;
    const ctx = this.#ctx;
    const failed = (r: KubectlResult): boolean => r.code !== 0 || r.error !== undefined;
    const sandboxes = await kubectl(ctx, ['get', 'pods', '-l', `${ROLE_LABEL}=sandbox`, '-o', 'json']);
    if (failed(sandboxes)) {
      res.errors.push(`kubectl get pods -l ${ROLE_LABEL}=sandbox: ${why(sandboxes)}`);
      return res;
    }
    let items: unknown;
    try {
      items = (JSON.parse(sandboxes.stdout) as { items?: unknown }).items;
    } catch {
      items = undefined;
    }
    if (!Array.isArray(items)) {
      res.errors.push(`kubectl get pods -l ${ROLE_LABEL}=sandbox printed no list: ${JSON.stringify(sandboxes.stdout.slice(0, 200))}`);
      return res;
    }
    const live = await kubectl(ctx, ['get', 'pods', '--field-selector', 'status.phase!=Succeeded,status.phase!=Failed', '-o', 'name']);
    if (failed(live)) {
      res.errors.push(`kubectl get pods -o name: ${why(live)}`);
      return res;
    }
    const alive = new Set(
      live.stdout
        .split('\n')
        .map((l) => l.trim())
        .filter((l) => l.startsWith('pod/'))
        .map((l) => l.slice(4)),
    );
    if (!alive.has(self)) {
      res.errors.push(`this process's own pod ${self} is not among namespace ${this.namespace}'s running pods, so their list is not trusted to say which creators are gone: nothing reaped`);
      return res;
    }
    const cutoff = this.#now() - ORPHAN_GRACE_MS;
    type Item = { metadata?: { name?: unknown; creationTimestamp?: unknown; labels?: Record<string, unknown>; annotations?: Record<string, unknown> } };
    const orphans: Array<{ name: string; trial: string | null }> = [];
    const keptTrials = new Set<string>();
    for (const item of items as Item[]) {
      const name = item?.metadata?.name;
      if (typeof name !== 'string') continue;
      const trial = item.metadata?.labels?.[NETWORK_LABEL];
      const trialOfPod = typeof trial === 'string' ? trial : null;
      const keep = (): void => {
        if (trialOfPod !== null) keptTrials.add(trialOfPod);
      };
      const creator = item.metadata?.annotations?.[CREATOR_ANNOTATION];
      if (!name.startsWith(POD_PREFIX) || typeof creator !== 'string' || alive.has(creator)) {
        keep();
        continue;
      }
      const created = parseDockerTime(item.metadata?.creationTimestamp);
      if (created === null) {
        res.errors.push(`pod/${name}: no creation time`);
        keep();
      } else if (created > cutoff) keep();
      else orphans.push({ name, trial: trialOfPod });
    }
    if (orphans.length === 0) return res;
    const refs: string[] = [];
    for (const o of orphans) {
      refs.push(`pod/${o.name}`, `secret/${envSecretName(o.name)}`, `networkpolicy/${o.name}${GATEWAY_POLICY_SUFFIX}`);
      res.containers.push(o.name);
    }
    for (const trial of new Set(orphans.map((o) => o.trial))) {
      if (trial === null || keptTrials.has(trial)) continue;
      let policy: string;
      try {
        policy = trialNetworkName(trial);
      } catch {
        continue;
      }
      refs.push(`networkpolicy/${policy}`);
      res.networks.push(policy);
    }
    this.warn(`k8s sandbox: reaping ${orphans.length} sandbox pod(s) whose creator is gone (${orphans.map((o) => o.name).join(' ')})${res.networks.length === 0 ? '' : ` and trial policies ${res.networks.join(' ')}`}`);
    await deleteObjects(ctx, refs);
    return res;
  }

  /**
   * When this process's own pod (the creator) is to be gone: its metadata.deletionTimestamp, read once through the
   * driver's kubectl within OWN_POD_READ_TIMEOUT_MS (the header's `Its own pod's deletion deadline`). Never throws: a
   * process with no pod of its own, a read that fails or prints no time is `unread`, one the API server refuses the
   * token of `refused`.
   */
  async ownDeletion(): Promise<OwnPodDeletion> {
    if (this.creator === null) return { state: 'unread', why: 'this process names no pod of its own (POD_NAME)' };
    let r: KubectlResult;
    try {
      r = await kubectl(this.#ctx, ['get', `pod/${this.creator}`, '-o', 'jsonpath={.metadata.deletionTimestamp}'], { timeoutMs: OWN_POD_READ_TIMEOUT_MS });
    } catch (err) {
      return { state: 'unread', why: `kubectl get pod/${this.creator}: ${(err as Error).message}` };
    }
    if (r.code !== 0 || r.error !== undefined) {
      const said = `kubectl get pod/${this.creator}: ${why(r)}`;
      return TOKEN_REFUSED_RE.test(r.stderr) ? { state: 'refused', why: said } : { state: 'unread', why: said };
    }
    const text = r.stdout.trim();
    if (text === '') return { state: 'none' };
    const at = Date.parse(text);
    return Number.isFinite(at) ? { state: 'deleting', deadline: new Date(at) } : { state: 'unread', why: `kubectl get pod/${this.creator} printed no time: ${JSON.stringify(text.slice(0, 100))}` };
  }

  imageDigest(runtime: Runtime): string {
    return imageFor(runtime, this.images).digest;
  }

  /**
   * A timed sandbox and its CPU clock (the header's Timing), as docker.ts openCpuClock hands back: every program the
   * sandbox spawns runs in a timed pod under the CPU launcher, its reading added to the clock once it exits. Nothing
   * runs for the clock itself (the launcher is perl in the program's own image), so `runtime` is only checked as one the
   * image table pins. Close the clock when the heat is done.
   */
  openCpuClock(runtime: Runtime): TimedK8sSandbox {
    imageFor(runtime, this.images);
    const clock = new K8sCpuClock(`${K8S_CPU_CLOCK_SOURCE} ${this.runtimeClass ?? 'default'} cpu-${randomBytes(6).toString('hex')}`);
    return { clock, sandbox: new K8sTimedSandbox(this, (spec) => this.#spawn(spec, true), clock) };
  }

  /**
   * The worker may exec into pods, and the image runs on the node (a pod running `true` in it, imagePullPolicy
   * Never, under the same RuntimeClass, account and selector, reaches Succeeded): once per runtime and digest.
   */
  async preflight(runtime: Runtime, imageDigest: string | null = null): Promise<void> {
    const entry = imageFor(runtime, this.images);
    const digest = imageDigest ?? entry.digest;
    const key = `${runtime} ${imageRef(entry, digest)}`;
    let done = this.#preflights.get(key);
    if (done === undefined) {
      done = this.#probe(entry.image, digest);
      this.#preflights.set(key, done);
      done.catch(() => this.#preflights.delete(key));
    }
    return done;
  }

  async #probe(image: string, digest: string): Promise<void> {
    const ref = imageRef({ image }, digest);
    const can = await kubectl(this.#ctx, ['auth', 'can-i', 'create', 'pods', '--subresource=exec']);
    if (can.code !== 0 || can.error !== undefined || can.stdout.trim() !== 'yes') {
      throw new SandboxError(`the worker may not exec into pods in namespace ${this.namespace} (kubectl auth can-i create pods --subresource=exec: ${can.stdout.trim() || why(can)}): deploy/k8s/base/rbac.yaml's Role grants it`);
    }
    const name = podName('preflight');
    const made = await kubectl(this.#ctx, ['create', '-f', '-'], { input: JSON.stringify(preflightPodSpec({ ...this.placement, name, image, digest })) });
    try {
      if (made.code !== 0 || made.error !== undefined) {
        const said = why(made);
        const message = `kubectl could not create the preflight pod for ${ref}: ${said}`;
        throw made.error === undefined && NO_ROOM_RE.test(said) ? new NodeRoomError(message, said) : new SandboxError(message);
      }
      const done = await awaitPod(this.#ctx, name, 'Succeeded', PREFLIGHT_TIMEOUT_MS);
      if (!done.ok) {
        if (done.reason === 'ErrImageNeverPull') throw new SandboxError(`image ${ref} is not on the node: run makefun-k8s.sh pull-grader-images`);
        const message = `the preflight pod ${name} for ${ref} did not run: ${done.why}`;
        throw done.noRoom === undefined ? new SandboxError(message) : new NodeRoomError(message, done.noRoom);
      }
    } finally {
      await deleteObjects(this.#ctx, [`pod/${name}`]);
    }
  }

  /**
   * The pod slots free now on the nodes this sandbox's pods go to (the header's Room on the node): of each node its
   * selector picks (every node with none) that is not cordoned, its status.allocatable.pods less the pods bound to it in
   * every namespace and not finished (prod's, dev's, the races', the platform's), summed. Answered from the last read for
   * NODE_ROOM_CACHE_MS, one read at a time. Null when it cannot be read: a refusal (the Role grants no nodes and no pods
   * outside the namespace) is warned of once and not tried again for NODE_ROOM_REFUSED_MS; any other failure is tried
   * again on the next ask after the cache.
   */
  nodePodRoom(): Promise<number | null> {
    const at = Date.now();
    if (this.#room !== null && at - this.#room.at < NODE_ROOM_CACHE_MS) return Promise.resolve(this.#room.value);
    if (this.#roomRefusedAt !== null && at - this.#roomRefusedAt < NODE_ROOM_REFUSED_MS) return Promise.resolve(null);
    this.#roomRead ??= this.#readRoom().finally(() => {
      this.#roomRead = null;
    });
    return this.#roomRead;
  }

  async #readRoom(): Promise<number | null> {
    const refused = (r: KubectlResult): boolean => r.error === undefined && /\(Forbidden\)|\bforbidden\b/i.test(r.stderr);
    const unknown = (r: KubectlResult, what: string): null => {
      if (refused(r)) {
        this.#roomRefusedAt = Date.now();
        this.warn(
          `k8s sandbox: the node's free pod slots cannot be read (${what}: ${why(r)}): grant this account get and list on nodes and list on pods in every namespace for the check; until then each pod waits for the scheduler's room within its ready budget, and is not read again for ${NODE_ROOM_REFUSED_MS / 60_000} minutes`,
        );
      } else {
        this.#room = { at: Date.now(), value: null };
      }
      return null;
    };
    const selector = this.nodeSelector === null ? [] : ['-l', Object.entries(this.nodeSelector).map(([k, v]) => `${k}=${v}`).join(',')];
    const listed = await this.#ctx.exec(['get', 'nodes', ...selector, '-o', 'json']);
    if (listed.code !== 0 || listed.error !== undefined) return unknown(listed, 'kubectl get nodes');
    let nodes: NodeJson[];
    try {
      nodes = (JSON.parse(listed.stdout) as { items?: NodeJson[] }).items ?? [];
    } catch {
      return unknown({ code: 1, stdout: '', stderr: 'printed no node list' }, 'kubectl get nodes');
    }
    let room = 0;
    for (const node of nodes) {
      if (node.spec?.unschedulable === true) continue;
      const name = node.metadata?.name;
      const allocatable = Number(node.status?.allocatable?.pods);
      if (typeof name !== 'string' || !DNS_SUBDOMAIN_RE.test(name) || !Number.isSafeInteger(allocatable) || allocatable < 0) {
        return unknown({ code: 1, stdout: '', stderr: `a node with no name or no allocatable pods: ${JSON.stringify(node.metadata?.name ?? null)}` }, 'kubectl get nodes');
      }
      const bound = await this.#ctx.exec(['get', 'pods', '--all-namespaces', '--field-selector', `spec.nodeName=${name},status.phase!=Succeeded,status.phase!=Failed`, '-o', 'name']);
      if (bound.code !== 0 || bound.error !== undefined) return unknown(bound, `kubectl get pods on node ${name}`);
      const used = bound.stdout.split('\n').filter((l) => l.trim() !== '').length;
      room += Math.max(0, allocatable - used);
    }
    this.#room = { at: Date.now(), value: room };
    this.#roomRefusedAt = null;
    return room;
  }

  /** The cluster could not run the program (K8S_DRIVER_FAILURE with the driver's error): never the program's own 125. */
  isDriverFailure(exit: SandboxExit): boolean {
    return exit.code === K8S_DRIVER_FAILURE && exit.error !== undefined;
  }

  /**
   * Delete `dir` (docker.ts removeTree's twin): with rm, else (what rm may not delete) from a reclaim pod
   * running RECLAIM_SCRIPT as the sandbox user, then what is left with rm. LeftoverError when the reclaim ran
   * and still could not delete what the program left, a plain SandboxError when the cluster could not run it.
   */
  async removeTree(dir: string): Promise<void> {
    try {
      await this.#rm(dir);
      return;
    } catch (err) {
      const code = (err as NodeJS.ErrnoException).code;
      if (code !== 'EACCES' && code !== 'EPERM' && code !== 'ENOTEMPTY' && code !== 'ENAMETOOLONG') throw err;
    }
    const entry = imageFor('node22', this.images);
    const name = podName('reclaim');
    const pod = reclaimPodSpec(dir, { ...this.placement, name, image: entry.image, digest: entry.digest });
    const proc = new K8sProcess(this.#ctx, { name, objects: async () => [pod], refs: [`pod/${name}`], argv: ['sh', '-c', RECLAIM_SCRIPT], pids: 0, network: null });
    proc.stdin.end();
    proc.stdout.resume();
    let stderr = '';
    proc.stderr.setEncoding('utf8').on('data', (s: string) => {
      if (stderr.length < METER_STDERR_BYTES) stderr += s;
    });
    if (!(await settlesWithin(proc.exited, RECLAIM_TIMEOUT_MS))) {
      await proc.kill();
      throw new SandboxError(`kubernetes could not reclaim ${dir}: no exit within ${RECLAIM_TIMEOUT_MS} ms`);
    }
    const exit = await proc.exited;
    const said = stderr.trim().split('\n')[0] ?? '';
    if (this.isDriverFailure(exit)) throw new SandboxError(`kubernetes could not reclaim ${dir}: ${exit.error}`);
    if (exit.code === RECLAIM_REFUSED) throw new LeftoverError(dir, `the sandbox user could not delete what is left in ${dir}: ${said}`);
    if (exit.code !== 0) throw new SandboxError(`kubernetes could not reclaim ${dir} (exit ${exit.code}): ${said}`);
    await this.#rm(dir);
  }

  spawn(spec: SandboxSpec): SandboxProcess {
    return this.#spawn(spec, false);
  }

  /** A program's pod (sandboxPodSpec) and its process; a timed one's under the CPU launcher (openCpuClock's sandbox). */
  #spawn(spec: SandboxSpec, timed: boolean): K8sProcess {
    const entry = imageFor(spec.runtime, this.images);
    const name = podName(spec.label);
    const network = spec.network === undefined ? null : checkSandboxNetwork(spec.network);
    const owner = network === null ? null : this.names.ownerOf(network.name);
    const podOptions = (): SandboxPodOptions => ({
      ...this.placement,
      name,
      image: entry.image,
      digest: spec.imageDigest ?? entry.digest,
      hostAliases: network === null ? [] : this.names.hostAliases(network.name),
      owner,
      ...(timed ? { timed } : {}),
    });
    // Built now so a bad spec throws here, as dockerRunArgs does; built again as the pod is made, with the
    // peers registered by then.
    sandboxPodSpec(spec, podOptions());
    // A launcher pod with no launcher, config or CA would die before `ready`, a void with no reason.
    const missing = houseFilesMissing(spec);
    if (missing.length > 0) throw new SandboxError(`the house ${spec.launcher!.houseDir} lacks ${missing.join(', ')} (launch.ts houseFor, writeHouse)`);
    const marks = objectMarks(name, network, owner);
    const secret = sandboxEnvSecret(spec, { name, namespace: this.namespace, ...marks });
    const gateway = isForwarder(network) ? this.llmGateway : null;
    const refs = [`pod/${name}`, ...(secret === null ? [] : [`secret/${secret.metadata.name}`]), ...(gateway === null ? [] : [`networkpolicy/${name}${GATEWAY_POLICY_SUFFIX}`])];
    const program = spec.launcher === undefined ? [...RUNTIME_COMMANDS[spec.runtime], `/bot/${scriptOf(spec)}`] : [...LAUNCHER_ARGV[spec.runtime]];
    const argv = timed ? cpuLauncherArgv(program) : program;
    const pids = this.runtimeClass === null ? 0 : Number(positiveInt(spec.limits.pids, 'pids')) + POD_OWN_TASKS;
    if (timed && pids !== 0 && pids < TIMED_ROOT_TASKS) {
      throw new SandboxError(`a timed pod's root tasks number ${TIMED_ROOT_TASKS} under its process cap, so its pids must be at least ${TIMED_ROOT_TASKS - POD_OWN_TASKS}, not ${spec.limits.pids}`);
    }
    // An entry's policy wait dials the served peers its hostAliases name: those registered as its pod is made.
    const dials = network !== null && isEntry(network) ? network.name : null;
    let peers: readonly ServedPeer[] = [];
    return new K8sProcess(this.#ctx, {
      name,
      refs,
      argv,
      pids,
      ...(timed ? { timed } : {}),
      network: network === null ? null : { name: network.name, names: [...(network.aliases ?? []), ...(network.hosts ?? [])], port: servedPort(network) },
      secret,
      objects: async () => {
        const policy = gateway === null ? [] : [gatewayPolicy({ name, namespace: this.namespace, ...marks, addresses: await this.#addressesOf(gateway.host), port: gateway.port })];
        if (dials !== null) peers = this.names.served(dials);
        return [...policy, sandboxPodSpec(spec, podOptions())];
      },
      ...(dials === null ? {} : { reach: { argv: POLICY_WAIT_ARGV[spec.runtime], peers: () => peers } }),
    });
  }

  /** A host's addresses, sorted: itself when it is one. */
  async #addressesOf(host: string): Promise<string[]> {
    if (isIP(host) !== 0) return [host];
    let addresses: string[];
    try {
      addresses = await this.#lookup(host);
    } catch (err) {
      throw new SandboxError(`the LLM gateway's host ${host} does not resolve: ${(err as Error).message}`);
    }
    const out = [...new Set(addresses)].sort();
    if (out.length === 0) throw new SandboxError(`the LLM gateway's host ${host} resolves to no address`);
    return out;
  }

  /** Meter `dir` from a meter pod (meterPodSpec, docker.ts's meter script) until stop(). */
  meterTree(dir: string, opts: TreeMeterOptions): TreeMeter {
    const entry = imageFor(opts.runtime, this.images);
    const name = podName(opts.label);
    if (!Number.isFinite(opts.budgetMs) || opts.budgetMs < 0) throw new SandboxError(`meter budget ${opts.budgetMs} is out of range`);
    const interval = Number(positiveInt(opts.intervalMs, 'meter interval'));
    // The program's budget runs from its start line, which may come this long after its spawn (its pod's
    // Ready, the policy wait, the exec's start): a meter started beside it keeps going as much longer.
    const preStartMs = this.#ctx.readyTimeoutMs + POLICY_WAIT_MS + KUBECTL_TIMEOUT_MS + (this.#ctx.execStartTimeoutMs ?? EXEC_START_TIMEOUT_MS);
    const passes = Math.ceil((opts.budgetMs + METER_SLACK_MS + preStartMs) / interval);
    const script = meterScript({ intervalMs: interval, passes, maxEntries: opts.maxEntries, maxBytes: opts.maxBytes, maxDepth: opts.maxDepth, maxPathBytes: opts.maxPathBytes });
    const pod = meterPodSpec(dir, { ...this.placement, name, image: entry.image, digest: opts.imageDigest ?? entry.digest });
    const proc = new K8sProcess(this.#ctx, { name, objects: async () => [pod], refs: [`pod/${name}`], argv: ['sh', '-c', script], pids: 0, network: null });
    return new K8sMeter(proc, opts);
  }
}
