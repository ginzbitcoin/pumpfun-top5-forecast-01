// The grade-dev / grade-final job handler (server/jobs.ts PipelineHandlers.grade): everything a
// grading needs, read from the database and the blob store, then gradeEntry / regradeL1 / regradeL2,
// then the run row (record.ts). Returns the run to publish. And an agent/v1 grade's own two job
// handlers, grade-trial and grade-aggregate (PipelineHandlers.gradeTrial, gradeAggregate: `agent/v1`
// below).
//
//   live grades    once a final-phase grade run is stored (a grade's recordGrade, an agent/v1 run's fan-in, a
//                  scrape/v1 final heat's runs), finalGradeLanded records a live change on the competition's
//                  `phase` topic, kind `grade` (server/competitions/live-judging.ts openGradeLive: at most one
//                  per JUDGE_LIVE_MIN_GAP_MS a competition, one inside the gap at its end), so a page holding
//                  the live stream reads GET /live again and its judging's grades count moves; never failing
//                  the grade (what goes wrong is logged)
//   submission     snapshot_sha256 (readSnapshotIndex), house, submitted_as_house, baseline,
//                  pricing_rev. The score's `house` is the standings' (server/payouts/standings.ts
//                  standingsHouse): a house entry, or any other entry a house account
//                  submitted that is no baseline, so a house account's entry from a GitHub
//                  repository outside the house organizations is never prize-eligible, as the
//                  export's `house` says (payouts/onchain.ts resultEntriesOf); a regrade reads it alike
//   competition    its validated bundle (harness, limits, leaderboard, and the eligibility rules
//                  score.ts eligibilityRulesOf reads: min_authored_coverage,
//                  submission_rule.transcripts_required, prize_requires_beating_hold_cash, and
//                  whether it has a build meter); a program/v1 bundle's directory on disk
//   phase          dev | final, and its dataset (pumpfun-replay/v2, bars-replay/v1, clmm-replay/v1:
//                  every phase of a replay grades on one): the row is read here, its files by
//                  loadDataset (a chain log; default dataset.ts createDatasetLoader), loadBarsDataset
//                  (a bars window; default dataset.ts createBarsDatasetLoader) or loadClmmDataset (a
//                  clmm window; default dataset.ts createClmmDatasetLoader), the collector's formats,
//                  every hash verified against the manifest and the manifest against the row. A bars
//                  window that cannot replay the bundle's universe (a symbol it does not carry,
//                  another mint or interval), or a clmm window that cannot replay its pool (another
//                  pool, bars that are not its rows') or is too short for its blocks (under its
//                  phase's floor of whole ones of the harness's interval.block_hours, 28 on final and
//                  8 on dev: `ranked floor` below, harnesses.ts ClmmShortWindowError), can never
//                  grade it: a PermanentJobError
//   cost           usage_line rows (cost.ts) and every transcript_session row (its provenance, and
//                  whether it reports usage: a session that reports none leaves the cost unpriced);
//                  under a bundle with a build meter (build_meter) the entrant's metered_request rows
//                  in the competition through the submission's created_at, matched against those
//                  lines (entry-cost.ts, metered.ts: `metered` below)
//   metered        a fresh grade of an entry under a build meter first syncs every build key its
//                  entrant holds in the competition from masq through the submission's created_at
//                  (server/metering/sync.ts syncEntrantKeys, through deps.meter: the pipeline hands
//                  in the metering job's broker; by default the environment's masq,
//                  MAKEFUN_LLM_GATEWAY=masq), so every request its cost counts is stored before it is
//                  read. A MasqBrokerError there, or no masq to ask while the entrant holds a key still
//                  to sync, is the platform's and never the entry's: a retryable Error, nothing
//                  recorded. masq stamps a request when it ends (src/meter.ts recordRequest: ts is the
//                  clock at the request's last byte), so one ending after the receipt is never counted,
//                  and its row reaches masq's store through its ingest writer: within a second
//                  (src/ingest/ch-sink.ts CH_FLUSH_MS), but through a ClickHouse outage only once the
//                  store answers again (a retry backing off to 30 s, the rows spilled to disk after
//                  30 s and replayed, a handed-over slot's spill picked up within a minute), so a
//                  request at or before the receipt can be answered late. A final grade (the phase
//                  that places and pays) therefore prices only once masq has had CAP_GUARD_LOOKBACK_MS
//                  (server/metering/sync.ts: the hour the metering job's cap guard already reaches
//                  back for rows masq records late) past the receipt: sooner, the job sends itself
//                  again for then (METERED_SETTLE_SLACK_MS past it; meteredSettleJobId of the job,
//                  on its own queue, through deps.jobs: none is a retryable Error) and hands on
//                  nothing, nothing synced, run or recorded: it tells the caller so (the handler's
//                  `handedOn`), and the pipeline sends nothing after the job (server/jobs.ts
//                  PipelineHandlers.gradeHandedOn: no hindsight sweep, cluster scan, code heat or
//                  publish; the job sent again sends them once it grades). A dev grade prices at
//                  once, on what masq answers then: provisional, as a dev board is (no prize is
//                  paid on it), and a request masq records later counts in the entrant's next entry,
//                  never re-priced into this one. The grade keeps the list of the requests
//                  it counted (entry-cost.ts `the list`: Cost.metered.requests_sha256), and an L1 or
//                  L2 regrade prices from exactly the stored rows that list names and never calls
//                  masq, so a row stored since never moves it: it re-derives the cost the grade
//                  stored. A list it cannot read, or a row it names that is gone, refuses the regrade
//                  (PermanentJobError)
//   authorship     loadAuthorship (default loadStoredAuthorship: the authorship_summary row the
//                  ingest wrote under the submission's pricing_rev): a grade takes the newest
//                  algorithm version; a regrade the version its stored run's score names
//                  (storedAuthorshipVersion), so an entry ingested again under a newer algorithm
//                  still regrades byte for byte (none when the run was graded with none; a
//                  version no row holds is a PermanentJobError)
//
// Rules decided here:
//   runtime        main.ts at the snapshot root -> node22, main.py -> python3.13; neither, both, or
//                  one the competition does not accept fails the entry without running anything. A
//                  patch/v1 entry (a diff) names none: it runs on its plan's (harnesses.ts PATCH_RUNTIME)
//   seed           one per (competition, phase, dataset): phaseSeed below (a replay's dataset part
//                  its dataset row's sha256), the competition's part competitionSeedKey (its seed_key,
//                  pinned when first seeded, so a later bundle edit never moves it). It is hello.seed (the
//                  bot's to use) and the bootstrap's seed, so every entry of a phase is resampled
//                  alike. A bars phase that races live (racesLive: the ranking phase carrying a race,
//                  contracts/competition.ts raceOf), and a pump phase that races live on fail-key scheme
//                  server-secret/v1 (gradeTakesRaceSeed), is seeded as its race seeds every racer's hello,
//                  server/race/entries.ts raceSeed (phaseSeed with no dataset part: none is frozen while the
//                  race runs), so a bot that reads hello.seed answers its official grade as it answered live
//                  (a bars race's crosscheck holds; a pump race, raced under this seed's fail key too, trades
//                  as its grade does). A pump phase that races live on any other scheme (phase-secret+beacon/v1:
//                  a sealed-window final committed at its deadline, whose commitment holds every final run to
//                  the phase seed of its drawn window, server/chain/verify.ts checkCommittedFailKey) keeps its
//                  dataset part, its race's hello seed the race's own (server/race/runner.ts); every other
//                  phase keeps its dataset part, and a regrade the seed its run recorded
//   crosscheck     a grade run recorded on the phase a bundle races live (racesLive) holds the race to it as it
//                  lands, the phase's results published (crosscheckLandedGrade: server/race/crosscheck.ts
//                  crosscheckRace over this job's blob store, which compares nothing before finalized_at, then
//                  every racer not compared yet whose official run is scored), so a race an admin's finalize
//                  published as it queued the final grades is compared as they land, with no reader of /live
//                  waited on. It never fails the grade: the run is recorded first, and a racer whose action log
//                  could not be read, or a crosscheck that fails, is logged (deps.log) and left uncompared for the
//                  live snapshot's retry (server/routes/live/snapshot.ts FrameBoard.crosscheck). A regrade lands no
//                  official run (the crosscheck reads grade runs alone) and compares nothing
//   fail key       the pump replay's failed-tx draw's key (the bars and clmm replays draw nothing), one per phase too, so every entry of a phase meets the
//                  same draws, never sent to the bot, derived by the phase's scheme (phase.fail_key_scheme:
//                  phaseFailKey):
//                    server-secret/v1        failKeyFor, as before the schemes: on dev public (publicFailKey of
//                                            the phase seed, which a kit reproduces), on final HKDF-SHA256 of the
//                                            server secret (deps.failKeySecret: config.betterAuthSecret) over the
//                                            phase seed
//                    phase-secret+beacon/v1  a final phase committed at its deadline: committedFailKey
//                                            (server/chain/deadline-commitment.ts) of the phase's own secret
//                                            (phase.fail_key_secret), the phase seed and the drand signature of the
//                                            sealed window's beacon round. The signature is the draw record's
//                                            (<deps.sealedDir>/<slug>/draw.json, verified against the competition
//                                            directory's sealed-window.yaml: verifyDrawRecord), taken only while
//                                            the phase's deadline commitment holds it: the document hashes to its
//                                            stored sha256, is this competition's sealed pool, fixed the secret's
//                                            sha256 and names the sidecar the draw was made for, its round and its
//                                            chain; and the drawn masked window is the phase's dataset. A phase
//                                            with no secret, no draw record that verifies, or one its commitment
//                                            does not name is a FailKeyUnavailableError: the job retries, the
//                                            admins are paged (at most once an hour per phase and reason in a
//                                            process: failKeyPager), and the server secret is never read instead
//                  The run keeps the key it was graded with (GradeOutcome.fail_key); a regrade reuses the stored
//                  run's when the row has one, else derives it again from the stored seed, by the phase's scheme
//   final window   the latest receipt server_time among the competition's submissions (null on dev)
//   instance       an instance-drawn program/v1 bundle (harness.generator) grades on a drawn instance
//                  under the sealed directory (deps.sealedDir; server/competitions/load.ts lays it out),
//                  never on data of its own (phaseInstance): its instance.yaml (in the competition
//                  directory) read and checked against the stored bundle; the dev phase on the practice
//                  instance, practice/{input,reference}, each tree digesting to the sidecar's practice
//                  digest; the final phase on scored-<k>/ of the newest instance-draw-<k>.json, the
//                  whole draw chain verified from the sidecar and drand (verifyInstanceDraws) and the
//                  instance's trees digesting to the record's (its programDataSha256 the record's
//                  instance_sha256). No draw record yet, no final grading yet: the grade waits for the
//                  draw (`not drawn` below). The phase seed's dataset part is
//                  the instance's digest (programDataSha256 of its two directories: the run's
//                  dataset_sha256), so a redraw seeds anew and a regrade of a run on another draw is
//                  refused (regrade.ts compares dataset_sha256). The scorer stays the bundle's own.
//   pack           a pack program/v1 bundle (harness.pack: a code bounty's) grades each phase on its
//                  pack's trees, never on data of its own (phasePackTrees): the dev phase on pack.dev,
//                  the final phase on pack.final, each tree materialized read-only from the blob store
//                  into <work root>/pack-trees/<digest>/ and re-hashed against its digest before every
//                  use (server/competitions/load.ts packTreeDir: a tree the store lacks is taken from a
//                  house pack competition's own copy, competitions/<slug>/pack/, once it re-hashes). Its
//                  programs are read from load.ts programCompetitionDir (competitions/code-tests-01, the
//                  house tests scorer, for a sponsored one with no directory of its own), its scorer
//                  directory re-hashed against the harness's scorer_sha256 first. A tree in neither
//                  place, or a scorer that does not re-hash, is a PermanentJobError. The phase seed's
//                  dataset part is the run's dataset digest (programDataSha256 of the two trees). Under
//                  cases 'per-file' the entry runs once per case (grader/program.ts), and under a gate
//                  the score carries performance.passed (grader/score.ts)
//   patch/v1       a patch/v1 bundle (contracts/patch.ts) grades each phase on the bounty's sealed base tree
//                  (repo.base_tree_sha256) and the phase's tree (pack.dev on dev, pack.final on final), never
//                  on data of its own (patchPhaseSetup): each materialized read-only from the blob store
//                  into <work root>/patch-base/<digest>/ and <work root>/patch-phase/<digest>/ and re-verified
//                  against its index on every use (patch/execute.ts patchTreeDir), the phase's lists read
//                  from its lists.json. A tree the store does not hold, or lists that do not read, is a
//                  PlatformFaultError (NO_PATCH_TREES_MESSAGE), as is a grade on the k8s sandbox, whose
//                  pods run no repository image. The phase seed's dataset part is the phase tree's digest
//                  (the run's dataset_sha256). No test log is kept, on either phase
//   k8s data       on the k8s sandbox (MAKEFUN_SANDBOX=k8s) a pod mounts nothing but subPaths of the data claim
//                  (sandbox/k8s.ts subPathOf), so a program/v1 grade's setup has every tree it mounts from
//                  outside MAKEFUN_K8S_DATA_ROOT staged onto the claim before any pod is made
//                  (stageProgramSetup): a bundle's own input/, reference/ and scorer directory, read from
//                  the image's competitions/<slug>/, are copied once to <data root>/bundle-trees/<slug>/
//                  <digest>/<path in the bundle>, read-only, each re-hashed against the digest its harness
//                  seals it to before every use (sandbox/bundle-trees.ts), and mounted from there. An
//                  instance's trees under the sealed directory and a pack's under the work root are on the
//                  claim already and mounted where they are. The copies are byte for byte, so the run's
//                  dataset and scorer digests are the image's. A tree the image does not hold as sealed is
//                  a PlatformFaultError. The same holds for the bundle trees an agent/v1 trial and a
//                  scrape/v1 scorer mount: an agent/v1 setup has its env directory and its scorer
//                  directory staged as env_sha256 and scorer_sha256 (stageAgentSetup) before any pass of a
//                  trial job and before an agent regrade, and a scrape/v1 scorer setup its scorer
//                  directory as scorer_sha256 (stageScrapeScorerSetup) before a heat and before an L1
//                  regrade (agentSetupFor, scrapeScorerSetupFor: the setup as it is off the k8s sandbox).
//                  Their instances (sealed directory), the forwarder bundles and every scratch (work
//                  root) are on the claim already. The docker and process drivers mount the image's
//                  paths as before
//   size          a program/v1 bundle naming a size count (harness.size: a Smallest code bounty's) scores
//                  every grade and regrade with the entry's code size (grader/size.ts codeSize) over the
//                  submission's snapshot index, less the competition's starter where the entry kept it
//                  unchanged: competitions/<slug>/starter/ as its kit hands it out
//                  (server/routes/competitions/kit.ts starterFiles; deps.starter, competitionStarter),
//                  so grade-local, counting over the kit.json listing, gives the same bytes. Counted once
//                  per job, before anything runs, and handed to gradeEntry, regradeL1 and regradeL2
//                  alike (GradeRequest.size, RegradeL1Request.size)
//   stopping       a grade stops once its job attempt's signal aborts (JobContext.signal: pg-boss gave the
//                  attempt up at its expiry, or the workers stop): gradeEntry kills the program running and
//                  starts none after it (grade.ts `Stopping`: a run per case stops between cases), a dev
//                  grade's timing likewise, and the job records no run (the signal is read again before the
//                  run row is written) and throws the signal's reason, no PermanentJobError: the retry
//                  grades afresh, not beside an attempt still running. A regrade stops alike: regradeL1's
//                  scorer, regradeL2's re-execution and scorer (regrade.ts `stopping`), and an agent/v1 L2's
//                  replays. An agent/v1 L1 and a scrape/v1 L1 take no signal and run to their end. No regrade
//                  records anything once the signal has aborted
//   entry          an entry graded as one execution (pumpfun-replay/v2, bars-replay/v1, clmm-replay/v1,
//   secrets        program/v1) runs with its entrant's env-lane entry secrets: a grade reads the account's
//                  active ones in the competition (activeEnvSecrets: server/secrets/store.ts
//                  sealedEntrySecretsFor, the env lane's alone: no provider-lane value ever reaches a sandbox
//                  but an agent/v1 forwarder, and sandbox/types.ts checkSandboxSecrets refuses one besides) and
//                  opens each with the grader's private keys (GradeWorkerDeps.entrySecrets.seal, default the
//                  environment's), before anything runs; none pushed: none, and no key read. They ride the
//                  entry's SnapshotSource (grade.ts SnapshotSource.secrets), so both of the grade's executions,
//                  every case of a run per case, every practice window of an eras run and a dev grade's
//                  provisional timing run the entry with the same values; the scorer never. One this grader
//                  cannot open (no private key here, a seal it lacks, a record that does not open) HOLDS the
//                  grade, which never fails the entry for it, the fault being the platform's key
//                  configuration and never the entrant's: nothing of the entry runs, no run is recorded, and
//                  the job throws EntrySecretsUnopenedError (its message opening
//                  ENTRY_SECRETS_UNOPENED_HOLD_REASON as snapshot.ts EntrySecretsHeldError's does, then each
//                  secret that did not open by NAME and row, and why; never a value), a retryable Error that
//                  pg-boss retries (each held attempt logged). On the job's LAST attempt (isLastAttempt) the
//                  handler throws EntrySecretsHeldFault instead, a PlatformFaultError, so the pipeline's grade
//                  stage never fails the entry: it puts it back to the status that attempt found, its error
//                  untouched (server/pipeline/index.ts; after an earlier held attempt that is the `running`
//                  the stage set), and the job dead-letters, paged once (`dead grade job` below: the page
//                  names the keys to mount and the resend, which grades it with them once a process holding
//                  them runs it). A regrade held so (an L2's recorded rows, an agent/v1 L2's) throws the same
//                  retryable error, its last attempt paged alike. The run records the rows by id
//                  (run.entry_secret_ids, record.ts RunSecrets; an eras run from its start). A final-phase run
//                  records them under its entrant's account lock (recordWithSecretsHeld: FOR SHARE on the user
//                  row, which a secret's push and delete take FOR NO KEY UPDATE), in the transaction that
//                  writes it, and only while every one of them still holds its ciphertext: a delete or replace
//                  after it then sees the run and keeps the row sealed for the challenge's L2 (server/secrets/
//                  store.ts finalRecorded), and one that erased a row while the grade ran leaves no run to
//                  record (a retryable Error naming it by NAME: the retry grades with the secrets as they
//                  stand), so no final run of these ever names a row its challenge re-run cannot open (a
//                  scrape/v1 run has no re-run: below). An agent/v1 final pass claims its trial alike (its
//                  env-lane rows checked in the claim's transaction: one erased since its pass opened it
//                  sends the pass round again, nothing claimed). Its stderr and error are masked of every
//                  form of every value (grade.ts executeOnce, record.ts putStderr). Its action log and, on
//                  program/v1, every output file it lists are scanned after the grade, never masked (they
//                  are scored byte for byte: secretHitsOfRun): a hit
//                  flags the run SECRET_IN_OUTPUT_FLAG (beside its score's flags, never in them: regrade.ts
//                  RUN_ONLY_FLAGS) with a SECRET_IN_OUTPUT_ACTION row (subject the run; data run_id and hits,
//                  each a NAME and a file: ACTION_LOG_SCAN_FILE, `output/<path>`, an eras window's under its
//                  key), in the transaction that records it. An L2 re-opens exactly the rows the run recorded
//                  (recordedEnvSecrets: retained rows included) and runs with them; once one is erased
//                  (replaced, deleted or purged) it is refused unexecuted (regrade.ts ENTRY_SECRETS_ERASED,
//                  recorded as a failed regrade_l2 run flagged so) and the run's L1, which needs no secret,
//                  stands. An agent/v1 L2 re-opens each replayed trial's (run_trial.entry_secret_ids, the env
//                  lane's) alike (AgentRegradeL2Request.trialSecrets). A code heat times each field entry with
//                  the rows its graded run recorded, re-opened (one erased since is left out, by NAME in the
//                  log: its timed outputs then show whether it mattered). A scrape/v1 heat (runScrapeHeatFor)
//                  opens every entrant's active ones before anything of the heat is made and runs each
//                  entrant's every trial with its own (grader/scrape/heat.ts, trial.ts: their values on the
//                  house launcher's stdin, never in a file; the cassette, the scrape answer key, its bodies
//                  and the launcher's tails masked of every form; /output scanned); the heat's reference read,
//                  the house's, runs with none, and so does every house entry (housePaysEntryLane: a house
//                  entry or a baseline, as an agent/v1 pass's), its account's secrets never read or opened.
//                  Each recorded run records its rows (run.entry_secret_ids), its error masked, and a form in
//                  its trials' /output (heat.ts ScrapeHeatRun.secret_hits, every attempt's) or its action log
//                  flags it SECRET_IN_OUTPUT_FLAG with one SECRET_IN_OUTPUT_ACTION row, all in the transaction
//                  that records the heat's runs (record.ts recordScrapeRuns, ScrapeRunRecord's RunSecrets). It
//                  records them without a final-phase grade's erased-row check (recordWithSecretsHeld):
//                  nothing runs a scrape entry with its recorded rows again (its L2 is refused, and neither a
//                  hindsight audit nor a dev stress runs one), and the check would let one entrant's delete
//                  send the whole final heat round again. A hindsight audit's surrogate runs and a dev
//                  stress's copies (grader/dev-stress.ts) re-open exactly the rows the run they stand for
//                  recorded, as an L2 does (recordedEnvSecrets), and run with them, masked alike
//                  (grader/hindsight-audit.ts runOnWindow): one erased since refuses the audit or the stress
//                  for good (a PermanentJobError naming it by NAME; a dead audit is paged, its verdict given by
//                  hand), one this grader cannot open retries it. A live race's racer gets none, nor does a
//                  judge, or the scorer
//   agent/v1      an agent entry grades as K trials (contracts/agent.ts), each a LIVE pass (its model
//                  calls metered and recorded in a cassette: a house-paid entry's on a masq key of the
//                  pass's own, an entrant's on its own keys, `entry lane` below) and, on the final phase, a
//                  REPLAY of it (grader/agent.ts runTrial; a dev trial runs once: `practice once` below),
//                  on the phase's instances (agentPhaseTrials,
//                  read from the trials sidecar instance.yaml and the sealed directory as `instance`
//                  reads a program/v1 bundle's): the dev phase one trial, on practice trial 0; the final
//                  phase every trial of the newest scored draw. Three jobs carry it (server/jobs.ts):
//     grade        startAgentRun: the run's row (record.ts startRun, status running, under the id
//                  agentRunId derives from the grade job, so a retry finds it) and its K run_trial rows
//                  (pending, each tagged with its place in the queue: record.ts `queue tags`), one
//                  grade-trial job per trial for live pass 1 (gradeTrialJobId, at gradeTrialPriority of
//                  its tag: contests share the slots, an entrant's trials queue behind its own, and trial
//                  0 of every entry of a final runs first) and the fan-in's first job. It
//                  publishes nothing. The run's dataset_sha256 is agentDatasetSha256 of its instances,
//                  its seed the phase seed over it; an entry that selects no runtime fails at once
//     grade-trial  createAgentTrialHandler moves one trial on from where its row stands, as far as the
//                  job's pass reaches; every move is written only while the row is still where it was
//                  read (record.ts moveTrial), so of two attempts on one trial one moves it:
//                    pending / void   live pass `pass` (its key minted, then the row claimed:
//                                     live_running, attempt = pass, the void's record cleared into
//                                     voided spend; an entrant's pass, which mints no key for its
//                                     entry lane, claims it as its house key comes back, or with no
//                                     target as it sets out: `entry lane` below), unscored; ends
//                                     live_done, timeout (0 on every column, done), or void. Its
//                                     key retired, the run takes the
//                                     flags its spend read sets (masqRunFlags: masq.ts's
//                                     gateway_spend_mismatch on a settled figure the meter disagrees
//                                     with, GATEWAY_SPEND_UNSETTLED_FLAG on one that never settled),
//                                     for admins only and never a score; on a house clock
//                                     (grader/house-clock.ts, the setup's `competition` its slug),
//                                     each pass, its replay's too, flags the run with the credit it
//                                     ran on (houseClockRunFlags), never a score either
//                    void             a series of AGENT_SERIES_PASSES live passes from the job's
//                                     first_pass: a void before its last sends the next pass its
//                                     own job (after AGENT_VOID_RERUN_DELAY_MS; an upstream_errors
//                                     void's after 5, then 10 minutes, agentVoidRerunDelayMs, so a
//                                     series outlasts a burst) on the same instance
//                                     with a fresh key; the last holds the trial. A pass cut off
//                                     (INTERRUPTED_VOID_REASON) spends none of it (`cut off` below)
//                    live_running     this job's pass cut off (the attempt that ran it stopped or
//                                     expired, or its grader died): what it left running removed
//                                     (`dead grader` below), then a void (INTERRUPTED_VOID_REASON),
//                                     its key retired, what masq metered on it counted as voided spend
//                                     (a figure that never settled flags the run
//                                     GATEWAY_SPEND_UNSETTLED_FLAG as a live pass's does)
//                    live_done        the export scored by the bundle's scorer (agent.ts
//                                     scoreTrialWithChecks; points checked as aggregateTrials counts
//                                     them), the per-check rows it wrote beside them kept with the
//                                     score (`checks` below), then the replay: finished or
//                                     nondeterministic, done. A recorded live pass never runs again,
//                                     and a scored one goes straight to its replay, or on the dev
//                                     phase straight to finished (`practice once` below)
//                    replaying        a replay cut off (no end on record): replayed again (it spends
//                                     nothing), what the cut-off one left running removed first
//                                     (`dead grader` below); one that met a fault records its end
//                                     (replay_finished_at, still replaying) and is retried as a fault
//                  cut off      a grader restart (a deploy, a rollout) cuts off every pass it runs, which is
//                               the platform's doing, never the entry's: a live pass voided
//                               INTERRUPTED_VOID_REASON is re-run spending no pass of its series (its
//                               next pass's job carries first_pass + 1, so the series counts the same
//                               passes), and a replay found cut off replays again. Each counts toward
//                               AGENT_INTERRUPTED_RERUNS in a row instead, on the row's error (a
//                               live void's words end `cut off <n> times in a row` from the second on,
//                               a replay's from its first: liveCutOffRun, replayCutOffRun); the
//                               AGENT_INTERRUPTED_RERUNS-th in a row holds the trial under
//                               INTERRUPTED_VOID_REASON, so one that kills its grader every time cannot
//                               loop. A job whose last attempt dies with the trial cut off is no fault
//                               either: the fan-in sends its pass's job again (`held` below). Those
//                               words, a void's and a hold's, stand on the row only until a pass ends
//                               otherwise: a live pass that ends live_done or timeout, and a replay that
//                               ends finished or nondeterministic, records its own ending (trialEnding:
//                               no void reason, and no error but a nondeterministic replay's fault), so
//                               no earlier attempt's fault outlives it; their history is the grader's
//                               log, the voided spend, the run's flags and a re-queue's audit row
//                  practice once  a dev-phase trial runs once (the owner, 2026-11-11: "for non-final
//                               grading we don't need to be so redundant"): its live pass recorded and
//                               scored, the trial is finished with no replay (replay_started_at and
//                               replay_finished_at stay null; server/db/schema.ts run_trial_replayed lets
//                               only a finished trial end so), and its run is flagged replay_skipped
//                               (regrade.ts REPLAY_SKIPPED_FLAG) in the same transaction. Nothing else of
//                               the live pass changes: its key minted and retired, its spend settled, its
//                               cassette, env log, state and outputs stored as before, so an L1 regrade and
//                               the public verification read all they read; an L2 regrade replays it there
//                               for the first time (regrade.ts `L2`). The replay was the half of a dev
//                               grade that told only whether it was nondeterministic (measured on
//                               production, 2026-11-11: 38-44% of a tiny-chess-01 trial's grading time, 27% of all
//                               trial slot-time); every final-phase trial still replays, as before. A dev
//                               trial found replaying (claimed by a release from before) replays to its end
//                               as before. The fan-in counts its executions as its live passes alone; the
//                               run's result carries no nondeterministic flag (no replay differed, as none ran:
//                               agent-score.ts agentDeterministic), so it ranks, and the flag tells every reader
//                               that no replay checked it (server/routes/archive/entry.ts agentTrialsOf)
//                  brief        a live pass copies the entry's brief as grader/agent.ts trialBriefSource
//                               picks it, handed the entry's baseline flag (submission.baseline): a house
//                               baseline on an instance holding reference/baseline-prompt.txt reads that,
//                               every other pass input/prompt.txt. The row records what the pass copied
//                               (run_trial prompt_sha256, baseline_prompt), and the replay hands runTrial
//                               that recorded choice, never the flag as it stands then: an admin may flip
//                               the flag between the two (no regrade is queued on a flip), and a replay on
//                               the other brief would miss its cassette, a false state_mismatch. A row
//                               recorded before the choice was replays on the flag. A replay that copied
//                               other bytes than its live pass recorded is a harness fault (replay_brief),
//                               never a verdict on the entry. The fan-in names each trial's prompt_sha256
//                               in the trials manifest, which an L2 regrade replays by (regrade.ts)
//                  checks       a scorer that writes per-check rows beside scores.json (program-scores.ts
//                               checks.json) has them kept on the trial's row with its score (run_trial
//                               checks, canonical JSON), or, when it wrote a malformed checks.json, why it
//                               was dropped (checks_issue: harnesses.ts scoreProgramBreakdown), the score
//                               standing as without it: a breakdown never fails a trial. The fan-in makes
//                               the run's checks trace of them (`grade-aggregate` below)
//                  dead grader  a grader that dies mid-pass leaves the pass's containers running on
//                               its network, and its scratch under the work root. Every pass of a
//                               trial names the trial's owner (trialOwner, `<run id>.<trial index>`;
//                               grader/agent.ts RunTrialOptions.owner), which labels its network
//                               makefun.trial=<owner>; before a pass makes its own network, and
//                               before a cut-off live pass is voided, every network carrying that
//                               label and each grader container on one are removed (network.ts
//                               reapTrial, through sandboxReap and runTrial's onReap) and logged by
//                               name (reapLine). Its scratch (the snapshot and the pass's own
//                               directory, and its scorer's) is named for the owner too,
//                               `<work root>/trial-<owner>-XXXXXX` (TRIAL_SCRATCH_PREFIX, regrade.ts
//                               ownedScratch); once a pass holds its trial (a live pass's claim,
//                               the replay's, a cut-off pass voided) every other directory so named
//                               is removed (regrade.ts reapScratch) and logged by path
//                               (scratchReapLine). A trial's passes run one at a time, each once
//                               its row is claimed for it, so what carries its owner then is a dead
//                               pass's; another trial's carries another owner. A pass looks only in
//                               its own process's work root (AgentTrialDeps.workRoot; an agent/v1
//                               regrade in GradeWorkerDeps.workRoot alike), and the pipeline's is
//                               the server's own across restarts (server/pipeline/index.ts
//                               startWorkers: config.workRoot, MAKEFUN_WORK_ROOT, default
//                               .data/work), so the grader that resumes a dead one's trial looks
//                               where it left its scratch. What no resumed pass comes back for the
//                               workers' start removes (server/pipeline/index.ts sweepDeadWork),
//                               and only once all three hold (removeIfDead): no active job on the
//                               start's database holds its owner, no one has touched it for six
//                               hours (its newest change, its own or a direct entry's, older than
//                               network.ts STALE_AFTER_MS), and no live process holds it open or as
//                               its cwd (processesHolding). A live pass's never ages so: ownedScratch
//                               hands every owned scratch out with a heartbeat, its `.alive`
//                               rewritten every ten minutes until the pass removes it (grade.ts
//                               keepScratchAlive), so a pass on another database sharing the work
//                               root keeps its scratch even where its containers' processes cannot be
//                               seen (the docker driver's). One younger, held or not to be asked
//                               about is kept and logged: a job on another database sharing the
//                               work root, or a run handed no job, may still work in it. A root no
//                               successor shares (a hand-built config's fresh per-process one, a
//                               test process's) is never looked in by the next process: only the
//                               opt-in sweep of per-process roots (MAKEFUN_SWEEP_PROCESS_WORK_ROOTS)
//                               removes it, once six hours still and held by no process
//                  entry lane   who pays the entry's own model calls (housePaysEntryLane). The house,
//                               for a house entry (submission.house), an entry a house account
//                               submitted (submitted_as_house) or a baseline: its live pass runs on a
//                               masq key of its own (grader/agent.ts TrialUpstream `masq`), minted
//                               before the claim. Never for an entrant's entry (the owner's rule: house
//                               money never pays an entrant's model calls): its live pass runs its entry
//                               lane on the entrant's own keys (agent.ts EntrantTrialUpstream `provider`;
//                               `entry secrets` below) and mints no masq key for it (masq_key_id stays
//                               null), the trial recorded entry_credential entrant with the entry_secret
//                               rows it ran with, both lanes (entry_secret_ids, a list exactly when the
//                               credential is entrant). An entrant with no provider key runs
//                               model-free (entrantKeysOf, the keys none): the forwarder answers each of
//                               its model calls itself, a 401 naming the entry secret that carries a key
//                               and how to push it (gateway/upstream.ts noProviderKeyMessage; with no
//                               seal public key on this deployment, so that a push answers 503, its words
//                               say pushing is not open here yet and name no command: `entry secrets`
//                               below), recorded in the cassette, sent
//                               nowhere and never counted toward a void (credential entrant: gateway/meter.ts), so the pass
//                               ends live_done and is scored and replayed as any other (no provider-lane
//                               id among entry_secret_ids). On the entrant's keys the same holds of a 401, 402, 403, 407 or
//                               429 its provider answers mid-pass (a key revoked, out of credit or rate
//                               limited is the entrant's, scored as the entry met it), while a 5xx, a 529
//                               or a reset still voids the pass and re-runs it. With a target its house
//                               lane still runs on a masq key (role house), and that key's mint claims the
//                               trial (house_masq_key_id), so a refused admin key still marks nothing; with
//                               none, nothing is minted and the trial is claimed as the pass sets out. Its
//                               entry lane spends no house money: what an entrant's pass spent
//                               (entry_credential entrant) is never the entry lane's house spend
//                               (laneSpentSql). A cut-off one retires the house key it holds, if
//                               any: its entry lane held none, its spend the entrant's and unmetered here
//                  entry        an entrant's pass, before it claims its trial, reads the secrets its account
//                  secrets      pushed to the competition (server/secrets/store.ts sealedEntrySecretsFor:
//                               the active rows; none: model-free, above), of the provider lane those of
//                               a provider the allowlist serves alone (a key for another pays for no call:
//                               never opened, never recorded), and opens each with the grader's private
//                               keys (store.ts openEntrySecretRows, server/secrets/seal.ts;
//                               AgentTrialDeps.entrySecrets.seal, default the environment's). A house-paid
//                               entry's pass reads none. No private key here, or a secret it cannot open:
//                               the trial held (ENTRY_SECRETS_UNOPENED_HOLD_REASON) and the admins paged,
//                               the fault the platform's, never masq in its place. Two lanes:
//                                 provider     ANTHROPIC_API_KEY, OPENAI_API_KEY, GEMINI_API_KEY or
//                                              GOOGLE_API_KEY: the forwarder's keys alone (agent.ts
//                                              EntrantKeys, its gateway.json, deleted once it is
//                                              ready), never a sandbox's variable; the entry keeps its
//                                              trial key and base URLs. Each is checked with its
//                                              provider first (gateway/providers.ts checkProviderKey:
//                                              its models list, spending nothing):
//                                   valid        the org and project ids its answers named are masked
//                                                with the keys, the pass runs on the keys, and the
//                                                secrets are marked used, the keys validated (markUsed)
//                                   refused      401, 402 or 403: on the final the pass waits for the
//                                                entrant to push a new key, the run flagged
//                                                ENTRY_SECRET_HELD_FLAG (stage.ts reads it), the key
//                                                checked again every AGENT_PROVIDER_KEY_RECHECK_MS (its
//                                                job sent for the next slot) within
//                                                AGENT_PROVIDER_KEY_HOLD_MS of the first refusal (an
//                                                ENTRY_SECRET_HELD_ACTION audit row: the window's start
//                                                and end), capped at the final phase's end; past it (or
//                                                once the competition is resolved, or on the dev phase
//                                                at once) the trial scores 0 (keyRefusedRecord):
//                                                recorded as a timeout, its record a cassette with no
//                                                entry and an empty export, void_reason
//                                                PROVIDER_KEY_REFUSED and the readable why as its
//                                                error, nothing run, nothing spent
//                                   unreachable  no verdict (no connection, the budget out, a 5xx): the
//                                                pass waits and checks again the same way, paged at
//                                                most once an hour, never scored for it: never the
//                                                entrant's
//                                 env          every other name: a variable of the entry's own sandbox
//                                              (agent.ts RunTrialOptions.secrets, SandboxSpec.secrets),
//                                              never the env's, a forwarder's or the scorer's, and the
//                                              same on the pass's replay, which opens exactly the rows
//                                              its live pass recorded (sealedEntrySecretsFor by id). One
//                                              erased meanwhile (replaced or removed by its entrant, or
//                                              purged) voids the live pass (ENTRY_SECRETS_ERASED_VOID_REASON),
//                                              so a fresh one runs on what the entrant holds now:
//                                              a replay on other values would replay nothing
//                               Every form of every value the pass holds (gateway/secret-mask.ts: both
//                               lanes, and the ids learned) is masked out of what it stores and says:
//                               the forwarder's answers and cassette (its `mask`), each request before
//                               the forwarder keys it (its `request_mask`, the env lane's, the replay's
//                               forwarder handed the same), the stored stderr tail, the pass's error, the
//                               words of a refused key's wait or zero and of a cut-off pass, and every
//                               log and page line; no value is stored or logged. The env's export and
//                               call log are scanned after each pass, never masked (they are scored and
//                               replayed byte for byte: agent.ts secretsInPassOutputs): a hit flags the
//                               run SECRET_IN_OUTPUT_FLAG beside a SECRET_IN_OUTPUT_ACTION audit row
//                               naming the secret's NAME and the file, never the value. Each pass, keys
//                               or none, also tells its forwarder whether an entrant can push a secret on
//                               this deployment at all (agent.ts EntrantKeys.entrySecrets, the config's
//                               entry_secrets): `on` while the seal settings hold a public key (the one the
//                               web seals with, from the same environment), `off` without one
//                               (entrySecretSealRefusal `seal`), when the no-key 401 says pushing is not
//                               open here yet instead of naming `makefun secrets push`
//                  spend        no contest-level spend gate: a live pass, dev or final, the first of its trial
//                               or a re-run, starts with no spend weighed on either lane, whatever the bundle
//                               names (inference's and target's dev_daily_usd, dev_total_usd and
//                               max_total_usd are read by nothing here): no day, practice budget or
//                               competition total holds it, and no row is locked to weigh one. What bounds
//                               a pass is its own budget alone: budget_usd_per_trial at the gateway
//                               forwarder, its key's masq cap at that × 1.05 (gateway/masq.ts),
//                               max_requests_per_trial and the per-request caps. A grade-trial job an
//                               earlier release sent for a pass it held back (ids keyed `daily:<day>`,
//                               `total:<day>` and `final-cap:<first>:<slot>`) starts its pass as it wakes,
//                               and a run flag such a release wrote (dev_daily_cap, dev_total_cap,
//                               final_total_cap) is neither written nor taken off here
//                  house lane   with a target (contracts/competition.ts AgentTarget, metered apart from
//                               the entry's calls), the env's calls to it run on a house key of the
//                               pass's own, on target.budget_usd_per_trial, its spend metered apart
//                               (run_trial house_spend_micro_usd, its cassette's totals, +
//                               voided_house_spend_micro_usd). The pass's mints claim the trial on the
//                               entry's key and record the house's beside it (house_masq_key_id), so a
//                               pass cut off retires both, each lane's meter counted as that lane's
//                               voided spend. An entrant's pass mints the house's alone, which claims
//                               the trial (`entry lane` above)
//                  scrape heat  while a scrape/v1 heat holds this host's lease (scrapeHostHeldBy:
//                               `scrape/v1` below), a trial's job runs nothing: it hands itself on to
//                               the next recheck slot (SCRAPE_HOST_RECHECK_MS; gradeTrialJobId of the
//                               pass, its series and the slot, at the trial's expiry; one yet to start
//                               its live pass takes a fresh place in the queue as it wakes), so
//                               no pass shares the CPU with a timed heat, none spends its expiry
//                               waiting one out, and nothing waits in a stopping process
//                  node room    on the k8s sandbox the node's pod slots are shared by every namespace (prod,
//                               dev, the races: sandbox/k8s.ts's header, Room on the node). A live pass or a
//                               replay sets out, and a live_done pass is scored, only while the node has
//                               room for its pods beside server/jobs.ts NODE_POD_HEADROOM (AgentTrialDeps
//                               .podRoom, K8sSandbox.nodePodRoom; agent.ts trialPods, the scorer one); short
//                               of it, nothing is minted or claimed and the job hands itself on to the next
//                               recheck slot (NODE_ROOM_RECHECK_MS; gradeTrialJobId of the pass, its series
//                               and the slot). A pass that set out and still met a node with no room for one
//                               of its pods ends void node_capacity (agent.ts NODE_CAPACITY_VOID_REASON: its
//                               entry never ran), which is no pass at all: its claim undone (unclaimed: the
//                               row as the pass found it, what masq metered on its keys counted as voided
//                               spend), a replay's put back as it stood, and the job handed on the same way.
//                               Unknown room (no RBAC to read it, another driver) holds nothing back
//                  A job whose pass is not the row's is stale and does nothing. The attempt's signal
//                  (JobContext.signal) stops every program of a pass: an aborted attempt writes
//                  nothing more. A trial done, the fan-in is told at once.
//     held         a trial held (run_trial status held, the run flagged stage.ts TRIAL_HELD_FLAG in
//                  the same transaction, the admins paged at once: trialHeldPage) when its series
//                  is spent, when a fault no retry mends meets its last attempt (a replay that voids,
//                  a scorer fault, a PermanentJobError), when AGENT_INTERRUPTED_RERUNS passes in a row
//                  were cut off (`cut off` above), or when its job died outside its handler (found by
//                  the fan-in's wait: DEAD_JOB_HOLD_REASON), unless it died with the trial cut off
//                  (live_running, or replaying with no end) and no other job of the trial waits or
//                  runs: then its pass's job is sent again, once per cut-off pass. An admin's re-queue (POST
//                  /api/admin/runs/:runId/trials/:index/requeue, server/routes/admin/grading.ts
//                  registerTrialRequeue, which the page names) sends it on through requeueHeldTrial:
//                  its whole live pass scored and replayed again, or a fresh series; a job the queue
//                  does not take puts it back on hold. A trial held for upstream errors (its series
//                  spent in a burst: UPSTREAM_ERRORS_VOID_REASON) is re-queued so by itself once, by
//                  its run's fan-in at its first wait slot TRIAL_SELF_REQUEUE_AFTER_MS (30 minutes)
//                  after its last pass ended, under trial.requeue rows of its own (actor null,
//                  data.actor TRIAL_SELF_REQUEUE_ACTOR, data.automatic); its page says so. Held again
//                  after that, it waits for an admin and is paged as any held trial; a trial held for
//                  any other reason is never re-queued by itself
//     refused key  a masq.ts MasqAdminKeyRefusal (the admin key not pinned to the grader host(s), or
//                  masq itself refusing it from this host's address: its 403 source-pin refusal,
//                  problem `source`, which the start-of-grader check reads as a refusal)
//                  stops agent/v1 grading: never a void, nothing of the trial is marked (the mint
//                  comes before the claim); the job fails as a harness fault and pages the admins with
//                  the refusal (which names the masq keys admin-sources fix), at most once an hour per
//                  process, and a last attempt sends the job again AGENT_REFUSAL_RETRY_MS later, so the
//                  trials run once the key is pinned. A MasqBrokerError stays a void
//     isolation    no trial's networks are made on an engine that does not keep trials apart: a Docker
//                  engine (grader/sandbox/network.ts probeIsolation: the egress bridge's enable_icc=false,
//                  which a daemon run with iptables off accepts and enforces not at all, and an internal
//                  network's lack of a route out), or the k8s driver's Kubernetes cluster (k8s-network.ts
//                  probeK8sIsolation: its NetworkPolicies enforced), the logs and pages naming the sandbox's
//                  driver's (ISOLATION_ENGINES). The trial handler probes the engine as the grader
//                  starts (createAgentTrialHandler, in the background: a refusal paged at once, a verdict
//                  that holds logged), one probe per process (network.ts engineIsolation, through
//                  sandboxIsolation), and every live pass and replay waits on that verdict before it
//                  mints a key or claims its trial. A refusal (network.ts IsolationRefusal, naming the
//                  setting that fixes it) is an operator's fault, met as a refused key is: never a void,
//                  nothing of the trial marked, the job failed as a harness fault, the admins paged (at
//                  most once an hour per process), a last attempt sent again AGENT_REFUSAL_RETRY_MS
//                  later; the engine is probed again ISOLATION_RECHECK_MS after a refusal, so the trials
//                  run once it is mended, with no restart. A probe that cannot finish (the daemon down,
//                  the image absent) is a harness fault like any other. An agent/v1 L2 regrade, whose
//                  replays make trial networks, is refused alike before it runs anything (its job retried,
//                  then paged as a dead grade job). The process driver makes no network and is never
//                  probed
//     regrade      regradeAgentRun: an agent/v1 regrade job (regrade_l1 or regrade_l2, sent by the
//                  attest, the challenge guard and POST /api/admin/runs/:id/regrade as for any kind)
//                  re-derives its stored grade run from its trials, never live: the phase's trials
//                  found as the grade found them (agentPhaseTrials; another draw is another
//                  dataset_sha256, refused), each trial's void re-runs from its row, the cost and the
//                  authorship its score names; then regrade.ts regradeAgentL1 (every trial's stored state
//                  export re-scored, re-aggregated, the score compared byte for byte, the checks trace
//                  recomputed and compared with the stored one: trace_differs) or regradeAgentL2
//                  (every replayed trial replayed from its stored cassette under the stored image and the
//                  same harness_version, no upstream and no spend, to its stored verdict; then L1), the
//                  forwarder GradeWorkerDeps.forwarder's (default the bundle's own build), recorded as a
//                  regrade run. No model is called. The job names its owner (regradeOwner,
//                  `regrade-<job id>`, the same on each attempt): its scratch is named for it and each
//                  replay runs under `<owner>.<trial index>`, so an attempt that follows one that died
//                  removes its scratch, containers and networks first and logs them (regrade.ts's
//                  `owner`; scratchReapLine, reapLine), as a trial's pass does after a `dead grader`
//     grade-aggregate  createAgentAggregateHandler, the fan-in: while a trial is not done, it holds the
//                  trials whose job died, then hands itself on to its next wait slot; once every trial
//                  is done, the trials manifest (agent-score.ts trialsManifest: the action log, stored
//                  as a blob), the performance (aggregateTrials), the score (score.ts buildScore, cost
//                  and authorship as a grade's) and the run's verdict (record.ts finishRun: finished, or
//                  nondeterministic when a trial is), and the run to publish. Beside the score, never in
//                  it, the run's checks trace (agent-score.ts agentChecksBreakdown of the trials' rows,
//                  `checks` above; stored as record.ts stores a grade's trace, run.trace_sha256), so
//                  result_sha256 is what it is without one: none when no trial's scorer wrote rows, and
//                  none, its reason logged, when they make none (trials scored on other checks, a
//                  checks.json dropped). An entrant's entry (no
//                  house entry, no baseline: standingsHouse, submission.baseline) under a harness that
//                  waives nothing (harness.target waives it: a scripted attacker making no model call of
//                  its own is a legal entry there; so does harness.model_calls: optional, a competition
//                  that does not require model calls: agent-score.ts agentHarnessFloorFacts) is held to the LLM
//                  agent floor (agent-score.ts, the rules' "Each entry is an LLM agent"), each trial's
//                  model calls counted off its stored cassette (gateway/cassette.ts
//                  cassetteModelCalls: completions the model answered using tokens, never a models
//                  listing): a trial whose store would be scored and whose live pass made none scores
//                  0, its store not scored (aggregateTrials handed the entry's facts), and the run's
//                  error names those trials (agentSilentNote, after the nondeterminism note if any); a
//                  run none of whose trials made one is refused instead (agentModelCallRefusal): the
//                  run failed, its error the plain reason (AGENT_NO_MODEL_CALL; for an entry whose
//                  passes ran on no provider key, keylessEntry, the missing key and the fix), no score, nobody
//                  paged; publish carries it to the entry, whose status shows the check model_call
//                  (server/entries/checks.ts, implied from that error in place of run_completes). A run
//                  it cannot aggregate is failed and paged on its last attempt; an entry cancelled
//                  meanwhile cancels it
//                  The gateway (openAgentGateway): masq from the server's config, opened with
//                  masq.ts openMasqBroker; null with MAKEFUN_LLM_GATEWAY off, and then no trial runs.
//                  A pin masq refuses from this host's address is paged as an ALERT at start (its 403
//                  source-pin refusal, openMasqBroker's MasqAdminKeyRefusal problem `source`), naming
//                  the address and the `masq keys admin-sources` fix; the broker is kept, so a pin
//                  fixed on the box is picked up by the next mint, and the trials void and hold as
//                  they always have until then.
//                  sweepStaleSandbox clears a crashed grader's containers and networks at start,
//                  once six hours old: what no resumed trial reaped (`dead grader` above).
//                  The agent/v1 runtime (grader/agent.ts, the gateway's modules, masq, the network
//                  sweep and the isolation probe) is loaded on an agent job's first use (the probe's
//                  module as a trial handler is made), never as this module loads: the kit's command
//                  line bundles this module for its rules (cli/grade-local.ts), and the forwarder's
//                  entry module (gateway/main.ts) runs its main when it is part of a bundle that is run
//   scrape/v1      a scrape entry grades in a heat (contracts/scrape.ts): every entrant, the house baseline among
//                  them, run once a round in an order drawn from a public drand round, each trial timed by the
//                  house launcher behind the recording TLS gateway and judged by the bundle's sealed scorer
//                  (grader/scrape/heat.ts runScrapeHeat, trial.ts, score.ts). A heat is exclusive to its host's
//                  egress: it holds the host's lease (heat.ts acquireScrapeHostLease, a scrape_heat_lease row of this
//                  process's database named for ScrapeWorkerDeps.leaseDir, default scrapeLeaseDirFromEnv:
//                  MAKEFUN_SCRAPE_LEASE_DIR, else <tmpdir>/makefun-scrape-lease), so two grading pods of one egress
//                  never run two heats against it, and while a live lease is held every other grade or regrade job of
//                  this host waits before it starts (scrapeHostQuiet: a program, replay or agent grade, a scrape L1
//                  regrade), and so does a heat (it is queued behind the running one); an agent/v1 trial's job and an
//                  entry's hindsight audit hand themselves on instead (scrapeHostHeldBy: `scrape heat` above, `one
//                  entry` below). A heat handed no database (a kit, a test) keeps its lease in its own process's memory.
//                  A wait, and a heat, end once pg-boss gives their job's attempt up (its signal: the attempt
//                  expired, or the workers stop): a heat so stopped releases the lease and records nothing.
//                  Its round is fetched from drand's relays and verified against the chain's key
//                  (verifyDrandRound) before the heat draws on it
//     dev          gradeScrapePractice: the job's entry beside the house baseline (the competition's latest
//                  baseline submission; none: a PermanentJobError naming the fix) in a practice heat
//                  (`practice-<hex>`, scrapeHeatIdOf of the job), the bundle's warm-up and main rounds with no
//                  playoff, on the newest drand round. The entry's run is recorded and published (the baseline's
//                  in it is not: its own job grades it). An entry selecting no runtime fails at once
//     final        createScrapeHeatHandler, the scrape-heat job ({phase_id}, scrapeHeatJobId): ONE heat
//                  (`final-<hex>`) of every final entry (admin/grading.ts entriesToGrade, as a lock queues them)
//                  and the baseline, on the first drand round at or after the phase's scheduled start
//                  (scrapeFinalRound: instance.ts scoredBeacon, as a scored instance draw takes it), waited for
//                  when the job runs early. Its field is read once, so first it holds while an entry taken in by
//                  the deadline (or a house baseline) awaits its snapshot or its transcripts gate
//                  (admin/grading.ts awaitingSnapshot, the predicate codeHeatDue waits on: an entry failed or
//                  cancelled for good holds nothing), looking again every SCRAPE_SNAPSHOT_POLL_MS on the waits'
//                  clock until its attempt's signal ends it (scrapeFieldSnapshotted): the same job, so the same
//                  heat id and round. The heat judges each trial as it ends and each run's stage standing
//                  as its stage ends (the playoff drawn from the main stage's); once it ends, one grade run per
//                  entry is recorded, all in one transaction, and handed on to publish (ScrapeHeatOutcome). A
//                  phase whose heat is recorded is never run again: the job answers its runs. A grade-final job
//                  of a scrape entry (scrapeFinalGrade) runs no heat: it hands on the entry's heat run once
//                  recorded, nothing before, and refuses an entry the recorded heat ran without. A heat, practice
//                  or final, that records says so in one log line (`[scrape] <what>: heat <id> recorded on the
//                  <driver> sandbox ...`, each recorded run scored, held or left unscored)
//     a run        its action log the trials manifest; its dataset_sha256 the heat record's canonical sha256
//                  (the record in the blob store: the archive serves it); its stderr_sha256 the heat's log
//                  (scrapeHeatLog: the reference read an L1 regrade rebuilds, the CA's digest, every attempt);
//                  its harness_version the harness source's plus the launcher's and the gateway's digests
//                  (scrapeHarnessVersion); its scorer_version the sealed scorer's and its image's; its seed
//                  phaseSeed over the heat record's digest. Its score is ranked when its scorer agreed with
//                  itself on every trial and it finished (score.ts: did_not_finish past trim failures). A run
//                  its scorer left unscored (a disagreement, or a fault twice: heat.ts) is the house's fault:
//                  recorded failed (SCRAPE_SCORER_FAULT_FLAG), never published, the admins paged
//     voids        a void re-runs with no cap per entry (heat.ts), so before prizes a run whose voids in a stage
//                  exceed twice the stage field's median plus 2 is held for an admin's review
//                  (scrapeVoidsReview: SCRAPE_VOIDS_REVIEW_FLAG on the run row, never in its score, its error
//                  naming the counts and the heat's log); it is scored as any, never penalized. A judged void
//                  (heat.ts: a short chart the upstream served, its attempt's outcome 'run' with judged_void
//                  set) re-runs too, and voids_rerun counts it, but the review never does: such voids hit every
//                  entrant in their window, so they say nothing of one run
//     regrade      L1 (regrade.ts regradeScrapeL1) re-judges every trial from the blob store; an L2 is refused
//                  (SCRAPE_L2_REFUSAL): the measurement is never re-run
//     rejudge      a run its scorer left unscored is judged again once an admin asks (POST /api/admin/runs/:id/rejudge,
//                  server/routes/admin/scrape-holds.ts), on the scrape-heat queue (server/jobs.ts ScrapeRejudgeJob), so
//                  on this host: createScrapeHeatHandler hands it to scrape-holds.ts judgeRejudgeJob with the grade
//                  jobs' sandbox, the scorer as it mounts it (scrapeScorerSetupFor), the lease, the work root and the
//                  job's owner (regradeOwner), and ScrapeWorkerDeps.scoring (default grader/scrape/score.ts)
//   code heat      a program/v1 harness naming a timing heat (ProgramHarness.timing: a code-fastest bounty's) ranks the
//                  entries that pass on CPU time net of the null-entry control (grader/code-heat.ts: the null entry, the
//                  house's own program, timed on the same clock beside them, each run counted less the median of the
//                  heat's control runs, below 0 when under it: code-heat.ts codeHeatNetRuns, never clamped, the heat's
//                  timings raised together when one would read below 0), read by a CPU clock on the docker driver or
//                  the k8s driver (GradeWorkerDeps.timingSandbox, default the grader's sandbox when it is either:
//                  timingSandboxOf). docker's (sandbox/docker.ts openCpuClock) reads a timing parent cgroup host-side;
//                  k8s's (sandbox/k8s.ts openCpuClock, its header's Timing) runs each timed pod's program under the
//                  house's CPU launcher, the child subreaper of everything the program starts, and sums the
//                  getrusage(RUSAGE_CHILDREN) each launcher reports once it has reaped them all (under gVisor its
//                  Sentry's 10 ms-tick estimate), each timed pod held to one CPU, its limit and request. A worker
//                  process times on ONE clock (processCpuClock: opened at its first timing and kept, so on docker it
//                  leaves one empty timing cgroup behind, not one per grade), one timing at a time, every timed run
//                  counted on the clock alone (docker: under its parent cgroup alone)
//     dev          a dev grade that passed its gate is timed CODE_TIMING_DEV_ROUNDS times on that clock, each run
//                  followed by one of the control (code-heat.ts runProvisionalTiming), and recorded with its provisional
//                  timing (the median of its runs net of the null-entry control, shown on the dev board, never weighed),
//                  or unranked when a timed run wrote other outputs (TIMING_OUTPUTS_DIFFER): grade.ts scoreWithTiming.
//                  A process whose sandbox reads no CPU time (the process driver) records it untimed, and says so; so
//                  does one whose clock a heat holds or waits for (ProcessCpuClock.heatAhead), at once: a dev grade
//                  never waits on a heat, which may hold the clock past the grade job's expiry (behind another dev
//                  grade's timing it waits). A clock, a timed run the sandbox fails or a control that does not end ok
//                  is the house's fault, thrown, so the job retries
//     final        createProgramHeatHandler, the code-heat job ({phase_id}, server/jobs.ts): once the phase is locked and
//                  every final grade has landed (server/competitions/lifecycle/finalize.ts codeHeatDue; while one is in
//                  flight the job hands itself on to its next CODE_HEAT_RECHECK_MS slot, codeHeatJobId of it) and an
//                  entry of the field (admin/grading.ts codeHeatField) has a grade run linked to no record, the whole
//                  field is timed in one heat, the null-entry control once in every round (code-heat.ts runCodeHeat), on
//                  the phase's plan as its grades ran it (the seed and data digest every field run recorded; another is
//                  a PermanentJobError: its outputs could never match), in the runtime the harness names, after any
//                  scrape heat holding the host (scrapeHostQuiet). The record (every reading gross, as the clock read
//                  it, the control's among them) is stored as a blob (its canonical JSON, named by its sha256); then, in
//                  one transaction, each field entry's grade run takes its score built again with its verdict (grade.ts
//                  scoreWithTiming: its timing at performance.timing, net of the null-entry control, or unranked:
//                  TIMING_OUTPUTS_DIFFER) and run.code_heat_sha256, the link a regrade rebuilds the timing through, and
//                  the board is told (record.ts GRADE_CHANGE). Each write holds only while the run's result_sha256 is
//                  the one the heat read; a run changed meanwhile writes nothing, and the retry times again. A phase
//                  with nothing owed is answered with nothing done, and drops any runs kept for it (below)
//     resume       the heat keeps its runs as they are measured, the control's among them (code-heat.ts the resume: a
//                  CodeHeatPartial in the work root, codeHeatPartialPath of the phase, rewritten whole after each run),
//                  so an attempt that dies or expires partway loses none: the next attempt of the phase's heat (the
//                  job's retry, or any later code-heat job of the phase: a wait slot's, a backstop, an admin's resend)
//                  on this host takes them as they stand, a kept control never timed again, and times only the rest,
//                  its record the one an uninterrupted heat makes of the same measurements. They are its only while
//                  their key holds (code-heat.ts codeHeatResumeKey over the phase seed, the timing, the finalist
//                  places, the field with each graded action log, the control's program: the sha256 of the null
//                  entry's script, code-heat.ts codeHeatControl, and the plan: the phase, its bundle's canonical sha256,
//                  the data digest, this process's harness_version, the runtime, its pinned image and each entry's
//                  snapshot and image) on a clock of their kind; anything else (the field changed, a regrade moved an
//                  action log, a deploy changed the grader or the control) drops them, and the heat starts over. They
//                  are removed once the heat's writes commit
//     hand-on      a heat may hold more work than its attempt has time for (pg-boss fails an attempt at its expiry,
//                  JobContext.expiresAt, and expires none past server/jobs.ts CODE_HEAT_MAX_EXPIRY_SECONDS). Its work
//                  at most is codeHeatPlannedRuns (the warm-up and main rounds over the field and the control, the
//                  playoff rounds over as many finalists as the field and codeHeatPlaces allow and the control) of
//                  codeHeatRunMs each (the phase's cases' time caps, and server/proposals/checks.ts
//                  PACK_CASE_OVERHEAD_MS a case for its containers' start and exit). The attempt starts a run only
//                  while that run at most and server/jobs.ts CODE_HEAT_SLACK_SECONDS still end before its expiry (its
//                  first run whatever its expiry when those two are more than any attempt holds); past that it stops
//                  between runs (the runs so far kept: `resume`) and sends the phase's next code-heat job itself
//                  (codeHeatJobId `rest:<job id>:<runs kept>`, the phase its singleton key), expiring after the runs
//                  still to come at most (server/jobs.ts codeHeatExpirySeconds), and records nothing: that job, or any
//                  of the phase's before it, goes on from the kept runs, so a heat of any length ends over successive
//                  attempts, its record the one an uninterrupted heat makes of the same measurements. Its waits
//                  before its first run count against its expiry too: for the process's clock behind other timings
//                  (another phase's heat may hold it as long as its own expiry) and then for any scrape heat holding
//                  the host. An attempt waits only until its expiry less the slack (createProgramHeatHandler
//                  codeHeatWait); then it leaves the clock's queue (ProcessCpuClock.exclusive's abort: it no longer
//                  counts in heatAhead, the timings behind it keep their order) or lets the clock go, times nothing,
//                  and hands on the same way, its runs kept as they stand, the job starting CODE_HEAT_RECHECK_MS on:
//                  a queue for the clock never fails an attempt by its expiry, burns its retries or pages a dead heat.
//                  Handed no expiry (a direct call) or no queue (deps.jobs) to hand on to, an attempt waits as long
//                  as its signal lets it and times the whole heat
//     late         a hand-on whose rest plans to end past the competition's result deadline (its open escrow's
//                  resolve_deadline, the earliest of them: past it post_result cannot land and the whole pot
//                  refunds) is paged (deps.page: codeHeatLatePage, naming the competition, the job, the planned finish
//                  and the deadline), once per heat and deadline in the process (createProgramHeatHandler's own record of
//                  what it paged; a later hand-on of the same heat is logged). The plan is the rest job's start (now,
//                  or its startAfter from a wait) and its runs at most of codeHeatRunMs each. It is an alert only: the
//                  hand-on is sent as it would be, and nothing is stopped, refused or resized. A competition with no
//                  open escrow has no such deadline, and pages nothing
//   judge heat     a judged final's heat (ProgramHarness.judge; grader/judge-heat.ts) is the code-heat job's other
//                  kind (createProgramHeatHandler, programHeatPhaseOf): due as a timing heat is (codeHeatDue), it
//                  holds no clock and no sandbox, its calls going to the house judge through masq, or straight to
//                  superbot-router for a model it serves while MAKEFUN_SUPERBOT_ROUTER_URL and _KEY are set
//                  (grader/judge-call.ts openJudgeHeat; JudgeWorkerDeps). judgeCodeHeat reads the field's artifacts
//                  (each entry's final grade's output file judge.artifact, program.ts readOutputFile) and the house
//                  anchors from the judge directory, held to judge_sha256 (treeSha256). An entry that passed and
//                  wrote none, or one the judge cannot read (an image of no type masq takes), is left out of the
//                  field, and the log says why: its
//                  run is linked to the heat's record with no verdict, so it ranks below every judged entry and holds
//                  up nothing (a field with no entry left is a PermanentJobError: the scorer's gate is to fail them).
//                  It plans the schedule from the phase's plan seed (judgeHeatSetup), and opens the heat on a key of
//                  its own (judge/final/<n>, n the phase's next judge key: the header's `judge keys`) with no dollar
//                  cap: whatever its worst case, it opens and sends every round its schedule plans, with no budget
//                  weighed before any of them (judge-call.ts openJudgeHeat with no key.capUsd); its request ledger
//                  (the calls still to come and the one fault re-send, each JUDGE_CALL_ATTEMPTS requests), its
//                  max_output_tokens, the one pinned model and the key's under-24 h life bound it. Only an unpriced
//                  model or a model blind to an image artifact holds it: the job is sent again
//                  JUDGE_HEAT_HOLD_RECHECK_MS on and pages once an hour (holdJudgeHeat; judgeHoldPage). A partial an
//                  earlier release kept (a heat it held before a round) resumes from its calls to the end.
//                  The calls the schedule has already planned (a batch: a Swiss round's, the
//                  playoff's) go out up to the heat's share of the judge pool at once (below; sendJudgeHeatCalls; the first alone while the
//                  heat may yet learn its model takes no forced tool and the process has not seen that model answer a
//                  forced form in the last 6 h: JudgeWorkerDeps.formsSeen), and each is taken strictly in the planned
//                  order, one that settles early held until those before it have: the calls, the record and the
//                  partial are a serial run's, byte for byte, and a heat that stops waits for every send in flight
//                  (each one metered) and keeps only the settled prefix. A call still out near its batch's end is
//                  backed up (JudgeWorkerDeps.backup, default grader/judge-backup.ts JUDGE_BACKUP: the batch's last
//                  20%, min 2, once its newest send is older than max(8 s, 1.25 x the median answer), or any send 90 s
//                  old; 3 sends a call at most, backups at most a quarter of the primaries, and only out of requests
//                  the heat's ledger can spare beside every call still to send and its fault re-send, so the ledger
//                  bounds it as before). The first send to answer with a verdict decides the
//                  call; its other sends are aborted at once and kept as the record's `spares` (judge-heat.ts), never
//                  scored; a call faults only when every send of it faulted. JUDGE_HEAT_CONCURRENCY (64) is a heat's
//                  width, what a live ramp (2026-11-11) found the shared model pool gives without slowing every call;
//                  the platform's budget is wider, JUDGE_POOL_BUDGET (96: in flight together it shed nothing and ran
//                  each call at 79.6% speed, about a fifth more work in total): every live heat, a final's and a dev
//                  grade's provisional one alike, on every grader process, shares one budget of JUDGE_POOL_BUDGET
//                  judge sends in flight, backups counted, and no heat holds more than its own width. A heat takes a
//                  seat in it once its key is minted (openJudgePoolSeat: a file `<id>.json` under the blob store's judge-pool directory, which
//                  every process reads, holding what the heat could use right now and when it was written, and beside
//                  it `<id>.seat` (makefun/judge-pool/v2), which an old process never reads, adding the heat's class and
//                  its sends in flight; rewritten when those move, at most each JUDGE_POOL_REFRESH_MS, and at least
//                  each JUDGE_POOL_BEAT_MS; removed when the send ends, however it ends) and keeps its sends in flight
//                  under its share (judgePoolShares: max-min fair over the seats' wants, every seat at least 4 of what
//                  it wants; a heat alone keeps its 64, two at once get 48 each, and one whose round is in its tail
//                  gives the rest to the other; final first: while a final's heat is live, the finals take their
//                  shares first and the dev grades' provisional heats split what is left, at least 1 each). A heat
//                  that joins, or whose want rises, takes its share less what the others hold in flight past theirs
//                  (judgePoolAllowance: no send in flight is cancelled when a share falls, so without it a final
//                  joining three full practice heats put 136 in flight), growing as their sends complete, so the
//                  pool stays within the budget plus the floors. A seat not written for JUDGE_POOL_STALE_MS (its grader died) counts no more, so its
//                  share goes back to the others within 30 s; the pool's own I/O failing leaves the heat bounded by
//                  its own width alone, as before the pool (JudgeWorkerDeps.pool: by default only on the environment's
//                  broker). The pool's pushback narrows the width under the share: each rate-limited re-send a turn
//                  finds (judge-call.ts JudgeHeat.pushbacks) halves the heat's width in force (never under 16), holds
//                  its backups 30 s, and each quiet 15 s gives 8 back (JUDGE_PUSHBACK_FLOOR), no call in flight
//                  cancelled. Each call is kept as it settles (the
//                  response blob first, then the calls and their spares: judgeHeatPartialPath, under
//                  judgeHeatResumeKey), with what it spent and the key held open, so an attempt that stops goes on
//                  from the next call, its open key retired first against what it metered.
//                  A call that faults is sent once again; a second fault, or more calls with no verdict than
//                  judge.invalid_share_max allows (stopped as soon as no call to come can mend it), fails the heat: a
//                  PermanentJobError with a JudgeHeatError its cause, nothing written, the dead job paged
//                  (codeHeatDeadPage). The heat done, its key is retired (masq's spend beside the meter: flags
//                  logged), the record stored, and each field entry's run written its score built again with its
//                  member's verdict (scoreWithJudge: performance.judge) and run.judge_heat_sha256, in one transaction
//                  held to the result each run had (a run written since retries the job, from the calls kept). A
//                  regrade rebuilds the verdict from that record (grader/regrade.ts judgeVerdictOf), never by calling
//                  a model
//   provisional judge
//                  a judged competition's dev grade that passed its gate plays its artifact against every house
//                  anchor in both orders before it is recorded (withProvisionalJudge; judge-heat.ts's provisional
//                  stage, judgeProvisionalCalls: two calls an anchor; sent as the judge heat's are, up to its share
//                  of the judge pool at once (a seat of its own, as a final's heat takes) and kept in planned order, a
//                  batch's last calls backed up by the
//                  same rule and their other sends kept in memory for the record's spares), on a key of its own
//                  (judge/dev/<n>) weighed
//                  first against judge.dev_daily_usd net of what the competition's provisional heats spent this UTC
//                  day (the header's `judge keys`). Its record is stored and linked as run.judge_heat_sha256, and its
//                  score carries the verdict (performance.judge, provisional: its win rate against the anchors),
//                  shown on the dev board and never weighed. A grade the heat cannot judge is recorded unjudged and
//                  says so in the log (no gateway, a worst case past the daily cap, no artifact or one the judge
//                  cannot read, a second faulted call, more calls with no verdict than judge.invalid_share_max
//                  allows); nothing is sent again, and nothing paged. A regrade rebuilds the verdict from the record.
//                  A bundle naming a ladder (judge.ladder: grader/judge-ladder-tree.ts readJudgeLadder, beside the judge
//                  directory) plays a v3 heat on it instead: the anchors once each, then its adaptive rounds against
//                  the ladder's members of fixed strength (judge-heat.ts judgeHeatPlannedCalls), rated against them.
//                  A short day drops whole adaptive rounds, the most that fit the cap net of the day's spend, before
//                  the grade is recorded unjudged
//   provisional reuse
//                  a dev artifact byte for byte one an earlier entry of the phase was judged on (server/entries/
//                  screen/artifact.ts judgedSameArtifact, oldest first) takes that verdict with no judge call: the
//                  earlier record's key the current judge's (provisionalRecordJudgeKey, provisionalJudgeKey), its
//                  phase seed the heat's, and its verdict on the artifact one the regrade rebuilds (grader/regrade.ts
//                  judgeRecordVerdictOf: a provisional field's one entrant member on the same bytes). The run links
//                  that record; no key is claimed, nothing reserved or spent. A miss, or a fault in the lookup (logged
//                  with its stack), is judged as above. Either way, once the heat ends, the artifact is written to the
//                  phase's entry_artifact (its fingerprint, record, whether it was reused, and near_of; no record when
//                  the heat judged nothing), a fault there logged and the heat kept (recordProvisionalArtifact). No row
//                  is written for a heat that ended on the platform's fault or the daily cap, nor for one that never
//                  reached an artifact the judge reads (no judge tree or ladder, no artifact, one the judge cannot
//                  read). Two identical artifacts judged at the same moment may both pay
//   provisional rejudge
//                  an admin's POST /api/admin/competitions/:slug/rejudge-provisional (server/routes/admin/grading.ts),
//                  and every 15 minutes the ops process's provisional-rejudge-sweep for each judged competition still
//                  taking entries (server/grading/provisional-rejudge-sweep.ts), sends, for each kept dev entry whose latest grade run passed its gate and is not yet judged on the
//                  bundle's current judge, a grade-dev job naming that run (server/jobs.ts GradeJob `rejudge`, an
//                  L1-shaped job: kind regrade_l1, reproduces_run_id the run). Its handler (rejudgeProvisional) runs
//                  no program and records no run: it plays the run's artifact in a provisional heat on the current
//                  judge (provisionalJudgeHeat, the dev grade's own: anchors, judge directory, house text, the daily
//                  cap, the record stored first) under the seed the run recorded, and writes the run its score built
//                  again with the new verdict and the link to the new record, in one transaction held to the result
//                  it had (GRADE_CHANGE told), as a new dev grade would record it; a heat that judges nothing records
//                  the run unjudged (old verdict and link dropped), as a dev grade is, but never over the platform's
//                  fault or the daily cap: a faulted heat writes nothing and throws for the job to retry, a capped one
//                  writes nothing and is sent again on a later UTC day, the verdict kept. What a verdict was judged on is
//                  its record's ProvisionalJudgeOn (format, agent, judge_sha256, media, artifact, invalid share, house
//                  text, and on a ladder its digest, rounds, games and spread), keyed by provisionalJudgeKeyOf: a run
//                  whose record's key is the current judge's (provisionalJudgeKey) is judged already, and is skipped,
//                  by the route and again by the job (whose record played fewer of the ladder's rounds on a short day
//                  counts as judged on it: provisionalRecordJudgeKey given the judge). A ladder landing on a bundle
//                  moves its key, so each kept dev entry is judged again on it, under the daily cap. A
//                  final phase's run is refused: its verdict is its heat's. Nothing is published after it
//   judge keys    every key a phase's judge heats mint is kept as a file of its own under the blob store
//                  (judgeKeysDir: JudgeKeyFile, `<attempt>.json`, claimed by a link that fails on a name taken, so
//                  no two heats share a number), with what its heat metered and what masq said it spent once retired
//                  (a provisional heat's worst case reserved while it runs). What a provisional heat may still spend
//                  is its cap net of every provisional key claimed the same UTC day; a final heat weighs no spend (it
//                  has no cap), its keys kept for their numbers and what they spent, a failed heat's on any host among
//                  them (a key another attempt left open retired first). A claim
//                  that never minted is removed by the first read past JUDGE_KEY_CLAIM_EXPIRE_MS (10 min) after
//                  its claim and counts nothing: its heat stopped between claim and mint (readJudgeKeys). A
//                  provisional heat that does not fit the day only because other heats in flight reserve their
//                  worst case (what the day has settled, judgeKeySettled, and its cheapest worst case fit) gives its
//                  claim back and claims again every 3-10 s for up to JUDGE_KEY_WAIT_MS (3 min) before it is held;
//                  it does not wait on open keys all claimed over JUDGE_KEY_ORPHAN_MS (15 min) before
//   scratch        a grade's executions and scorer, and a regrade's re-execution and scorer, work in
//                  directories under the work root (GradeWorkerDeps.workRoot). Handed its job's context
//                  (GradeJobContext), the handler names them for the job: its owner is regradeOwner of
//                  the job's id, `regrade-<job id>`, the same on each attempt and no other job's, so
//                  they are `exec-<owner>-XXXXXX` and `score-<owner>-XXXXXX` (grade.ts
//                  GradeRequest.owner, regrade.ts RegradeL1Request.owner). Each attempt first
//                  removes what an attempt of the job that died left so named (grade.ts
//                  reapGradeScratch), each path logged (scratchReapLine). What no attempt comes back
//                  for is removed by the workers' start (server/pipeline/index.ts sweepDeadWork), and
//                  only once all three hold (removeIfDead): no active job on the start's database
//                  holds its owner, no one has touched it for six hours (its newest change, its own or
//                  a direct entry's, older than grader/sandbox/network.ts STALE_AFTER_MS), and no live
//                  process holds it open or as its cwd (processesHolding). One younger, held or not to
//                  be asked about is kept and logged: a job on another database sharing the work root,
//                  or a run handed no job, may still work in it. Handed no context (a test, a direct
//                  call), it names them for no one, `exec-XXXXXX` and `score-XXXXXX`, as before;
//                  nothing removes those after a crash. An agent/v1 regrade's is its own (`regrade`)
//
// practice windows  a dev phase whose bundle carries practice_windows (contracts/competition.ts Phase.practice_windows:
//                  {count, hours}, a pumpfun-replay/v2 harness; its dev dataset is null, each window's attached to a
//                  practice_window row) grades the entry on every window, gradeEras:
//                    - the run row first, `running`, under agentRunId of the grade job (so a retried job finds it)
//                      with no dataset_sha256 or seed (the median window is not known yet)
//                    - each window in key order (practiceWindowKeys): one the run's run_era rows hold finished (its
//                      dataset, seed and Score as the window has them) is kept, so a retry resumes; any other is
//                      graded on eraWindowPlan (its own dataset, the seed phaseSeed(competition key, 'dev', that
//                      dataset's sha256) and the public fail key of it, no final window), two executions byte
//                      equal (grade.ts gradeEntry), and its run_era row and blobs recorded (record.ts recordEra)
//                    - the grade stops at the first window not ranked (failed, timed out, two executions that
//                      disagree, an unmetered cost): that window's outcome is the run's, its own Score the result
//                      (the first such window by key is what score.ts aggregateEras returns)
//                    - otherwise the run's result is aggregateEras over every window's Score (regrade.ts erasResult),
//                      and the run's dataset_sha256, seed, fail key, action log, trace and stderr are the median
//                      window's (the result's performance.eras.rank_window); exec_count and wall_ms are the sums over
//                      the windows, flags the median Score's
//                  A regrade of a run with run_era rows follows them window by window (regrade.ts regradeErasL1,
//                  regradeErasL2): each row's dataset resolved by its unique sha256, its own seed and public fail key,
//                  the regrade's run a run_era row of its own for each. A dev phase without practice_windows, and a
//                  run without run_era rows, take the path they always have.
//
// Harness faults (sandbox, scorer, a dataset the sim refuses) propagate so the job retries, and so
// does a committed fail key that cannot be derived yet (FailKeyUnavailableError, paged: the header's
// `fail key`); a job
// that can never succeed (no bundle, no snapshot, no dataset, a dataset that fails its hashes, a
// stored authorship summary that does not validate, nothing to regrade, an instance bundle whose
// instance does not check, an agent/v1 run its regrade cannot re-derive, a scrape/v1 competition with
// no house baseline, a scrape/v1 L2 regrade) is a PermanentJobError and goes to the dead-letter queue.
// An instance bundle with no instance drawn yet to grade on is the platform's (`not drawn` below).
//
// platform fault   a clmm score whose LVR (fees - costs - hedged PnL) parts from LVR leg by leg by
//                  more than rounding (sim/clmm/metrics.ts ClmmLvrMismatchError, which every clmm
//                  plan's score throws: harnesses.ts clmmPlan, assertClmmLvr) is a fault of the
//                  scorer or the engine, never the entry's, and no retry mends it: the grade or
//                  regrade throws server/jobs.ts PlatformFaultError (a PermanentJobError naming the
//                  entry or run, the phase and both LVRs), so the job dead-letters at once and is
//                  paged as a `dead grade job` (below), and no run is recorded, so nothing is posted
//                  and the entry is never scored on it; the pipeline's grade stage puts the entry
//                  back as it was rather than failing it (server/pipeline/index.ts). The scorer is
//                  GradeWorkerDeps.clmmScorer (default scoreClmmActionLog); the check holds whatever
//                  it is
//
// not drawn        an instance-drawn phase whose instance is not drawn yet is the platform's, never
//                  the entry's: no instance.yaml in the competition directory at all (nothing drawn:
//                  the practice draw writes it), on the final phase no scored draw record yet (no
//                  instance-draw-0.json: the scored round is not drawn), or an instance tree that is
//                  not there at all (the practice instance or trial not drawn yet: `instance`,
//                  `agent/v1` above; a scored one whose trees are gone). Each is an
//                  InstanceNotDrawnError, a PlatformFaultError naming what is not there and the draw
//                  that mends it. No run is recorded. The pipeline's grade stage puts the entry back as
//                  it was and hands the grade job on until the draw is there (server/pipeline/index.ts),
//                  so a grade's is never paged as a `dead grade job` (below) by its handler (one a stage
//                  with no queue could not hand on dead-letters, and the sweep pages it); a wait past
//                  a day (a draw never made, or a competition directory or MAKEFUN_SEALED_DIR that is
//                  not where the draw wrote) pages the admins once, by the pipeline, and the entry
//                  waits on (server/pipeline/index.ts INSTANCE_WAIT_PAGE_MS); a regrade's
//                  dead-letters and is paged as any PlatformFaultError. What is there but does not
//                  check (an instance.yaml that cannot be read or does not check, a draw record chain
//                  that does not verify, a tree that digests otherwise) stays a PermanentJobError
//
// ranked floor     a clmm phase's window is held to its phase's floor of whole blocks of the
//                  harness's interval.block_hours (contracts/clmm-protocol.ts clmmPhaseBlocksIssue):
//                  CLMM_RANKED_MIN_BLOCKS (28) on the final phase, whose board pays the prizes,
//                  CLMM_MIN_BLOCKS (8) on dev; under it the grade or regrade is a PermanentJobError
//                  (harnesses.ts ClmmShortWindowError, its reason naming the phase, the blocks and
//                  the floor)
//
// dead grade job   a grade job that dies for good pages the admins, once per job and attempt: its
//                  GRADE_JOB_DEAD_ACTION row (the system's, subject the submission), written under
//                  the submission row's lock before the line goes out, is what keeps it from being
//                  paged again. Found in two places. The job's own handler as it dies, when it is
//                  handed its job context (GradeJobContext, which the pipeline's grade stage hands
//                  on: a PermanentJobError, or any throw on its last attempt, isLastAttempt). And a
//                  sweep (createDeadGradeJobPager), run by every grade job before it grades and by
//                  the forfeit sweep's job every 15 minutes (server/pipeline/index.ts startWorkers),
//                  over every grade job pg-boss holds failed that no row records: one that died
//                  outside its handler (refused by the grade stage before it, expired with its
//                  process gone, failed by hand) or whose handler was handed no context. The page
//                  (deps.page, default console.error: a "[grade] ALERT:" line) names the
//                  competition, the entry, the phase, the job, how it died and its last error, and
//                  the admin route that queues it again: a regrade's POST
//                  /api/admin/runs/<run>/regrade, a grade's POST
//                  /api/admin/submissions/<entry>/grade/resend with the dead job's id, which sends it
//                  again under a fresh job id (server/routes/admin/grading.ts registerGradeResend).
//                  A job held on its entrant's entry secrets (its error opening
//                  ENTRY_SECRETS_UNOPENED_HOLD_REASON: `entry secrets` above) is paged as held, never
//                  failed: the entry waits ungraded, and the fix is the seal private keys that open the
//                  secrets its error names (MAKEFUN_ENTRY_SECRET_SEAL_PRIVATE_KEYS_FILE; on the cluster,
//                  Secret makefun-entry-secret-seal), then the same route (heldGradeJobPage).
//                  An entry that is out (cancelled, or a refusal that stands: a duplicate snapshot or a
//                  committed secret, server/pipeline/publish.ts isRefused) was never to
//                  be graded: its death is recorded and logged, not paged. A row or a sweep that
//                  fails is logged and never fails the job (its own error stands). The row goes
//                  through payouts/audit.ts recordAudit, whose AuditAction names grade.job_dead.
//
// The hindsight-audit job handler (server/jobs.ts PipelineHandlers.hindsightAudit:
// createHindsightAuditHandler; its rules are server/routes/admin/hindsight.ts's, its audit
// grader/hindsight-audit.ts's):
//   sweep {phase_id}    on a drawn sealed window's final phase (its draw attached the phase's dataset:
//                       admin/hindsight.ts drawnFinal) whose grading has settled, one job per audit
//                       target lacking hindsight_clean and per appeal filed with no record yet
//                       (server/jobs.ts hindsightAuditJobId); anything else is a no-op
//   one entry           its latest final grade run (finished, a replay score) audited with auditEntry:
//                       the snapshot materialized as the grader mounts it; the drawn masked window
//                       (the phase's dataset row) as the real window, its digest the run's; the real
//                       run's hello seed and fail key (the run's, else derived again as grading
//                       derives it: phaseFailKey by the phase's scheme, a FailKeyUnavailableError
//                       retried and paged alike, the header's `fail key`) and its stored net PnL; the
//                       env-lane entry secrets the run recorded, re-opened (recordedEnvSecrets, the
//                       header's `entry secrets`: one erased since is a PermanentJobError, one this
//                       grader cannot open a retryable Error, nothing run either way); the
//                       static scan against the drawn source
//                       (the draw's source dataset row) with the dev phase's window as `background`
//                       (its public amounts identify nothing), the index built once per window pair
//                       and kept (buildHindsightIndex), and the entrant's entry wallets and payout
//                       wallet as ignoreAddresses; CHEAT_CHECK.m surrogates per rung (appeal_m on an
//                       appeal); the seeds from one master secret, HKDF-SHA256 of the server secret
//                       (deps.failKeySecret, on either fail-key scheme) over (kind, entry, run,
//                       appeal attempt) (hindsightSeedMaster), so a
//                       retried job rebuilds the same surrogates and an appeal gets fresh ones. The
//                       record must pass checkAuditRecord, then admin/hindsight.ts
//                       recordHindsightAudit keeps it (and, on an audit, records the check). An audit
//                       of a run already recorded, or an appeal with none awaiting its re-run, is a
//                       no-op; what can never succeed (no draw, no finished replay run, an AuditError)
//                       is a PermanentJobError. The audit works in `<work root>/hindsight-<owner>-XXXXXX`
//                       (HINDSIGHT_SCRATCH_PREFIX), named for its job (regradeOwner of the job's id,
//                       the same on each attempt). Before anything else, each attempt removes what an
//                       attempt of the job that died left so named (regrade.ts reapScratch), each path
//                       logged (scratchReapLine). What no attempt comes back for is removed by the
//                       workers' start (server/pipeline/index.ts sweepDeadWork), and only once all
//                       three hold (removeIfDead): no active job on the start's database holds its
//                       owner, no one has touched it for six hours (its newest change, its own or a
//                       direct entry's, older than grader/sandbox/network.ts STALE_AFTER_MS), and no
//                       live process holds it open or as its cwd (processesHolding). One younger, held
//                       or not to be asked about is kept and logged: a job on another database sharing
//                       the work root, or a run handed no job, may still work in it. While a scrape/v1
//                       heat holds this host's lease (scrapeHostHeldBy: `scrape/v1` above), an audit
//                       runs nothing: once the no-op cases are ruled out it hands its job on to the next
//                       recheck slot (SCRAPE_HOST_RECHECK_MS, server/jobs.ts hindsightAuditWaitJobId),
//                       so no surrogate shares the CPU with a timed heat and none spends its expiry on it.
//                       An attempt stops once its signal aborts (JobContext.signal: pg-boss gives the
//                       attempt up at its expiry, and retries the job): its replays run in a sandbox
//                       bound to the signal (grade.ts stoppableSandbox), so the abort kills the replay
//                       running and no later one starts, and an attempt given up before its audit
//                       materializes nothing. Its scratch is removed as ever, nothing is recorded (not
//                       even a record its audit finished), and it rejects with the signal's reason,
//                       never a PermanentJobError: the retry audits afresh, never beside a first that
//                       goes on replaying, and records once.
//   dead                an entry job that dies for good pages the admins, once per job: its
//                       HINDSIGHT_AUDIT_DEAD_ACTION row (the system's, subject the submission), written
//                       under the submission row's lock before the line goes out, is what keeps a
//                       later sweep from paging the job again. Found in two places. The job's own
//                       handler as it dies (a PermanentJobError, or any throw on its last attempt:
//                       isLastAttempt of JobContext.retryLimit), when the audit's entry is an
//                       unchecked audit target on that run and no newer audit job of the run is held,
//                       or an appeal waits for that re-run. And each sweep, after its sends, for every
//                       unchecked target whose latest audit job pg-boss holds failed, and every
//                       appeal still waiting whose latest re-run job (kind appeal, of the run it
//                       re-runs) pg-boss holds failed (admin/hindsight.ts latestAuditJobOf): one that
//                       died outside its handler, expired with its process gone, or failed by hand.
//                       The page (deps.page, default console.error: a "[hindsight] ALERT:" line) names
//                       the competition, the entry, the run, the job, how it died and its error, and
//                       the fix. A dead audit's: a verdict at POST /api/admin/submissions/<id>/hindsight
//                       (deadAuditOf), given with no audit record, open until the final phase is
//                       finalized (at or after its ends_at too, which the page then says). A dead
//                       appeal re-run's: a verdict deciding the appeal without it, likewise open until
//                       finalize (deadAppealOf past ends_at); its handler pages it only while no newer
//                       re-run job of the appeal is held. Reading or writing a page that fails is
//                       logged, and never fails the job (its own error stands) or the sweep.
//
// The dev-stress job handler (server/jobs.ts PipelineHandlers.devStress) is grader/dev-stress.ts's
// createDevStressHandler, which reads this file's helpers (practiceWindowsOf, storedEraWindows, entryRuntime, regradeOwner,
// scratchReapLine, scrapeHostHeldBy) and which nothing here imports back: the eras dev grade's stress on the kit's shared
// block surrogates, its scratch `<work root>/devstress-<owner>-XXXXXX` (DEV_STRESS_SCRATCH_PREFIX), a scrape/v1 heat
// waited out as an audit's (server/jobs.ts devStressWaitJobId).

import { createHash, hkdfSync } from 'node:crypto';
import { link, mkdir, mkdtemp, readdir, readFile, rename, stat, unlink, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { isAbsolute, join, relative, resolve, sep } from 'node:path';
import { existsSync, lstatSync, readdirSync, readFileSync } from 'node:fs';
import { and, asc, count, desc, eq, inArray, isNotNull, isNull, ne, or, sql } from 'drizzle-orm';
import { z } from 'zod';
import { AGENT_TRIAL_STATUSES, TRIAL_OUTPUTS_FORMAT, TrialOutputs, type AgentTrialRecordT, type AgentTrialStatusT, type TrialOutputsT } from '../contracts/agent.ts';
import { CompetitionBundle, PROGRAM_JUDGE_ANCHORS_DIR, practiceWindowKeys, raceOf, rankingPhaseIndex, scorerDirOf, type AgentHarnessT, type CompetitionBundleT, type HarnessT, type ProgramHarnessT, type ProgramJudgeT, type PracticeWindowsT, type ProgramTimingT, type ScrapeHarnessT } from '../contracts/competition.ts';
import { PATCH_LISTS_FILE, type PatchHarnessT, type PatchListsT, type PatchPhaseT } from '../contracts/patch.ts';
import { IsoDateTime, U64 } from '../contracts/primitives.ts';
import { AuthorshipSummary, Score, type AuthorshipSummaryT, type ProgramJudgeScoreT, type ScoreT } from '../contracts/score.ts';
import { ScrapeHeat, type ScrapeHeatT } from '../contracts/scrape.ts';
import type { BlobStore } from '../server/blobstore.ts';
import { COMMITTED_FAIL_KEY_SCHEME, committedFailKey, DeadlineCommitment, failKeySecretSha256, SERVER_SECRET_FAIL_KEY_SCHEME, verifyDeadlineCommitment } from '../server/chain/deadline-commitment.ts';
import { DRAW_FILE, DrawRecord, isSealedWindowError, MAX_SEALED_WINDOW_BYTES, SEALED_WINDOW_FILE, verifyDrawRecord, type SealedWindowChainOptions } from '../server/chain/sealed-window.ts';
import {
  checkInstanceBundle,
  INSTANCE_FILE,
  instanceDrawFile,
  instanceDrawK,
  isInstanceError,
  MAX_INSTANCE_BYTES,
  parseInstanceSidecar,
  parseTrialsSidecar,
  scoredBeacon,
  verifyInstanceDraws,
  type InstanceChainOptions,
  type TrialsSidecarT,
} from '../server/competitions/instance.ts';
import {
  COMPETITIONS_DIR,
  INSTANCE_TREES,
  instanceRootOf,
  judgedArtifactTrees,
  judgedHouseSlug,
  PACK_CACHE_DIR,
  packScorerIssue,
  packTreeDigest,
  packTreeDir,
  packTreeSources,
  practiceInstanceDir,
  practiceTrialDir,
  programCompetitionDir,
  rehashes,
  scoredInstanceDir,
  scoredTrialDir,
  sealedDirFromEnv,
  treeSha256,
  TreeDigestError,
  type PackTreeName,
} from '../server/competitions/load.ts';
import type { GradeLive } from '../server/competitions/live-judging.ts';
import { agentTrialsRefusal, isDevAuthNodeEnv, loadConfig, type Config, type SolanaCluster } from '../server/config.ts';
import type { Db } from '../server/db/client.ts';
import { uuidv7 } from '../server/db/ids.ts';
import { auditEvent, authorshipSummary, competition, competitionEscrow, competitionProposal, dataset, entrySecret, phase, practiceWindow, run, runTrial, submission, user } from '../server/db/schema.ts';
import { buildHindsightIndex, CHEAT_CHECK, type CheatCheck, type HindsightIndex } from '../server/entries/hindsight.ts';
import type { GatewaySpendRunFlag } from '../server/api-types/inference.ts';
import type { TRIAL_HELD_FLAG as StageTrialHeldFlag } from '../server/entries/stage.ts';
import {
  agentRunId,
  agentTrialExpirySeconds,
  CODE_HEAT_MAX_EXPIRY_SECONDS,
  CODE_HEAT_SLACK_SECONDS,
  codeHeatExpirySeconds,
  CodeHeatJob,
  codeHeatJobId,
  GradeJob,
  gradeAggregateJobId,
  gradeQueue,
  gradeTrialJobId,
  gradeTrialPriority,
  hindsightAuditJobId,
  hindsightAuditWaitJobId,
  isLastAttempt,
  isScrapeRejudgeJob,
  NODE_POD_HEADROOM,
  nodeHasRoom,
  PermanentJobError,
  PlatformFaultError,
  ScrapeRejudgeJob,
  sendCodeHeat,
  type AggregatedRun,
  type HindsightAuditKind,
  type JobContext,
  type JobHandler,
  type JobPayload,
  type JobQueue,
  type QueueName,
  type ScrapeRejudgeJobT,
} from '../server/jobs.ts';
import type { RejudgeJobEnd } from '../server/routes/admin/scrape-holds.ts';
import { recordLiveChange } from '../server/live/changes.ts';
import { countEntryArtifactFault } from '../server/ops/metrics.ts';
import { recordAudit, type AuditAction } from '../server/payouts/audit.ts';
import { PACK_CASE_OVERHEAD_MS } from '../server/proposals/checks.ts';
import { standingsHouse, type HouseFacts } from '../server/payouts/standings.ts';
import { entryWallets } from '../server/repos/claim-file.ts';
import { RepoIntakeError } from '../server/repos/errors.ts';
import { DRAND_QUICKNET, drandChainFromEnv, roundMin, roundTime, verifyDrandRound, type DrandChain } from '../server/repos/freshness.ts';
import { materializeSnapshot, readSnapshotIndex, removeMaterialized, type SnapshotIndex } from '../server/repos/index-tar.ts';
import { AuditError, auditEntry, checkAuditRecord, loadHindsightSource, type AuditOptions, type HindsightAuditRecordT } from './hindsight-audit.ts';
import { harnessVersion, PROJECT_ROOT } from './version.ts';
import type { BarsDataset } from '../sim/bars/engine.ts';
import type { ClmmDataset } from '../sim/clmm/engine.ts';
import { ClmmLvrMismatchError } from '../sim/clmm/metrics.ts';
import type { ReplayDataset } from '../sim/engine.ts';
import { SimDataError } from '../sim/engine.ts';
import { canonicalJson, canonicalSha256, compareCodeUnits, sha256Hex } from '../sim/canonical.ts';
import { parseU64, publicFailKey } from '../sim/rng.ts';
import type { UniverseSampleT } from '../sim/universe.ts';
import type { AgentSetup, EntrantKeys, MasqTrialUpstream, PassUpstream, SecretOutputHit, TrialPass, TrialScored, TrialVoidReason } from './agent.ts';
import { ENTRY_SECRET_HELD_FLAG, PROVIDER_KEY_REFUSED, providersOfModels, SECRET_IN_OUTPUT_FLAG, SECRET_PROVIDER_NAME, type SecretProvider } from '../contracts/entry-secrets.ts';
import type { entrySecretSealSettings } from '../server/secrets/seal.ts';
import type { OpenedEntrySecret, SealedEntrySecretRow } from '../server/secrets/store.ts';
import type { EntrySecretsOpenT } from './gateway/upstream.ts';
import type { FormIndex, FormSet } from './gateway/secret-mask.ts';
import type { KeyCheck } from './gateway/providers.ts';
import { agentChecksBreakdown, agentDeterministic, agentHarnessFloorFacts, agentModelCallRefusal, agentSilentNote, aggregateTrials, trialsManifest, type AgentTrialResult } from './agent-score.ts';
import { entryCostOf, MeteredCountError, storedMeteredCost, type EntryCost } from './entry-cost.ts';
import { createBarsDatasetLoader, createClmmDatasetLoader, createDatasetLoader, DatasetIntegrityError } from './dataset.ts';
import { ProgramDatasetError, readFrozenProgramDataset } from './program-dataset.ts';
import type { GatewayBundle } from './gateway/bundle.ts';
import type { MasqAdminKeyRefusal, MasqBroker, MasqBuildKeyBroker, MasqJudgeKeyBroker, MintedTrialKey, RetiredTrialKey, TrialKeySpec } from './gateway/masq.ts';
import { houseClockFlag } from './house-clock.ts';
import { EXEC_SCRATCH_PREFIX, gradeEntry, holdScratch, preflight, reapGradeScratch, redactThrown, refusedGrade, releaseScratch, removeScratch, scoreWithTiming, stoppableSandbox, traceIssueLine, type EntryFacts, type GradeOutcome, type GradeRequest, type SnapshotSource } from './grade.ts';
import {
  agentPlan,
  barsPlan,
  ClmmShortWindowError,
  clmmPlan,
  NO_PATCH_TREES_MESSAGE,
  PATCH_RUNTIME,
  patchPlan,
  programPlan,
  replayPlan,
  scorerVersionOf,
  scrapePlan,
  type ClmmScorer,
  type HarnessPlan,
  type PatchPlanInput,
} from './harnesses.ts';
import { PATCH_BASE_CACHE, PATCH_PHASE_CACHE, PatchRunnerError, patchTreeDir, readPatchLists, type PatchTree } from './patch/execute.ts';
import { programCases, programDataSha256, programPaths, readOutputFile, type ProgramOutputRead, type ProgramSetup } from './program.ts';
import { ScorerError, type ProgramScores, type ScorerChecksT } from './program-scores.ts';
import { addRunFlags, deferTrialQueueTag, dropRunFlag, eraOfGrade, eraOfRegrade, faultTrialQueueTag, finishRun, GRADE_CHANGE, insertTrials, loadEras, loadStoredRun, loadTrials, moveTrial, recordEra, retagTrial, recordGrade, recordRegrade, recordScrapeRuns, recordSecretHits, SECRET_IN_OUTPUT_ACTION, startRun, type EraRow, type RunSecrets, type SecretHit, type EraWindowRef, type RunIds, type RunRow, type ScrapeRunRecord, type TrialRow, type TrialUpdate } from './record.ts';
import { ENTRY_SECRETS_ERASED, erasResult, ownedScratch, reapScratch, regradeAgentL1, regradeAgentL2, regradeErasL1, regradeErasL2, regradeL1, regradeL2, RegradeError, regradeScrapeL1, REPLAY_SKIPPED_FLAG, SCRAPE_HEAT_LOG_FORMAT, SCRAPE_L2_REFUSAL, type AgentRegradeL1Request, type ErasRegradeWindow, type ScratchReap, type StoredRun } from './regrade.ts';
import { entrySecretForms, redactSecrets } from './run.ts';
import { buildScore, eligibilityRulesOf, scoreDigest, TIMING_OUTPUTS_DIFFER, type EligibilityRules, type EraWindowScore } from './score.ts';
import { codeSize, kitStarterFiles, type StarterFile } from './size.ts';
import { encodeTrace } from './trace.ts';
import { BundleTreeError, k8sDataRoot, stageBundleTree, type StagedTree } from './sandbox/bundle-trees.ts';
import { DockerSandbox } from './sandbox/docker.ts';
import { K8sSandbox, underDataRoot } from './sandbox/k8s.ts';
import type { CodeHeatOutcome as CodeHeatRun, CodeHeatPartialStore, TimedEntry, TimedSandbox, TimingSandbox } from './code-heat.ts';
import type { CodeHeatDue } from '../server/competitions/lifecycle/finalize.ts';
import type { CrosscheckReport } from '../server/race/crosscheck.ts';
import type { JudgeHeatCallT, JudgeHeatLadderT, JudgeHeatPartialT, JudgeHeatSetupT, JudgeHeatSpareT, JudgePlannedCallT, JudgeSpareEndT } from './judge-heat.ts';
import type { JudgeBackupRule, JudgeCallOutcome, JudgeSendState } from './judge-backup.ts';
import type { JudgeLadderInputs } from './judge-ladder-tree.ts';
import type { JudgeCallResult, JudgeForms, JudgeHeat, JudgeHold } from './judge-call.ts';
import type { CodeHeatFieldRow } from '../server/routes/admin/grading.ts';
import type { IsolationCheck, IsolationDriver, ISOLATION_ENGINES as SandboxIsolationEngines, IsolationRefusal, IsolationVerdict, ReapResult } from './sandbox/network.ts';
import type { ScrapeHeatAttempt, ScrapeHeatClock, ScrapeHeatDeps, ScrapeHeatEvent, ScrapeHeatOptions, ScrapeHeatResult, ScrapeLeaseDb, ScrapePacing } from './scrape/heat.ts';
import type { ScrapeScorerSetup } from './scrape/score.ts';
import { ENTRY_SCRIPTS, type Runtime, type Sandbox } from './sandbox/types.ts';

export interface GradeWorkerDeps {
  db: Db;
  blobs: BlobStore;
  sandbox: Sandbox;
  /** Existing directory for the executions' scratch directories (named for the job when the handler is handed one: the header's `scratch`). */
  workRoot: string;
  /** A phase's frozen dataset (its chunks read and parsed) and its universe sample rule (default createDatasetLoader()). */
  loadDataset?(row: typeof dataset.$inferSelect): Promise<{ dataset: ReplayDataset; sample: UniverseSampleT }>;
  /** A bars-replay/v1 phase's frozen bars window (its bars files read and parsed; default createBarsDatasetLoader()). */
  loadBarsDataset?(row: typeof dataset.$inferSelect): Promise<{ dataset: BarsDataset }>;
  /** A clmm-replay/v1 phase's frozen pool window (its bars and rows files read and parsed; default createClmmDatasetLoader()). */
  loadClmmDataset?(row: typeof dataset.$inferSelect): Promise<{ dataset: ClmmDataset }>;
  /**
   * What scores a clmm-replay/v1 action log (harnesses.ts ClmmPlanInput.scorer; default
   * sim/clmm/metrics.ts scoreClmmActionLog). Its LVR is held to LVR leg by leg whatever it is (the
   * header's `platform fault`); a test plants a fault in one.
   */
  clmmScorer?: ClmmScorer;
  /**
   * The submission's authorship summary (transcripts/authorship.ts ledger.summary) priced under
   * `pricingRev`: of algorithm `algoVersion` (a regrade's: the version its stored run was graded
   * with), else the newest; null when none was computed (default loadStoredAuthorship).
   */
  loadAuthorship?(submissionId: string, pricingRev: string, algoVersion?: number): Promise<AuthorshipSummaryT | null>;
  /**
   * A program/v1 competition's directory, and a sealed-window one's, holding its sealed-window.yaml (the header's
   * `fail key`; default competitions/<slug>; a pack competition's server/competitions/load.ts programCompetitionDir,
   * competitions/code-tests-01 for a sponsored one: competitionDirOf, the header's `pack`).
   */
  competitionDir?(slug: string): string;
  /**
   * A competition's starter as its kit hands it out, each file's path relative to starter/ with its size and sha256
   * (grader/size.ts StarterFile): what a program/v1 size count leaves out of an entry that kept it unchanged (the
   * header's `size`). Read only under a size count. Default: competitionStarter(COMPETITIONS_DIR, slug).
   */
  starter?(slug: string): Promise<readonly StarterFile[]>;
  /**
   * MAKEFUN_SEALED_DIR (config.sealedDir): where an instance-drawn competition's instances and draw
   * records are, <sealedDir>/<slug>/instance/ (the header's `instance`), and a sealed-window
   * competition's draw record, <sealedDir>/<slug>/draw.json, which a phase-secret+beacon/v1 final
   * phase's fail key mixes the signature of (the header's `fail key`). Default: the environment's, as
   * server/config.ts resolves it (load.ts sealedDirFromEnv).
   */
  sealedDir?: string;
  /**
   * The drand chain an instance sidecar's beacon, or a sealed window's, may name besides quicknet
   * (config.drandChain: a dev-auth MAKEFUN_DRAND_CHAIN test chain; quicknet names none). Default:
   * MAKEFUN_DRAND_CHAIN from the environment under dev auth (MAKEFUN_DEV_AUTH with NODE_ENV development
   * or test), else quicknet alone.
   */
  drandChain?: DrandChain;
  /**
   * The server secret a server-secret/v1 final phase's fail key is derived from (config.betterAuthSecret;
   * the pipeline passes it); never read for a phase-secret+beacon/v1 one. Default: BETTER_AUTH_SECRET
   * from the environment, else server/auth.ts's dev-only DEV_AUTH_SECRET (config.ts requires a real
   * secret in production).
   */
  failKeySecret?: string;
  /**
   * Where a grade job that died for good is paged, one line each (the header's `dead grade job`), and a
   * fail key that cannot be derived (the header's `fail key`; default console.error, as a dead hindsight
   * audit job is paged).
   */
  page?: (line: string) => void;
  /**
   * Where a dead grade job recorded without a page (its entry is out) is logged, what a grade or regrade
   * job's attempt removed of one that died (the header's `scratch`), a fail key that cannot be
   * derived once it was paged within the hour, and a race's crosscheck on a landed grade that could not
   * compare a racer or failed (the header's `crosscheck`; default console.log).
   */
  log?: (line: string) => void;
  /**
   * The clock a dead grade job's row is written at, an agent/v1 run starts at, fail-key pages are spaced by, a final
   * grade under a build meter waits for masq by (the header's `metered`), and a code-heat job reads against its
   * attempt's expiry (the header's `hand-on`; default the wall clock).
   */
  now?: () => Date;
  /**
   * Where an agent/v1 grade sends its trials' jobs and its fan-in's, a final grade under a build meter sends itself
   * again for when masq has settled (the header's `metered`), and a code-heat job hands itself on (the header's
   * `code heat`: a wait slot, and the rest of a heat its attempt cannot hold, `hand-on`): the pipeline's queue. Without
   * it an agent/v1 grade job fails (a retryable Error): nothing could run its trials; and so does a metered final grade
   * inside its settle window.
   */
  jobs?: Pick<JobQueue, 'send'>;
  /** The gateway forwarder an agent/v1 L2 regrade replays its trials through (default grader/gateway/bundle.ts gatewayBundle, cached under <workRoot>/gateway). */
  forwarder?: () => Promise<Pick<GatewayBundle, 'dir' | 'script'>>;
  /** The engine check an agent/v1 L2 regrade passes before it replays (the header's `isolation`; default sandboxIsolation(sandbox), null: none). */
  isolation?: IsolationCheck | null;
  /** A scrape/v1 heat's parts (the header's `scrape/v1`): its lease, drand, gateway, launcher, pacing; tests replace the heat's own. */
  scrape?: ScrapeWorkerDeps;
  /**
   * The sandbox a code-fastest timing reads CPU time on (the header's `code heat`): its openCpuClock is opened once for
   * the process (processCpuClock) and every timed run goes to the timed sandbox it hands back. Default: `sandbox` when it
   * is the docker or the k8s driver (timingSandboxOf); null, none (the process driver reads no CPU time): a dev grade is
   * recorded untimed and a heat is refused. A test hands in one whose clock it drives.
   */
  timingSandbox?: TimingSandbox | null;
  /**
   * The masq broker a fresh grade of an entry under a build meter syncs its entrant's build keys through first (the
   * header's `metered`: server/metering/sync.ts syncEntrantKeys reads its request pages): the pipeline hands in the one
   * its metering job runs on (server/pipeline/index.ts startWorkers). Default: the environment's (server/config.ts
   * loadConfig: MAKEFUN_LLM_GATEWAY=masq with MAKEFUN_LLM_GATEWAY_URL and MAKEFUN_LLM_GATEWAY_ADMIN_KEY, masq.ts
   * masqBrokerFromConfig), made when first needed. Null, or MAKEFUN_LLM_GATEWAY off: none, and a fresh grade of an
   * entrant holding a key still to sync fails as a retryable Error. A regrade never calls it.
   */
  meter?: Pick<MasqBuildKeyBroker, 'requests'> | null;
  /** A judged final's heat (the header's `judge heat`): where its calls go. */
  judge?: JudgeWorkerDeps;
  /**
   * How a grade, a regrade and a code heat open an entrant's env-lane entry secrets (the header's `entry secrets`): the
   * grader's seal settings, whose private keys open them (default the environment's, entrySecretSealSettings of
   * loadConfig(), read when an entrant's secrets are first opened).
   */
  entrySecrets?: Pick<AgentEntrySecretDeps, 'seal'>;
}

/** Where a judge heat's calls go (GradeWorkerDeps.judge; the header's `judge heat`). */
export interface JudgeWorkerDeps {
  /**
   * The broker each attempt of a heat mints its judge key at, and retires it at (grader/judge-call.ts openJudgeHeat).
   * Default: the environment's, made when first needed from one loadConfig(): server/superbot-router.ts judgeKeyBroker over
   * masq's (masq.ts masqBrokerFromConfig, as GradeWorkerDeps.meter's) and, with MAKEFUN_SUPERBOT_ROUTER_URL and
   * MAKEFUN_SUPERBOT_ROUTER_KEY set, superbot-router's (routerJudgeBroker), which mints for the models it serves (a judge
   * on superbot, superbot-fast, superbot-flash or a DeepSeek-V4.1-Flash id then dials the router directly; every other
   * judge, Claude's included, stays on masq) and retires a router key id as the router's. Null, or MAKEFUN_LLM_GATEWAY off
   * with the router pair unset: none, and a heat due fails as a PermanentJobError.
   */
  broker?: MasqJudgeKeyBroker | null;
  /** The fetch the judge's calls go out on (default globalThis.fetch). */
  fetch?: typeof fetch;
  /** One call's bound, ms (default grader/judge-call.ts's). */
  timeoutMs?: number;
  /** The most of a heat's planned calls in flight at once (default JUDGE_HEAT_CONCURRENCY; 1 sends them one at a time). */
  concurrency?: number;
  /**
   * The rule a heat's calls still out near a batch's end are backed up by (the header's `judge heat`;
   * grader/judge-backup.ts): undefined, the house's JUDGE_BACKUP; null, none (each call sent once, as before backups).
   */
  backup?: JudgeBackupRule | null;
  /** The clock a heat's sends are aged and stamped by, and its backup wake sleeps on (default Date.now and a timer). */
  clock?: JudgeHeatClock;
  /**
   * The models this process has seen answer a forced form (sendJudgeHeatCalls: a heat's first call then goes out with
   * the rest). Default: with the environment's broker, a memo of the process's (6 h); with an injected broker, none.
   */
  formsSeen?: JudgeFormsSeen;
  /**
   * The platform's one budget of judge sends in flight that a heat takes a seat in while it sends (the header's `judge
   * heat`; openJudgePoolSeat): its seats' directory (default judgePoolDir, under the blob store) and its size (default
   * JUDGE_POOL_BUDGET). Undefined: a seat only on the environment's broker (as `formsSeen`'s default; an injected broker
   * takes none); null: none, each heat bounded by its width alone, as before the pool.
   */
  pool?: { dir?: string; budget?: number } | null;
}

/** The HKDF label of the final phase's fail key. */
export const FAIL_KEY_LABEL = 'agent-fun/fail-key';

/**
 * The final phase's fail key (u64 decimal): the first 8 bytes, big-endian, of
 * HKDF-SHA256(ikm = the server secret, salt = empty, info = "agent-fun/fail-key" 0x00 <phase seed>).
 * Without the secret nothing (hello.seed included) predicts it.
 */
export function secretFailKey(secret: string, seed: string): string {
  if (secret.length === 0) throw new RangeError('the fail-key secret is empty');
  parseU64(seed, 'seed');
  const okm = Buffer.from(hkdfSync('sha256', secret, Buffer.alloc(0), `${FAIL_KEY_LABEL}\0${seed}`, 8));
  return okm.readBigUInt64BE(0).toString();
}

/**
 * The fail key of a server-secret/v1 phase (phaseFailKey picks the scheme): public on `dev` (publicFailKey of its seed,
 * what a kit reproduces), secret on any other (`final`).
 */
export function failKeyFor(phaseKey: string, seed: string, secret: string): string {
  return phaseKey === 'dev' ? publicFailKey(seed) : secretFailKey(secret, seed);
}

/** The fail-key secret when the deps name none (see GradeWorkerDeps.failKeySecret). */
async function defaultFailKeySecret(): Promise<string> {
  const env = (process.env.BETTER_AUTH_SECRET ?? '').trim();
  if (env !== '') return env;
  return (await import('../server/auth.ts')).DEV_AUTH_SECRET;
}

/** The environment's masq broker for a metered grade's sync (GradeWorkerDeps.meter's default), once made; undefined until then. */
let environmentMeter: Pick<MasqBuildKeyBroker, 'requests'> | null | undefined;

/** The broker a fresh metered grade syncs through (GradeWorkerDeps.meter, else the environment's, made once); null: none. */
async function meterOf(deps: Pick<GradeWorkerDeps, 'meter'>): Promise<Pick<MasqBuildKeyBroker, 'requests'> | null> {
  if (deps.meter !== undefined) return deps.meter;
  if (environmentMeter === undefined) {
    const { masqBrokerFromConfig } = await import('./gateway/masq.ts');
    environmentMeter = masqBrokerFromConfig(loadConfig());
  }
  return environmentMeter;
}

/**
 * The entry's cost (entry-cost.ts entryCostOf, under its bundle). `fresh` is a grade's, not a regrade's: under a build
 * meter it first syncs every build key the entrant holds in the competition through the submission's created_at (the
 * header's `metered`), so every request the cost counts is stored, and keeps the list of those it counted; a regrade
 * (`stored`: the stored run's result) prices from exactly the stored rows its list names, and never calls masq. A
 * broker fault on the sync, or no broker while a key is still to sync, is the platform's, never the entry's: a
 * retryable Error (its cause the broker's), thrown before anything is graded or recorded. A regrade whose list or a row
 * it names is gone is a PermanentJobError.
 */
async function entryCostFor(
  deps: Pick<GradeWorkerDeps, 'db' | 'blobs' | 'meter'>,
  input: { sub: typeof submission.$inferSelect; bundle: CompetitionBundleT; fresh: boolean; stored?: unknown; signal?: AbortSignal },
): Promise<EntryCost> {
  const { sub, bundle } = input;
  if (bundle.build_meter !== undefined && input.fresh) {
    const { syncEntrantKeys } = await import('../server/metering/sync.ts');
    const { MasqBrokerError } = await import('./gateway/masq.ts');
    const what = `submission ${sub.id}'s metered requests (its entrant's build keys in competition ${sub.competitionId}, through ${sub.createdAt.toISOString()})`;
    const broker = await meterOf(deps);
    const meter: Pick<MasqBuildKeyBroker, 'requests'> = broker ?? {
      requests: async () => {
        throw new Error(`${what} cannot be synced: this process has no masq to read them from (MAKEFUN_LLM_GATEWAY=masq with its URL and admin key); the grade waits for one, never the entry's fault`);
      },
    };
    try {
      await syncEntrantKeys(deps.db, meter, { competitionId: sub.competitionId, userId: sub.userId, through: sub.createdAt, ...(input.signal === undefined ? {} : { signal: input.signal }) });
    } catch (err) {
      if (err instanceof MasqBrokerError) throw new Error(`${what} could not be synced from masq (${err.message}): the platform's fault, never the entry's; the job retries`, { cause: err });
      throw err;
    }
  }
  const counted = input.fresh ? undefined : storedMeteredCost(input.stored);
  try {
    return await entryCostOf(deps.db, sub, bundle, { blobs: deps.blobs, ...(counted === undefined ? {} : { counted }) });
  } catch (err) {
    if (err instanceof MeteredCountError) throw new PermanentJobError(err.message, { cause: err });
    throw err;
  }
}

/** How far past masq's settle (the receipt plus CAP_GUARD_LOOKBACK_MS) a metered final grade waiting on it is sent again for: a grader clock behind the queue's still finds it settled. */
export const METERED_SETTLE_SLACK_MS = 60_000;

/** The grade job a metered final grade job `gradeJobId` sends itself again as while masq settles (the header's `metered`): one per job, so a retried attempt sends it once. */
export function meteredSettleJobId(gradeJobId: string): string {
  return sha256Uuid(`grade-metered-settle\0${gradeJobId.toLowerCase()}`);
}

/**
 * Whether a fresh final grade of `sub` under a build meter waits for masq to settle (the header's `metered`): before the
 * receipt plus CAP_GUARD_LOOKBACK_MS by deps.now, the grade job is sent again on its own queue for that instant plus
 * METERED_SETTLE_SLACK_MS at the priority it was sent at, so it keeps its place (meteredSettleJobId of the job; a uuid
 * of its own with no job context), `handedOn` told once
 * it is sent (the pipeline then sends nothing after this job), and the instant answered; settled, null. With no queue
 * to send it on, a retryable Error.
 */
async function meteredSettleWait(
  deps: Pick<GradeWorkerDeps, 'jobs' | 'now' | 'log'>,
  input: { sub: typeof submission.$inferSelect; ph: typeof phase.$inferSelect; job: JobPayload<'grade-dev'>; ctx: GradeJobContext | undefined; handedOn: (() => void) | undefined },
): Promise<Date | null> {
  const { sub, ph, job, ctx } = input;
  const { CAP_GUARD_LOOKBACK_MS } = await import('../server/metering/sync.ts');
  const settled = new Date(sub.createdAt.getTime() + CAP_GUARD_LOOKBACK_MS);
  const now = (deps.now ?? (() => new Date()))();
  if (now.getTime() >= settled.getTime()) return null;
  const what = `submission ${sub.id}'s ${ph.key} grade prices its metered build cost once masq has had ${CAP_GUARD_LOOKBACK_MS / 60_000} minutes past its receipt (${sub.createdAt.toISOString()}) to record every request it counts, at ${settled.toISOString()}`;
  if (deps.jobs === undefined) throw new Error(`${what}, and this process has no queue to send the grade on for then: the job retries`);
  const queue = ctx?.queue === 'grade-dev' || ctx?.queue === 'grade-final' ? ctx.queue : gradeQueue(ph.key);
  const id = meteredSettleJobId(ctx?.id ?? uuidv7());
  const startAfter = new Date(settled.getTime() + METERED_SETTLE_SLACK_MS);
  await deps.jobs.send(queue, job, { id, startAfter, ...(ctx?.priority === undefined ? {} : { priority: ctx.priority }) });
  // Nothing graded: whatever follows a grade follows the job sent again, never this one.
  input.handedOn?.();
  (deps.log ?? ((line: string) => console.log(line)))(`[grade] ${what}: sent again on ${queue} for ${startAfter.toISOString()} (job ${id}); nothing is graded now`);
  return settled;
}

// ---------------------------------------------------------------- the fail key's scheme

/** The largest draw.json a committed fail key reads its signature from (makeDrawRecord's spelling is under 2 KB). */
export const MAX_SEALED_DRAW_BYTES = 65_536;

/** How long a fail key that cannot be derived goes unpaged again, per phase and reason, in one process (failKeyPager). */
export const FAIL_KEY_PAGE_MS = 60 * 60_000;

/**
 * Why a phase's fail key cannot be derived now (phaseFailKey; the header's `fail key`): a phase-secret+beacon/v1 phase
 * with no fail-key secret, no draw record that verifies, or one its deadline commitment does not name (and a scheme this
 * grader does not know). A retryable Error, never a PermanentJobError: an admin can mend each (the window drawn,
 * MAKEFUN_SEALED_DIR pointed where the draw wrote it), the job retries until then, and nothing derives the key from the
 * server secret meanwhile. `fix` names the mend, in the page's words.
 */
export class FailKeyUnavailableError extends Error {
  readonly phaseId: string;
  readonly fix: string;

  constructor(phaseId: string, message: string, fix: string, options?: { cause?: unknown }) {
    super(message, options);
    this.name = 'FailKeyUnavailableError';
    this.phaseId = phaseId;
    this.fix = fix;
  }
}

/** What phaseFailKey reads of a phase row. */
export type FailKeyPhase = Pick<typeof phase.$inferSelect, 'id' | 'key' | 'failKeyScheme' | 'failKeySecret' | 'deadlineCommitment' | 'deadlineCommitmentSha256'>;

export interface PhaseFailKeyInput {
  phase: FailKeyPhase;
  /** The competition's slug: its draw record's and its deadline commitment's. */
  slug: string;
  /** The seed the run is graded under (the phase seed; a regrade's, its stored run's). */
  seed: string;
  /** The phase's dataset row digest, the seed's dataset part: on phase-secret+beacon/v1 the drawn masked window must be it. */
  datasetSha256: string;
  /** The competition's directory, holding its sealed-window.yaml (GradeWorkerDeps.competitionDir's). */
  compDir: string;
  /** MAKEFUN_SEALED_DIR: the draw record is <sealedDir>/<slug>/draw.json. */
  sealedDir: string;
  /** The sealed-window module's explicit test option (instanceChainOptions of the deps' drandChain). */
  chain: SealedWindowChainOptions;
  /** The server secret (GradeWorkerDeps.failKeySecret, else defaultFailKeySecret): asked for on server-secret/v1 alone. */
  serverSecret: () => string | Promise<string>;
}

/**
 * The fail key of a phase's run (u64 decimal), by the phase's scheme (phase.fail_key_scheme; the header's `fail key`):
 *   server-secret/v1        failKeyFor of the server secret, byte for byte as before the schemes
 *   phase-secret+beacon/v1  committedFailKey(phase.fail_key_secret, seed, the drand signature of the sealed window's
 *                           beacon round): the signature the draw record's (<sealedDir>/<slug>/draw.json), verified
 *                           against <compDir>/sealed-window.yaml (verifyDrawRecord), and taken only while the phase's
 *                           deadline commitment holds it: the document hashes to its stored sha256, is this
 *                           competition's sealed pool, fixed the secret's sha256, and names the sidecar the draw was
 *                           made for, its round and its chain; the drawn masked window is `datasetSha256`. The server
 *                           secret is never asked for.
 * Throws FailKeyUnavailableError (retryable) when the committed key cannot be derived, and on a scheme it does not know.
 */
export async function phaseFailKey(input: PhaseFailKeyInput): Promise<string> {
  const scheme: string = input.phase.failKeyScheme;
  if (scheme === SERVER_SECRET_FAIL_KEY_SCHEME) return failKeyFor(input.phase.key, input.seed, await input.serverSecret());
  if (scheme === COMMITTED_FAIL_KEY_SCHEME) return committedPhaseFailKey(input);
  throw new FailKeyUnavailableError(
    input.phase.id,
    `the ${input.phase.key} phase of ${input.slug} names fail-key scheme ${JSON.stringify(scheme)}, which this grader does not know`,
    `grade it with a grader that knows the scheme; no other scheme stands in for it`,
  );
}

/** phaseFailKey on phase-secret+beacon/v1 (see there): every refusal a FailKeyUnavailableError. */
function committedPhaseFailKey(input: PhaseFailKeyInput): string {
  const { phase: ph, slug } = input;
  const decide = `an admin decides how ${slug}'s ${ph.key} phase is graded: no fail key of it is derived from the server secret`;
  const unavailable = (why: string, fix: string, cause?: unknown) =>
    new FailKeyUnavailableError(ph.id, `the ${ph.key} phase of ${slug} keys its failed-tx draws by ${COMMITTED_FAIL_KEY_SCHEME}, and ${why}`, fix, cause === undefined ? undefined : { cause });
  const secret = ph.failKeySecret;
  if (secret === null) throw unavailable('it holds no fail-key secret', `the deadline commitment writes the secret with its document; ${decide}`);
  if (ph.key !== 'final') throw unavailable('it is no final phase: only the final phase is committed at its deadline', decide);

  // The commitment as stored: whole, this competition's sealed pool, and the secret the one whose sha256 it fixed.
  const sha = ph.deadlineCommitmentSha256;
  if (sha === null || !verifyDeadlineCommitment(ph.deadlineCommitment, sha)) throw unavailable(`its deadline commitment is not a commitment document hashing to its sha256 ${sha ?? '(none)'}`, decide);
  const doc = DeadlineCommitment.parse(ph.deadlineCommitment);
  if (doc.slug !== slug) throw unavailable(`its deadline commitment is competition ${doc.slug}'s`, decide);
  let secretSha256: string | null = null;
  try {
    secretSha256 = failKeySecretSha256(secret);
  } catch {
    // Not 32 bytes of hex (the column's check says it is): it matches nothing.
  }
  if (secretSha256 !== doc.fail_key.secret_sha256) throw unavailable(`its fail-key secret does not hash to the secret_sha256 ${doc.fail_key.secret_sha256} its deadline commitment fixed`, decide);
  const committed = doc.window;
  if (committed.kind !== 'sealed_pool') {
    throw unavailable(`its deadline commitment names a ${committed.kind} window, whose round ${doc.fail_key.round} no draw record signs: this grader takes the round's signature from a sealed window's draw alone`, decide);
  }

  // The draw: draw.json under the sealed directory, verified against the sidecar, and the one the commitment names.
  const drawFix = `draw the window once round ${doc.fail_key.round} is emitted (POST /api/admin/competitions/${slug}/sealed-window/draw), and grade with MAKEFUN_SEALED_DIR where the draw wrote ${DRAW_FILE}`;
  const sidecarPath = join(input.compDir, SEALED_WINDOW_FILE);
  const sidecar = sealedFileOf(sidecarPath, MAX_SEALED_WINDOW_BYTES);
  if ('why' in sidecar) throw unavailable(`its ${SEALED_WINDOW_FILE} ${sidecarPath} ${sidecar.why}`, `grade where competitions/${slug}/${SEALED_WINDOW_FILE} is the committed sidecar (sha256 ${committed.sidecar_sha256})`);
  const drawPath = join(input.sealedDir, slug, DRAW_FILE);
  const drawn = sealedFileOf(drawPath, MAX_SEALED_DRAW_BYTES);
  if ('why' in drawn) throw unavailable(`its draw record ${drawPath} ${drawn.why}`, drawFix);
  let raw: unknown;
  try {
    raw = JSON.parse(drawn.bytes.toString('utf8'));
  } catch (err) {
    throw unavailable(`its draw record ${drawPath} is not JSON`, decide, err);
  }
  let draw;
  try {
    draw = verifyDrawRecord({ sidecar: sidecar.bytes, record: raw, competition: slug, ...input.chain });
  } catch (err) {
    if (isSealedWindowError(err)) throw unavailable(`its draw record ${drawPath} does not verify against ${sidecarPath} (${err.code}): ${err.message}`, decide, err);
    throw err;
  }
  const beacon = DrawRecord.parse(raw).beacon;
  if (draw.sidecarSha256 !== committed.sidecar_sha256) {
    throw unavailable(`its draw record was made for the ${SEALED_WINDOW_FILE} of sha256 ${draw.sidecarSha256}, not the ${committed.sidecar_sha256} its deadline commitment fixed`, decide);
  }
  if (draw.round !== doc.fail_key.round || beacon.chain !== doc.fail_key.chain) {
    throw unavailable(`its draw record signs drand round ${draw.round} on chain ${beacon.chain}, not the round ${doc.fail_key.round} on chain ${doc.fail_key.chain} its deadline commitment's fail key mixes in`, decide);
  }
  if (draw.opening.masked_dataset_sha256 !== input.datasetSha256) {
    throw unavailable(
      `its draw opens the masked window ${draw.opening.masked_dataset_sha256}, but the phase's dataset is ${input.datasetSha256}: the seed and the key are of the window graded`,
      `attach the drawn window to the phase (the draw does: POST /api/admin/competitions/${slug}/sealed-window/draw); ${decide}`,
    );
  }
  return committedFailKey(secret, input.seed, draw.signature);
}

/** A regular file's bytes (never through a link), at most `max`; else why there are none, in words that follow its path. */
function sealedFileOf(path: string, max: number): { bytes: Buffer } | { why: string } {
  let st;
  try {
    st = lstatSync(path);
  } catch {
    return { why: 'is not there' };
  }
  if (!st.isFile()) return { why: 'is not a regular file' };
  if (st.size > max) return { why: `is ${st.size} bytes, over the ${max}-byte limit` };
  try {
    return { bytes: readFileSync(path) };
  } catch (err) {
    return { why: `cannot be read (${(err as Error).message})` };
  }
}

/**
 * A fail key derived through `derive` (phaseFailKey), a FailKeyUnavailableError paged as it goes by (the header's
 * `fail key`): at most once per FAIL_KEY_PAGE_MS per phase and reason in this process (logged in between), then thrown
 * on, so the job retries. `tag` opens each line ("[grade]", "[hindsight]"); `what` names the job's work.
 */
function failKeyPager(
  deps: { page?: (line: string) => void; log?: (line: string) => void; now?: () => Date },
  tag: string,
): (what: string, derive: () => Promise<string>) => Promise<string> {
  const page = deps.page ?? ((line: string) => console.error(line));
  const log = deps.log ?? ((line: string) => console.log(line));
  const now = deps.now ?? (() => new Date());
  /** When each phase's reason was last paged. */
  const paged = new Map<string, number>();
  return async (what, derive) => {
    try {
      return await derive();
    } catch (err) {
      if (!(err instanceof FailKeyUnavailableError)) throw err;
      const at = now().getTime();
      const key = `${err.phaseId}\0${err.message}`;
      const last = paged.get(key);
      if (last !== undefined && at - last < FAIL_KEY_PAGE_MS) {
        log(`${tag} ${what} waits on its fail key (paged at ${new Date(last).toISOString()}): ${err.message}`);
      } else {
        paged.set(key, at);
        page(`${tag} ALERT: ${what} waits on its fail key: ${err.message}. The job retries, and no fail key is derived from the server secret instead. Fix: ${err.fix}`);
      }
      throw err;
    }
  };
}

/**
 * The stored authorship summary of a submission (server/pipeline/ingest.ts writes it): the
 * authorship_summary row under `pricingRev` of algorithm `algoVersion` when one is named (a
 * regrade's), else the newest, validated; null when there is none.
 */
export async function loadStoredAuthorship(db: Db, submissionId: string, pricingRev: string, algoVersion?: number): Promise<AuthorshipSummaryT | null> {
  const [row] = await db
    .select({ summary: authorshipSummary.summary, algoVersion: authorshipSummary.algoVersion })
    .from(authorshipSummary)
    .where(
      and(
        eq(authorshipSummary.submissionId, submissionId),
        eq(authorshipSummary.pricingRev, pricingRev),
        ...(algoVersion === undefined ? [] : [eq(authorshipSummary.algoVersion, algoVersion)]),
      ),
    )
    .orderBy(desc(authorshipSummary.algoVersion))
    .limit(1);
  if (row === undefined) return null;
  const parsed = AuthorshipSummary.safeParse(row.summary);
  if (!parsed.success || parsed.data.algo_version !== row.algoVersion) {
    throw new PermanentJobError(`submission ${submissionId}'s stored authorship summary (algorithm ${row.algoVersion}) does not validate`);
  }
  return parsed.data;
}

/**
 * The authorship algorithm version a stored run's score names (score.authorship.algo_version): the
 * summary its regrade must be given again. Null when the run was graded with no summary; undefined
 * when its result carries no score to read one from (a failed run).
 */
export function storedAuthorshipVersion(result: unknown): number | null | undefined {
  if (result === null || typeof result !== 'object' || !('authorship' in result)) return undefined;
  const authorship = (result as { authorship: unknown }).authorship;
  if (authorship === null) return null;
  const version = (authorship as { algo_version?: unknown } | undefined)?.algo_version;
  return typeof version === 'number' && Number.isInteger(version) ? version : undefined;
}

/** The phase seed: the first 8 bytes of sha256("agent-fun/seed/v1\0<competition>\0<phase>\0<dataset sha256>"), as a u64 decimal. */
export function phaseSeed(competitionKey: string, phaseKey: string, datasetSha256: string | null): string {
  const h = createHash('sha256').update(`agent-fun/seed/v1\0${competitionKey}\0${phaseKey}\0${datasetSha256 ?? ''}`).digest('hex');
  return BigInt(`0x${h.slice(0, 16)}`).toString();
}

/** The competition key phaseSeed takes: competition.seed_key (pinned when the row was first seeded), else its bundle_sha256, else its slug. */
export function competitionSeedKey(comp: { seedKey: string | null; bundleSha256: string | null; slug: string }): string {
  return comp.seedKey ?? comp.bundleSha256 ?? comp.slug;
}

/**
 * Whether `phaseKey` is the phase a bundle races live (the header's `seed`): its ranking phase, carrying a race
 * (contracts/competition.ts raceOf), the phase server/race/runner.ts races.
 */
export function racesLive(bundle: Pick<CompetitionBundleT, 'phases'>, phaseKey: string): boolean {
  return raceOf(bundle) !== null && bundle.phases[rankingPhaseIndex(bundle.phases)]?.key === phaseKey;
}

/**
 * Whether a pump phase's official grade takes its race's seed (the header's `seed`): only when the phase races live
 * (racesLive) and keys its failed-tx draws by server-secret/v1, the scheme the race holds too (server/race/runner.ts
 * derives the same key from the same seed). On any other scheme (phase-secret+beacon/v1, a sealed-window final
 * committed at its deadline) the grade keeps its dataset part: the commitment holds every final run to
 * phaseSeed(seed key, final, the drawn masked window) (server/chain/verify.ts checkCommittedFailKey), so the race seed
 * there would be refused seed_mismatch.
 */
export function gradeTakesRaceSeed(bundle: Pick<CompetitionBundleT, 'phases'>, ph: Pick<FailKeyPhase, 'key' | 'failKeyScheme'>): boolean {
  return racesLive(bundle, ph.key) && ph.failKeyScheme === SERVER_SECRET_FAIL_KEY_SCHEME;
}

/** An error's words: the first line of its message, then of each cause's (a Drizzle query error's cause says why it failed). */
function errorWords(err: unknown): string {
  const words: string[] = [];
  for (let e: unknown = err, depth = 0; e !== undefined && e !== null && depth < 4; e = e instanceof Error ? e.cause : undefined, depth++) {
    words.push((e instanceof Error ? e.message : String(e)).split('\n')[0]!);
  }
  return words.join(': ');
}

/**
 * The crosscheck of the race on phase `phaseId` of `slug` as grade run `runId` lands on it (the header's
 * `crosscheck`): server/race/crosscheck.ts crosscheckRace over `deps.blobs`, its report. Never throws: a racer it could
 * not compare is logged (deps.log), and a crosscheck that fails is logged and answers null, every answer it stored
 * before the failure kept (each is final on its own), the rest left uncompared for the live snapshot's retry.
 * crosscheck.ts loads only here, on a racing phase, as raceSeed does.
 */
export async function crosscheckLandedGrade(deps: Pick<GradeWorkerDeps, 'db' | 'blobs' | 'log'>, landed: { slug: string; phaseId: string; runId: string }): Promise<CrosscheckReport | null> {
  const log = deps.log ?? ((line: string) => console.log(line));
  const what = `[grade] the crosscheck of ${landed.slug}'s race (phase ${landed.phaseId}) as run ${landed.runId} landed`;
  let report: CrosscheckReport;
  try {
    const { crosscheckRace } = await import('../server/race/crosscheck.ts');
    report = await crosscheckRace(deps.db, deps.blobs, landed.phaseId);
  } catch (err) {
    log(`${what} failed, its racers left uncompared for the live snapshot to try again: ${errorWords(err)}`);
    return null;
  }
  if (report.problems.length > 0) {
    log(`${what} left ${report.problems.length} racer(s) uncompared, for the live snapshot to try again: ${report.problems.map((p) => `${p.submission_id} (run ${p.run_id}): ${p.problem}`).join('; ')}`);
  }
  return report;
}

/** The runtime a snapshot's root entrypoint selects, or why it selects none. */
export function entryRuntime(index: SnapshotIndex, accepted: readonly Runtime[]): { runtime: Runtime } | { error: string } {
  const roots = new Set(index.files.filter((f) => f.kind === 'file').map((f) => f.path));
  const found = (Object.entries(ENTRY_SCRIPTS) as [Runtime, string][]).filter(([, script]) => roots.has(script)).map(([r]) => r);
  if (found.length === 0) return { error: `the snapshot has no ${Object.values(ENTRY_SCRIPTS).join(' or ')} at its root` };
  if (found.length > 1) return { error: `the snapshot has both ${found.map((r) => ENTRY_SCRIPTS[r]).join(' and ')} at its root: keep one entrypoint` };
  const runtime = found[0]!;
  if (!accepted.includes(runtime)) return { error: `${ENTRY_SCRIPTS[runtime]} selects ${runtime}, which this competition does not accept (${accepted.join(', ')})` };
  return { runtime };
}

async function one<T>(rows: Promise<T[]>, what: string): Promise<T> {
  const [row] = await rows;
  if (row === undefined) throw new PermanentJobError(`${what} does not exist`);
  return row;
}

/** The latest receipt server_time among a competition's submissions (ISO), or null. */
export async function lastReceiptAt(db: Db, competitionId: string): Promise<string | null> {
  const [row] = await db
    .select({ at: sql<string | null>`max((${submission.receipt}->>'server_time')::timestamptz)` })
    .from(submission)
    .where(and(eq(submission.competitionId, competitionId), isNotNull(submission.receipt)));
  const at = row?.at ?? null;
  return at === null ? null : new Date(at).toISOString();
}

// ---------------------------------------------------------------- drawn instances

/** The largest instance-draw-<k>.json read (formatInstanceDraw's spelling is under 2 KB). */
export const MAX_INSTANCE_DRAW_BYTES = 65_536;

/** The instance a phase of an instance-drawn bundle grades on (phaseInstance). */
export interface PhaseInstance {
  /** practice on the dev phase, scored on the final. */
  purpose: 'practice' | 'scored';
  /** The scored draw in force (the newest record's k); null for practice. */
  k: number | null;
  /** The instance directory, holding input/ and reference/. */
  dir: string;
  /** <dir>/input: ProgramSetup.inputDir (the entry's /input). */
  inputDir: string;
  /** <dir>/reference: ProgramSetup.referenceDir (the scorer's /reference). */
  referenceDir: string;
  /** The draw record's instance_sha256, which programDataSha256 of the two directories must equal; null for practice (the sidecar holds tree digests only). */
  instanceSha256: string | null;
}

/** The test option an instance sidecar is read under: `chain` (default MAKEFUN_DRAND_CHAIN under dev auth, from the environment) when it is not quicknet. */
export function instanceChainOptions(chain?: DrandChain, env: Readonly<Record<string, string | undefined>> = process.env): InstanceChainOptions {
  let c = chain;
  if (c === undefined) {
    try {
      const devAuth = ['1', 'true'].includes((env.MAKEFUN_DEV_AUTH ?? '').toLowerCase()) && isDevAuthNodeEnv(env.NODE_ENV);
      c = drandChainFromEnv(env, { devAuth });
    } catch {
      // server/config.ts refuses it at boot: quicknet alone
      c = DRAND_QUICKNET;
    }
  }
  return c.hash === DRAND_QUICKNET.hash ? {} : { testChain: c };
}

/** A regular file's bytes (never through a link), at most `max`; null when there is none. Anything else is a PermanentJobError naming `what`. */
function readSmallFile(path: string, max: number, what: string): Buffer | null {
  let st;
  try {
    st = lstatSync(path);
  } catch {
    return null;
  }
  if (!st.isFile()) throw new PermanentJobError(`${what} ${path} is not a regular file`);
  if (st.size > max) throw new PermanentJobError(`${what} ${path} is ${st.size} bytes, over the ${max}-byte limit`);
  return readFileSync(path);
}

/**
 * A phase's instance not drawn yet (the header's `not drawn`): what phaseInstance or agentPhaseTrials reads is not there
 * at all (the competition's instance.yaml, the scored draw's first record, or an instance tree checkInstanceTrees
 * reads), which the draw mends and the entry never caused. A PlatformFaultError, so a caller that knows nothing of it
 * dead-letters the job and never fails the entry; the pipeline's grade stage puts the entry back and hands its grade
 * job on until the draw lands (server/pipeline/index.ts).
 */
export class InstanceNotDrawnError extends PlatformFaultError {
  /** What is not there: the instance.yaml, the instance-draw-0.json or the tree directory. */
  readonly path: string;
  constructor(message: string, path: string) {
    super(message);
    this.name = 'InstanceNotDrawnError';
    this.path = path;
  }
}

/** Whether nothing is at `path` (not even a link). */
function isAbsent(path: string): boolean {
  try {
    lstatSync(path);
    return false;
  } catch (err) {
    return (err as NodeJS.ErrnoException).code === 'ENOENT';
  }
}

/**
 * The error of a competition's instance.yaml that readSmallFile found none of at `path`: not there at all, an
 * InstanceNotDrawnError (the practice draw writes it); there but not to be read, a PermanentJobError.
 */
function sidecarNotThere(path: string, message: string): PermanentJobError {
  return isAbsent(path) ? new InstanceNotDrawnError(message, path) : new PermanentJobError(message);
}

/**
 * An instance directory's input/ and reference/ against their tree digests (load.ts treeSha256), or a PermanentJobError
 * naming `what` and `fix`: an InstanceNotDrawnError when the tree is not there at all.
 */
function checkInstanceTrees(dir: string, expected: Record<(typeof INSTANCE_TREES)[number], string>, what: string, fix: string): void {
  for (const tree of INSTANCE_TREES) {
    const at = join(dir, tree);
    let actual: string;
    try {
      actual = treeSha256(at);
    } catch (err) {
      if (!(err instanceof TreeDigestError)) throw err;
      const why = err.rel === '' ? err.reason : `holds ${err.rel}, which ${err.reason}`;
      const message = `${what}'s ${tree} directory ${at} ${why}: ${fix}`;
      if (err.rel === '' && isAbsent(at)) throw new InstanceNotDrawnError(message, at);
      throw new PermanentJobError(message);
    }
    if (actual !== expected[tree]) throw new PermanentJobError(`${what}'s ${tree} directory ${at} digests to ${actual}, not ${expected[tree]}: ${fix}`);
  }
}

/**
 * Every draw record under a competition's instance directory `root`, instance-draw-0.json to the
 * newest, each parsed as JSON, none missing; the empty list when there is none (`root` not there at
 * all included: nothing is drawn yet). Throws PermanentJobError: a `root` that cannot be read, a record
 * missing from the chain, not a regular file, too large or not JSON.
 */
function readDrawRecords(root: string, slug: string): unknown[] {
  let names: string[];
  try {
    names = readdirSync(root);
  } catch (err) {
    if ((err as NodeJS.ErrnoException).code !== 'ENOENT') throw new PermanentJobError(`${slug}'s instance directory ${root} cannot be read for its draw records: ${(err as Error).message}`);
    names = [];
  }
  const ks = names
    .map((n) => instanceDrawK(n))
    .filter((k): k is number => k !== null)
    .sort((a, b) => a - b);
  if (ks.length === 0) return [];
  const newest = ks[ks.length - 1]!;
  const records: unknown[] = [];
  for (let k = 0; k <= newest; k++) {
    const path = join(root, instanceDrawFile(k));
    const raw = readSmallFile(path, MAX_INSTANCE_DRAW_BYTES, `${slug}'s draw record`);
    if (raw === null) throw new PermanentJobError(`${slug}'s draw records run k = 0 to ${newest} with none missing, and ${path} is not there`);
    try {
      records.push(JSON.parse(raw.toString('utf8')));
    } catch (err) {
      throw new PermanentJobError(`${slug}'s draw record ${path} is not JSON: ${(err as Error).message}`);
    }
  }
  return records;
}

/**
 * The instance an instance-drawn bundle's phase grades on (the header's `instance`): the competition
 * directory's instance.yaml read under `chain` (parseInstanceSidecar) and checked against `bundle`
 * (checkInstanceBundle); the dev phase's the practice instance (load.ts practiceInstanceDir), its trees
 * the sidecar's practice digests; any other phase's (the final's) the newest scored draw, every
 * instance-draw-<k>.json from k = 0 verified as one chain (verifyInstanceDraws: the sidecar's sha256,
 * the scored round's signature, the seed, the redraw links), and scored-<k>/'s trees the newest
 * record's digests. Throws PermanentJobError: no retry can draw an instance or mend one. What is not there at all (no
 * instance.yaml, no draw record yet, a tree) is an InstanceNotDrawnError: the draw mends it.
 */
export function phaseInstance(input: { slug: string; bundle: CompetitionBundleT; compDir: string; sealedDir: string; phaseKey: string; chain: InstanceChainOptions }): PhaseInstance {
  const { slug, bundle } = input;
  const h = bundle.harness;
  if (h.kind !== 'program/v1' || h.generator === undefined) throw new PermanentJobError(`${slug} is not an instance-drawn program/v1 competition`);
  const sidecarPath = join(input.compDir, INSTANCE_FILE);
  const practiceFix = `draw it with node scripts/competitions/instance.ts practice --competition ${slug} (it re-draws a committed ${INSTANCE_FILE}'s practice instance into a removed practice/)`;
  const bytes = readSmallFile(sidecarPath, MAX_INSTANCE_BYTES, `${slug}'s ${INSTANCE_FILE}`);
  if (bytes === null) throw sidecarNotThere(sidecarPath, `${slug} is instance-drawn, and its competition directory has no ${INSTANCE_FILE} (${sidecarPath}) to say which instances it grades on: ${practiceFix}`);
  const final = bundle.phases.find((p) => p.key === 'final');
  let sidecar;
  try {
    sidecar = parseInstanceSidecar(bytes, input.chain);
    if (final === undefined) throw new PermanentJobError(`${slug} is instance-drawn and has no final phase to draw its scored instance for`);
    checkInstanceBundle(sidecar, { generatorSha256: h.generator_sha256, opensAt: bundle.competition.opens_at, finalStartsAt: final.starts_at, finalEndsAt: final.ends_at }, input.chain);
  } catch (err) {
    if (isInstanceError(err)) throw new PermanentJobError(`${slug}'s ${INSTANCE_FILE} does not check (${err.code}): ${err.message}`, { cause: err });
    throw err;
  }

  if (input.phaseKey === 'dev') {
    const dir = practiceInstanceDir(input.sealedDir, slug);
    checkInstanceTrees(dir, { input: sidecar.practice.input_sha256, reference: sidecar.practice.reference_sha256 }, `${slug}'s practice instance`, practiceFix);
    return { purpose: 'practice', k: null, dir, inputDir: join(dir, 'input'), referenceDir: join(dir, 'reference'), instanceSha256: null };
  }

  const root = instanceRootOf(input.sealedDir, slug);
  const records = readDrawRecords(root, slug);
  if (records.length === 0) {
    throw new InstanceNotDrawnError(
      `the ${input.phaseKey} phase of ${slug} grades on its drawn scored instance, and there is no draw record (${instanceDrawFile(0)}) in ${root}: the final phase is graded once the scored round (${sidecar.scored.beacon.round}, ${sidecar.scored.beacon.at}) is drawn (POST /api/admin/competitions/${slug}/instance/draw)`,
      join(root, instanceDrawFile(0)),
    );
  }
  let draw;
  try {
    draw = verifyInstanceDraws({ sidecar: bytes, records, competition: slug, ...input.chain }).at(-1)!;
  } catch (err) {
    if (isInstanceError(err)) throw new PermanentJobError(`${slug}'s draw records do not verify (${err.code}): ${err.message}`, { cause: err });
    throw err;
  }
  const dir = scoredInstanceDir(input.sealedDir, slug, draw.k);
  checkInstanceTrees(dir, { input: draw.record.input_sha256, reference: draw.record.reference_sha256 }, `${slug}'s scored instance ${draw.k}`, `it is not the instance ${instanceDrawFile(draw.k)} records; the final phase grades only on the draw as recorded`);
  return { purpose: 'scored', k: draw.k, dir, inputDir: join(dir, 'input'), referenceDir: join(dir, 'reference'), instanceSha256: draw.record.instance_sha256 };
}

/**
 * The directory a competition's programs are read from: GradeWorkerDeps.competitionDir's, else
 * competitions/<slug>, or for a pack program/v1 harness server/competitions/load.ts programCompetitionDir's
 * (the header's `pack`: the house tests competition's for a sponsored code bounty; likewise its medium's pilot's for a
 * sponsored judged-artifact competition, whose own trees judgedTreesOf finds).
 */
export function competitionDirOf(deps: Pick<GradeWorkerDeps, 'competitionDir'>, slug: string, harness: HarnessT): string {
  return deps.competitionDir?.(slug) ?? programCompetitionDir(slug, harness, COMPETITIONS_DIR);
}

/**
 * A competition's starter as its kit hands it out (the header's `size`): every file the kit route copies under
 * starter/ (server/routes/competitions/kit.ts starterFiles: <competitionsDir>/<slug>/starter/, dot entries,
 * node_modules and __pycache__ left out), each read and hashed as kit.json lists it, its path relative to starter/
 * (grader/size.ts kitStarterFiles), so the server counts an entry's code against exactly the files an entrant was
 * handed. [] for a competition with no starter (a sponsored code bounty has no directory of its own, and its kit no
 * starter/).
 */
export async function competitionStarter(competitionsDir: string, slug: string): Promise<StarterFile[]> {
  // Loaded when used: the kit route is a large module, needed by a size count's grade alone.
  const { starterFiles } = await import('../server/routes/competitions/kit.ts');
  return kitStarterFiles(
    starterFiles(competitionsDir, slug).map(([path, abs]) => {
      const bytes = readFileSync(abs);
      return { path, size: bytes.length, sha256: sha256Hex(bytes) };
    }),
  );
}

/** The pack trees a phase of a pack bundle grades on (phasePackTrees). */
export interface PhasePackTrees {
  /** The pack's half the phase grades on: dev on the dev phase, final on any other. */
  half: 'dev' | 'final';
  /** The materialized input tree: ProgramSetup.inputDir (the entry's /input, one case at a time under cases 'per-file'). */
  inputDir: string;
  /** The materialized reference tree: ProgramSetup.referenceDir (the scorer's /reference). */
  referenceDir: string;
}

/**
 * The trees a pack bundle's phase grades on (the header's `pack`): its scorer directory under `compDir`
 * re-hashed against scorer_sha256 (load.ts packScorerIssue), then the phase's input and reference trees
 * (pack.dev on the dev phase, pack.final on the final) materialized from `blobs` into
 * <workRoot>/pack-trees/ and re-hashed (load.ts packTreeDir; a tree the store lacks is taken from a pack/
 * copy beside `compDir`'s competition.yaml, once it re-hashes). Throws PermanentJobError: no retry mends
 * a scorer that is not the sealed one or a tree the house does not hold.
 */
export async function phasePackTrees(input: { slug: string; harness: ProgramHarnessT; compDir: string; phaseKey: string; blobs: BlobStore; workRoot: string }): Promise<PhasePackTrees> {
  const { slug, harness: h } = input;
  if (h.pack === undefined) throw new PermanentJobError(`${slug} is not a pack program/v1 competition`);
  const scorer = packScorerIssue(h, input.compDir);
  if (scorer !== null) throw new PermanentJobError(`${slug} grades with the scorer its harness seals (scorer_sha256 ${h.scorer_sha256 ?? 'none'}), and ${scorer}`);
  const half = input.phaseKey === 'dev' ? 'dev' : 'final';
  const dirOf = async (tree: PackTreeName): Promise<string> => {
    const digest = packTreeDigest(h.pack!, tree);
    try {
      return await packTreeDir({ blobs: input.blobs, digest, cacheRoot: join(input.workRoot, PACK_CACHE_DIR), sources: packTreeSources([input.compDir], tree) });
    } catch (err) {
      if (err instanceof Error && err.name === 'PackError') {
        throw new PermanentJobError(`the ${input.phaseKey} phase of ${slug} grades on its pack's ${tree} tree ${digest}, which cannot be materialized: ${err.message}`, { cause: err });
      }
      throw err;
    }
  };
  return { half, inputDir: await dirOf(`${half}/input`), referenceDir: await dirOf(`${half}/reference`) };
}

/**
 * A program/v1 phase's plan as its grades build it: an instance-drawn bundle's on the phase's instance (the header's
 * `instance`), a pack bundle's on the phase's pack trees (`pack`), each seeded on that data's digest (phaseSeed of it;
 * none for a bundle with data of its own), or on `seed` when one is given (a regrade's, the stored run's). What a grade,
 * a regrade and a timing heat (the header's `code heat`) run the entry under.
 */
async function programPhasePlan(
  deps: Pick<GradeWorkerDeps, 'db' | 'blobs' | 'workRoot' | 'competitionDir' | 'sealedDir' | 'drandChain' | 'sandbox'>,
  input: { slug: string; bundle: CompetitionBundleT; harness: ProgramHarnessT; phaseKey: string; competitionKey: string; seed: string | null },
): Promise<HarnessPlan> {
  return programPlan(await programPhaseSetup(deps, input));
}

/**
 * The tree at `dir`, the bundle's `rel` (its path in the bundle, '.' the competition root), as the k8s sandbox's pods
 * mount it (the header's `k8s data`): staged under the data root `dataRoot` as <dataRoot>/bundle-trees/<slug>/<digest>/
 * <rel> (sandbox/bundle-trees.ts stageBundleTree), the digest `sealed` its harness seals it to (undefined: its own), or
 * null when it lies under the data root already, where it is mounted as it is. A tree the image does not hold as
 * sealed is a PlatformFaultError naming `what`: the image's fault, never the entry's.
 */
async function stageOntoClaim(o: { slug: string; dataRoot: string }, dir: string, rel: string, sealed: string | undefined, what: string): Promise<StagedTree | null> {
  if (underDataRoot(o.dataRoot, dir)) return null;
  try {
    return await stageBundleTree({ dataRoot: o.dataRoot, slug: o.slug, source: dir, rel, digest: sealed ?? null });
  } catch (err) {
    if (err instanceof BundleTreeError) {
      throw new PlatformFaultError(`${o.slug}'s ${what} cannot be staged onto the k8s sandbox's data claim (${o.dataRoot}), the only tree its pods mount: ${err.message}`, { cause: err });
    }
    throw err;
  }
}

/** A bundle directory (its path in the bundle, '.' the root) under the competition directory `compDir`. */
function bundleDirOf(compDir: string, rel: string): string {
  return rel === '.' ? compDir : join(compDir, ...rel.split('/'));
}

/**
 * A program/v1 setup as the k8s sandbox's pods can mount it (the header's `k8s data`): each tree a grade of it mounts
 * (the scorer directory at /bot, the input data at /input, the reference data at /reference) that lies outside the data
 * root `dataRoot` staged under <dataRoot>/bundle-trees/<slug>/<digest>/ (sandbox/bundle-trees.ts stageBundleTree),
 * a bundle's own tree as the digest its harness seals it to (scorer_sha256, input_sha256, reference_sha256), and the
 * setup pointed at the copies: its compDir the scorer's stage directory, so the scorer is at the bundle's own path in
 * it, and its inputDir and referenceDir named. A tree already under the data root (an instance's under the sealed
 * directory, a pack's under the work root) is mounted where it is. The copies are the trees byte for byte, so the
 * run's dataset digest (programDataSha256) and scorer digest (programScorerDigest) are the image's. A tree the image
 * does not hold as sealed is a PlatformFaultError: the image's fault, never the entry's.
 */
export async function stageProgramSetup(setup: ProgramSetup, o: { slug: string; dataRoot: string }): Promise<ProgramSetup> {
  const h = setup.harness;
  const paths = programPaths(setup);
  const stage = (dir: string, rel: string, sealed: string | undefined, what: string): Promise<StagedTree | null> => stageOntoClaim(o, dir, rel, sealed, what);
  // The bundle's own trees by the paths and digests its harness names them; an instance's or a pack's (named in the
  // setup) by their own digests, under their tree's name.
  const scorer = await stage(paths.scorerDir, scorerDirOf(h.scorer.entrypoint), h.scorer_sha256, 'scorer directory');
  const own = (named: string | undefined, rel: string | null, sealed: string | undefined, tree: 'input' | 'reference') =>
    named === undefined && rel !== null ? { rel, sealed } : { rel: tree, sealed: undefined };
  let inputDir: string | null = null;
  if (paths.inputDir !== null) {
    const t = own(setup.inputDir, h.input_data, h.input_sha256, 'input');
    inputDir = (await stage(paths.inputDir, t.rel, t.sealed, 'input data'))?.dir ?? paths.inputDir;
  }
  const r = own(setup.referenceDir, h.scorer.reference_data, h.reference_sha256, 'reference');
  const referenceDir = (await stage(paths.referenceDir, r.rel, r.sealed, 'reference data'))?.dir ?? paths.referenceDir;
  return { ...setup, compDir: scorer?.root ?? setup.compDir, ...(inputDir === null ? {} : { inputDir }), referenceDir };
}

/**
 * An agent/v1 setup as the k8s sandbox's pods can mount it (the header's `k8s data`): the env directory (the env's
 * /bot) and the scorer directory (the scorer's /bot), the bundle's own trees read from the image's competitions/<slug>/,
 * staged under <dataRoot>/bundle-trees/<slug>/ as the digests the harness seals them to (env_sha256, scorer_sha256),
 * and the setup pointed at the copies: its compDir the scorer's stage directory, so the scorer is at the bundle's own
 * path in it (agent.ts trialProgramSetup), and its envDir the env's copy (agent.ts envProgram). A tree under the data
 * root already is mounted where it is. A trial's instance (the sealed directory) and its forwarder and scratch (the
 * work root) are on the claim already. The copies are the trees byte for byte, so the run's scorer_version (the
 * sealed scorer_sha256) is unchanged. A tree the image does not hold as sealed is a PlatformFaultError.
 */
export async function stageAgentSetup(setup: AgentSetup, o: { slug: string; dataRoot: string }): Promise<AgentSetup> {
  const h = setup.harness;
  const envRel = scorerDirOf(h.env.entrypoint);
  const envDir = setup.envDir ?? bundleDirOf(setup.compDir, envRel);
  const scorerRel = scorerDirOf(h.scorer.entrypoint);
  const env = await stageOntoClaim(o, envDir, envRel, h.env_sha256, 'env directory');
  const scorer = await stageOntoClaim(o, bundleDirOf(setup.compDir, scorerRel), scorerRel, h.scorer_sha256, 'scorer directory');
  return { ...setup, compDir: scorer?.root ?? setup.compDir, envDir: env?.dir ?? envDir };
}

/**
 * A scrape/v1 scorer setup as the k8s sandbox's pods can mount it (the header's `k8s data`): the scorer directory (the
 * scorer's /bot), read from the image's competitions/<slug>/, staged under <dataRoot>/bundle-trees/<slug>/ as its
 * sealed scorer_sha256, and the setup's compDir its stage directory, so the scorer is at the bundle's own path in it
 * (scrape/score.ts scrapeProgramSetup). A scorer under the data root already is mounted where it is. A scorer the image
 * does not hold as sealed is a PlatformFaultError.
 */
export async function stageScrapeScorerSetup(setup: ScrapeScorerSetup, o: { slug: string; dataRoot: string }): Promise<ScrapeScorerSetup> {
  const rel = scorerDirOf(setup.harness.scorer.entrypoint);
  const scorer = await stageOntoClaim(o, bundleDirOf(setup.compDir, rel), rel, setup.harness.scorer_sha256, 'scorer directory');
  return scorer === null ? setup : { ...setup, compDir: scorer.root };
}

/** An agent/v1 setup as `sandbox`'s programs mount it: on the k8s sandbox stageAgentSetup's (under its data root), else `setup` itself. */
export async function agentSetupFor(sandbox: Parameters<typeof k8sDataRoot>[0], slug: string, setup: AgentSetup): Promise<AgentSetup> {
  const dataRoot = k8sDataRoot(sandbox);
  return dataRoot === null ? setup : stageAgentSetup(setup, { slug, dataRoot });
}

/**
 * A scrape/v1 scorer setup as `sandbox`'s programs mount it: on the k8s sandbox stageScrapeScorerSetup's (under its data
 * root), else `setup` itself. What judges a scrape/v1 run with a k8s sandbox takes its setup from here.
 */
export async function scrapeScorerSetupFor(sandbox: Parameters<typeof k8sDataRoot>[0], slug: string, setup: ScrapeScorerSetup): Promise<ScrapeScorerSetup> {
  const dataRoot = k8sDataRoot(sandbox);
  return dataRoot === null ? setup : stageScrapeScorerSetup(setup, { slug, dataRoot });
}

/**
 * What programPhasePlan plans on: the phase's program setup (its instance's or pack's trees, or a sponsored
 * judged-artifact bundle's reference data: judgedTreesOf; on the k8s sandbox, stageProgramSetup's) and its seed.
 */
async function programPhaseSetup(
  deps: Pick<GradeWorkerDeps, 'db' | 'blobs' | 'workRoot' | 'competitionDir' | 'sealedDir' | 'drandChain' | 'sandbox'>,
  input: { slug: string; bundle: CompetitionBundleT; harness: ProgramHarnessT; phaseKey: string; competitionKey: string; seed: string | null },
): Promise<{ setup: ProgramSetup; seed: string }> {
  const { slug, bundle, harness, phaseKey } = input;
  const compDir = competitionDirOf(deps, slug, harness);
  let setup: ProgramSetup = { compDir, harness, leaderboard: bundle.leaderboard };
  // An instance-drawn bundle grades on the phase's instance, and seeds on its digest; a pack bundle on
  // the phase's pack trees, and seeds on theirs.
  let instanceSha256: string | null = null;
  if (harness.generator !== undefined) {
    const instance = phaseInstance({ slug, bundle, compDir, sealedDir: deps.sealedDir ?? sealedDirFromEnv(), phaseKey, chain: instanceChainOptions(deps.drandChain) });
    setup = { ...setup, inputDir: instance.inputDir, referenceDir: instance.referenceDir };
    instanceSha256 = programDataSha256(setup);
    if (instance.instanceSha256 !== null && instanceSha256 !== instance.instanceSha256) {
      throw new PermanentJobError(`${slug}'s scored instance ${instance.dir} has dataset digest ${instanceSha256}, not its draw record's instance_sha256 ${instance.instanceSha256}`);
    }
  } else if (harness.pack !== undefined) {
    const trees = await phasePackTrees({ slug, harness, compDir, phaseKey, blobs: deps.blobs, workRoot: deps.workRoot });
    setup = { ...setup, inputDir: trees.inputDir, referenceDir: trees.referenceDir };
    instanceSha256 = programDataSha256(setup);
  } else if (harness.final_dataset === true && phaseKey === 'final') {
    // A final_dataset bundle's final grades on the program dataset attached to it, and seeds on its trees' digest.
    const trees = await programFinalDataset(deps.db, slug);
    setup = { ...setup, inputDir: trees.inputDir, referenceDir: trees.referenceDir };
    instanceSha256 = programDataSha256(setup);
    if (instanceSha256 !== trees.dataSha256) throw new PermanentJobError(`${slug}'s final dataset ${trees.slug} digests to ${instanceSha256}, not its manifest's data_sha256 ${trees.dataSha256}`);
  } else if (harness.judge !== undefined && judgedHouseSlug(harness) !== null) {
    // A judged-artifact bundle grades on its medium's pilot gate scorer, the sealed one, and on its own caps.
    const scorer = packScorerIssue(harness, compDir);
    if (scorer !== null) throw new PermanentJobError(`${slug} grades with the gate scorer its harness seals (scorer_sha256 ${harness.scorer_sha256 ?? 'none'}), and ${scorer}`);
    const trees = await judgedTreesOf(deps, slug, harness, harness.judge);
    if (trees.referenceDir !== null) setup = { ...setup, referenceDir: trees.referenceDir };
  }
  // A k8s pod mounts only the data claim: what the grade mounts from outside it is staged there (the header's `k8s data`).
  const dataRoot = k8sDataRoot(deps.sandbox);
  if (dataRoot !== null) setup = await stageProgramSetup(setup, { slug, dataRoot });
  return { setup, seed: input.seed ?? phaseSeed(input.competitionKey, phaseKey, instanceSha256) };
}

/**
 * What a patch/v1 phase's plan grades on (grader/harnesses.ts patchPlan): the bounty's sealed base tree
 * (repo.base_tree_sha256) and the phase's tree (pack.dev on the dev phase, pack.final on the final), each
 * materialized from `blobs` under <workRoot>/patch-base/ and <workRoot>/patch-phase/ and re-verified
 * (patch/execute.ts patchTreeDir), the phase tree's lists.json, and its seed: phaseSeed of the phase tree's digest,
 * or `seed` when one is given (a regrade's, the stored run's). Its test log is never kept: what a grade records is
 * the run log alone, and the final's tests are sealed. Throws PlatformFaultError, the platform's fault and no
 * entry's, on the k8s sandbox (its pods run no repository image: sandbox/k8s.ts refuses one) and for a tree the
 * house cannot materialize or a phase tree whose lists.json is absent or invalid (NO_PATCH_TREES_MESSAGE): no retry
 * mends either. A tree that does not match its index where it was made (PatchRunnerError), or a read that failed
 * otherwise, is thrown as it is, retried.
 */
export async function patchPhaseSetup(
  deps: Pick<GradeWorkerDeps, 'blobs' | 'workRoot' | 'sandbox'>,
  input: { slug: string; harness: PatchHarnessT; phaseKey: string; competitionKey: string; seed: string | null },
): Promise<PatchPlanInput> {
  const { slug, harness: h, phaseKey } = input;
  if (deps.sandbox.kind === 'k8s') {
    throw new PlatformFaultError(`${slug} is a patch/v1 competition, which grades on the docker sandbox alone: the k8s sandbox runs no repository image (MAKEFUN_SANDBOX=k8s)`);
  }
  const phase: PatchPhaseT = phaseKey === 'dev' ? 'dev' : 'final';
  const treeOf = async (what: string, digest: string, cache: string): Promise<PatchTree> => {
    try {
      return await patchTreeDir({ blobs: deps.blobs, digest, cacheRoot: join(deps.workRoot, cache) });
    } catch (err) {
      if (err instanceof RepoIntakeError) {
        throw new PlatformFaultError(`${slug}: ${NO_PATCH_TREES_MESSAGE}, and the ${phaseKey} phase's ${what} ${digest} cannot be materialized: ${err.message}`, { cause: err });
      }
      throw err;
    }
  };
  const base = await treeOf('base tree', h.repo.base_tree_sha256, PATCH_BASE_CACHE);
  const tree = await treeOf(`${phase} tree`, h.pack[phase].tree_sha256, PATCH_PHASE_CACHE);
  let lists: PatchListsT;
  try {
    lists = await readPatchLists(tree.dir);
  } catch (err) {
    // The tree matched its sealed index just now: lists that are not there, not a file or not lists were sealed so.
    const sealed = err instanceof PatchRunnerError || err instanceof z.ZodError || err instanceof SyntaxError || (err instanceof Error && 'code' in err && err.code === 'ENOENT');
    if (!sealed) throw err;
    throw new PlatformFaultError(`${slug}: ${NO_PATCH_TREES_MESSAGE}, and the ${phase} tree ${h.pack[phase].tree_sha256}'s ${PATCH_LISTS_FILE} does not read: ${err instanceof Error ? err.message : String(err)}`, { cause: err });
  }
  return {
    setup: { harness: h, phase, base, phaseTreeDir: tree.dir, lists, keepTestLog: false },
    seed: input.seed ?? phaseSeed(input.competitionKey, phaseKey, h.pack[phase].tree_sha256),
  };
}

/**
 * The trees a final_dataset program/v1 bundle's final phase grades on (contracts/competition.ts
 * ProgramHarness.final_dataset): the program dataset attached to that phase (phase.dataset_id), its directory (the row's
 * path, against the project root as every dataset row's is) verified whole and held to the row's sha256
 * (grader/program-dataset.ts readFrozenProgramDataset). Throws PermanentJobError when none is attached (the lock waits
 * for one: contracts/competition.ts gradesOnPhaseDataset, so a grade asked for without one is a fault no retry mends)
 * or when it does not verify; a directory that is not there at all is an ordinary error, retried (a volume may not be
 * mounted yet), as a replay's dataset is.
 */
async function programFinalDataset(db: Db, slug: string): Promise<{ slug: string; inputDir: string; referenceDir: string; dataSha256: string }> {
  const [row] = await db
    .select({ ds: dataset })
    .from(phase)
    .innerJoin(competition, eq(competition.id, phase.competitionId))
    .leftJoin(dataset, eq(dataset.id, phase.datasetId))
    .where(and(eq(competition.slug, slug), eq(phase.key, 'final')));
  if (row === undefined) throw new PermanentJobError(`${slug} has no final phase`);
  if (row.ds === null) throw new PermanentJobError(`the final phase of ${slug} grades on its attached dataset, and none is attached (npm run admin:dataset -- --sealed --attach ${slug}:final)`);
  const dir = resolve(PROJECT_ROOT, row.ds.path);
  if (!existsSync(dir)) throw new Error(`the final dataset ${row.ds.slug} of ${slug} is not at ${dir}`);
  try {
    const frozen = readFrozenProgramDataset(dir, { expectSha256: row.ds.sha256 });
    return { slug: row.ds.slug, inputDir: frozen.inputDir, referenceDir: frozen.referenceDir, dataSha256: frozen.manifest.data_sha256 };
  } catch (err) {
    if (err instanceof ProgramDatasetError) throw new PermanentJobError(`dataset ${row.ds.slug}: ${err.message}`, { cause: err });
    throw err;
  }
}

/** Where a judged bundle's judge reads its judge directory and its gate its reference data (judgedTreesOf). */
export interface JudgedTrees {
  /** The judge directory (readJudgeTree reads it, held to judge_sha256). */
  judgeDir: string;
  /** The gate's reference data when it is not the competition directory's own (ProgramSetup.referenceDir), else null. */
  referenceDir: string | null;
  /**
   * The judge's ladder directory when the bundle names a ladder and it is not the competition directory's own (a
   * sponsored judged-artifact competition's, materialized from its choice: judgeLadderDirOf reads it); no key otherwise.
   */
  ladderDir?: string;
}

/**
 * Where a judged program/v1 bundle's judge directory and gate reference data are read: judge.dir and
 * scorer.reference_data under its competition's directory in the image (competitionDirOf) when those are the sealed
 * trees (a house judged competition's own, or a sponsored one's composed of its pilot's own inputs), referenceDir null.
 * Else, for a bundle sealed to its medium's pilot gate scorer (load.ts judgedHouseSlug: a sponsored judged-artifact
 * competition, which has no directory of its own) that a proposal set up, the trees load.ts judgedArtifactTrees
 * materializes under <workRoot>/pack-trees/ from the proposal's choice (competition_proposal.document.harness, as the
 * team's setup left it) and the anchors' blobs, each held to the bundle's seal, and, when the bundle names a ladder,
 * its ladder directory too (ladderDir), from the choice's ladder and its blobs, held to ladder_sha256: a sponsored
 * bundle's own directory (its pilot's) holds none. A competition no proposal set up keeps its directory's, which
 * readJudgeTree (and grader/judge-ladder-tree.ts readJudgeLadder) refuses when it is not the sealed one. Throws
 * PermanentJobError when the trees cannot be materialized: no retry mends a choice, an anchor or a ladder file that is
 * not the sealed one.
 */
export async function judgedTreesOf(deps: Pick<GradeWorkerDeps, 'db' | 'blobs' | 'workRoot' | 'competitionDir'>, slug: string, harness: ProgramHarnessT, judge: ProgramJudgeT): Promise<JudgedTrees> {
  const compDir = competitionDirOf(deps, slug, harness);
  const own: JudgedTrees = { judgeDir: bundleDirOf(compDir, judge.dir), referenceDir: null };
  if (judgedHouseSlug(harness) === null) return own;
  const reference = harness.scorer.reference_data;
  const ownReference = reference === null || harness.reference_sha256 === undefined || rehashes(bundleDirOf(compDir, reference), harness.reference_sha256);
  const ownLadder = judge.ladder === undefined || rehashes(bundleDirOf(compDir, judge.ladder.dir), judge.ladder.ladder_sha256);
  if (ownReference && ownLadder && rehashes(own.judgeDir, judge.judge_sha256)) return own;
  const [row] = await deps.db
    .select({ document: competitionProposal.document })
    .from(competitionProposal)
    .innerJoin(competition, eq(competition.id, competitionProposal.competitionId))
    .where(eq(competition.slug, slug))
    .limit(1);
  if (row === undefined) return own;
  const document = row.document;
  const choice = typeof document === 'object' && document !== null && 'harness' in document ? document.harness : null;
  try {
    return await judgedArtifactTrees({ blobs: deps.blobs, harness, choice, cacheRoot: join(deps.workRoot, PACK_CACHE_DIR) });
  } catch (err) {
    if (err instanceof Error && (err.name === 'JudgedTreesError' || err.name === 'PackError')) {
      throw new PermanentJobError(
        `${slug}'s reference data ${harness.reference_sha256 ?? 'unsealed'} and judge directory ${judge.judge_sha256}${judge.ladder === undefined ? '' : ` and ladder directory ${judge.ladder.ladder_sha256}`} cannot be materialized from its proposal's choice: ${err.message}`,
        { cause: err },
      );
    }
    throw err;
  }
}

/**
 * Where a judged bundle's ladder directory is read: the one judgedTreesOf materialized (`trees.ladderDir`, a sponsored
 * judged-artifact competition's), else judge.ladder.dir under its competition's directory (competitionDirOf).
 */
function judgeLadderDirOf(deps: Pick<GradeWorkerDeps, 'competitionDir'>, slug: string, harness: ProgramHarnessT, ladder: NonNullable<ProgramJudgeT['ladder']>, trees: Pick<JudgedTrees, 'ladderDir'>): string {
  return trees.ladderDir ?? bundleDirOf(competitionDirOf(deps, slug, harness), ladder.dir);
}

/**
 * The ladder a regrade holds a dev run's v3 provisional record to (regrade.ts RegradeL1Request.judgeLadder): a function
 * reading the bundle's sealed ladder (grader/judge-ladder-tree.ts readJudgeLadder, beside the judge directory
 * judgedTreesOf finds) on its first call and answering that read after. A judge directory that cannot be materialized
 * reads as the ladder's refusal: only a v3 record is held to it, and a v1 or v2 record's regrade never calls it.
 */
async function regradeJudgeLadder(
  deps: Pick<GradeWorkerDeps, 'db' | 'blobs' | 'workRoot' | 'competitionDir'>,
  slug: string,
  harness: ProgramHarnessT,
  judge: ProgramJudgeT,
): Promise<() => JudgeLadderInputs | { refused: string }> {
  const ladder = judge.ladder;
  if (ladder === undefined) return () => ({ refused: 'the bundle names no ladder (harness.judge.ladder)' });
  let trees: JudgedTrees | { refused: string };
  try {
    trees = await judgedTreesOf(deps, slug, harness, judge);
  } catch (err) {
    if (!(err instanceof PermanentJobError)) throw err;
    trees = { refused: err.message };
  }
  const { readJudgeLadder } = await import('./judge-ladder-tree.ts');
  let read: JudgeLadderInputs | { refused: string } | undefined;
  return () => (read ??= 'refused' in trees ? trees : readJudgeLadder(judgeLadderDirOf(deps, slug, harness, ladder, trees), judge, trees.judgeDir));
}

// ---------------------------------------------------------------- practice windows: the eras dev grade

/** A pumpfun-replay/v2 bundle's harness. */
type PumpHarnessT = Extract<HarnessT, { kind: 'pumpfun-replay/v2' }>;

/** A dev phase's practice windows (Phase.practice_windows) and the pump replay harness they grade on; null for a phase without them. */
export function practiceWindowsOf(bundle: CompetitionBundleT, phaseKey: string): { harness: PumpHarnessT; windows: PracticeWindowsT } | null {
  if (bundle.harness.kind !== 'pumpfun-replay/v2') return null;
  const windows = bundle.phases.find((p) => p.key === phaseKey)?.practice_windows;
  return windows === undefined ? null : { harness: bundle.harness, windows };
}

/** One practice window as a grade takes it: its key, the dataset row it grades on and the seed it runs under (phaseSeed over that dataset). */
export interface EraWindow {
  key: string;
  ds: typeof dataset.$inferSelect;
  seed: string;
}

/**
 * A dev phase's practice windows with a dataset attached, in key order, each under its own seed (phaseSeed of the
 * competition key, the dev phase and the window's dataset). A PermanentJobError when a window the bundle names has no
 * dataset (the pipeline holds the grade until every one has: server/pipeline/ingest.ts gradePhaseOf), or its row names
 * another length than the bundle's.
 */
export async function attachedEraWindows(db: Db, phaseId: string, windows: PracticeWindowsT, competitionKey: string): Promise<EraWindow[]> {
  const rows = await db.select({ key: practiceWindow.key, hours: practiceWindow.hours, ds: dataset }).from(practiceWindow).innerJoin(dataset, eq(dataset.id, practiceWindow.datasetId)).where(eq(practiceWindow.phaseId, phaseId));
  const byKey = new Map(rows.map((r) => [r.key, r]));
  return practiceWindowKeys(windows.count).map((key) => {
    const row = byKey.get(key);
    if (row === undefined) throw new PermanentJobError(`practice window ${key} of the dev phase has no dataset attached`);
    if (row.hours !== windows.hours) throw new PermanentJobError(`practice window ${key} is ${row.hours} h long, and the bundle's windows are ${windows.hours} h`);
    return { key, ds: row.ds, seed: phaseSeed(competitionKey, 'dev', row.ds.sha256) };
  });
}

/**
 * The windows an eras run graded, from its run_era rows (in the order given): each one's dataset resolved by the
 * row's dataset_sha256 (unique, so it is the dataset the window was graded on even when the phase's attached one has
 * been replaced), under the seed the row recorded. A PermanentJobError when a dataset is gone.
 */
export async function storedEraWindows(db: Db, rows: readonly EraRow[]): Promise<EraWindow[]> {
  const windows: EraWindow[] = [];
  for (const row of rows) {
    const ds = await one(db.select().from(dataset).where(eq(dataset.sha256, row.datasetSha256)), `dataset ${row.datasetSha256} (practice window ${row.windowKey})`);
    windows.push({ key: row.windowKey, ds, seed: row.seed });
  }
  return windows;
}

/**
 * One practice window's plan: the window's dataset loaded through `load` and checked against its row, replayed under the
 * window's seed and the public fail key of it (a dev phase's: failKeyFor), no final window. The eras dev grade, its
 * regrade and the dev-stress runs of a window build theirs here.
 */
export async function eraWindowPlan(harness: PumpHarnessT, window: EraWindow, load: NonNullable<GradeWorkerDeps['loadDataset']>): Promise<HarnessPlan> {
  const { ds } = window;
  let loaded;
  try {
    loaded = await load(ds);
  } catch (err) {
    if (err instanceof DatasetIntegrityError) throw new PermanentJobError(`dataset ${ds.slug}: ${err.message}`, { cause: err });
    throw err;
  }
  if (loaded.dataset.sha256 !== ds.sha256) throw new PermanentJobError(`dataset ${ds.slug} loads as ${loaded.dataset.sha256}, not its recorded ${ds.sha256}`);
  return replayPlan({ harness, dataset: loaded.dataset, sample: loaded.sample, seed: window.seed, failKey: publicFailKey(window.seed), finalWindow: null });
}

function eraRef(w: EraWindow): EraWindowRef {
  return { key: w.key, datasetId: w.ds.id, datasetSha256: w.ds.sha256, seed: w.seed };
}

/** The Score a finished window's row holds, or null when the row is not one a retried grade may resume from (another dataset or seed, no whole Score, a Score that no longer hashes to its sha256). */
function keptEraScore(row: EraRow, w: EraWindow): ScoreT | null {
  if (row.status !== 'finished' || row.result === null || row.actionLogSha256 === null || row.datasetSha256 !== w.ds.sha256 || row.seed !== w.seed) return null;
  const parsed = Score.safeParse(row.result);
  return parsed.success && scoreDigest(parsed.data).sha256 === row.resultSha256 ? parsed.data : null;
}

/** What gradeEras takes from the grade handler. */
interface ErasGrade {
  deps: GradeWorkerDeps;
  ctx: GradeJobContext | undefined;
  ids: RunIds;
  harness: PumpHarnessT;
  /** The windows' length (practice_windows.hours): what aggregateEras is given. */
  hours: number;
  windows: readonly EraWindow[];
  /** The first window's plan, built already: it stands for the versions every window's plan has alike. */
  plan: HarnessPlan;
  runtime: Runtime;
  /** The entry, its env-lane entry secrets with it (SnapshotSource.secrets): what every window runs. */
  snapshot: SnapshotSource;
  /** Those secrets' rows and values (the header's `entry secrets`): recorded on the run, masked out of each window's row, and scanned for. */
  secrets: EnvSecrets;
  /** gradeEntry's request but a window's plan, runtime, snapshot and label: the handler's `common` and `stop`. */
  base: Omit<GradeRequest, 'plan' | 'runtime' | 'snapshot' | 'label'>;
  load: NonNullable<GradeWorkerDeps['loadDataset']>;
}

/**
 * A dev grade on practice windows (the header's `practice windows`): the run row first (running, the way an agent/v1
 * run starts, under the id of this grade job so a retry finds it), then each window in key order: one already finished
 * in the run's run_era rows is kept (the retry resumes), any other is graded on its own plan (two executions, byte
 * equal: grade.ts gradeEntry) and its row and blobs recorded. The grade stops at the first window that is not ranked
 * (a failure, a timeout, two executions that disagree, an unmetered cost): that window's own outcome is the run's, as
 * aggregateEras returns the first such window's Score. Otherwise the run's result is aggregateEras over every window,
 * and its dataset_sha256, seed, action log, trace and stderr are the median window's. exec_count and wall_ms are the
 * windows' sums; the flags the median Score's. Every window runs with the entrant's env-lane entry secrets (the header's
 * `entry secrets`): the run records their rows from its start, each window's row is masked of them, and every graded
 * window's action log is scanned for them before the verdict: a hit flags the run secret_in_output with its
 * SECRET_IN_OUTPUT_ACTION row (each file under its window's key), written once, before finishRun.
 */
async function gradeEras(g: ErasGrade): Promise<{ run_id: string }> {
  const { deps, ctx, ids } = g;
  const { db, blobs } = deps;
  const runId = ctx === undefined ? uuidv7() : agentRunId(ctx.id);
  const mask = entrySecretForms(g.secrets.env);
  await startRun(db, {
    id: runId,
    ...ids,
    imageDigest: deps.sandbox.imageDigest(g.runtime),
    datasetSha256: null,
    harnessVersion: harnessVersion(),
    scorerVersion: scorerVersionOf(g.plan, deps.sandbox),
    seed: null,
    startedAt: new Date(),
    entrySecretIds: g.secrets.ids,
  });

  const done = new Map((await loadEras(db, runId)).map((r) => [r.windowKey, r]));
  const graded: string[] = [];
  const scores: EraWindowScore[] = [];
  /** The window the grade stopped at: what the run takes from it, the window's Score if it has one. */
  let stopped: { key: string; status: GradeOutcome['status']; error: string | null; flags: string[]; score: ScoreT | null } | null = null;
  for (const [i, w] of g.windows.entries()) {
    graded.push(w.key);
    const row = done.get(w.key);
    const kept = row === undefined ? null : keptEraScore(row, w);
    if (kept !== null) {
      if (!kept.eligibility.ranked) {
        stopped = { key: w.key, status: 'finished', error: null, flags: kept.flags, score: kept };
        break;
      }
      scores.push({ key: w.key, score: kept });
      continue;
    }
    ctx?.signal?.throwIfAborted();
    const plan = i === 0 ? g.plan : await eraWindowPlan(g.harness, w, g.load);
    const outcome = await gradeEntry({ ...g.base, plan, runtime: g.runtime, snapshot: g.snapshot, label: `grade-dev-${w.key}` });
    // An attempt given up records nothing more, however far it got: its retry grades the windows not recorded again.
    ctx?.signal?.throwIfAborted();
    await recordEra(db, blobs, runId, eraOfGrade(eraRef(w), outcome), mask);
    if (outcome.status !== 'finished' || outcome.result === null || !outcome.result.eligibility.ranked) {
      stopped = { key: w.key, status: outcome.status, error: outcome.error, flags: outcome.flags, score: outcome.result };
      break;
    }
    scores.push({ key: w.key, score: outcome.result });
  }

  ctx?.signal?.throwIfAborted();
  const rows = (await loadEras(db, runId)).filter((r) => graded.includes(r.windowKey));
  const result = stopped === null ? erasResult(scores, g.hours) : stopped.score;
  const rankKey = stopped !== null ? stopped.key : result?.performance.kind === 'pumpfun-replay/v2' ? result.performance.eras?.rank_window : undefined;
  const rank = rows.find((r) => r.windowKey === rankKey);
  if (rank === undefined) throw new Error(`run ${runId}: no window row for ${rankKey ?? 'a rank window'}`);
  // Every graded window's action log scanned for the secrets it ran with, never masked (the header's `entry secrets`).
  const hits: SecretHit[] = [];
  for (const r of rows) hits.push(...(await secretHitsOfRun(blobs, 'pumpfun-replay/v2', { sha256: r.actionLogSha256 }, g.secrets.env, `${r.windowKey}/`)));
  if (hits.length > 0) {
    (deps.log ?? ((line: string) => console.log(line)))(secretHitsLine(`run ${runId} (submission ${ids.submissionId}'s dev grade on practice windows)`, hits));
    // Written once: a retry of a grade that died after it finds it there.
    const [held] = await db.select({ id: auditEvent.id }).from(auditEvent).where(and(eq(auditEvent.action, SECRET_IN_OUTPUT_ACTION), eq(auditEvent.subjectType, 'run'), eq(auditEvent.subjectId, runId))).limit(1);
    if (held === undefined) await recordSecretHits(db, runId, hits);
  }
  const flags = stopped !== null ? stopped.flags : (result?.flags ?? []);
  await finishRun(db, blobs, runId, {
    status: stopped === null ? 'finished' : stopped.status,
    action_log_json: null,
    action_log_sha256: rank.actionLogSha256,
    result,
    result_sha256: result === null ? null : scoreDigest(result).sha256,
    exec_count: rows.reduce((n, r) => n + r.execCount, 0),
    wall_ms: rows.reduce((n, r) => n + (r.wallMs ?? 0), 0),
    error: stopped === null || stopped.error === null ? null : `window ${stopped.key}: ${stopped.error}`,
    finished_at: new Date(),
    median: {
      dataset_sha256: rank.datasetSha256,
      seed: rank.seed,
      fail_key: publicFailKey(rank.seed),
      flags: hits.length === 0 ? flags : [...new Set([...flags, SECRET_IN_OUTPUT_FLAG])].sort(compareCodeUnits),
      trace_sha256: rank.traceSha256,
      stderr_sha256: rank.stderrSha256,
    },
  });
  return { run_id: runId };
}

/** A Score's flags (performance and execution, sorted), as a window's run_era row holds them: the flags its regrade is given as the window's. */
function eraFlagsOf(result: unknown): string[] {
  const flags = (result as { flags?: unknown } | null)?.flags;
  return Array.isArray(flags) ? flags.filter((f): f is string => typeof f === 'string') : [];
}

/**
 * The windows of an eras run as the regrade takes them: each run_era row (in the order `windows` were built from them,
 * storedEraWindows) a stored run of its own, the public fail key of its seed (a dev phase's), the run's versions and
 * image, and the plan of its own dataset built when the regrade comes to it.
 */
function eraRegradeWindows(stored: StoredRun & RunIds, rows: readonly EraRow[], windows: readonly EraWindow[], harness: PumpHarnessT, load: NonNullable<GradeWorkerDeps['loadDataset']>): ErasRegradeWindow[] {
  return windows.map((w, i) => {
    const row = rows[i]!;
    return {
      ...eraRef(w),
      stored: {
        id: `${stored.id} window ${w.key}`,
        submission_id: stored.submission_id,
        status: row.status,
        harness_version: stored.harness_version,
        scorer_version: stored.scorer_version,
        image_digest: stored.image_digest,
        dataset_sha256: row.datasetSha256,
        seed: row.seed,
        fail_key: publicFailKey(row.seed),
        action_log_sha256: row.actionLogSha256,
        result: row.result,
        result_sha256: row.resultSha256,
        flags: eraFlagsOf(row.result),
        stderr_sha256: row.stderrSha256,
        trace_sha256: row.traceSha256,
      },
      plan: () => eraWindowPlan(harness, w, load),
    };
  });
}

// ---------------------------------------------------------------- entry secrets of an entry's own runs

/**
 * The seal settings an entrant's secrets open with (GradeWorkerDeps.entrySecrets.seal, else the environment's:
 * server/secrets/seal.ts entrySecretSealSettings of loadConfig()), read once, when first asked.
 */
export function entrySecretSealOf(deps: Pick<GradeWorkerDeps, 'entrySecrets'>): () => Promise<EntrySecretSealSettings> {
  let settings: EntrySecretSealSettings | null = null;
  return async () => {
    settings ??= deps.entrySecrets?.seal ?? (await import('../server/secrets/seal.ts')).entrySecretSealSettings(loadConfig());
    return settings;
  };
}

/** An entrant's env-lane entry secrets as a run of its code takes them (the header's `entry secrets`): their rows (ids, in name order) and NAME to value. */
export interface EnvSecrets {
  ids: string[];
  env: Record<string, string>;
}

/** Whose secrets: the entrant's account and the competition. */
interface SecretOwner {
  userId: string;
  competitionId: string;
}

/** No secret. */
function noEnvSecrets(): EnvSecrets {
  return { ids: [], env: {} };
}

/** Rows read for a run, by NAME and row as a message names them, never a value. */
function secretRowsNamed(rows: readonly { id: string; name: string }[]): string {
  return rows.map((r) => `${r.name} (entry_secret ${r.id})`).join(', ');
}

/** An env-lane entry secret this grader could not open: its row, its NAME, and why (the seal's words), never a value. */
export interface UnopenedEnvSecret {
  id: string;
  name: string;
  why: string;
}

/**
 * A grade, a regrade or a heat held on its entrant's env-lane entry secrets (the header's `entry secrets`): some it must
 * run the entry with cannot be opened in this process (no seal private key here, entrySecretSealRefusal's words; or one
 * sealed to a key this grader lacks, or a record that does not open, EntrySecretSealError's), so nothing of the entry
 * runs and nothing is recorded. The platform's key configuration, never the entrant's fault: a retryable Error, never a
 * PermanentJobError, so pg-boss tries the job again (a deploy may bring the key). Its message opens
 * ENTRY_SECRETS_UNOPENED_HOLD_REASON (as server/pipeline/snapshot.ts EntrySecretsHeldError's does), then names `what`,
 * the secrets by NAME and row, and why; never a value. A fresh grade's last attempt throws EntrySecretsHeldFault in its
 * place (createGradeHandler).
 */
export class EntrySecretsUnopenedError extends Error {
  /** The NAMES of the secrets that did not open, in the order read. */
  readonly names: readonly string[];
  constructor(words: string, names: readonly string[]) {
    super(`${ENTRY_SECRETS_UNOPENED_HOLD_REASON}: ${words}`);
    this.name = 'EntrySecretsUnopenedError';
    this.names = [...names];
  }
}

/**
 * A fresh grade still held on its entrant's entry secrets on its job's last attempt (EntrySecretsUnopenedError; the
 * header's `entry secrets`): a PlatformFaultError, so the pipeline's grade stage never fails the entry but puts it back
 * to the status that attempt found it in, its error untouched (server/pipeline/index.ts), and the job dead-letters,
 * paged once by its handler (the header's `dead grade job`: heldGradeJobPage names the keys to mount and the resend).
 * Its message is the hold's.
 */
export class EntrySecretsHeldFault extends PlatformFaultError {
  /** The NAMES of the secrets that did not open (EntrySecretsUnopenedError.names). */
  readonly names: readonly string[];
  constructor(held: EntrySecretsUnopenedError) {
    super(held.message, { cause: held });
    this.name = 'EntrySecretsHeldFault';
    this.names = held.names;
  }
}

/** Whether a job's error (thrown, or as pg-boss keeps its message) is a hold on its entrant's entry secrets. */
function isEntrySecretsHold(err: unknown): boolean {
  if (err instanceof EntrySecretsUnopenedError || err instanceof EntrySecretsHeldFault) return true;
  return typeof err === 'string' && err.startsWith(`${ENTRY_SECRETS_UNOPENED_HOLD_REASON}: `);
}

/**
 * Each of `rows` (env-lane rows server/secrets/store.ts sealedEntrySecretsFor read, in its order) opened with the
 * grader's private keys (server/secrets/seal.ts openEntrySecret): those that open as a run takes them, and every one that
 * does not (sealed to a key this grader lacks, a record that does not open) with the seal's words, never a value. Any
 * other fault is thrown as it is.
 */
async function openEnvRows(privateKeys: EntrySecretSealSettings['privateKeys'], rows: readonly SealedEntrySecretRow[]): Promise<{ opened: EnvSecrets; unopened: UnopenedEnvSecret[] }> {
  const { EntrySecretSealError, openEntrySecret } = await import('../server/secrets/seal.ts');
  const opened = noEnvSecrets();
  const unopened: UnopenedEnvSecret[] = [];
  for (const r of rows) {
    try {
      const value = openEntrySecret(privateKeys, r.sealed, r.aad);
      opened.ids.push(r.id);
      opened.env[r.name] = value;
    } catch (err) {
      // The seal's words never quote a value; anything else is a fault of this process, thrown as it is.
      if (!(err instanceof EntrySecretSealError)) throw err;
      unopened.push({ id: r.id, name: r.name, why: err.message });
    }
  }
  return { opened, unopened };
}

/** Secrets that did not open, as a message names them: each cause's rows by NAME and row, then the cause ("A (entry_secret x), B (entry_secret y): why; C (entry_secret z): why"). */
function unopenedNamed(unopened: readonly UnopenedEnvSecret[]): string {
  const byWhy = new Map<string, UnopenedEnvSecret[]>();
  for (const u of unopened) byWhy.set(u.why, [...(byWhy.get(u.why) ?? []), u]);
  return [...byWhy].map(([why, rows]) => `${secretRowsNamed(rows)}: ${why}`).join('; ');
}

/**
 * The env-lane entry secrets a fresh grade of `who`'s entry runs with (the header's `entry secrets`): the account's active
 * ones in the competition (server/secrets/store.ts sealedEntrySecretsFor), opened with the grader's private keys; never
 * the provider lane's (no sandbox but an agent/v1 forwarder's holds a provider key). None pushed: none, and no key read.
 * Any this grader cannot open (no private key here, a seal it lacks) holds the grade: EntrySecretsUnopenedError naming
 * every one that did not open by NAME and row, and why, never a value; the job is retried, the entry never graded
 * without them and never failed for them.
 */
export async function activeEnvSecrets(db: Pick<Db, 'select'>, seal: () => Promise<EntrySecretSealSettings>, who: SecretOwner, what: string): Promise<EnvSecrets> {
  const [{ entrySecretSealRefusal }, { sealedEntrySecretsFor }] = await Promise.all([import('../server/secrets/seal.ts'), import('../server/secrets/store.ts')]);
  const rows = (await sealedEntrySecretsFor(db, who)).secrets.filter((r) => r.lane === 'env');
  if (rows.length === 0) return noEnvSecrets();
  const settings = await seal();
  const off = entrySecretSealRefusal(settings, 'open');
  if (off !== null) {
    throw new EntrySecretsUnopenedError(
      `${what}: the env-lane entry secrets its entrant pushed (${secretRowsNamed(rows)}) cannot be opened here, so it is not graded without them (its job tries again): ${off}`,
      rows.map((r) => r.name),
    );
  }
  const { opened, unopened } = await openEnvRows(settings.privateKeys, rows);
  if (unopened.length > 0) {
    const which =
      unopened.length === 1
        ? 'an env-lane entry secret its entrant pushed cannot be opened here, so it is not graded without it'
        : `${unopened.length} env-lane entry secrets its entrant pushed cannot be opened here, so it is not graded without them`;
    throw new EntrySecretsUnopenedError(
      `${what}: ${which} (its job tries again): ${unopenedNamed(unopened)}`,
      unopened.map((u) => u.name),
    );
  }
  return opened;
}

/**
 * The env-lane entry secrets of rows `ids` a run recorded (run.entry_secret_ids, run_trial.entry_secret_ids), for a run of
 * the entry again (the header's `entry secrets`): exactly those rows, retained ones included, the provider lane's left
 * out, opened as the run opened them. `opened`: the rows still held, opened (`secrets`), and `erased` the rows whose
 * ciphertext is gone since (replaced, deleted, purged, or no row of `who`'s: by NAME and row; null when none is).
 * `unopened`: this grader cannot open the rows held (`off`: no private key here, entrySecretSealRefusal's words, every
 * held row's NAME in `names`; `seal`: those it cannot open, each by NAME and row with EntrySecretSealError's words, their
 * NAMES in `names`), `erased` beside it alike. No value in any word.
 */
export async function recordedEnvSecrets(
  db: Pick<Db, 'select'>,
  seal: () => Promise<EntrySecretSealSettings>,
  who: SecretOwner,
  ids: readonly string[] | null | undefined,
): Promise<{ kind: 'opened'; secrets: EnvSecrets; erased: string | null } | { kind: 'unopened'; cause: 'off' | 'seal'; why: string; names: string[]; erased: string | null }> {
  const asked = [...new Set(ids ?? [])];
  if (asked.length === 0) return { kind: 'opened', secrets: noEnvSecrets(), erased: null };
  const [{ entrySecretSealRefusal }, { sealedEntrySecretsFor }] = await Promise.all([import('../server/secrets/seal.ts'), import('../server/secrets/store.ts')]);
  const lanes = await db.select({ id: entrySecret.id, name: entrySecret.name, lane: entrySecret.lane }).from(entrySecret).where(inArray(entrySecret.id, asked));
  // A row that is not there (or not a uuid) is no provider key: asked for, and named erased by the read.
  const envIds = asked.filter((id) => lanes.find((r) => r.id === id)?.lane !== 'provider');
  if (envIds.length === 0) return { kind: 'opened', secrets: noEnvSecrets(), erased: null };
  const read = await sealedEntrySecretsFor(db, { ...who, ids: envIds });
  const erased = read.erased.length === 0 ? null : read.erased.map((id) => `${lanes.find((r) => r.id === id)?.name ?? 'a secret'} (entry_secret ${id})`).join(', ');
  if (read.secrets.length === 0) return { kind: 'opened', secrets: noEnvSecrets(), erased };
  const settings = await seal();
  const off = entrySecretSealRefusal(settings, 'open');
  if (off !== null) return { kind: 'unopened', cause: 'off', why: off, names: read.secrets.map((r) => r.name), erased };
  const { opened, unopened } = await openEnvRows(settings.privateKeys, read.secrets);
  if (unopened.length > 0) return { kind: 'unopened', cause: 'seal', why: unopenedNamed(unopened), names: unopened.map((u) => u.name), erased };
  return { kind: 'opened', secrets: opened, erased };
}

/**
 * Of rows `ids` a final-phase run of `who`'s entry opened and is recording (run.entry_secret_ids,
 * run_trial.entry_secret_ids: the header's `entry secrets`), the env-lane ones whose ciphertext is gone since (replaced,
 * deleted or purged), by NAME and row; null when every one still holds it. A provider-lane row is never re-opened (a
 * replay runs on no key), so never asked about. Read in the caller's transaction, after it wrote the ids, under `who`'s
 * account lock: FOR SHARE on the user row, which server/secrets/store.ts's push and delete take FOR NO KEY UPDATE before
 * they read which rows a final run recorded (finalRecorded). A delete holding the lock first has committed by the time
 * this reads (its erasure is seen here); one coming after waits for the caller's commit, then reads the run and keeps
 * the row sealed for the challenge's re-run. No value in any word.
 */
export async function erasedSinceOpened(tx: Pick<Db, 'select'>, who: SecretOwner, ids: readonly string[] | null | undefined): Promise<string | null> {
  const asked = [...new Set(ids ?? [])];
  if (asked.length === 0) return null;
  await tx.select({ id: user.id }).from(user).where(eq(user.id, who.userId)).for('share');
  const lanes = await tx.select({ id: entrySecret.id, name: entrySecret.name, lane: entrySecret.lane }).from(entrySecret).where(inArray(entrySecret.id, asked));
  const envIds = asked.filter((id) => lanes.find((r) => r.id === id)?.lane !== 'provider');
  if (envIds.length === 0) return null;
  const { sealedEntrySecretsFor } = await import('../server/secrets/store.ts');
  const read = await sealedEntrySecretsFor(tx, { ...who, ids: envIds });
  return read.erased.length === 0 ? null : read.erased.map((id) => `${lanes.find((r) => r.id === id)?.name ?? 'a secret'} (entry_secret ${id})`).join(', ');
}

/**
 * Record a final-phase run that ran its entry with env-lane rows `ids` (the header's `entry secrets`): `write` writes it
 * in a transaction (record.ts recordGrade, handed it as its Db, nests its own), then every row it names must still hold
 * its ciphertext under the entrant's account lock (erasedSinceOpened), so a delete or replace either sees the run and
 * keeps the row for the challenge's re-run or came first. One erased while the run ran rolls the write back: a
 * retryable Error naming it by NAME (`what` the run), never a value, and the job runs the entry again with the secrets
 * as they stand. With no ids, `write` writes on `db` as ever.
 */
export async function recordWithSecretsHeld<T>(db: Db, who: SecretOwner, ids: readonly string[], what: string, write: (db: Db) => Promise<T>): Promise<T> {
  if (ids.length === 0) return write(db);
  return db.transaction(async (tx) => {
    const out = await write(tx as unknown as Db);
    const erased = await erasedSinceOpened(tx, who, ids);
    if (erased !== null) {
      throw new Error(
        `${what} ran with an env-lane entry secret its entrant removed or replaced while it ran, whose sealed copy is erased (${erased}): its run is not recorded, since a challenge's re-run could never open it, and its job runs it again with the secrets as they stand`,
      );
    }
    return out;
  });
}

/** The file a scan names a run's action log by (record.ts SecretHit.file); an output is `output/<path>`. */
export const ACTION_LOG_SCAN_FILE = 'action-log.json';

/** The NAMEs whose forms occur in a byte stream, read chunk by chunk with the last (longest pattern − 1) bytes carried over, so no occurrence is cut. */
async function secretNamesIn(stream: AsyncIterable<Uint8Array>, index: FormIndex): Promise<Set<string>> {
  const { findForms } = await import('./gateway/secret-mask.ts');
  let longest = 0;
  for (const p of index.patterns) longest = Math.max(longest, Buffer.byteLength(p, 'utf8'));
  const names = new Set<string>();
  let carry = Buffer.alloc(0);
  for await (const chunk of stream) {
    const buf = carry.length === 0 ? Buffer.from(chunk) : Buffer.concat([carry, chunk]);
    for (const hit of findForms(buf, index, { limit: 1 })) names.add(hit.name);
    carry = Buffer.from(buf.subarray(Math.max(0, buf.length - Math.max(0, longest - 1))));
  }
  return names;
}

/**
 * Where a run graded as one execution holds a form of the entry secrets it ran with (the header's `entry secrets`), by
 * NAME and file, never the value, and never masked (they are scored byte for byte): its canonical action log
 * (ACTION_LOG_SCAN_FILE: `log.json` when the caller holds it, else blob `log.sha256`) and, on program/v1, every output
 * file the log lists (`output/<path>`), read from the blob store as stored. `prefix` goes before each file (an eras
 * window's key). Hits in file order, then name order; none with no secret or no log.
 */
export async function secretHitsOfRun(
  blobs: Pick<BlobStore, 'get' | 'openRead'>,
  kind: HarnessT['kind'],
  log: { json?: string | null; sha256: string | null },
  env: Readonly<Record<string, string>>,
  prefix = '',
): Promise<SecretHit[]> {
  const held = log.json === undefined || log.json === null ? null : log.json;
  if (Object.keys(env).length === 0 || (held === null && log.sha256 === null)) return [];
  const { secretScanIndex } = await import('./agent.ts');
  const index = secretScanIndex(env);
  if (index.patterns.length === 0) return [];
  let json = held;
  if (json === null) {
    const bytes = await blobs.get(log.sha256!, { verify: true });
    if (bytes === null) throw new Error(`action log ${log.sha256} is missing from the blob store, so its outputs cannot be scanned for the entry's secrets`);
    json = Buffer.from(bytes).toString('utf8');
  }
  const sorted = (names: Iterable<string>) => [...names].sort(compareCodeUnits);
  const { findForms } = await import('./gateway/secret-mask.ts');
  const hits: SecretHit[] = [];
  for (const name of sorted(new Set(findForms(json, index, { limit: 1 }).map((h) => h.name)))) hits.push({ name, file: `${prefix}${ACTION_LOG_SCAN_FILE}` });
  if (kind === 'program/v1') {
    const { ProgramOutputs } = await import('./program.ts');
    const outputs = ProgramOutputs.parse(JSON.parse(json));
    for (const f of outputs.files) {
      for (const name of sorted(await secretNamesIn(await blobs.openRead(f.sha256), index))) hits.push({ name, file: `${prefix}output/${f.path}` });
    }
  }
  return hits;
}

/**
 * What a regrade run records of the entry secrets (record.ts recordRegrade's RunSecrets; the header's `entry secrets`): an
 * L2 the rows it re-executed the entry with, or, refused because one is erased (`erased`), the rows its run recorded,
 * which it would have run with; its stderr and error masked of their values. An L1 runs nothing: none.
 */
function l2Secrets(kind: JobPayload<'grade-dev'>['kind'], stored: Pick<StoredRun, 'entry_secret_ids'>, secrets: EnvSecrets, erased: string | undefined, forms: FormSet | null): Pick<RunSecrets, 'entry_secret_ids' | 'mask'> {
  if (kind !== 'regrade_l2') return {};
  return { entry_secret_ids: erased === undefined ? secrets.ids : (stored.entry_secret_ids ?? []), mask: forms };
}

/** A log line naming a run's outputs that held entry secrets, by NAME and file, never a value. */
function secretHitsLine(what: string, hits: readonly SecretHit[]): string {
  const names = [...new Set(hits.map((h) => h.name))].join(', ');
  const files = [...new Set(hits.map((h) => h.file))].join(', ');
  return `[grade] ${what}: its outputs hold a form of entry secret ${names} (${files}), never masked: its run is flagged ${SECRET_IN_OUTPUT_FLAG}`;
}

/** The final grades' live feed of each database in this process (finalGradeLanded): one gap per competition, whichever job lands the grade. */
const gradeLives = new WeakMap<object, Promise<GradeLive>>();

/**
 * Tell the live board a grade run of competition `competitionId`'s final phase landed (server/competitions/
 * live-judging.ts openGradeLive: a live change on its `phase` topic, kind `grade`, at most one per JUDGE_LIVE_MIN_GAP_MS
 * a competition, one inside the gap recorded at its end), so a page holding the live stream reads GET /live again and
 * its judging's grades move (the run's own `standings` change, record.ts GRADE_CHANGE, moves only the leaderboard).
 * Never throws: the grade stands whatever becomes of the change, and what fails is logged.
 */
async function finalGradeLanded(db: Db, competitionId: string, log: (line: string) => void): Promise<void> {
  try {
    let feed = gradeLives.get(db);
    if (feed === undefined) {
      feed = import('../server/competitions/live-judging.ts').then((m) => m.openGradeLive({ db, log }));
      gradeLives.set(db, feed);
      feed.catch(() => gradeLives.delete(db));
    }
    await (await feed).landed(competitionId);
  } catch (err) {
    log(`[grade] the final grades' live change on competition ${competitionId} could not be recorded (${err instanceof Error ? err.message : String(err)}): the live board shows them at its next read`);
  }
}

/**
 * The grade job handler (see the header). Handed the job's context (JobQueue.work's), it pages the job
 * should it die for good; with or without one, every job first sweeps the grade jobs that died before
 * it (the header's `dead grade job`). `handedOn`, when given, is told when the job, instead of grading,
 * has sent itself again to grade later (the header's `metered`): it answers null with nothing graded,
 * and the pipeline's grade stage marks the job so nothing is sent after it (server/pipeline/index.ts,
 * server/jobs.ts PipelineHandlers.gradeHandedOn).
 */
export function createGradeHandler(deps: GradeWorkerDeps): (job: JobPayload<'grade-dev'>, ctx?: GradeJobContext, handedOn?: () => void) => Promise<{ run_id: string } | null> {
  const { db, blobs } = deps;
  const loadDataset = deps.loadDataset ?? createDatasetLoader();
  const loadBarsDataset = deps.loadBarsDataset ?? createBarsDatasetLoader();
  const loadClmmDataset = deps.loadClmmDataset ?? createClmmDatasetLoader();
  const loadAuthorship = deps.loadAuthorship ?? ((submissionId: string, pricingRev: string, algoVersion?: number) => loadStoredAuthorship(db, submissionId, pricingRev, algoVersion));
  const dead = createDeadGradeJobPager(deps);
  const failKeyPaged = failKeyPager(deps, '[grade]');
  const sealOf = entrySecretSealOf(deps);
  const grade = async (job: JobPayload<'grade-dev'>, ctx: GradeJobContext | undefined, handedOn: (() => void) | undefined): Promise<{ run_id: string } | null> => {
    const sub = await one(db.select().from(submission).where(eq(submission.id, job.submission_id)), `submission ${job.submission_id}`);
    const ph = await one(db.select().from(phase).where(eq(phase.id, job.phase_id)), `phase ${job.phase_id}`);
    if (ph.competitionId !== sub.competitionId) throw new PermanentJobError(`phase ${ph.id} is not a phase of submission ${sub.id}'s competition`);
    const comp = await one(db.select().from(competition).where(eq(competition.id, sub.competitionId)), `competition ${sub.competitionId}`);
    if (comp.bundle === null) throw new PermanentJobError(`competition ${comp.slug} has no bundle (a demo row cannot be graded)`);
    let bundle: CompetitionBundleT;
    try {
      bundle = CompetitionBundle.parse(comp.bundle);
    } catch (err) {
      throw new PermanentJobError(`competition ${comp.slug}'s stored bundle does not validate`, { cause: err });
    }
    // An admin's provisional rejudge of a kept dev run (the header's `provisional rejudge`): it runs no program and
    // records no run, only the run's verdict judged again, so it hands nothing on (no publish).
    if (job.rejudge !== undefined) {
      await rejudgeProvisional(deps, { job, sub, ph, comp, bundle, ...(ctx?.signal === undefined ? {} : { signal: ctx.signal }) });
      return null;
    }
    if (sub.snapshotSha256 === null) throw new PermanentJobError(`submission ${sub.id} has no snapshot yet`);
    // A fresh final grade under a build meter prices only once masq has settled the requests it counts (the header's
    // `metered`): sooner, the job is sent again for then, and hands on nothing (`handedOn` told). A dev grade prices at once.
    if (job.kind === 'grade' && bundle.build_meter !== undefined && ph.key !== 'dev' && (await meteredSettleWait(deps, { sub, ph, job, ctx, handedOn })) !== null) return null;
    const index = await readSnapshotIndex(blobs, sub.snapshotSha256);
    const competitionKey = competitionSeedKey(comp);

    // A scrape entry grades in a heat of timed trials (the header's `scrape/v1`): on dev its practice heat beside the
    // house baseline, on the final phase the phase's one heat (createScrapeHeatHandler), whose run this job hands on.
    // Its L1 regrade re-judges the record; an L2 is refused: the measurement is never re-run.
    if (bundle.harness.kind === 'scrape/v1') {
      if (job.kind === 'regrade_l2') throw new PermanentJobError(SCRAPE_L2_REFUSAL);
      const scrape: ScrapeGradeStart = { deps, ctx, sub, ph, comp: { id: comp.id, slug: comp.slug }, bundle, harness: bundle.harness, index, competitionKey, loadAuthorship };
      if (job.kind === 'regrade_l1') {
        await scrapeHostQuiet(deps, `run ${job.reproduces_run_id}'s regrade_l1 regrade`, ctx?.signal);
        return regradeScrapeRun({ ...scrape, job });
      }
      return ph.key === 'dev' ? gradeScrapePractice(scrape) : scrapeFinalGrade(scrape);
    }
    // While a scrape heat holds this host (its lease), no other grading runs here (the header's `scrape/v1`).
    await scrapeHostQuiet(deps, job.kind === 'grade' ? `submission ${sub.id}'s grade on the ${ph.key} phase` : `run ${job.reproduces_run_id}'s ${job.kind} regrade`, ctx?.signal);

    // An agent entry grades as K trials, run by jobs of their own (the header's `agent/v1`): the job starts the run.
    // Its regrade re-derives a stored run from its trials (regrade.ts regradeAgentL1, regradeAgentL2).
    if (bundle.harness.kind === 'agent/v1') {
      const agent = { deps, ctx, sub, ph, comp: { id: comp.id, slug: comp.slug }, bundle, harness: bundle.harness, index, competitionKey };
      if (job.kind === 'grade') return startAgentRun(agent);
      return regradeAgentRun({ ...agent, job, loadAuthorship });
    }

    // A regrade re-derives a stored grade run, under the seed that run recorded.
    let stored: Awaited<ReturnType<typeof loadStoredRun>> = null;
    if (job.kind !== 'grade') {
      stored = await loadStoredRun(db, job.reproduces_run_id!);
      if (stored === null) throw new PermanentJobError(`run ${job.reproduces_run_id} does not exist`);
      if (stored.submissionId !== sub.id || stored.phaseId !== ph.id) throw new PermanentJobError(`run ${stored.id} is not a run of submission ${sub.id} in phase ${ph.id}`);
      const [orig] = await db.select({ kind: run.kind }).from(run).where(eq(run.id, stored.id));
      if (orig?.kind !== 'grade') throw new PermanentJobError(`run ${stored.id} is a ${orig?.kind}; regrade the grade run it reproduces`);
      if (stored.seed === null) throw new PermanentJobError(`run ${stored.id} recorded no seed`);
    }

    /** A replay phase's dataset row and its frozen files, through `load`, checked against the row. */
    const phaseDataset = async <T extends { dataset: { sha256: string } }>(load: (row: DatasetRow) => Promise<T>): Promise<{ ds: DatasetRow; loaded: T }> => {
      if (ph.datasetId === null) throw new PermanentJobError(`phase ${ph.key} of ${comp.slug} has no dataset attached`);
      const ds = await one(db.select().from(dataset).where(eq(dataset.id, ph.datasetId)), `dataset ${ph.datasetId}`);
      let loaded: T;
      try {
        loaded = await load(ds);
      } catch (err) {
        if (err instanceof DatasetIntegrityError) throw new PermanentJobError(`dataset ${ds.slug}: ${err.message}`, { cause: err });
        throw err;
      }
      if (loaded.dataset.sha256 !== ds.sha256) throw new PermanentJobError(`dataset ${ds.slug} loads as ${loaded.dataset.sha256}, not its recorded ${ds.sha256}`);
      return { ds, loaded };
    };

    // A dev phase on practice windows grades every window (gradeEras), and a regrade of a run that did follows its run_era rows (eraRegradeWindows).
    // The plan built here is the first window's: what the run takes its versions and runtimes from, window by window the same.
    const practice = stored === null ? practiceWindowsOf(bundle, ph.key) : null;
    const storedEras = stored === null ? [] : await loadEras(db, stored.id);
    let eras: { harness: PumpHarnessT; windows: EraWindow[] } | null = null;
    let plan: HarnessPlan;
    if (practice !== null) {
      const windows = await attachedEraWindows(db, ph.id, practice.windows, competitionKey);
      eras = { harness: practice.harness, windows };
      plan = await eraWindowPlan(practice.harness, windows[0]!, loadDataset);
    } else if (storedEras.length > 0) {
      if (bundle.harness.kind !== 'pumpfun-replay/v2') throw new PermanentJobError(`run ${stored!.id} has practice windows, and ${comp.slug}'s harness is ${bundle.harness.kind}`);
      const windows = await storedEraWindows(db, storedEras);
      eras = { harness: bundle.harness, windows };
      plan = await eraWindowPlan(bundle.harness, windows[0]!, loadDataset);
    } else if (bundle.harness.kind === 'pumpfun-replay/v2') {
      const { ds, loaded } = await phaseDataset(loadDataset);
      const receipt = ph.key === 'final' ? await lastReceiptAt(db, comp.id) : null;
      // The phase that races live on fail-key scheme server-secret/v1 is seeded as its race seeds every racer's hello (the
      // header's `seed`: gradeTakesRaceSeed); on any other scheme (a sealed-window final committed at its deadline) it keeps
      // its dataset part, the seed its commitment holds every final run to; a regrade keeps its run's. raceSeed loads only
      // then: server/race/entries.ts reaches the admin routes and better-auth, which no other grade, nor any CLI importing
      // this file, should load.
      const seed = stored?.seed ?? (gradeTakesRaceSeed(bundle, ph) ? (await import('../server/race/entries.ts')).raceSeed(comp, ph.key) : phaseSeed(competitionKey, ph.key, ds.sha256));
      // By the phase's scheme (the header's `fail key`); a regrade keeps the key its run was graded with.
      const failKey =
        stored?.fail_key ??
        (await failKeyPaged(stored === null ? `${comp.slug}: submission ${sub.id}'s grade on the ${ph.key} phase` : `${comp.slug}: run ${stored.id}'s ${job.kind} regrade`, () =>
          phaseFailKey({
            phase: ph,
            slug: comp.slug,
            seed,
            datasetSha256: ds.sha256,
            compDir: competitionDirOf(deps, comp.slug, bundle.harness),
            sealedDir: deps.sealedDir ?? sealedDirFromEnv(),
            chain: instanceChainOptions(deps.drandChain),
            serverSecret: () => deps.failKeySecret ?? defaultFailKeySecret(),
          }),
        ));
      plan = replayPlan({
        harness: bundle.harness,
        dataset: loaded.dataset,
        sample: loaded.sample,
        seed,
        failKey,
        finalWindow: receipt === null ? null : { last_graded_receipt_at: receipt },
      });
    } else if (bundle.harness.kind === 'bars-replay/v1') {
      // Every phase of a bars competition grades on a frozen bars window, dev included.
      const { ds, loaded } = await phaseDataset(loadBarsDataset);
      const receipt = ph.key === 'final' ? await lastReceiptAt(db, comp.id) : null;
      // The phase that races live is seeded as its race seeds every racer's hello (the header's `seed`); a regrade keeps its
      // run's. raceSeed loads only then: server/race/entries.ts reaches the admin routes and better-auth, which no other
      // grade, nor any CLI importing this file, should load.
      const seed = stored?.seed ?? (racesLive(bundle, ph.key) ? (await import('../server/race/entries.ts')).raceSeed(comp, ph.key) : phaseSeed(competitionKey, ph.key, ds.sha256));
      try {
        plan = barsPlan({ harness: bundle.harness, dataset: loaded.dataset, seed, finalWindow: receipt === null ? null : { last_graded_receipt_at: receipt } });
      } catch (err) {
        if (err instanceof SimDataError) throw new PermanentJobError(`dataset ${ds.slug} cannot replay ${comp.slug}'s universe: ${err.message}`, { cause: err });
        throw err;
      }
    } else if (bundle.harness.kind === 'clmm-replay/v1') {
      // Every phase of a clmm competition grades on a frozen pool window, dev included.
      const { ds, loaded } = await phaseDataset(loadClmmDataset);
      const receipt = ph.key === 'final' ? await lastReceiptAt(db, comp.id) : null;
      const seed = stored?.seed ?? phaseSeed(competitionKey, ph.key, ds.sha256);
      try {
        plan = clmmPlan({
          harness: bundle.harness,
          dataset: loaded.dataset,
          seed,
          finalWindow: receipt === null ? null : { last_graded_receipt_at: receipt },
          // The phase's floor of whole blocks: 28 on the ranked final phase, 8 on dev (contracts/clmm-protocol.ts clmmPhaseBlocksIssue).
          phase: ph.key,
          ...(deps.clmmScorer === undefined ? {} : { scorer: deps.clmmScorer }),
        });
      } catch (err) {
        if (err instanceof ClmmShortWindowError) throw new PermanentJobError(`dataset ${ds.slug}: ${comp.slug}'s window is too short for its blocks: ${err.message}`, { cause: err });
        if (err instanceof SimDataError) throw new PermanentJobError(`dataset ${ds.slug} cannot replay ${comp.slug}'s pool: ${err.message}`, { cause: err });
        throw err;
      }
    } else if (bundle.harness.kind === 'patch/v1') {
      // A patch/v1 phase grades on the bounty's sealed base tree and the phase's tree, never as a program/v1 run.
      plan = patchPlan(await patchPhaseSetup(deps, { slug: comp.slug, harness: bundle.harness, phaseKey: ph.key, competitionKey, seed: stored?.seed ?? null }));
    } else {
      plan = await programPhasePlan(deps, { slug: comp.slug, bundle, harness: bundle.harness, phaseKey: ph.key, competitionKey, seed: stored?.seed ?? null });
    }

    // Under a build meter a grade syncs the entrant's metered requests first and keeps the list of those it counts; a
    // regrade prices from exactly the stored ones that list names (the header's `metered`).
    const { cost, pricingRev } = await entryCostFor(deps, { sub, bundle, fresh: stored === null, ...(stored === null ? {} : { stored: stored.result }), ...(ctx?.signal === undefined ? {} : { signal: ctx.signal }) });
    // A regrade is given the summary its run was graded with (the version its score names), whatever
    // the entry was ingested under since; a grade the newest.
    const version = stored === null ? undefined : storedAuthorshipVersion(stored.result);
    let authorship: AuthorshipSummaryT | null = null;
    if (version !== null) {
      authorship = await loadAuthorship(sub.id, pricingRev, version);
      if (version !== undefined && authorship?.algo_version !== version) {
        throw new PermanentJobError(`run ${stored!.id} was graded with authorship algorithm ${version}, and submission ${sub.id} has no summary of it under pricing_rev ${pricingRev}`);
      }
    }
    // Handed its job, the grade names its scratch for the job, the same on each attempt, and an attempt first removes
    // what one that died left (the header's `scratch`); with no job, its scratch is named for none, as before.
    let owned: { owner?: string; onScratchReap?: (reaped: ScratchReap) => void } = {};
    if (ctx !== undefined) {
      const what = stored === null ? `submission ${sub.id}'s grade on the ${ph.key} phase (job ${ctx.id})` : `run ${stored.id}'s ${job.kind} regrade (job ${ctx.id})`;
      const before = `attempt ${ctx.retryCount + 1}`;
      const log = deps.log ?? ((line: string) => console.log(line));
      owned = {
        owner: regradeOwner(ctx.id),
        onScratchReap: (r) => {
          const line = scratchReapLine(what, before, r);
          if (line !== null) log(line);
        },
      };
    }
    const rules = eligibilityRulesOf(bundle);
    // Under a size count, the entry's code size over its snapshot, the competition's starter left out where kept as
    // handed (the header's `size`): one count for the grade and every regrade of it.
    const starterOf = deps.starter ?? ((slug: string) => competitionStarter(COMPETITIONS_DIR, slug));
    const size = rules.size === undefined ? undefined : codeSize(rules.size, index.files, await starterOf(comp.slug));
    // A regrade under a judge naming a ladder: the ladder a dev run's v3 provisional record is held to, read only if one is.
    const judgeLadder = stored !== null && bundle.harness.kind === 'program/v1' && bundle.harness.judge?.ladder !== undefined ? await regradeJudgeLadder(deps, comp.slug, bundle.harness, bundle.harness.judge) : undefined;
    const common = {
      plan,
      sandbox: deps.sandbox,
      limits: bundle.limits,
      workRoot: deps.workRoot,
      blobs,
      cost,
      authorship,
      entry: { house: standingsHouse(sub), baseline: sub.baseline },
      rules,
      ...(size === undefined ? {} : { size }),
      // The judge heat the bundle names, whose record a regrade holds a judged run's verdict to (regrade.ts judgeVerdictOf).
      ...(bundle.harness.kind === 'program/v1' && bundle.harness.judge !== undefined ? { judge: bundle.harness.judge } : {}),
      ...(judgeLadder === undefined ? {} : { judgeLadder }),
      ...owned,
    };
    const ids = { submissionId: sub.id, phaseId: ph.id };
    // A patch/v1 entry is a diff, in no runtime of its own: it runs on the plan's one (harnesses.ts PATCH_RUNTIME).
    const picked = bundle.harness.kind === 'patch/v1' ? { runtime: PATCH_RUNTIME } : entryRuntime(index, plan.runtimes);
    /** A clmm score whose LVR parts from LVR leg by leg, as the platform's fault (the header's `platform fault`); any other error as it is. */
    const platformFault = (err: unknown, what: string): unknown =>
      err instanceof ClmmLvrMismatchError
        ? new PlatformFaultError(`${comp.slug}: ${what} is refused as the platform's fault, never the entry's (no run is recorded, nothing is posted): ${err.message}`, { cause: err })
        : err;

    // The attempt's signal stops the grade or regrade once pg-boss gives the attempt up (grade.ts's `Stopping`, regrade.ts's
    // `stopping`): the program running killed, nothing more run, the reason thrown (retried, never permanent), and no run
    // recorded.
    const stop = ctx?.signal === undefined ? {} : { signal: ctx.signal };
    // The entrant's env-lane entry secrets every run of the entry here gets (the header's `entry secrets`): a grade the
    // account's active ones, an L2 exactly those its run recorded, re-opened (once one is erased the L2 is refused, its
    // L1 standing); an L1 runs nothing and opens none. They ride the entry's snapshot, so every execution of it gets them.
    const secretOwner = { userId: sub.userId, competitionId: comp.id };
    let secrets: EnvSecrets = { ids: [], env: {} };
    let secretsErased: string | undefined;
    if (stored === null) {
      if (!('error' in picked)) secrets = await activeEnvSecrets(db, sealOf, secretOwner, `${comp.slug}: submission ${sub.id}'s grade on the ${ph.key} phase`);
    } else if (job.kind === 'regrade_l2') {
      const recorded = await recordedEnvSecrets(db, sealOf, secretOwner, stored.entry_secret_ids);
      if (recorded.erased !== null) {
        secretsErased = `an env-lane entry secret run ${stored.id} ran the entry with is erased since (replaced, deleted or purged): ${recorded.erased}, so it cannot re-execute as it was graded; its L1 stands`;
        (deps.log ?? ((line: string) => console.log(line)))(`[grade] ${comp.slug}: run ${stored.id}'s regrade_l2 is refused unexecuted (${ENTRY_SECRETS_ERASED}): ${secretsErased}`);
      } else if (recorded.kind === 'unopened') {
        // Held, as a grade is (the header's `entry secrets`): retried, nothing re-executed, its last attempt paged.
        const which = recorded.cause === 'off' ? ` (${recorded.names.join(', ')})` : '';
        throw new EntrySecretsUnopenedError(
          `${comp.slug}: run ${stored.id}'s regrade_l2: the env-lane entry secrets its run ran with${which} cannot be opened here, so it is not re-executed without them (its job tries again): ${recorded.why}`,
          recorded.names,
        );
      } else {
        secrets = recorded.secrets;
      }
    }
    const secretForms = entrySecretForms(secrets.env);
    const snapshot: SnapshotSource = { index, blobs, ...(secrets.ids.length === 0 ? {} : { secrets: secrets.env }) };
    if (stored === null) {
      if (practice !== null && eras !== null && !('error' in picked)) {
        return gradeEras({ deps, ctx, ids, harness: eras.harness, hours: practice.windows.hours, windows: eras.windows, plan, runtime: picked.runtime, snapshot, secrets, base: { ...common, ...stop }, load: loadDataset });
      }
      let outcome;
      try {
        outcome = 'error' in picked ? refusedGrade(plan, picked.error) : await gradeEntry({ ...common, ...stop, runtime: picked.runtime, snapshot, label: ph.key === 'dev' ? 'grade-dev' : 'grade-final' });
      } catch (err) {
        throw platformFault(err, `entry ${sub.id}'s grade on the ${ph.key} phase`);
      }
      // A code-fastest dev grade that passed carries its provisional timing (the header's `code heat`); the final's heat times the field after every final grade.
      if (!('error' in picked) && ph.key === 'dev' && rules.timing !== undefined) {
        outcome = await withProvisionalTiming(deps, {
          outcome,
          sub,
          plan,
          runtime: picked.runtime,
          snapshot,
          limits: bundle.limits,
          rules,
          entry: common.entry,
          ...(owned.owner === undefined ? {} : { owner: owned.owner }),
          ...stop,
        });
      }
      // A judged dev grade that passed carries its provisional judge verdict (the header's `provisional judge`); the final's heat judges the field after every final grade.
      let judgeHeat: string | null = null;
      if (!('error' in picked) && ph.key === 'dev' && bundle.harness.kind === 'program/v1' && bundle.harness.judge !== undefined) {
        const judged = await withProvisionalJudge(deps, {
          outcome,
          sub,
          comp,
          ph,
          plan,
          harness: bundle.harness,
          judge: bundle.harness.judge,
          rules,
          entry: common.entry,
          ...stop,
        });
        outcome = judged.outcome;
        judgeHeat = judged.judge_heat_sha256;
      }
      // An attempt given up records nothing, however far it got: its retry grades again, and records once.
      ctx?.signal?.throwIfAborted();
      // The record its verdict came from, linked as the run's judge heat in the run's own insert (the regrade rebuilds the verdict from it).
      // Its action log and outputs scanned for the secrets it ran with, never masked (the header's `entry secrets`).
      const hits = await secretHitsOfRun(blobs, bundle.harness.kind, { json: outcome.action_log_json, sha256: outcome.action_log_sha256 }, secrets.env);
      if (hits.length > 0) (deps.log ?? ((line: string) => console.log(line)))(secretHitsLine(`${comp.slug}: submission ${sub.id}'s grade on the ${ph.key} phase`, hits));
      ctx?.signal?.throwIfAborted();
      const links = { judge_heat_sha256: judgeHeat, entry_secret_ids: secrets.ids, mask: secretForms, secret_hits: hits };
      // A final run's rows recorded only while each still holds its ciphertext, under its entrant's account lock, so a
      // challenge's re-run of it can always open them (the header's `entry secrets`).
      const runId =
        ph.key === 'final'
          ? await recordWithSecretsHeld(db, secretOwner, secrets.ids, `${comp.slug}: submission ${sub.id}'s grade on the final phase`, (into) => recordGrade(into, blobs, outcome, ids, links))
          : await recordGrade(db, blobs, outcome, ids, links);
      // A final grade moves the live board's grades count (finalGradeLanded): the page reads /live again.
      if (ph.key === 'final') await finalGradeLanded(db, comp.id, deps.log ?? ((line: string) => console.log(line)));
      // An official run of the phase that races live, once its results are published: the race held to it now (the header's `crosscheck`).
      if (racesLive(bundle, ph.key)) await crosscheckLandedGrade(deps, { slug: comp.slug, phaseId: ph.id, runId });
      return { run_id: runId };
    }
    try {
      if (eras !== null) {
        // An eras run regrades window by window (regrade.ts regradeErasL1, regradeErasL2); the regrade run takes a run_era row of its own for each.
        const windows = eraRegradeWindows(stored, storedEras, eras.windows, eras.harness, loadDataset);
        const base: Omit<typeof common, 'plan'> = common;
        let regraded;
        if (job.kind === 'regrade_l1') {
          regraded = await regradeErasL1({ ...base, ...stop, stored, windows });
        } else {
          if ('error' in picked) throw new PermanentJobError(picked.error);
          regraded = await regradeErasL2({ ...base, ...stop, stored, windows, runtime: picked.runtime, snapshot, label: 'regrade', ...(secretsErased === undefined ? {} : { secretsErased }) });
        }
        ctx?.signal?.throwIfAborted();
        return { run_id: await recordRegrade(db, blobs, regraded.outcome, ids, regraded.windows.map((w) => eraOfRegrade(w, w.outcome)), l2Secrets(job.kind, stored, secrets, secretsErased, secretForms)) };
      }
      let outcome;
      if (job.kind === 'regrade_l1') {
        outcome = await regradeL1({ ...common, ...stop, stored });
      } else {
        if ('error' in picked) throw new PermanentJobError(picked.error);
        outcome = await regradeL2({ ...common, ...stop, stored, runtime: picked.runtime, snapshot, label: 'regrade', ...(secretsErased === undefined ? {} : { secretsErased }) });
      }
      // regradeL1 / regradeL2 reject once the signal has aborted; read again here, so an attempt given up never writes the row.
      ctx?.signal?.throwIfAborted();
      return { run_id: await recordRegrade(db, blobs, outcome, ids, [], l2Secrets(job.kind, stored, secrets, secretsErased, secretForms)) };
    } catch (err) {
      if (err instanceof RegradeError) throw new PermanentJobError(err.message, { cause: err });
      throw platformFault(err, `run ${stored.id}'s ${job.kind} regrade on the ${ph.key} phase`);
    }
  };
  return async (job, ctx, handedOn) => {
    // Before it grades: the grade jobs that died since, unpaged (outside their handler, or with no context handed it).
    await dead.sweep().catch((err: unknown) => console.error('[grade] the dead grade jobs could not be read to page them; the next grade job looks again:', err));
    try {
      return await grade(job, ctx, handedOn);
    } catch (thrown) {
      const last = ctx !== undefined && isLastAttempt(ctx);
      // Held on its entrant's entry secrets (the header's `entry secrets`): retried while attempts remain, each logged,
      // never paged; on a fresh grade's last attempt the platform's fault, which the pipeline's grade stage never fails
      // the entry on (it puts back the status the attempt found).
      const err = thrown instanceof EntrySecretsUnopenedError && last && job.kind === 'grade' ? new EntrySecretsHeldFault(thrown) : thrown;
      if (ctx !== undefined && thrown instanceof EntrySecretsUnopenedError && !last) {
        (deps.log ?? ((line: string) => console.log(line)))(
          `[grade] job ${ctx.id} (${ctx.queue}) of submission ${job.submission_id} is held on attempt ${attemptWords(ctx)}, never failed: ${thrown.message}; pg-boss tries it again, and its last attempt pages`,
        );
      }
      // Dying for good (pg-boss retries it no more): paged, then the job's own error stands. A grade whose instance is
      // not drawn is not dying: the pipeline's grade stage hands it on (the header's `not drawn`).
      if (ctx !== undefined && (err instanceof PermanentJobError || last) && !(err instanceof InstanceNotDrawnError && job.kind === 'grade')) {
        await dead.dying(job, ctx, err).catch((e: unknown) => console.error(`[grade] ${ctx.id}: submission ${job.submission_id}'s ${job.kind} job died for good, and paging it failed; the next grade job's sweep pages it:`, e));
      }
      throw err;
    }
  };
}

// ---------------------------------------------------------------- code-fastest: the timing clock, the dev timing and the heat

/**
 * The sandbox a code-fastest timing reads CPU time on (GradeWorkerDeps.timingSandbox, which a test hands in, null for
 * none): by default the grader's own when it is the docker driver (a timing parent cgroup, sandbox/docker.ts) or the
 * k8s driver (the CPU launcher's readings, sandbox/k8s.ts openCpuClock); null on the process driver, which reads none.
 */
export function timingSandboxOf(deps: Pick<GradeWorkerDeps, 'sandbox' | 'timingSandbox'>): TimingSandbox | null {
  if (deps.timingSandbox !== undefined) return deps.timingSandbox;
  return deps.sandbox instanceof DockerSandbox || deps.sandbox instanceof K8sSandbox ? deps.sandbox : null;
}

/** `p`, or the signal's reason once it aborts first. */
function untilAborted(p: Promise<void>, signal: AbortSignal | undefined): Promise<void> {
  if (signal === undefined) return p;
  signal.throwIfAborted();
  return new Promise((resolve, reject) => {
    const onAbort = (): void => reject(signal.reason);
    signal.addEventListener('abort', onAbort, { once: true });
    void p.then(() => {
      signal.removeEventListener('abort', onAbort);
      resolve();
    });
  });
}

/**
 * The one CPU clock a worker process times on (the header's `code heat`): its timing sandbox's openCpuClock, opened at
 * the first timing and kept open, so a docker process leaves one empty timing cgroup behind (sandbox/docker.ts: a clock's
 * parent stays once it closes, where this process may not remove it), never one per grade; a k8s clock is a sum this
 * process holds (sandbox/k8s.ts K8sCpuClock) and leaves nothing. One timing at a time (exclusive): no two timed runs
 * count on the clock at once (docker: share its parent cgroup, whose usage is their CPU time). A clock that fails a read
 * is closed and left, and the next timing opens a fresh one. It knows which of its timings are heats (exclusive's
 * `holder`), so a dev grade's timing can tell it would wait on one (heatAhead) and not wait.
 */
export class ProcessCpuClock {
  readonly #base: TimingSandbox;
  #open: TimedSandbox | null = null;
  #tail: Promise<void> = Promise.resolve();
  /** The heats handed in that have not ended: holding the clock, or waiting for it. */
  #heats = 0;

  constructor(base: TimingSandbox) {
    this.#base = base;
  }

  /**
   * Run `fn` once every timing handed in before it has ended, handing it a sandbox whose openCpuClock is this clock (a
   * close of it leaves the clock open: grader/code-heat.ts openCodeTimer closes its timer). An abort of `signal` while it
   * waits throws the signal's reason, and nothing runs: it leaves the queue, the timings behind it waiting only for those
   * before it (a heat's wait given up at its expiry: the header's `hand-on`). `holder` says what the timing is: a `heat` (a code-heat job's,
   * which may hold the clock up to its job's expiry, server/jobs.ts CODE_HEAT_EXPIRY_SECONDS, or a hand-on's up to
   * CODE_HEAT_MAX_EXPIRY_SECONDS: the header's `hand-on`) counts in heatAhead from
   * the call until it ends, waiting included; a `timing` (a dev grade's, the default) does not.
   */
  async exclusive<T>(fn: (sandbox: TimingSandbox) => Promise<T>, signal?: AbortSignal, holder: 'heat' | 'timing' = 'timing'): Promise<T> {
    const before = this.#tail;
    let release!: () => void;
    const mine = new Promise<void>((resolve) => {
      release = resolve;
    });
    this.#tail = before.then(() => mine);
    if (holder === 'heat') this.#heats++;
    try {
      await untilAborted(before, signal);
      return await fn(sharedClockSandbox(this, this.#base));
    } finally {
      if (holder === 'heat') this.#heats--;
      release();
    }
  }

  /**
   * Whether a heat holds the clock or waits for it (exclusive's `holder`): a timing handed in now would wait for that heat
   * to end. A dev grade's timing never does (withProvisionalTiming).
   */
  get heatAhead(): boolean {
    return this.#heats > 0;
  }

  /** The open clock and its timed sandbox, opened now (in `runtime`'s image) if none is; its close() leaves it open. */
  lease(runtime: Runtime): TimedSandbox {
    const open = (this.#open ??= this.#base.openCpuClock(runtime));
    const drop = async (): Promise<void> => {
      if (this.#open !== open) return;
      this.#open = null;
      await open.clock.close().catch(() => undefined);
    };
    const guarded = async (read: () => Promise<bigint>): Promise<bigint> => {
      try {
        return await read();
      } catch (err) {
        await drop();
        throw err;
      }
    };
    return {
      clock: { source: open.clock.source, read: () => guarded(() => open.clock.read()), settled: () => guarded(() => open.clock.settled()), close: async () => undefined },
      sandbox: open.sandbox,
    };
  }

  /** Whether a clock is open now. */
  get isOpen(): boolean {
    return this.#open !== null;
  }

  /** Close the clock (a worker's stop); the next timing opens a fresh one. */
  async close(): Promise<void> {
    const open = this.#open;
    this.#open = null;
    await open?.clock.close();
  }
}

/**
 * The timing sandbox as ProcessCpuClock.exclusive hands it out: the base itself in every member (its methods bound to it,
 * so a class's private state answers, and `instanceof` holds), but its openCpuClock is the process's one clock (lease).
 */
function sharedClockSandbox(clock: ProcessCpuClock, base: TimingSandbox): TimingSandbox {
  const openCpuClock = (runtime: Runtime): TimedSandbox => clock.lease(runtime);
  return new Proxy(base, {
    get(target, prop) {
      if (prop === 'openCpuClock') return openCpuClock;
      const value: unknown = Reflect.get(target, prop, target);
      return typeof value === 'function' ? (value as (...args: unknown[]) => unknown).bind(target) : value;
    },
  });
}

const PROCESS_CPU_CLOCKS = new WeakMap<object, ProcessCpuClock>();

/** This process's one CPU clock on `sandbox` (ProcessCpuClock): the same for every grade and heat job handed that sandbox. */
export function processCpuClock(sandbox: TimingSandbox): ProcessCpuClock {
  let clock = PROCESS_CPU_CLOCKS.get(sandbox);
  if (clock === undefined) {
    clock = new ProcessCpuClock(sandbox);
    PROCESS_CPU_CLOCKS.set(sandbox, clock);
  }
  return clock;
}

/** Close this process's CPU clock on `sandbox`, if one is open (server/pipeline/index.ts, as the workers stop). */
export async function closeProcessCpuClock(sandbox: Sandbox | null): Promise<void> {
  if (sandbox !== null) await PROCESS_CPU_CLOCKS.get(sandbox)?.close();
}

/** What a dev grade's provisional timing reads (withProvisionalTiming). */
interface ProvisionalTimingInput {
  outcome: GradeOutcome;
  sub: Pick<typeof submission.$inferSelect, 'id' | 'receipt' | 'createdAt'>;
  plan: HarnessPlan;
  runtime: Runtime;
  snapshot: SnapshotSource;
  limits: CompetitionBundleT['limits'];
  rules: EligibilityRules;
  entry: EntryFacts;
  owner?: string;
  signal?: AbortSignal;
}

/**
 * A code-fastest dev grade with its provisional timing (the header's `code heat`): a grade that passed its gate timed
 * CODE_TIMING_DEV_ROUNDS times on the process's clock (code-heat.ts runProvisionalTiming, its outputs held to the
 * graded action log) and its score built again with the verdict (grade.ts scoreWithTiming); any other grade as it is.
 * With no timing sandbox in this process the grade is recorded untimed, and that is logged; so it is, at once, when a
 * heat holds the process's clock or waits for it (ProcessCpuClock.heatAhead): the timing would wait for the heat, which
 * may run past the grade job's own expiry. Behind another dev grade's timing it waits, as long as the job's signal
 * lets it. The signal stops the timing too (runProvisionalTiming): its run under way killed, nothing recorded.
 */
async function withProvisionalTiming(deps: GradeWorkerDeps, t: ProvisionalTimingInput): Promise<GradeOutcome> {
  const score = t.outcome.result;
  if (t.outcome.status !== 'finished' || score === null || score.performance.kind !== 'program/v1' || score.performance.passed !== true || t.outcome.action_log_sha256 === null) return t.outcome;
  const log = deps.log ?? ((line: string) => console.log(line));
  const timing = timingSandboxOf(deps);
  if (timing === null) {
    log(`[grade] submission ${t.sub.id}: its dev grade is recorded with no provisional timing: this process's ${deps.sandbox.kind} sandbox reads no CPU time (a timing runs on the docker driver or the k8s driver)`);
    return t.outcome;
  }
  const { runProvisionalTiming } = await import('./code-heat.ts');
  // No await between this read and exclusive below, which joins the clock's queue as it is called: no heat comes between.
  const clock = processCpuClock(timing);
  if (clock.heatAhead) {
    log(`[grade] submission ${t.sub.id}: its dev grade is recorded with no provisional timing: a timing heat holds this process's CPU clock (or waits for it), and a dev grade never waits on a heat`);
    return t.outcome;
  }
  const ms = receiptMs(t.sub);
  const entry: TimedEntry = {
    entry: t.sub.id,
    received_at: new Date(Number.isFinite(ms) ? ms : t.sub.createdAt.getTime()).toISOString(),
    action_log_sha256: t.outcome.action_log_sha256,
    snapshot: t.snapshot,
    image_digest: t.outcome.image_digest,
  };
  const verdict = await clock.exclusive(
    (sandbox) =>
      runProvisionalTiming({
        plan: t.plan,
        sandbox,
        runtime: t.runtime,
        limits: t.limits,
        workRoot: deps.workRoot,
        blobs: deps.blobs,
        entry,
        ...(t.owner === undefined ? {} : { owner: t.owner }),
        ...(t.signal === undefined ? {} : { signal: t.signal }),
      }),
    t.signal,
  );
  const timed = scoreWithTiming(score, verdict, t.entry, t.rules);
  return { ...t.outcome, result: timed.result, result_sha256: timed.result_sha256 };
}

/** What a judged dev grade's provisional judge heat reads (withProvisionalJudge). */
interface ProvisionalJudgeInput {
  outcome: GradeOutcome;
  /** The entry: its id, and its account and competition, which its artifact is recorded under (entry_artifact). */
  sub: Pick<typeof submission.$inferSelect, 'id' | 'userId' | 'competitionId'>;
  comp: { slug: string };
  /** The dev phase: whose kept judge keys the day's spend is read from (judgeKeysDir). */
  ph: { id: string };
  plan: HarnessPlan;
  /** The bundle's harness: where its judge directory is read (judgedTreesOf). */
  harness: ProgramHarnessT;
  judge: ProgramJudgeT;
  rules: EligibilityRules;
  entry: EntryFacts;
  signal?: AbortSignal;
}

/** A dev grade as withProvisionalJudge leaves it, and the judge heat record its verdict came from (null: the grade is recorded unjudged). */
interface ProvisionalJudged {
  outcome: GradeOutcome;
  judge_heat_sha256: string | null;
}

/**
 * A judged dev grade with its provisional judge verdict (the header's `provisional judge`): a grade that passed its
 * gate plays its artifact against every house anchor in both orders (provisionalJudgeHeat), its score built again with
 * the verdict (scoreWithJudge: performance.judge, provisional), to be linked to the run (run.judge_heat_sha256); any
 * other grade as it is. A grade its heat cannot judge is recorded unjudged and says so in the log.
 */
async function withProvisionalJudge(deps: GradeWorkerDeps, j: ProvisionalJudgeInput): Promise<ProvisionalJudged> {
  const score = j.outcome.result;
  const as: ProvisionalJudged = { outcome: j.outcome, judge_heat_sha256: null };
  if (j.outcome.status !== 'finished' || score === null || score.performance.kind !== 'program/v1' || score.performance.passed !== true || j.outcome.action_log_sha256 === null) return as;
  const log = deps.log ?? ((line: string) => console.log(line));
  const heat = await provisionalJudgeHeat(deps, {
    actionLog: { sha256: j.outcome.action_log_sha256, json: j.outcome.action_log_json },
    sub: j.sub,
    comp: j.comp,
    ph: j.ph,
    phaseSeed: j.plan.seed,
    harness: j.harness,
    judge: j.judge,
    ...(j.signal === undefined ? {} : { signal: j.signal }),
  });
  if ('unjudged' in heat) {
    log(`[grade] submission ${j.sub.id}: its dev grade is recorded with no provisional judge verdict: ${heat.unjudged}`);
    return as;
  }
  const judged = scoreWithJudge(score, heat.verdict, j.entry, j.rules);
  log(`[grade] submission ${j.sub.id}: its dev grade is judged provisionally against ${provisionalHeatWords(heat)}`);
  return { outcome: { ...j.outcome, result: judged.result, result_sha256: judged.result_sha256 }, judge_heat_sha256: heat.judge_heat_sha256 };
}

/** What a provisional judge heat reads (provisionalJudgeHeat): a dev grade's (withProvisionalJudge), or a kept dev run's again (rejudgeProvisional). */
interface ProvisionalHeatInput {
  /** The action log the artifact is read from; its JSON, when given, stored first (a grade's, ahead of the run that records it). */
  actionLog: { sha256: string; json: string | null };
  /** The entry: its id, and its account and competition, which its artifact is recorded under (entry_artifact). */
  sub: Pick<typeof submission.$inferSelect, 'id' | 'userId' | 'competitionId'>;
  comp: { slug: string };
  /** The dev phase: whose kept judge keys the day's spend is read from (judgeKeysDir). */
  ph: { id: string };
  /** The dev phase's seed, a u64 decimal: the plan's (a grade's), or the seed its run recorded (a rejudge's). */
  phaseSeed: string;
  /** The bundle's harness: where its judge directory is read (judgedTreesOf). */
  harness: ProgramHarnessT;
  judge: ProgramJudgeT;
  signal?: AbortSignal;
}

/**
 * Why a provisional heat judged nothing, for a rejudge to weigh against the verdict the run has (rejudgeProvisional):
 * `fault` the platform's (a judge call that faulted again after its one resend, a judge key masq did not mint, no LLM
 * gateway), so the job is retried; `budget` the daily cap, or a judge model with no price, so it is sent again another
 * UTC day; `other` the heat's own end on the artifact (no artifact or one the judge cannot read, too many calls with no
 * verdict, a model that cannot see images...).
 */
type ProvisionalUnjudgedCause = 'fault' | 'budget' | 'other';

/** A provisional heat's end: why it judged nothing, or its verdict and the record it is stored as, with what the log says of it. */
type ProvisionalHeat =
  | { unjudged: string; cause: ProvisionalUnjudgedCause }
  | {
      verdict: ProgramJudgeScoreT;
      judge_heat_sha256: string;
      /** The judge anchors it played, two calls each. */
      anchors: number;
      calls: number;
      invalid_calls: number;
      micro_usd: string;
      /** A heat on a ladder's: the adaptive rounds it played (a short day's fewer), of its ladder's, each of `games` games. */
      adaptive?: { rounds: number; of: number; games: number };
      /**
       * Present only when no heat was played: the verdict is an earlier entry's on the same artifact bytes, read from
       * its record (`judge_heat_sha256`; the header's `provisional reuse`), with no call sent, no key and no spend.
       */
      reused?: true;
    };

/**
 * A win rate's millionths as the 0..1 fraction they are, at every digit they hold: 868330 is '0.868330', 1000000
 * '1.000000' (six fraction digits, fixed, so an exact 870000 never reads as rounded). Integer arithmetic only. Every
 * printed win rate (the worker's log, grade-local's summary, verify-result's re-derivation) goes through it.
 */
export function winRateFraction(micro: number): string {
  const n = Math.round(micro);
  const abs = Math.abs(n);
  return `${n < 0 ? '-' : ''}${Math.floor(abs / 1_000_000)}.${String(abs % 1_000_000).padStart(6, '0')}`;
}

/** A judged provisional heat in the log's words: its anchors, its calls, what it spent, its record and the win rate in full; a reused verdict says so. */
function provisionalHeatWords(h: Exclude<ProvisionalHeat, { unjudged: string }>): string {
  if (h.reused === true) {
    return `the verdict of record ${h.judge_heat_sha256} on the same artifact bytes, reused with no judge call sent (${h.calls} calls, ${h.micro_usd} µUSD): win rate ${winRateFraction(h.verdict.win_rate_micro)}`;
  }
  const games = h.adaptive === undefined ? '' : ` and ${h.adaptive.rounds * h.adaptive.games} adaptive ladder games (${h.adaptive.rounds} of ${h.adaptive.of} rounds)`;
  return `${h.anchors} anchors${games} in ${h.calls} calls (${h.invalid_calls} with no verdict, ${h.micro_usd} µUSD, record ${h.judge_heat_sha256}): win rate ${winRateFraction(h.verdict.win_rate_micro)}`;
}

/**
 * One dev entry's provisional judge heat (the header's `provisional judge`): its artifact played against every house
 * anchor in both orders (grader/judge-heat.ts judgeProvisionalCalls: two an anchor), on a key of its own weighed first
 * against judge.dev_daily_usd net of what the competition's provisional heats spent this UTC day (the header's `judge
 * keys`), its record stored before its verdict is read from it. `unjudged`, with why and its cause, when the heat cannot judge it: no
 * gateway, no judge directory of the bundle's, no artifact or one the judge cannot read, a worst case past the daily
 * cap (past it only on other heats in flight, once it has waited up to JUDGE_KEY_WAIT_MS for them to settle: the
 * header's `judge keys`), a key that does not open, a second faulted call, or more calls with no verdict than judge.invalid_share_max
 * allows. Nothing is sent again, and nothing paged. The signal stops it too: its key retired, the error thrown.
 *
 * A bundle naming a ladder (judge.ladder) plays a v3 heat on it: the ladder read and held (grader/judge-ladder-tree.ts
 * readJudgeLadder; one that does not read judges nothing), the field the entry, the judge anchors and the rungs, the
 * anchors played once each and then the ladder's adaptive rounds (judgeHeatPlannedCalls). Its rounds degrade before it
 * goes unjudged: the most whole rounds whose worst case fits the cap alone, then, once the day's spend is read, the
 * most that fit what is left of it (its key's reservation shrunk to match); only when none fits is it held as today.
 *
 * An artifact the judge reads that is byte for byte one an earlier entry of the phase was judged on, on the current
 * judge and phase seed, takes that verdict with no heat played (reusedProvisionalVerdict; the header's `provisional
 * reuse`). Every heat's artifact that ends judged, reused or recorded unjudged is then written to the phase's
 * entry_artifact (recordProvisionalArtifact), a fault there logged and the heat kept.
 */
async function provisionalJudgeHeat(deps: GradeWorkerDeps, j: ProvisionalHeatInput): Promise<ProvisionalHeat> {
  const { judge } = j;
  const unjudged = (why: string, cause: ProvisionalUnjudgedCause = 'other'): ProvisionalHeat => ({ unjudged: why, cause });
  let trees: JudgedTrees;
  try {
    trees = await judgedTreesOf(deps, j.comp.slug, j.harness, judge);
  } catch (err) {
    if (err instanceof PermanentJobError) return unjudged(err.message);
    throw err;
  }
  const dir = readJudgeTree(trees.judgeDir, judge);
  if ('refused' in dir) return unjudged(dir.refused);
  // A bundle naming a ladder: its sealed ladder read and held (grader/judge-ladder-tree.ts), beside the competition's
  // judge directory (a sponsored one's materialized with it: judgedTreesOf), and the heat a v3 one on it. A ladder the image does not hold judges nothing, as a judge directory.
  let ladder: ProvisionalLadder | null = null;
  if (judge.ladder !== undefined) {
    const { judgeLadderBlock, readJudgeLadder } = await import('./judge-ladder-tree.ts');
    const read = readJudgeLadder(judgeLadderDirOf(deps, j.comp.slug, j.harness, judge.ladder, trees), judge, trees.judgeDir);
    if ('refused' in read) return unjudged(`its judge's ladder does not read: ${read.refused}`);
    ladder = { read, design: judge.ladder, block: judgeLadderBlock };
  }
  // The action log stored ahead of the run that records it (grader/record.ts recordGrade stores it again, as the same blob): the artifact is read through it.
  if (j.actionLog.json !== null) {
    const put = await deps.blobs.put(j.actionLog.json);
    if (put.sha256 !== j.actionLog.sha256) throw new Error(`submission ${j.sub.id}'s action log stored as ${put.sha256}, not ${j.actionLog.sha256}`);
  }
  const art = await readOutputFile(deps.blobs, j.actionLog.sha256, judge.artifact);
  if (art === null) return unjudged(`its outputs hold no ${judge.artifact}, the artifact the judge compares (the scorer's gate is to fail an entry that writes none)`);
  const refused = await judgeArtifactRefusal(judge.media, art);
  if (refused !== null) return unjudged(`the judge cannot read its ${judge.artifact} (${refused})`);
  // An earlier entry's verdict on the same bytes, on the current judge, taken with no call (the header's `provisional
  // reuse`): before any setup, broker or key. Else the heat is played as it always was.
  const heat = (await reusedProvisionalVerdict(deps, j, art, ladder)) ?? (await playProvisionalJudgeHeat(deps, j, dir, ladder, art));
  await recordProvisionalArtifact(deps, j, art, heat);
  return heat;
}

/** A provisional heat's ladder (judge.ladder) as provisionalJudgeHeat read and held it: what readJudgeLadder read, the bundle's design, and the block its setup builds. */
interface ProvisionalLadder {
  read: JudgeLadderInputs;
  design: NonNullable<ProgramJudgeT['ladder']>;
  block: typeof import('./judge-ladder-tree.ts').judgeLadderBlock;
}

/**
 * The verdict a provisional heat of `art` takes with no call (the header's `provisional reuse`): of the phase's other
 * entries judged on the same bytes (judgedSameArtifact, oldest first), the first whose record is keyed on the current
 * judge (provisionalRecordJudgeKey against provisionalJudgeKey), was drawn under this heat's phase seed, and holds a
 * verdict on the artifact that a regrade of this entry's run rebuilds (grader/regrade.ts judgeRecordVerdictOf: its
 * judge, seed and ladder held, the field's one entrant member on these bytes; judge-heat.ts judgeHeatVerdicts). Null on
 * a miss: no such entry, a field that played the artifact in no game, another judge or seed. A fault in the lookup is
 * logged with its full stack and is a miss too, so the heat is judged as it always was; the signal's abort is thrown.
 */
async function reusedProvisionalVerdict(deps: GradeWorkerDeps, j: ProvisionalHeatInput, art: ProgramOutputRead, ladder: ProvisionalLadder | null): Promise<ProvisionalHeat | null> {
  const log = deps.log ?? ((line: string) => console.log(line));
  try {
    const { judgedSameArtifact } = await import('../server/entries/screen/artifact.ts');
    const { judgeRecordVerdictOf, loadJudgeHeatRecord } = await import('./regrade.ts');
    const rows = await judgedSameArtifact(deps.db, j.ph.id, art.sha256);
    const entryId = j.sub.id.toLowerCase();
    const tried = new Set<string>();
    let key: string | null = null;
    for (const row of rows) {
      if (row.submissionId.toLowerCase() === entryId || tried.has(row.judgeHeatSha256)) continue;
      tried.add(row.judgeHeatSha256);
      j.signal?.throwIfAborted();
      key ??= await provisionalJudgeKey(j.judge);
      if ((await provisionalRecordJudgeKey(deps.blobs, row.judgeHeatSha256, j.judge)) !== key) continue;
      const record = await loadJudgeHeatRecord(deps.blobs, row.judgeHeatSha256);
      if (record.phase_seed !== j.phaseSeed) continue;
      let verdict: ProgramJudgeScoreT;
      try {
        verdict = judgeRecordVerdictOf(record, row.judgeHeatSha256, { id: `the grade of entry ${entryId}`, submission_id: entryId, seed: j.phaseSeed, artifact_sha256: art.sha256, artifact_bytes: art.size }, j.judge, ladder?.read).verdict;
      } catch (err) {
        // A record that judged the bytes in no game (a field under two members), or one a regrade would not hold: judged afresh.
        if (err instanceof RegradeError) continue;
        throw err;
      }
      log(
        `[grade] submission ${j.sub.id}: its ${j.judge.artifact} is byte for byte entry ${row.submissionId}'s (${art.sha256}), judged on the current judge in record ${row.judgeHeatSha256}: that verdict is reused and no judge call is sent`,
      );
      return { verdict, judge_heat_sha256: row.judgeHeatSha256, anchors: 0, calls: 0, invalid_calls: 0, micro_usd: '0', reused: true };
    }
    return null;
  } catch (err) {
    if (j.signal?.aborted === true) throw err;
    countEntryArtifactFault('lookup');
    log(`[grade] submission ${j.sub.id}: the lookup of an earlier verdict on its ${j.judge.artifact} ${art.sha256} failed, so it is judged afresh: ${err instanceof Error ? (err.stack ?? err.message) : String(err)}`);
    return null;
  }
}

/**
 * The entry's artifact written to its phase's entry_artifact once its heat ends (the header's `provisional reuse`): its
 * media, sha256, size and fingerprint (artifactFingerprint: a text's normalised sha256, an image's dHash), the record
 * its verdict is in, whether it was reused, and near_of (nearArtifactOf). A heat that judged nothing writes the row with
 * no record, unless it ended on the platform's fault or the daily cap: a run then keeps the verdict it had (a
 * rejudge's), or is judged again later, so the row is left as it was. Never throws: a fault is logged with its full
 * stack, and the heat stands.
 */
async function recordProvisionalArtifact(deps: GradeWorkerDeps, j: ProvisionalHeatInput, art: ProgramOutputRead, heat: ProvisionalHeat): Promise<void> {
  if ('unjudged' in heat && heat.cause !== 'other') return;
  const log = deps.log ?? ((line: string) => console.log(line));
  try {
    const { artifactFingerprint, nearArtifactOf, recordArtifact } = await import('../server/entries/screen/artifact.ts');
    const media = j.judge.media;
    const print = await artifactFingerprint(media, art.bytes, (line) => log(`[grade] submission ${j.sub.id}: ${line}`));
    const nearOf = await nearArtifactOf(deps.db, { phaseId: j.ph.id, userId: j.sub.userId, artifactSha256: art.sha256, normSha256: print.normSha256, dhash: print.dhash });
    await recordArtifact(deps.db, {
      submissionId: j.sub.id,
      phaseId: j.ph.id,
      competitionId: j.sub.competitionId,
      userId: j.sub.userId,
      media,
      artifactSha256: art.sha256,
      bytes: art.size,
      normSha256: print.normSha256,
      dhash: print.dhash,
      judgeHeatSha256: 'unjudged' in heat ? null : heat.judge_heat_sha256,
      reused: !('unjudged' in heat) && heat.reused === true,
      nearOf,
    });
  } catch (err) {
    countEntryArtifactFault('record');
    log(`[grade] submission ${j.sub.id}: its ${j.judge.artifact} ${art.sha256} could not be written to the phase's entry_artifact, and its heat stands: ${err instanceof Error ? (err.stack ?? err.message) : String(err)}`);
  }
}

/**
 * The provisional heat provisionalJudgeHeat plays on an artifact the judge reads when no earlier verdict is reused: the
 * setup, the daily cap's reservation, its key, its calls and its record (see provisionalJudgeHeat).
 */
async function playProvisionalJudgeHeat(deps: GradeWorkerDeps, j: ProvisionalHeatInput, dir: JudgeDirInputs, ladder: ProvisionalLadder | null, art: ProgramOutputRead): Promise<ProvisionalHeat> {
  const log = deps.log ?? ((line: string) => console.log(line));
  const now = deps.now ?? (() => new Date());
  const { judge } = j;
  const unjudged = (why: string, cause: ProvisionalUnjudgedCause = 'other'): ProvisionalHeat => ({ unjudged: why, cause });
  const jh = await import('./judge-heat.ts');
  const { JUDGE_CALL_ATTEMPTS, JudgeArtifactRefused, JudgeCallFault, judgeCapMicroUsd, judgePreflight, judgeSystemPrompt, openJudgeHeat } = await import('./judge-call.ts');
  const entryId = j.sub.id.toLowerCase();
  // Its setup at each number of adaptive rounds it may play (a ladder's 0 to its rounds, a short day's fewer; with no
  // ladder the one v2 setup): every one built before a key is claimed, so none can fail after.
  const full = ladder?.design.rounds ?? 0;
  const setups: JudgeHeatSetupT[] = [];
  try {
    for (let r = 0; r <= full; r++) {
      setups.push(
        jh.judgeHeatSetup({
          stage: 'provisional',
          phaseSeed: j.phaseSeed,
          judge,
          entries: [{ entry: entryId, artifact_sha256: art.sha256, artifact_bytes: art.size }],
          anchors: dir.anchors,
          ...(ladder === null ? {} : { rungs: ladder.read.rungs, ladder: ladder.block(ladder.read, { rounds: r, games: ladder.design.games, spread: ladder.design.spread }, art.sha256) }),
        }),
      );
    }
  } catch (err) {
    if (err instanceof jh.JudgeHeatError) return unjudged(`its heat does not set up: ${err.message}`);
    throw err;
  }
  // The judge anchors it plays (every one but its own artifact's), two calls each; on a ladder two more each adaptive game.
  const anchorsPlayed = setups[0]!.field.filter((m) => m.anchor && m.artifact_sha256 !== art.sha256).length;
  let rounds = full;
  let setup = setups[rounds]!;
  let planned = jh.judgeHeatPlannedCalls(setup);
  // Two an anchor; none when its artifact is the one anchor's bytes (the field then a single member; a ladder heat's
  // setup refuses that above, as it rates against at least one other anchor).
  if (planned === 0) return unjudged(`its ${judge.artifact} is byte for byte the house's only anchor, so there is nothing to play it against`);
  let broker: MasqJudgeKeyBroker | null;
  try {
    broker = await judgeBrokerOf(deps);
  } catch (err) {
    return unjudged(`the LLM gateway is not configured (${err instanceof Error ? err.message : String(err)})`, 'fault');
  }
  if (broker === null) return unjudged("this process has no LLM gateway (MAKEFUN_LLM_GATEWAY=masq, its URL and admin key) and no superbot-router pair (MAKEFUN_SUPERBOT_ROUTER_URL and MAKEFUN_SUPERBOT_ROUTER_KEY) to send the house judge's calls through", 'fault');
  // Every artifact a call may carry: the anchors, on a ladder its rungs, and the entry's.
  const artifacts = new Map(dir.artifacts);
  if (ladder !== null) for (const [sha256, bytes] of ladder.read.artifacts) artifacts.set(sha256, bytes);
  artifacts.set(art.sha256, art.bytes);
  const list = [...artifacts].map(([sha256, bytes]) => ({ sha256, bytes }));
  const at = now();
  const cap = `judge.dev_daily_usd ($${judge.dev_daily_usd}), the daily cap on the competition's provisional judge heats`;
  const capMicroUsd = judgeCapMicroUsd(judge.dev_daily_usd);
  // The worst case of `n` calls (judgePreflight's: every request at the dearest pair's price).
  const preflightOf = (n: number): ReturnType<typeof judgePreflight> =>
    judgePreflight({
      agent: judge.agent,
      system: judgeSystemPrompt(dir.prompt, setup.house_text),
      media: judge.media,
      house: setup.house_text,
      artifacts: list,
      calls: n,
      capMicroUsd,
      at: at.toISOString(),
    });
  // The heat's worst case, reserved in its key's file before the day's spend is read: a heat running beside it counts it.
  // Its planned calls and room for the one a fault sends again.
  let pre: ReturnType<typeof judgePreflight>;
  try {
    pre = preflightOf(planned + 1);
  } catch (err) {
    if (err instanceof JudgeArtifactRefused) return unjudged(`the judge refuses the house ${ladder === null ? 'anchor' : 'anchor or rung'} ${err.sha256}: ${err.message}`);
    throw err;
  }
  if (pre.budget.worstMicroUsd === null || pre.budget.requestMicroUsd === null) return unjudged(pre.hold?.why ?? `the judge's model ${judge.agent.model} has no price`, 'budget');
  // A ladder heat's graceful degradation: the most whole adaptive rounds, from its full design down to none, whose worst
  // case (its calls and the one sent again, JUDGE_CALL_ATTEMPTS requests each at the dearest pair's price, as the
  // preflight weighs it) fits the cap net of `spentMicroUsd`; null when even none does.
  const perRequest = pre.budget.requestMicroUsd;
  const worstOf = (r: number): bigint => perRequest * BigInt((jh.judgeHeatPlannedCalls(setups[r]!) + 1) * JUDGE_CALL_ATTEMPTS);
  const roundsFitting = (most: number, spentMicroUsd: bigint): number | null => {
    for (let r = most; r >= 0; r--) if (spentMicroUsd + worstOf(r) <= capMicroUsd) return r;
    return null;
  };
  if (ladder !== null && pre.hold !== null && pre.hold.kind === 'budget') {
    // Its full design alone passes the cap: as many rounds as fit an empty day, or none and the hold of none.
    const fit = roundsFitting(full, 0n);
    rounds = fit ?? 0;
    setup = setups[rounds]!;
    planned = jh.judgeHeatPlannedCalls(setup);
    pre = preflightOf(planned + 1);
  }
  if (pre.hold !== null && pre.hold.kind === 'budget') return unjudged(`its worst case alone passes ${cap}: ${pre.hold.why}`, 'budget');
  const keysDir = judgeKeysDir(deps.blobs, j.ph.id);
  const day = utcDayOf(at).day;
  // What each try claims with: the rounds and worst case that fit an empty day.
  const roundsAlone = rounds;
  const reservedAlone = String(pre.budget.worstMicroUsd);
  // A heat that does not fit only because other heats in flight reserve their worst case waits for them to settle
  // (JUDGE_KEY_WAIT_MS): its claim given back, then claimed and weighed again, on its own clock, made when it first waits.
  let clock: JudgeHeatClock | null = null;
  let waitFrom: number | null = null;
  let tries = 0;
  let mine: JudgeKeyFileT;
  let spent: bigint;
  for (;;) {
    rounds = roundsAlone;
    setup = setups[rounds]!;
    planned = jh.judgeHeatPlannedCalls(setup);
    mine = await claimJudgeKey(
      keysDir,
      {
        format: JUDGE_KEY_FORMAT,
        phase_id: j.ph.id.toLowerCase(),
        stage: 'provisional',
        at: at.toISOString(),
        key_id: null,
        label: null,
        reserved_micro_usd: reservedAlone,
        meter_micro_usd: '0',
        masq_micro_usd: null,
        open: true,
      },
      1,
    );
    // Held behind other heats in flight: what the day has settled, and how many of its other open keys are live.
    let behind: { settled: bigint; live: number } | null = null;
    try {
      const claimed = mine;
      const others = (await readJudgeKeys(keysDir, at)).filter((k) => k.attempt !== claimed.attempt && utcDayOf(new Date(k.at)).day === day);
      spent = others.reduce((sum, k) => sum + judgeKeySpend(k), 0n);
      if (ladder !== null) {
        // What is left of the day takes as many whole adaptive rounds as fit; with none fitting, the heat of none is held
        // below as a heat with no ladder is. Its key's reservation shrinks to the heat it plays.
        const fit = roundsFitting(rounds, spent);
        if ((fit ?? 0) < rounds) {
          rounds = fit ?? 0;
          setup = setups[rounds]!;
          planned = jh.judgeHeatPlannedCalls(setup);
          mine = await writeJudgeKey(keysDir, { ...mine, reserved_micro_usd: String(worstOf(rounds)) });
        }
        if (fit !== null && rounds < full) {
          log(
            `[grade] submission ${j.sub.id}: its provisional heat plays ${rounds} of its ladder's ${full} adaptive rounds (${planned} calls): the worst case of another would pass ${cap}, net of the ${spent} µUSD the day's provisional heats have spent`,
          );
        }
      }
      if (spent + worstOf(rounds) > capMicroUsd) {
        // A key open and claimed inside JUDGE_KEY_ORPHAN_MS is a heat in flight; an older one a killed heat's orphan.
        const nowMs = now().getTime();
        behind = {
          settled: others.reduce((sum, k) => sum + judgeKeySettled(k), 0n),
          live: others.filter((k) => k.open && nowMs - Date.parse(k.at) <= JUDGE_KEY_ORPHAN_MS).length,
        };
      }
    } catch (err) {
      // The claim holds the heat's worst case against the day for as long as its file stands: a heat that stops before
      // its key is minted gives it back, or every heat that failed here would count a whole heat it never played.
      const claimed = mine;
      await dropJudgeKey(keysDir, claimed).catch((e: unknown) =>
        log(`[grade] submission ${j.sub.id}: its provisional judge key claim ${claimed.attempt} could not be given back (${e instanceof Error ? (e.stack ?? e.message) : String(e)})`),
      );
      throw err;
    }
    // It fits; or it would not fit beside the day's settled spend alone, or nothing in flight will settle: weighed (and
    // held) below as it always was.
    if (behind === null || behind.settled + worstOf(0) > capMicroUsd || behind.live === 0) break;
    if (clock === null) {
      if (deps.judge?.clock !== undefined) clock = deps.judge.clock;
      else {
        const timers = await import('node:timers/promises');
        clock = { now: () => Date.now(), sleep: (ms, sig) => timers.setTimeout(ms, undefined, sig === undefined ? undefined : { signal: sig }) };
      }
    }
    const nowMs = clock.now();
    waitFrom ??= nowMs;
    // Past the wait, by its clock or by its tries (a clock that stands still): held below as it always was.
    if (nowMs - waitFrom >= JUDGE_KEY_WAIT_MS || tries >= Math.ceil(JUDGE_KEY_WAIT_MS / JUDGE_KEY_WAIT_MIN_MS)) {
      log(
        `[grade] submission ${j.sub.id}: its provisional heat waited ${nowMs - waitFrom} ms (${tries} tries) for the day's other heats in flight to settle, and its worst case still does not fit`,
      );
      break;
    }
    await dropJudgeKey(keysDir, mine);
    if (tries === 0) {
      log(
        `[grade] submission ${j.sub.id}: its provisional heat's worst case would pass ${cap} net of the ${spent} µUSD the day's provisional heats hold, of which ${behind.settled} µUSD is settled and the rest reserved by ${behind.live} heats in flight: its claim is given back, and it tries again for up to ${JUDGE_KEY_WAIT_MS} ms`,
      );
    }
    tries++;
    await clock.sleep(JUDGE_KEY_WAIT_MIN_MS + Math.floor(Math.random() * (JUDGE_KEY_WAIT_MAX_MS - JUDGE_KEY_WAIT_MIN_MS + 1)), j.signal);
    j.signal?.throwIfAborted();
  }
  if (tries > 0 && spent + worstOf(rounds) <= capMicroUsd) {
    log(`[grade] submission ${j.sub.id}: its provisional heat fits the day after ${tries} tries (${clock!.now() - waitFrom!} ms), net of the ${spent} µUSD the day's provisional heats hold`);
  }
  // Its planned calls, and room for the one a fault sends again.
  const calls = planned + 1;
  let opening: Awaited<ReturnType<typeof openJudgeHeat>>;
  try {
    opening = await openJudgeHeat({
      broker,
      key: { slug: j.comp.slug, phase: 'dev', attempt: mine.attempt, capUsd: judge.dev_daily_usd },
      agent: judge.agent,
      prompt: dir.prompt,
      media: judge.media,
      house: setup.house_text,
      artifacts: list,
      calls,
      spentMicroUsd: spent,
      blobs: deps.blobs,
      ...(deps.judge?.fetch === undefined ? {} : { fetch: deps.judge.fetch }),
      ...(deps.judge?.timeoutMs === undefined ? {} : { timeoutMs: deps.judge.timeoutMs }),
      now: () => now().getTime(),
      ...(j.signal === undefined ? {} : { signal: j.signal }),
    });
  } catch (err) {
    await dropJudgeKey(keysDir, mine);
    if (j.signal?.aborted === true) throw err;
    const { MasqBrokerError } = await import('./gateway/masq.ts');
    return unjudged(`its judge key did not open (${err instanceof Error ? err.message : String(err)})`, err instanceof MasqBrokerError || err instanceof JudgeCallFault ? 'fault' : 'other');
  }
  if (opening.held !== null) {
    if (opening.retired === null) await dropJudgeKey(keysDir, mine);
    else await writeJudgeKey(keysDir, retiredJudgeKey({ ...mine, key_id: opening.retired.id }, 0n, opening.retired));
    const held = opening.held;
    return held.kind === 'budget'
      ? unjudged(`the day's provisional heats have spent ${spent} µUSD, and this one's worst case would pass ${cap}: ${held.why}`, 'budget')
      : unjudged(held.why, held.kind === 'unpriced' ? 'budget' : 'other');
  }
  const heat = opening.heat;
  const minted = await writeJudgeKey(keysDir, { ...mine, key_id: heat.key.id, label: heat.key.label });
  const done: JudgeHeatCallT[] = [];
  // The kept calls' other sends (a backup's, or the primary a backup decided before), in memory until the record.
  const spares: JudgeHeatSpareT[] = [];
  let resent = 0;
  const stopped: { failed: string | null; cause: ProvisionalUnjudgedCause } = { failed: null, cause: 'other' };
  const fault = (s: JudgeSentT): boolean => !s.ok && s.err instanceof JudgeCallFault;
  const { JUDGE_BACKUP } = await import('./judge-backup.ts');
  const formsSeen = judgeFormsSeenOf(deps);
  // Its seat in the platform's one budget of judge sends in flight (the header's `judge heat`), held while it sends.
  const seat = await judgePoolSeatOf(deps, heat.key.label, 'practice', (line) => log(`[grade] submission ${j.sub.id}: provisional ${line}`));
  try {
    // Its calls up to min(its width, its share of JUDGE_POOL_BUDGET) at once, each kept in planned order, the last of a batch backed up (sendJudgeHeatCalls).
    await sendJudgeHeatCalls({
      heat,
      setup,
      calls: done,
      concurrency: deps.judge?.concurrency ?? JUDGE_HEAT_CONCURRENCY,
      ...(seat === null ? {} : { seat }),
      ...(j.signal === undefined ? {} : { signal: j.signal }),
      backup: deps.judge?.backup === undefined ? JUDGE_BACKUP : deps.judge.backup,
      ...(deps.judge?.clock === undefined ? {} : { clock: deps.judge.clock }),
      ...(formsSeen === undefined ? {} : { formsSeen }),
      callsTotal: planned,
      // Its one fault re-send's requests (the key's planned + 1 calls), held back from a backup while unspent.
      reserveRequests: () => (resent === 0 ? JUDGE_CALL_ATTEMPTS : 0),
      log: (line) => log(`[grade] submission ${j.sub.id}: provisional ${line}`),
      doomed: (ahead) =>
        ahead.some((s) => !s.ok && !fault(s)) ||
        resent + ahead.filter(fault).length > 1 ||
        jh.judgeHeatInvalidShareOver(done.filter((c) => c.verdict === null).length + ahead.filter((s) => s.ok && s.answer.verdict === null).length, planned, judge.invalid_share_max),
      take: async (next, sent, callSpares) => {
        if (!sent.ok) {
          const err = sent.err;
          if (!(err instanceof JudgeCallFault)) throw err;
          if (j.signal?.aborted === true) throw j.signal.reason instanceof Error ? j.signal.reason : err;
          if (resent === 0) {
            log(`[grade] submission ${j.sub.id}: provisional judge call ${done.length + 1} of ${planned} faulted (${err.message}): it is sent again, the heat's one`);
            resent = 1;
            return 'again';
          }
          stopped.failed = `call ${done.length + 1} of ${planned} faulted (${err.message}) after the heat had sent one faulted call again`;
          stopped.cause = 'fault';
          return 'stop';
        }
        try {
          done.push(jh.judgeHeatCallOf(next, sent.answer));
        } catch (err) {
          if (!(err instanceof jh.JudgeHeatError)) throw err;
          stopped.failed = err.message;
          return 'stop';
        }
        spares.push(...callSpares);
        const invalid = done.filter((c) => c.verdict === null).length;
        if (jh.judgeHeatInvalidShareOver(invalid, planned, judge.invalid_share_max)) {
          stopped.failed = `${invalid} of its heat's ${planned} calls came back with no verdict, over judge.invalid_share_max ${judge.invalid_share_max}`;
          return 'stop';
        }
        return 'kept';
      },
    });
  } finally {
    // Its seat given back whatever came of the heat (it never throws).
    await seat?.close();
    // Retired whatever came of the heat, once every call in flight settled; what it spent kept against the day's cap.
    const retired = await heat.retire().catch((err: unknown) => {
      log(`[grade] submission ${j.sub.id}: its provisional judge key ${heat.key.label} could not be retired (${err instanceof Error ? err.message : String(err)}): masq lets it lapse`);
      return null;
    });
    if (retired !== null && retired.flags.length > 0) log(`[grade] submission ${j.sub.id}: retired its provisional judge key ${heat.key.label}: ${retired.flags.join('; ')}`);
    await writeJudgeKey(keysDir, retired === null ? { ...minted, meter_micro_usd: String(heat.meterMicroUsd()) } : retiredJudgeKey(minted, heat.meterMicroUsd(), retired));
  }
  if (stopped.failed !== null) return unjudged(stopped.failed, stopped.cause);
  let record: ReturnType<typeof jh.judgeHeatRecordOf>;
  try {
    record = jh.judgeHeatRecordOf(setup, done, spares);
  } catch (err) {
    if (!(err instanceof jh.JudgeHeatError)) throw err;
    return unjudged(err.message);
  }
  const digest = jh.judgeHeatRecordDigest(record);
  const put = await deps.blobs.put(digest.json);
  if (put.sha256 !== digest.sha256) throw new Error(`submission ${j.sub.id}'s provisional judge heat record stored as ${put.sha256}, not ${digest.sha256}`);
  const verdict = jh.judgeHeatEntryVerdicts(record).get(entryId);
  if (verdict === undefined) throw new Error(`submission ${j.sub.id}'s provisional judge heat record ${digest.sha256} holds no verdict on it`);
  return {
    verdict,
    judge_heat_sha256: digest.sha256,
    anchors: anchorsPlayed,
    calls: record.calls.length,
    invalid_calls: record.invalid_calls,
    micro_usd: record.totals.micro_usd,
    ...(ladder === null ? {} : { adaptive: { rounds, of: full, games: ladder.design.games } }),
  };
}

// ---------------------------------------------------------------- the provisional rejudge

/**
 * What a provisional verdict was judged on (the header's `provisional rejudge`): the record's format, the house judge's
 * model call and directory (agent, judge_sha256), what it reads (media, artifact), the share of calls it may leave with
 * no verdict, and the house text its requests were built from. A heat setup or a stored record holds every one of them.
 */
export type ProvisionalJudgeOn = Pick<JudgeHeatSetupT, 'format' | 'agent' | 'judge_sha256' | 'media' | 'artifact' | 'invalid_share_max' | 'house_text'> & {
  /** A heat on a ladder's (a v3 record's): the sealed ladder and its adaptive design. */
  ladder?: Pick<JudgeHeatLadderT, 'ladder_sha256' | 'rounds' | 'games' | 'spread'>;
};

/**
 * The key of what a provisional verdict was judged on (ProvisionalJudgeOn): two verdicts share one scale exactly when
 * their keys are equal. One with no ladder hashes the fields it always has, so a bundle naming none keeps its key; one on
 * a ladder (format v3) hashes its ladder's digest and design beside them.
 */
export function provisionalJudgeKeyOf(on: ProvisionalJudgeOn): string {
  const key = {
    format: on.format,
    agent: on.agent,
    judge_sha256: on.judge_sha256,
    media: on.media,
    artifact: on.artifact,
    invalid_share_max: on.invalid_share_max,
    house_text: on.house_text,
  };
  if (on.ladder === undefined) return canonicalSha256(key);
  return canonicalSha256({ ...key, ladder: { ladder_sha256: on.ladder.ladder_sha256, rounds: on.ladder.rounds, games: on.ladder.games, spread: on.ladder.spread } });
}

/**
 * The key (provisionalJudgeKeyOf) of a provisional heat run now on `judge`, a bundle's: the current record format and
 * house text, and when it names a ladder, the ladder's format (JUDGE_HEAT_FORMAT_V3), digest and design.
 */
export async function provisionalJudgeKey(judge: ProgramJudgeT): Promise<string> {
  const { JUDGE_HEAT_FORMAT, JUDGE_HEAT_FORMAT_V3 } = await import('./judge-heat.ts');
  const { JUDGE_HOUSE_TEXT } = await import('./judge-call.ts');
  const ladder = judge.ladder;
  return provisionalJudgeKeyOf({
    format: ladder === undefined ? JUDGE_HEAT_FORMAT : JUDGE_HEAT_FORMAT_V3,
    agent: judge.agent,
    judge_sha256: judge.judge_sha256,
    media: judge.media,
    artifact: judge.artifact,
    invalid_share_max: judge.invalid_share_max,
    house_text: { ...JUDGE_HOUSE_TEXT },
    ...(ladder === undefined ? {} : { ladder: { ladder_sha256: ladder.ladder_sha256, rounds: ladder.rounds, games: ladder.games, spread: ladder.spread } }),
  });
}

/**
 * The key (provisionalJudgeKeyOf) of the provisional heat record `sha256` a dev run links, or null when it is no
 * provisional record this store holds whole (missing, corrupt, refused, or a final heat's): such a run is judged again.
 * Given the bundle's `judge`, a record on its ladder that played fewer adaptive rounds than the ladder names (a short
 * day's, provisionalJudgeHeat) is keyed at the ladder's rounds: it is on the current judge, so it is not paid for again.
 */
export async function provisionalRecordJudgeKey(blobs: Pick<BlobStore, 'get'>, sha256: string, judge?: ProgramJudgeT): Promise<string | null> {
  const { loadJudgeHeatRecord } = await import('./regrade.ts');
  try {
    const record = await loadJudgeHeatRecord(blobs, sha256);
    if (record.stage !== 'provisional') return null;
    const on = record.ladder;
    const design = judge?.ladder;
    if (on !== undefined && design !== undefined && on.ladder_sha256 === design.ladder_sha256 && on.games === design.games && on.spread === design.spread && on.rounds < design.rounds) {
      return provisionalJudgeKeyOf({ ...record, ladder: { ...on, rounds: design.rounds } });
    }
    return provisionalJudgeKeyOf(record);
  } catch (err) {
    if (err instanceof RegradeError) return null;
    throw err;
  }
}

/** How a provisional rejudge ended (rejudgeProvisional): judged on the current judge, recorded unjudged, or nothing written and why. */
export type ProvisionalRejudgeEnd =
  | { kind: 'judged'; run_id: string; judge_heat_sha256: string; win_rate_micro: number; result_sha256: string }
  | { kind: 'unjudged'; run_id: string; why: string; result_sha256: string }
  | { kind: 'skipped'; run_id: string; why: string };

/**
 * A kept dev run's provisional verdict judged again on its bundle's current judge (the header's `provisional rejudge`;
 * server/jobs.ts GradeJob `rejudge`): the run its job names, a finished grade run of the job's entry on the dev phase
 * that passed its gate, plays its artifact in a provisional heat (provisionalJudgeHeat: the anchors, the judge
 * directory, the house text, the daily cap, the record stored before its verdict is read), and its score is built again
 * with the new verdict and written with the link to the new record, in one transaction held to the result it had, as a
 * new dev grade would record it. A heat that judges nothing records the run unjudged (its old verdict and link dropped),
 * as a dev grade is recorded unjudged, unless it ended on the platform's fault or the daily cap (ProvisionalUnjudgedCause):
 * the verdict is kept and nothing written, a fault thrown for the job to retry, the cap skipped for a later UTC day's
 * sweep. Nothing is written for a run already judged on the current judge (its record's
 * key is the job's), for a run that is no passed grade, or for an unjudged run the heat leaves unjudged. A final
 * phase's run is refused (PermanentJobError): its verdict is its heat's.
 */
async function rejudgeProvisional(
  deps: GradeWorkerDeps,
  r: { job: JobPayload<'grade-dev'>; sub: typeof submission.$inferSelect; ph: typeof phase.$inferSelect; comp: typeof competition.$inferSelect; bundle: CompetitionBundleT; signal?: AbortSignal },
): Promise<ProvisionalRejudgeEnd> {
  const { db, blobs } = deps;
  const log = deps.log ?? ((line: string) => console.log(line));
  const runId = r.job.reproduces_run_id;
  const what = `run ${runId ?? '?'}'s provisional rejudge (entry ${r.sub.id}, ${r.comp.slug})`;
  if (runId === null) throw new PermanentJobError(`${what}: the job names no run`);
  if (r.ph.key !== 'dev') throw new PermanentJobError(`${what}: phase ${r.ph.id} is the ${r.ph.key} phase, and only a dev run's provisional verdict is judged again (a final run's verdict is its phase's judge heat's)`);
  const harness = r.bundle.harness;
  if (harness.kind !== 'program/v1' || harness.judge === undefined) throw new PermanentJobError(`${what}: ${r.comp.slug}'s bundle names no judge heat, so it has no provisional verdict to judge again`);
  const judge = harness.judge;
  const [row] = await db.select().from(run).where(eq(run.id, runId));
  if (row === undefined) throw new PermanentJobError(`${what}: run ${runId} does not exist`);
  if (row.submissionId !== r.sub.id || row.phaseId !== r.ph.id || row.kind !== 'grade') throw new PermanentJobError(`${what}: run ${runId} is no grade run of entry ${r.sub.id} on phase ${r.ph.id}`);
  const skipped = (why: string): ProvisionalRejudgeEnd => {
    log(`[grade] ${what}: nothing is written: ${why}`);
    return { kind: 'skipped', run_id: row.id, why };
  };
  const parsed = Score.safeParse(row.result);
  const score = parsed.success ? parsed.data : null;
  const perf = score?.performance;
  if (row.status !== 'finished' || score === null || perf?.kind !== 'program/v1' || perf.passed !== true || row.actionLogSha256 === null || row.seed === null) {
    return skipped('it is no finished grade that passed its gate with an action log and a seed, so it carries no provisional verdict');
  }
  const key = await provisionalJudgeKey(judge);
  if (r.job.rejudge !== undefined && r.job.rejudge.judge_key !== key) log(`[grade] ${what}: the bundle's judge changed since the job was sent (key ${r.job.rejudge.judge_key}): it is judged on the judge it names now (key ${key})`);
  if (perf.judge !== undefined && row.judgeHeatSha256 !== null && (await provisionalRecordJudgeKey(blobs, row.judgeHeatSha256, judge)) === key) {
    return skipped(`it is judged on the current judge already (record ${row.judgeHeatSha256})`);
  }
  const heat = await provisionalJudgeHeat(deps, {
    actionLog: { sha256: row.actionLogSha256, json: null },
    sub: r.sub,
    comp: r.comp,
    ph: r.ph,
    phaseSeed: row.seed,
    harness,
    judge,
    ...(r.signal === undefined ? {} : { signal: r.signal }),
  });
  const entry: EntryFacts = { house: standingsHouse(r.sub), baseline: r.sub.baseline };
  const rules = eligibilityRulesOf(r.bundle);
  if ('unjudged' in heat && perf.judge === undefined && row.judgeHeatSha256 === null) return skipped(`it stays unjudged: ${heat.unjudged}`);
  // A verdict is never dropped for the platform's fault or the cap: a fault is retried, the cap waits for another day.
  if ('unjudged' in heat && heat.cause === 'fault') {
    log(`[grade] ${what}: nothing is written, its verdict kept, and the job is retried: ${heat.unjudged}`);
    throw new Error(`${what}: its heat could not judge it (${heat.unjudged}), the platform's fault: its verdict is kept and the job retried`);
  }
  if ('unjudged' in heat && heat.cause === 'budget') return skipped(`kept its verdict: ${heat.unjudged}; the sweep sends it again on a later UTC day`);
  const next = 'unjudged' in heat ? { ...scoreWithJudge(score, null, entry, rules), judge_heat_sha256: null } : { ...scoreWithJudge(score, heat.verdict, entry, rules), judge_heat_sha256: heat.judge_heat_sha256 };
  // An attempt given up writes nothing: its retry judges again (the record it stored stays, unlinked).
  r.signal?.throwIfAborted();
  await db.transaction(async (tx) => {
    const updated = await tx
      .update(run)
      .set({ result: next.result, resultSha256: next.result_sha256, judgeHeatSha256: next.judge_heat_sha256 })
      .where(and(eq(run.id, row.id), eq(run.resultSha256, row.resultSha256 ?? '')))
      .returning({ id: run.id });
    // A run written since it was read (a regrade, or another rejudge): the retry judges it as it now stands.
    if (updated.length === 0) throw new Error(`${what}: run ${row.id} changed while its heat ran`);
    await recordLiveChange(tx, { ...GRADE_CHANGE, scopeId: r.comp.id });
  });
  if ('unjudged' in heat) {
    log(`[grade] ${what}: it is recorded with no provisional judge verdict (its verdict${row.judgeHeatSha256 === null ? '' : ` and record ${row.judgeHeatSha256}`} dropped), as a dev grade is: ${heat.unjudged}`);
    return { kind: 'unjudged', run_id: row.id, why: heat.unjudged, result_sha256: next.result_sha256 };
  }
  log(`[grade] ${what}: judged provisionally again on the current judge (key ${key}) against ${provisionalHeatWords(heat)}${row.judgeHeatSha256 === null ? '' : `, in place of record ${row.judgeHeatSha256}`}`);
  return { kind: 'judged', run_id: row.id, judge_heat_sha256: heat.judge_heat_sha256, win_rate_micro: heat.verdict.win_rate_micro, result_sha256: next.result_sha256 };
}

/** How often a code-heat job whose phase is still grading looks again (the header's `code heat`): at its next slot of this length. */
export const CODE_HEAT_RECHECK_MS = 5 * 60_000;

/**
 * The context a code-heat job is handed (JobQueue.work's): its id names its scratch's owner, its signal stops the heat
 * (the run under way killed, never kept), and its expiry is what the heat's runs must end before, the rest handed on
 * (the header's `hand-on`).
 */
export type CodeHeatJobContext = Pick<JobContext, 'id'> & Partial<Pick<JobContext, 'retryCount' | 'retryLimit' | 'signal' | 'expiresAt'>>;

/**
 * The most runs a heat makes (the header's `hand-on`; grader/code-heat.ts the stages): the warm-up and main rounds over a
 * field of `field` entries and the control, then the playoff rounds over as many finalists as it can take (`places`,
 * codeHeatPlaces, and no more than the field; none under two) and the control. A main round that leaves fewer entries
 * ranked names fewer finalists, so the heat makes at most this many.
 */
export function codeHeatPlannedRuns(timing: Pick<ProgramTimingT, 'warmup_rounds' | 'rounds' | 'playoff_rounds'>, field: number, places: number): number {
  if (!Number.isSafeInteger(field) || field < 0 || !Number.isSafeInteger(places) || places < 0) throw new RangeError(`a heat of ${field} entries and ${places} finalist places: counts`);
  if (field === 0) return 0;
  const most = Math.min(field, places);
  const finalists = timing.playoff_rounds > 0 && most >= 2 ? most : 0;
  return (timing.warmup_rounds + timing.rounds) * (field + 1) + (finalists === 0 ? 0 : timing.playoff_rounds * (finalists + 1));
}

/**
 * The longest one run of a heat takes, in ms (the header's `hand-on`): under one run per case (grader/program.ts
 * executeProgram), each case's time cap (its reference manifest's, programCases) and server/proposals/checks.ts
 * PACK_CASE_OVERHEAD_MS for its containers' start and exit; under one whole run, the competition's wall budget and one
 * case's overhead. The control's run goes over the same cases, so it takes as long at most. A manifest that does not
 * read is ScorerError, as it is to the heat's first run.
 */
export function codeHeatRunMs(setup: ProgramSetup, limits: Pick<CompetitionBundleT['limits'], 'wall_budget_sec'>): number {
  if (setup.harness.cases !== 'per-file') return limits.wall_budget_sec * 1000 + PACK_CASE_OVERHEAD_MS;
  return programCases(programPaths(setup).referenceDir).reduce((ms, c) => ms + c.time_cap_ms + PACK_CASE_OVERHEAD_MS, 0);
}

/** One entry of a recorded heat, as its grade run now stands. */
export interface CodeHeatEntryOutcome {
  submission_id: string;
  run_id: string;
  /** `timed`: its timing is on its score; TIMING_OUTPUTS_DIFFER: a timed run wrote other outputs, and it is unranked. */
  verdict: 'timed' | typeof TIMING_OUTPUTS_DIFFER;
  /** Its timing's rank key (null when unranked). */
  trimmed_mean_cpu_us: number | null;
  rounds: number | null;
  /** The run's result_sha256 after the heat. */
  result_sha256: string;
}

/** What a code-heat job recorded on a timing heat (the header's `code heat`). */
export interface CodeHeatOutcome {
  kind: 'timing';
  phase_id: string;
  /** The heat record's sha256: its blob's name, and every timed run's run.code_heat_sha256. */
  heat_sha256: string;
  /** Where the CPU time was read (CpuClock.source: the record's, the clock of its first run), how many runs the heat made, and its finalists. */
  cpu_source: string;
  runs: number;
  /**
   * How many of the runs an earlier attempt of the heat measured and kept, taken as they stood (the header's `resume`):
   * 0 when this attempt timed every one.
   */
  kept_runs: number;
  /** Every clock the record's runs were read on, cpu_source first: more than one when an attempt resumed on a fresh clock. */
  cpu_sources: string[];
  finalists: string[];
  /** How long the heat ran, in ms (its runs, not the wait for the clock). */
  wall_ms: number;
  /** Every entry of the field, in receipt order. */
  entries: CodeHeatEntryOutcome[];
}

/** A due phase whose heat is a timing heat, with its timing (createProgramHeatHandler): what timeCodeHeat times. */
type TimingHeatDue = Extract<CodeHeatDue, { kind: 'due' }> & { timing: ProgramTimingT };

/** A due phase whose heat is a judge heat, with its judge (createProgramHeatHandler): what judgeCodeHeat judges. */
type JudgeHeatDue = Extract<CodeHeatDue, { kind: 'due' }> & { judge: ProgramJudgeT };

/** What a code-heat job recorded, by its heat's kind: a timing heat's (CodeHeatOutcome) or a judge heat's (JudgeHeatOutcome). */
export type ProgramHeatOutcome = CodeHeatOutcome | JudgeHeatOutcome;

/**
 * The code-heat job handler (the header's `code heat`), for a program-heat final of either kind (finalize.ts
 * programHeatPhaseOf): a code-fastest final's field timed in one heat on the process's clock, or a judged final's
 * judged in one by the house judge (judgeCodeHeat, the header's `judge heat`); either way its record stored, and each
 * field entry's grade run written its score with its verdict and the link to the record. Null when it recorded
 * nothing: the phase is no program-heat final, is not locked, has nothing owed, or is still grading (the job then hands
 * itself on to its next CODE_HEAT_RECHECK_MS slot on deps.jobs), the heat's runs would outlast the attempt (it times
 * those that fit, keeps them and hands the rest on: the header's `hand-on`), the attempt waited for the clock (or a
 * scrape heat holding the host) until its expiry less the slack (it hands on from the wait, timing nothing:
 * codeHeatWait, handOnCodeHeatWait), or a judge heat is held at its opening (it hands on an hour later: the header's
 * `judge heat`). Throws PermanentJobError on what no retry mends (no timing sandbox here, a field run graded under
 * another plan, a judge heat that failed); anything else (a clock that does not read, a sandbox that fails, a record
 * that does not hold, a gateway that does not answer) is the house's fault, and the job is retried.
 */
export function createProgramHeatHandler(deps: GradeWorkerDeps): (data: JobPayload<'code-heat'>, ctx?: CodeHeatJobContext) => Promise<ProgramHeatOutcome | null> {
  return programHeatHandler(deps, true);
}

/**
 * createProgramHeatHandler for a code-fastest final alone, its outcome a timing heat's: a TypeError, judging nothing,
 * on a phase whose heat is a judge heat.
 */
export function createCodeHeatHandler(deps: GradeWorkerDeps): (data: JobPayload<'code-heat'>, ctx?: CodeHeatJobContext) => Promise<CodeHeatOutcome | null> {
  const handle = programHeatHandler(deps, false);
  return async (data, ctx) => {
    const out = await handle(data, ctx);
    if (out?.kind === 'judge') throw new TypeError(`phase ${out.phase_id}'s heat is a judge heat: createProgramHeatHandler judges it`);
    return out;
  };
}

/** The code-heat job handler (createProgramHeatHandler); with `judges` false, one that refuses a judge heat before judging (createCodeHeatHandler). */
function programHeatHandler(deps: GradeWorkerDeps, judges: boolean): (data: JobPayload<'code-heat'>, ctx?: CodeHeatJobContext) => Promise<ProgramHeatOutcome | null> {
  const { db } = deps;
  const log = deps.log ?? ((line: string) => console.log(line));
  const now = deps.now ?? (() => new Date());
  // The heats whose hand-on this process paged as ending past their result deadline (the header's `late`), when.
  const late: LatePaged = new Map();
  // The competitions whose held judge heat this process paged (the header's `judge heat`), when: once an hour each.
  const held: HoldPaged = new Map();
  return async (input, ctx) => {
    const data = CodeHeatJob.parse(input);
    const jobKey = ctx?.id ?? uuidv7();
    const { codeHeatDue } = await import('../server/competitions/lifecycle/finalize.ts');
    const first = await codeHeatDue(db, data.phase_id);
    if (first.kind === 'waiting') {
      if (deps.jobs === undefined) {
        log(`[code-heat] ${jobKey}: the heat of phase ${data.phase_id} waits (${first.why}), and no queue is handed in to look again on`);
        return null;
      }
      const slot = Math.floor(now().getTime() / CODE_HEAT_RECHECK_MS) + 1;
      const at = new Date(slot * CODE_HEAT_RECHECK_MS);
      const id = codeHeatJobId(data.phase_id, `wait:${slot}`);
      await sendCodeHeat(deps.jobs, data.phase_id, { id, startAfter: at });
      log(`[code-heat] ${jobKey}: the heat of phase ${data.phase_id} waits: ${first.why}; it looks again at ${at.toISOString()} (job ${id})`);
      return null;
    }
    if (first.kind === 'none') {
      log(`[code-heat] ${jobKey}: nothing to ${first.heat === 'judge' ? 'judge' : 'time'}: ${first.why}`);
      await dropCodeHeatPartial(deps, data.phase_id, `[code-heat] ${jobKey}`);
      return null;
    }
    if (first.heat.kind === 'judge') {
      if (!judges) throw new TypeError(`phase ${data.phase_id}'s heat is a judge heat: createProgramHeatHandler judges it`);
      // No clock and no sandbox: its calls go to the house judge over the network (the header's `judge heat`).
      return judgeCodeHeat(deps, { ...first, judge: first.heat.judge }, jobKey, ctx, held);
    }
    const firstTimed: TimingHeatDue = { ...first, timing: first.heat.timing };
    const timing = timingSandboxOf(deps);
    if (timing === null) {
      throw new PermanentJobError(`the final phase of ${first.comp.slug} is due its timing heat, and this process's ${deps.sandbox.kind} sandbox reads no CPU time: a heat runs on the docker driver or the k8s driver (MAKEFUN_SANDBOX docker or k8s)`);
    }
    // Its waits before its runs end at its expiry less the slack, and the heat hands on then (the header's `hand-on`):
    // with no expiry or no queue to hand on to, it waits as long as its attempt's signal lets it.
    const jobs = deps.jobs;
    const wait = ctx?.expiresAt === undefined || jobs === undefined ? null : codeHeatWait(ctx.expiresAt, now, ctx.signal);
    let latest = firstTimed;
    let waitingOn = "this process's CPU clock, another timing holding it";
    try {
      // Held as a heat: while it holds the clock or waits for it, a dev grade's timing does not wait (withProvisionalTiming).
      return await processCpuClock(timing).exclusive(
        async (sandbox) => {
          // Read again under the clock: another job of this process may have timed the phase while this one waited for it.
          const due = await codeHeatDue(db, data.phase_id);
          if (due.kind !== 'due') {
            wait?.end();
            log(`[code-heat] ${jobKey}: nothing to time once the clock was free: ${due.why}`);
            if (due.kind === 'none') await dropCodeHeatPartial(deps, data.phase_id, `[code-heat] ${jobKey}`);
            return null;
          }
          // A bundle that turned to a judge heat while this one waited: the retry judges it, off the clock.
          if (due.heat.kind !== 'timing') throw new Error(`phase ${data.phase_id}'s heat turned from a timing heat to a ${due.heat.kind} heat while its job waited for the clock: the job's retry takes it as it now stands`);
          const timed: TimingHeatDue = { ...due, timing: due.heat.timing };
          latest = timed;
          // No timing beside a scrape heat holding this host (the header's `scrape/v1`). Given up as the clock came, its
          // wait was the clock's.
          if (wait?.signal.aborted !== true) waitingOn = 'a scrape heat holding this host';
          await scrapeHostQuiet(deps, `the timing heat of ${due.comp.slug}'s final phase (job ${jobKey})`, wait?.signal ?? ctx?.signal);
          // Its waits are over: from here its runs stop for its expiry between runs (timeCodeHeat).
          wait?.end();
          return timeCodeHeat(deps, timed, sandbox, jobKey, ctx, late);
        },
        wait?.signal ?? ctx?.signal,
        'heat',
      );
    } catch (err) {
      if (wait === null || jobs === undefined || !wait.gaveUp(err)) throw err;
      // Out of the clock's queue (exclusive's abort) or off the clock: handed on, never failed by its expiry.
      return handOnCodeHeatWait(deps, jobs, latest, jobKey, { on: waitingOn, until: wait.until, endsAt: wait.endsAt }, late);
    } finally {
      wait?.end();
    }
  };
}

/** The longest one timer waits (setTimeout's most, 2^31 - 1 ms): a longer wait is several. */
const TIMER_MAX_MS = 2 ** 31 - 1;

/**
 * A code-heat attempt's waits before its runs (createProgramHeatHandler: for the process's clock behind other timings, then
 * for any scrape heat holding the host), held to its expiry `endsAt` less server/jobs.ts CODE_HEAT_SLACK_SECONDS (the
 * header's `hand-on`): its signal aborts with a CodeHeatHandOn once that comes (gaveUp), or with the attempt's own
 * reason first (`signal`: pg-boss gave it up). How long is left is read on `now` as the wait starts, then on the
 * monotonic clock. `end` disarms it: the waits are over, and its deadline stops nothing after.
 */
function codeHeatWait(endsAt: Date, now: () => Date, signal: AbortSignal | undefined): { signal: AbortSignal; until: Date; endsAt: Date; gaveUp(err: unknown): boolean; end(): void } {
  const until = new Date(endsAt.getTime() - CODE_HEAT_SLACK_SECONDS * 1000);
  const stop = new AbortController();
  const reason = new CodeHeatHandOn(`the heat waited until ${until.toISOString()}, ${CODE_HEAT_SLACK_SECONDS} s before its attempt expires at ${endsAt.toISOString()}`);
  const fireAt = performance.now() + Math.max(0, until.getTime() - now().getTime());
  let ended = false;
  let timer: ReturnType<typeof setTimeout> | undefined;
  // Always on a timer, never at once: a clock that is free is taken (exclusive, in microtasks) before the timer fires.
  const arm = (): void => {
    timer = setTimeout(
      () => {
        timer = undefined;
        if (ended) return;
        if (performance.now() >= fireAt) stop.abort(reason);
        else arm();
      },
      Math.min(TIMER_MAX_MS, Math.max(0, Math.ceil(fireAt - performance.now()))),
    );
  };
  arm();
  return {
    signal: signal === undefined ? stop.signal : AbortSignal.any([signal, stop.signal]),
    until,
    endsAt,
    gaveUp: (err) => stop.signal.aborted && err === reason,
    end: () => {
      ended = true;
      if (timer !== undefined) clearTimeout(timer);
      timer = undefined;
    },
  };
}

/**
 * The heat of a due phase handed on from its wait (createProgramHeatHandler; the header's `hand-on`): its attempt waited for
 * `w.on` until its expiry less the slack and timed nothing, so it sends the phase's next job as a heat stopped between its
 * runs does (sendCodeHeatRest: `rest:<job id>:<runs kept>`, the runs kept as they stand, expiring after the rest at most),
 * not before CODE_HEAT_RECHECK_MS from now, and logs it (and pages it when the rest plans to end past the result deadline:
 * pageLateCodeHeat). Null: nothing recorded, and nothing failed.
 */
async function handOnCodeHeatWait(
  deps: GradeWorkerDeps,
  jobs: Pick<JobQueue, 'send'>,
  due: TimingHeatDue,
  jobKey: string,
  w: { on: string; until: Date; endsAt: Date },
  late: LatePaged,
): Promise<null> {
  const log = deps.log ?? ((line: string) => console.log(line));
  const now = deps.now ?? (() => new Date());
  const { codeHeatPartialFile } = await import('./code-heat.ts');
  const { runMs, plannedRuns } = await codeHeatWork(deps, due);
  const kept = await keptCodeHeatRuns(codeHeatPartialFile(codeHeatPartialPath(deps.workRoot, due.ph.id)));
  const startAfter = new Date(now().getTime() + CODE_HEAT_RECHECK_MS);
  const next = await sendCodeHeatRest(jobs, due.ph.id, { jobKey, kept, plannedRuns, runMs, startAfter });
  log(
    `[code-heat] ${jobKey}: the heat of ${due.comp.slug}'s final phase hands on: it waited for ${w.on} until ${w.until.toISOString()}, ${CODE_HEAT_SLACK_SECONDS} s before this attempt expires at ${w.endsAt.toISOString()}, and timed nothing; ` +
      `${kept} of its ${plannedRuns} runs at most are kept, and job ${next.id}${next.sent === null ? ' (sent before)' : ''} times the rest (${next.rest} at most) from ${startAfter.toISOString()}, expiring ${next.expireInSeconds} s after it starts`,
  );
  await pageLateCodeHeat(deps, due, jobKey, { job: next.id, rest: next.rest, runMs, startsAt: startAfter }, late);
  return null;
}

/** What createProgramHeatHandler paged of late heats (the header's `late`): codeHeatLateKey to when it paged. */
type LatePaged = Map<string, Date>;

/** Which heat and deadline a late page is for (the header's `late`): one page each. */
function codeHeatLateKey(phaseId: string, deadline: Date): string {
  return `${phaseId.toLowerCase()} ${deadline.toISOString()}`;
}

/** A hand-on that plans to end past its competition's result deadline (codeHeatLatePage's facts). */
export interface CodeHeatLate {
  slug: string;
  phase_id: string;
  /** The rest job handed on to (codeHeatJobId `rest:…`), its runs at most, one run's time at most, and when it starts. */
  job: string;
  rest: number;
  run_ms: number;
  starts_at: Date;
  /** starts_at plus rest runs of run_ms each: when the heat ends at the latest. */
  finishes_by: Date;
  /** The competition's open escrow's resolve_deadline (the earliest, with one on each cluster), and that escrow's address. */
  deadline: Date;
  escrow: string;
}

/**
 * The page of a heat whose hand-on plans to end past its competition's result deadline (the header's `late`): the
 * competition, the job, the planned finish and the deadline, past which post_result cannot land and the whole pot
 * refunds to the sponsor. An alert only: it says that nothing was stopped.
 */
export function codeHeatLatePage(l: CodeHeatLate): string {
  return (
    `[code-heat] ALERT: the timing heat of ${l.slug}'s final phase (phase ${l.phase_id}) handed its rest on to job ${l.job}, which plans to finish by ${l.finishes_by.toISOString()} ` +
    `(${l.rest} ${l.rest === 1 ? 'run' : 'runs'} at most, each up to ${l.run_ms} ms, from ${l.starts_at.toISOString()}): after the competition's result deadline ${l.deadline.toISOString()} ` +
    `(escrow ${l.escrow}'s resolve_deadline), past which no result can be posted and the whole pot refunds to the sponsor. ` +
    `Nothing is stopped or refused: the heat goes on as planned, and this page is not sent again for it. What holds it is in the job's log (a wait for this host's CPU clock or a scrape heat, or runs taking their time caps)`
  );
}

/**
 * Page the admins once a heat hands on (sendCodeHeatRest) when the rest it sent plans to end past the competition's
 * result deadline (the header's `late`): `rest` runs at most of `runMs` each from `startsAt`, against the earliest
 * resolve_deadline of its escrows still open (none open: no deadline, nothing paged). Once per heat and deadline in
 * `late`; a later hand-on of the same heat is logged. An alert only: a deadline that cannot be read is logged, and the
 * hand-on stands either way.
 */
async function pageLateCodeHeat(
  deps: GradeWorkerDeps,
  due: Extract<CodeHeatDue, { kind: 'due' }>,
  jobKey: string,
  o: { job: string; rest: number; runMs: number; startsAt: Date },
  late: LatePaged,
): Promise<void> {
  const log = deps.log ?? ((line: string) => console.log(line));
  const page = deps.page ?? ((line: string) => console.error(line));
  const now = deps.now ?? (() => new Date());
  let open: { escrow: string; resolveDeadline: Date }[];
  try {
    open = await deps.db
      .select({ escrow: competitionEscrow.escrow, resolveDeadline: competitionEscrow.resolveDeadline })
      .from(competitionEscrow)
      .where(and(eq(competitionEscrow.competitionId, due.comp.id), eq(competitionEscrow.status, 'open')));
  } catch (err) {
    log(`[code-heat] ${jobKey}: the result deadline of ${due.comp.slug} could not be read (${err instanceof Error ? err.message : String(err)}): the hand-on to job ${o.job} stands, unchecked against it`);
    return;
  }
  const first = open.reduce<{ escrow: string; resolveDeadline: Date } | null>((a, e) => (a === null || e.resolveDeadline < a.resolveDeadline ? e : a), null);
  if (first === null) return;
  const finishesBy = new Date(o.startsAt.getTime() + o.rest * o.runMs);
  if (finishesBy.getTime() <= first.resolveDeadline.getTime()) return;
  const key = codeHeatLateKey(due.ph.id, first.resolveDeadline);
  const paged = late.get(key);
  if (paged !== undefined) {
    log(`[code-heat] ${jobKey}: job ${o.job} plans to finish the heat of ${due.comp.slug}'s final phase by ${finishesBy.toISOString()}, past its result deadline ${first.resolveDeadline.toISOString()} (paged at ${paged.toISOString()})`);
    return;
  }
  late.set(key, now());
  page(codeHeatLatePage({ slug: due.comp.slug, phase_id: due.ph.id, job: o.job, rest: o.rest, run_ms: o.runMs, starts_at: o.startsAt, finishes_by: finishesBy, deadline: first.resolveDeadline, escrow: first.escrow }));
}

/** A due heat's phase setup, as its grades ran it (programPhaseSetup of its competition and final phase, no seed). */
function codeHeatPhaseSetup(deps: GradeWorkerDeps, due: Extract<CodeHeatDue, { kind: 'due' }>): Promise<{ setup: ProgramSetup; seed: string }> {
  const { comp, ph, bundle, harness } = due;
  return programPhaseSetup(deps, { slug: comp.slug, bundle, harness, phaseKey: ph.key, competitionKey: competitionSeedKey(comp), seed: null });
}

/**
 * A due heat's work at most (the header's `hand-on`): its finalist places (code-heat.ts codeHeatPlaces), one run's time at
 * most (codeHeatRunMs over `setup`, default the phase's: codeHeatPhaseSetup) and its runs at most (codeHeatPlannedRuns).
 */
async function codeHeatWork(deps: GradeWorkerDeps, due: TimingHeatDue, setup?: ProgramSetup): Promise<{ places: number; runMs: number; plannedRuns: number }> {
  const { codeHeatPlaces } = await import('./code-heat.ts');
  const places = codeHeatPlaces(due.bundle.prizes, due.timing);
  const runMs = codeHeatRunMs(setup ?? (await codeHeatPhaseSetup(deps, due)).setup, due.bundle.limits);
  return { places, runMs, plannedRuns: codeHeatPlannedRuns(due.timing, due.field.length, places) };
}

/**
 * Send the job that times the rest of phase `phaseId`'s heat (the header's `hand-on`): codeHeatJobId `rest:<job id>:<runs
 * kept>`, expiring after the runs still to come at most (server/jobs.ts codeHeatExpirySeconds of them at `runMs` each),
 * not before `startAfter` when one is named. Its id, the send's answer (null: sent before), the runs left and the expiry.
 */
async function sendCodeHeatRest(
  jobs: Pick<JobQueue, 'send'>,
  phaseId: string,
  o: { jobKey: string; kept: number; plannedRuns: number; runMs: number; startAfter?: Date },
): Promise<{ id: string; sent: string | null; rest: number; expireInSeconds: number }> {
  const rest = Math.max(0, o.plannedRuns - o.kept);
  const expireInSeconds = codeHeatExpirySeconds(rest * o.runMs);
  const id = codeHeatJobId(phaseId, `rest:${o.jobKey}:${o.kept}`);
  const sent = await sendCodeHeat(jobs, phaseId, { id, expireInSeconds, ...(o.startAfter === undefined ? {} : { startAfter: o.startAfter }) });
  return { id, sent, rest, expireInSeconds };
}

/** Where the code-heat job keeps a phase's heat runs as they are measured (the header's `resume`): a file of the work root, one per phase. */
export function codeHeatPartialPath(workRoot: string, phaseId: string): string {
  return join(workRoot, `code-heat-partial-${phaseId.toLowerCase()}.json`);
}

/**
 * Drop what was kept for phase `phaseId`'s heat, the runs of a timing heat and the calls of a judge heat (the header's
 * `resume`, `judge heat`): it owes nothing. A removal that fails is logged under `who`.
 */
async function dropCodeHeatPartial(deps: Pick<GradeWorkerDeps, 'workRoot' | 'log'>, phaseId: string, who: string): Promise<void> {
  const { codeHeatPartialFile } = await import('./code-heat.ts');
  for (const [store, what] of [
    [codeHeatPartialFile(codeHeatPartialPath(deps.workRoot, phaseId)), 'runs'],
    [codeHeatPartialFile(judgeHeatPartialPath(deps.workRoot, phaseId)), 'judge calls'],
  ] as const) {
    try {
      await store.remove();
    } catch (err) {
      (deps.log ?? ((line: string) => console.log(line)))(`${who}: the ${what} kept at ${store.where} could not be removed (${err instanceof Error ? err.message : String(err)})`);
    }
  }
}

/** How many runs `store` keeps of a heat (the header's `resume`): 0 when it keeps none, or none that reads as kept runs. */
async function keptCodeHeatRuns(store: CodeHeatPartialStore): Promise<number> {
  const { CodeHeatPartial } = await import('./code-heat.ts');
  try {
    const text = await store.read();
    if (text === null) return 0;
    const parsed = CodeHeatPartial.safeParse(JSON.parse(text));
    return parsed.success ? parsed.data.runs.length : 0;
  } catch {
    return 0;
  }
}

/** Why an attempt of a heat stopped between its runs (the header's `hand-on`): its next run could outlast it. */
class CodeHeatHandOn extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'CodeHeatHandOn';
  }
}

/**
 * The heat of a due phase (createProgramHeatHandler), on `sandbox` (the process's clock), recorded; or, when its runs would
 * outlast the attempt, those that fit timed and kept and the rest handed on (null: the header's `hand-on`), paged when
 * the rest plans to end past the result deadline (`late`: pageLateCodeHeat).
 */
async function timeCodeHeat(
  deps: GradeWorkerDeps,
  due: TimingHeatDue,
  sandbox: TimingSandbox,
  jobKey: string,
  ctx: CodeHeatJobContext | undefined,
  late: LatePaged,
): Promise<CodeHeatOutcome | null> {
  const { db, blobs } = deps;
  const log = deps.log ?? ((line: string) => console.log(line));
  const now = deps.now ?? (() => new Date());
  const { comp, ph, bundle, harness, timing, field } = due;
  const { CodeHeatError, codeHeatPartialFile, runCodeHeat } = await import('./code-heat.ts');
  const what = `the timing heat of ${comp.slug}'s final phase (job ${jobKey})`;
  const phaseSetup = await codeHeatPhaseSetup(deps, due);
  const plan = programPlan(phaseSetup);
  // A timing heat races the entries in one language (contracts/competition.ts ProgramHarness.timing): its one runtime.
  const runtime = harness.runtimes.length === 1 ? harness.runtimes[0]! : null;
  if (runtime === null) throw new PermanentJobError(`${comp.slug}'s harness names ${harness.runtimes.length} runtimes, and a timing heat runs the entries in one`);
  const runRows = await db
    .select()
    .from(run)
    .where(
      inArray(
        run.id,
        field.map((f) => f.run_id),
      ),
    );
  const runOf = new Map(runRows.map((r) => [r.id, r]));
  const subRows = await db
    .select()
    .from(submission)
    .where(
      inArray(
        submission.id,
        field.map((f) => f.submission_id),
      ),
    );
  const subOf = new Map(subRows.map((s) => [s.id, s]));
  const entries: TimedEntry[] = [];
  /** The entry_secret rows each entry is timed with (the header's `entry secrets`), by submission: what its kept runs were measured under. */
  const timedSecretIds = new Map<string, string[]>();
  const sealOf = entrySecretSealOf(deps);
  for (const f of field) {
    const r = runOf.get(f.run_id);
    const sub = subOf.get(f.submission_id);
    if (r === undefined || sub === undefined) throw new CodeHeatError(`entry ${f.submission_id}'s grade run ${f.run_id} is gone`);
    // Timed under any other plan, its runs could never write its graded outputs: the house's to mend, never the entry's.
    if (r.seed !== plan.seed || r.datasetSha256 !== plan.datasetSha256) {
      throw new PermanentJobError(
        `${what}: entry ${f.submission_id}'s final grade (run ${r.id}) ran under seed ${r.seed ?? 'none'} on data ${r.datasetSha256 ?? 'none'}, and the phase's plan is seed ${plan.seed} on ${plan.datasetSha256 ?? 'none'}: its timed runs could never write its graded outputs. Regrade the phase as it stands, then send the heat again`,
      );
    }
    // The env-lane entry secrets its graded run ran with, re-opened (the header's `entry secrets`): its timed runs run as
    // it was graded. One erased since is left out, said by NAME: whether it mattered, its timed outputs show.
    const recorded = await recordedEnvSecrets(db, sealOf, { userId: sub.userId, competitionId: comp.id }, r.entrySecretIds);
    if (recorded.kind === 'unopened') {
      throw new Error(`${what}: the env-lane entry secrets entry ${f.submission_id}'s final grade (run ${r.id}) ran with cannot be opened here, so it is not timed without them (the job tries again): ${recorded.why}`);
    }
    if (recorded.erased !== null) {
      log(`[code-heat] ${jobKey}: entry ${f.submission_id} is timed without the env-lane entry secret its final grade (run ${r.id}) ran with that is erased since (replaced, deleted or purged): ${recorded.erased}; its timed outputs are held to its graded ones as ever`);
    }
    const env = recorded.secrets.env;
    if (recorded.secrets.ids.length > 0) timedSecretIds.set(f.submission_id, recorded.secrets.ids);
    entries.push({
      entry: f.submission_id,
      received_at: f.received_at,
      action_log_sha256: f.action_log_sha256,
      snapshot: { index: await readSnapshotIndex(blobs, f.snapshot_sha256), blobs, ...(recorded.secrets.ids.length === 0 ? {} : { secrets: env }) },
      image_digest: f.image_digest,
    });
  }
  // Named for its job, the same on each attempt: an attempt first removes what one that died left (the header's `scratch`).
  const owner = ctx === undefined ? undefined : regradeOwner(ctx.id);
  if (owner !== undefined) {
    const line = scratchReapLine(what, `attempt ${(ctx?.retryCount ?? 0) + 1}`, await reapGradeScratch(sandbox, deps.workRoot, owner));
    if (line !== null) log(line);
  }
  // The runs this host kept of the phase's heat, and what they must have been measured under (the header's `resume`).
  const partial = codeHeatPartialFile(codeHeatPartialPath(deps.workRoot, ph.id));
  const measuredUnder = {
    phase_id: ph.id.toLowerCase(),
    bundle_sha256: canonicalSha256(JSON.parse(JSON.stringify(bundle)) as unknown),
    dataset_sha256: plan.datasetSha256,
    harness_version: harnessVersion(),
    runtime,
    image_digest: sandbox.imageDigest(runtime),
    // Each entry's entry_secret rows only where it is timed with some, so a field with none keys what it always did.
    field: field
      .map((f) => {
        const secretIds = timedSecretIds.get(f.submission_id);
        return { entry: f.submission_id, snapshot_sha256: f.snapshot_sha256, image_digest: f.image_digest, ...(secretIds === undefined ? {} : { entry_secret_ids: secretIds }) };
      })
      .sort((a, b) => compareCodeUnits(a.entry, b.entry)),
  };

  // The heat's work at most, and what of it this attempt has time for (the header's `hand-on`).
  const { places, runMs, plannedRuns } = await codeHeatWork(deps, due, phaseSetup.setup);
  const slackMs = CODE_HEAT_SLACK_SECONDS * 1000;
  const endsAt = ctx?.expiresAt;
  const jobs = deps.jobs;
  // A run no attempt could hold (its caps past pg-boss's most) is started by each attempt whatever its expiry: one an attempt.
  const anyAttemptHoldsARun = runMs + slackMs <= CODE_HEAT_MAX_EXPIRY_SECONDS * 1000;
  let timedNow = 0;
  const stop = new AbortController();
  /** Stop the heat before its next run when that run at most could end past the attempt's expiry less the slack. */
  const stopIfOutrun = (): void => {
    if (endsAt === undefined || jobs === undefined || stop.signal.aborted) return;
    if (now().getTime() + runMs + slackMs <= endsAt.getTime() || (timedNow === 0 && !anyAttemptHoldsARun)) return;
    stop.abort(new CodeHeatHandOn(`${what}: its next run may take up to ${runMs} ms, and this attempt expires at ${endsAt.toISOString()}`));
  };
  if (endsAt !== undefined && jobs === undefined && now().getTime() + plannedRuns * runMs + slackMs > endsAt.getTime()) {
    log(
      `[code-heat] ${jobKey}: the heat's ${plannedRuns} runs at most, each up to ${runMs} ms, may outlast this attempt (it expires at ${endsAt.toISOString()}), and no queue is handed in to hand the rest on to: ` +
        'it times them all, and should the attempt expire the next job of the phase goes on from the runs it kept',
    );
  }
  stopIfOutrun();
  const signal = ctx?.signal === undefined ? stop.signal : AbortSignal.any([ctx.signal, stop.signal]);
  const started = Date.now();
  let heat: CodeHeatRun;
  try {
    heat = await runCodeHeat({
      plan,
      sandbox,
      runtime,
      limits: bundle.limits,
      workRoot: deps.workRoot,
      blobs,
      phaseSeed: plan.seed,
      timing,
      places,
      entries,
      progress: { store: partial, plan: measuredUnder },
      log: (line) => log(`[code-heat] ${jobKey}: ${line}`),
      // Told of each run as it is recorded, before it is kept: the heat stops before the next one when that may outrun the attempt.
      onRun: () => {
        timedNow++;
        stopIfOutrun();
      },
      ...(owner === undefined ? {} : { owner }),
      signal,
    });
  } catch (err) {
    if (!(stop.signal.aborted && err === stop.signal.reason) || jobs === undefined || endsAt === undefined) throw err;
    // Stopped between runs, every run so far kept (the header's `resume`): the rest goes on in a job sized to it.
    const kept = await keptCodeHeatRuns(partial);
    const next = await sendCodeHeatRest(jobs, ph.id, { jobKey, kept, plannedRuns, runMs });
    log(
      `[code-heat] ${jobKey}: the heat of ${comp.slug}'s final phase hands on: its next run may take up to ${runMs} ms, and this attempt expires at ${endsAt.toISOString()} (${CODE_HEAT_SLACK_SECONDS} s of it kept free); ` +
        `${kept} of its ${plannedRuns} runs at most are kept (${timedNow} timed by this attempt), and job ${next.id}${next.sent === null ? ' (sent before)' : ''} times the rest (${next.rest} at most), expiring ${next.expireInSeconds} s after it starts`,
    );
    // Sent with no startAfter: it starts as soon as the phase's queue lets it.
    await pageLateCodeHeat(deps, due, jobKey, { job: next.id, rest: next.rest, runMs, startsAt: now() }, late);
    return null;
  }
  const wallMs = Date.now() - started;
  const put = await blobs.put(heat.json);
  if (put.sha256 !== heat.sha256) throw new CodeHeatError(`the heat record's blob ${put.sha256} is not its sha256 ${heat.sha256}`);

  // Each field entry's grade run, its score built again with its verdict, and the link to the record: in one transaction.
  const rules = eligibilityRulesOf(bundle);
  const writes = field.map((f) => {
    const r = runOf.get(f.run_id)!;
    const sub = subOf.get(f.submission_id)!;
    const verdict = heat.verdicts.get(f.submission_id);
    if (verdict === undefined) throw new CodeHeatError(`the heat's record holds no verdict on ${f.submission_id}, an entry of its field`);
    const stored = Score.safeParse(r.result);
    if (!stored.success) throw new CodeHeatError(`entry ${f.submission_id}'s grade run ${r.id} holds no score that validates`);
    const timed = scoreWithTiming(stored.data, verdict, { house: standingsHouse(sub), baseline: sub.baseline }, rules);
    return { f, r, verdict, ...timed };
  });
  await db.transaction(async (tx) => {
    for (const w of writes) {
      const [written] = await tx
        .update(run)
        .set({ result: w.result, resultSha256: w.result_sha256, codeHeatSha256: heat.sha256 })
        .where(and(eq(run.id, w.r.id), w.r.resultSha256 === null ? isNull(run.resultSha256) : eq(run.resultSha256, w.r.resultSha256)))
        .returning({ id: run.id });
      if (written === undefined) {
        throw new CodeHeatError(
          `entry ${w.f.submission_id}'s grade run ${w.r.id} changed while the heat ran: nothing of it is written, and the job's retry records the heat again from the runs kept at ${partial.where} while its field and plan stand (else it times the field again)`,
        );
      }
    }
    await recordLiveChange(tx, { ...GRADE_CHANGE, scopeId: comp.id });
  });
  // Recorded and written: nothing is left to resume.
  try {
    await partial.remove();
  } catch (err) {
    log(`[code-heat] ${jobKey}: the heat is recorded, and the runs kept at ${partial.where} could not be removed (${err instanceof Error ? err.message : String(err)})`);
  }
  const keptRuns = heat.resume.kind === 'resumed' ? heat.resume.runs : 0;
  const cpuSources = heat.resume.kind === 'resumed' ? [...heat.resume.cpu_sources] : [heat.record.cpu_source];
  const outcome: CodeHeatOutcome = {
    kind: 'timing',
    phase_id: ph.id,
    heat_sha256: heat.sha256,
    cpu_source: heat.record.cpu_source,
    runs: heat.record.runs.length,
    kept_runs: keptRuns,
    cpu_sources: cpuSources,
    finalists: [...heat.record.finalists],
    wall_ms: wallMs,
    entries: writes.map((w) => ({
      submission_id: w.f.submission_id,
      run_id: w.r.id,
      verdict: w.verdict === TIMING_OUTPUTS_DIFFER ? TIMING_OUTPUTS_DIFFER : 'timed',
      trimmed_mean_cpu_us: w.verdict === TIMING_OUTPUTS_DIFFER ? null : w.verdict.trimmed_mean_cpu_us,
      rounds: w.verdict === TIMING_OUTPUTS_DIFFER ? null : w.verdict.rounds,
      result_sha256: w.result_sha256,
    })),
  };
  const unranked = outcome.entries.filter((e) => e.verdict !== 'timed').map((e) => e.submission_id);
  log(
    `[code-heat] ${jobKey}: timed ${field.length} ${field.length === 1 ? 'entry' : 'entries'} of ${comp.slug}'s final phase in ${outcome.runs} runs` +
      `${keptRuns === 0 ? '' : ` (${keptRuns} kept by an earlier attempt, ${outcome.runs - keptRuns} timed by this one)`} (${(wallMs / 1000).toFixed(1)} s) on ${cpuSources.join(' then ')}; record ${heat.sha256}` +
      `${outcome.finalists.length === 0 ? '' : `; finalists ${outcome.finalists.join(', ')}`}${unranked.length === 0 ? '' : `; unranked (${TIMING_OUTPUTS_DIFFER}): ${unranked.join(', ')}`}`,
  );
  return outcome;
}

// ---------------------------------------------------------------- a judged final's heat (the header's `judge heat`)

/** How long a judge heat held at its opening (grader/judge-call.ts JudgeHold) waits before it is weighed again: its next code-heat job's start. */
export const JUDGE_HEAT_HOLD_RECHECK_MS = 60 * 60_000;

/** When this process last paged each competition's held judge heat, by competition id (AGENT_REFUSAL_PAGE_MS apart). */
type HoldPaged = Map<string, number>;

/** One field entry of a recorded judge heat (JudgeHeatOutcome). */
export interface JudgeHeatEntryOutcome {
  submission_id: string;
  run_id: string;
  /** Its artifact's sha256: the member it played as, one with every entry whose artifact has the same bytes. */
  artifact_sha256: string;
  /** Its verdict (performance.judge): the rank key, and whether its member played the playoff. */
  win_rate_micro: number;
  finalist: boolean;
  /** Its grade run's result_sha256 once the verdict is written. */
  result_sha256: string;
}

/** What a code-heat job recorded on a judge heat (the header's `judge heat`). */
export interface JudgeHeatOutcome {
  kind: 'judge';
  phase_id: string;
  /** The heat record's sha256 (grader/judge-heat.ts JudgeHeatRecord): its blob's name, and every judged run's run.judge_heat_sha256. */
  heat_sha256: string;
  /** The calls the record holds, those an earlier attempt kept of them, and those that came back with no verdict. */
  calls: number;
  kept_calls: number;
  invalid_calls: number;
  /** What the heat spent, µUSD (a u64 decimal): every attempt its keys sent and priced, over every attempt of the job. */
  spent_micro_usd: string;
  /** The playoff's members, artifact sha256s, in Swiss-standing order. */
  finalists: string[];
  /** What retiring this attempt's key found (grader/gateway/masq.ts RetiredTrialKey.flags); empty when it opened none. */
  key_flags: string[];
  /** Every field entry judged, in the field's order. */
  entries: JudgeHeatEntryOutcome[];
  /** Every field entry the heat left out (no artifact, or one the judge cannot read), in the field's order: its run linked to the record, with no verdict. */
  left_out: { submission_id: string; run_id: string; why: string; result_sha256: string | null }[];
}

/** Where the code-heat job keeps a phase's judge calls as they settle (the header's `judge heat`): a file of the work root, one per phase. */
export function judgeHeatPartialPath(workRoot: string, phaseId: string): string {
  return join(workRoot, `judge-heat-partial-${phaseId.toLowerCase()}.json`);
}

/** The environment's masq broker for a judge heat's keys (JudgeWorkerDeps.broker's default), once made; undefined until then. */
let environmentJudgeBroker: MasqJudgeKeyBroker | null | undefined;

/**
 * The broker a judge heat mints its keys at (JudgeWorkerDeps.broker, else the environment's, made once); null: none. The
 * environment's is server/superbot-router.ts judgeKeyBroker over masq's (masqBrokerFromConfig) and, with
 * MAKEFUN_SUPERBOT_ROUTER_URL and _KEY set, the router's (routerJudgeBroker), from one loadConfig().
 */
async function judgeBrokerOf(deps: Pick<GradeWorkerDeps, 'judge'>): Promise<MasqJudgeKeyBroker | null> {
  if (deps.judge?.broker !== undefined) return deps.judge.broker;
  if (environmentJudgeBroker === undefined) {
    const { masqBrokerFromConfig } = await import('./gateway/masq.ts');
    const { judgeKeyBroker, routerJudgeBroker, routerRouteFromConfig } = await import('../server/superbot-router.ts');
    const config = loadConfig();
    const route = routerRouteFromConfig(config);
    environmentJudgeBroker = judgeKeyBroker(masqBrokerFromConfig(config), route === null ? null : routerJudgeBroker(route));
  }
  return environmentJudgeBroker;
}

/** How long a model seen answering a forced form is taken to answer one still (environmentFormsSeen). */
const JUDGE_FORMS_SEEN_MS = 6 * 3_600_000;

/**
 * The models this process saw answer a forced form (`answer` or `tool`, HTTP 200) on the environment's broker, each
 * with when it last did: JudgeWorkerDeps.formsSeen's default beside environmentJudgeBroker, true for 6 h after a note.
 */
const environmentFormsSeen: JudgeFormsSeen = (() => {
  const seen = new Map<string, number>();
  return {
    has: (model) => {
      const at = seen.get(model);
      return at !== undefined && Date.now() - at < JUDGE_FORMS_SEEN_MS;
    },
    note: (model) => {
      seen.set(model, Date.now());
    },
  };
})();

/** The forms memo a heat reads (JudgeWorkerDeps.formsSeen, else the process's own only on the environment's broker). */
function judgeFormsSeenOf(deps: Pick<GradeWorkerDeps, 'judge'>): JudgeFormsSeen | undefined {
  if (deps.judge?.formsSeen !== undefined) return deps.judge.formsSeen;
  return deps.judge?.broker === undefined ? environmentFormsSeen : undefined;
}

/** A kept judge key's format (JudgeKeyFile). */
const JUDGE_KEY_FORMAT = 'makefun/judge-key/v1';

/**
 * One judge key a phase's heats minted, or the attempt about to mint it (the header's `judge keys`): a file of its own
 * under the blob store (judgeKeysDir, `<attempt>.json`), so what it spent is known on whichever host runs the next heat
 * (a provisional key's against the day's cap), and the attempt number its label carries (grader/gateway/masq.ts judgeKeyLabel) is no
 * other heat's.
 */
const JudgeKeyFile = z.strictObject({
  format: z.literal(JUDGE_KEY_FORMAT),
  phase_id: z.string().min(1),
  stage: z.enum(['final', 'provisional']),
  attempt: z.int().min(1),
  /** When the attempt was claimed: the UTC day a provisional key's spend counts on against judge.dev_daily_usd. */
  at: IsoDateTime,
  /** The key as minted; null before the mint. */
  key_id: z.string().min(1).nullable(),
  label: z.string().min(1).nullable(),
  /** The heat's worst case (judge-call.ts JudgeBudget.worstMicroUsd), held against the cap while the key is open: a provisional heat's; 0 on a final's, whose heats run one at a time. */
  reserved_micro_usd: U64,
  /** The heat's meter when the key was last written, and masq's spend on it once retired (null before). */
  meter_micro_usd: U64,
  masq_micro_usd: U64.nullable(),
  /** Whether the key may still spend: not yet retired. */
  open: z.boolean(),
});
type JudgeKeyFileT = z.infer<typeof JudgeKeyFile>;

/** Where a phase's judge keys are kept (JudgeKeyFile): a directory under the blob store's root, which every host grading against the database shares. */
export function judgeKeysDir(blobs: Pick<BlobStore, 'root'>, phaseId: string): string {
  return join(blobs.root, 'judge-keys', phaseId.toLowerCase());
}

/** The names a kept judge key's file takes: `<attempt>.json`. */
const JUDGE_KEY_FILE_RE = /^([1-9][0-9]*)\.json$/;

/**
 * How old a claim that never minted (open, key_id null; by its `at`) is removed by whoever reads the phase's keys, and
 * counts nothing: a claim lives the seconds from its claim to its mint, so one older was left by a heat that stopped
 * between them (a crash, a SIGTERM, an abort) and would hold its worst case against its cap for good.
 */
const JUDGE_KEY_CLAIM_EXPIRE_MS = 10 * 60_000;

/**
 * A phase's kept judge keys (judgeKeysDir), in attempt order; none before its first. A file that does not read is
 * thrown: what its key spent cannot be counted. One gone between the listing and its read is none: another heat dropped
 * a claim that minted nothing (dropJudgeKey), and it spent nothing. A claim that never minted, older at `now` than
 * JUDGE_KEY_CLAIM_EXPIRE_MS, is none too, and its file removed; a minted key counts however old.
 */
async function readJudgeKeys(dir: string, now: Date): Promise<JudgeKeyFileT[]> {
  let names: string[];
  try {
    names = await readdir(dir);
  } catch (err) {
    if ((err as NodeJS.ErrnoException).code === 'ENOENT') return [];
    throw err;
  }
  const keys: JudgeKeyFileT[] = [];
  for (const name of names) {
    if (!JUDGE_KEY_FILE_RE.test(name)) continue;
    const path = join(dir, name);
    let key: JudgeKeyFileT;
    try {
      key = JudgeKeyFile.parse(JSON.parse(await readFile(path, 'utf8')));
    } catch (err) {
      if ((err as NodeJS.ErrnoException).code === 'ENOENT') continue;
      throw new Error(`the judge key kept at ${path} does not read (${err instanceof Error ? err.message : String(err)}): what it spent cannot be counted against its cap`);
    }
    if (key.open && key.key_id === null && now.getTime() - Date.parse(key.at) > JUDGE_KEY_CLAIM_EXPIRE_MS) {
      await dropJudgeKey(dir, key);
      continue;
    }
    keys.push(key);
  }
  return keys.sort((a, b) => a.attempt - b.attempt);
}

/**
 * Claim a phase's next judge key attempt (the header's `judge keys`), from `from` on and past every attempt kept: its
 * file written whole beside the others, then linked into place, which fails on a name that exists, so two claims never
 * take one number.
 */
async function claimJudgeKey(dir: string, key: Omit<JudgeKeyFileT, 'attempt'>, from: number): Promise<JudgeKeyFileT> {
  await mkdir(dir, { recursive: true });
  let attempt = from;
  for (const name of await readdir(dir)) {
    const m = JUDGE_KEY_FILE_RE.exec(name);
    if (m !== null) attempt = Math.max(attempt, Number(m[1]) + 1);
  }
  const tmp = join(dir, `.claim-${uuidv7()}.tmp`);
  try {
    for (; ; attempt++) {
      const claimed: JudgeKeyFileT = { ...key, attempt };
      await writeFile(tmp, canonicalJson(claimed), { mode: 0o600 });
      try {
        await link(tmp, join(dir, `${attempt}.json`));
        return claimed;
      } catch (err) {
        if ((err as NodeJS.ErrnoException).code !== 'EEXIST') throw err;
      }
    }
  } finally {
    await unlink(tmp).catch(() => undefined);
  }
}

/** Write a kept judge key over its file, whole (a file beside it renamed into place). */
async function writeJudgeKey(dir: string, key: JudgeKeyFileT): Promise<JudgeKeyFileT> {
  const tmp = join(dir, `.${key.attempt}-${uuidv7()}.tmp`);
  await writeFile(tmp, canonicalJson(key), { mode: 0o600 });
  await rename(tmp, join(dir, `${key.attempt}.json`));
  return key;
}

/** Drop a claimed attempt that minted nothing (a heat held before its mint): its number goes to the next heat. */
async function dropJudgeKey(dir: string, key: JudgeKeyFileT): Promise<void> {
  await unlink(join(dir, `${key.attempt}.json`)).catch((err: unknown) => {
    if ((err as NodeJS.ErrnoException).code !== 'ENOENT') throw err;
  });
}

/**
 * What a kept judge key has spent for certain, µUSD: a retired key's spend (judgeKeySpend), an open one's meter alone,
 * the rest of the worst case its heat reserved not yet spent.
 */
function judgeKeySettled(key: JudgeKeyFileT): bigint {
  return key.open ? BigInt(key.meter_micro_usd) : judgeKeySpend(key);
}

/**
 * How long a provisional heat that does not fit the day's cap only because other heats in flight hold their worst case
 * against it waits for them to settle before it is held (playProvisionalJudgeHeat; a heat lasts 25-110 s), on the heat's
 * clock: its claim given back, and claimed and weighed again every JUDGE_KEY_WAIT_MIN_MS to JUDGE_KEY_WAIT_MAX_MS.
 */
const JUDGE_KEY_WAIT_MS = 3 * 60_000;
const JUDGE_KEY_WAIT_MIN_MS = 3_000;
const JUDGE_KEY_WAIT_MAX_MS = 10_000;
/**
 * How old an open key (by its claim's `at`) is taken for an orphan a killed heat left, not a heat in flight: a heat
 * held behind only such keys does not wait, as nothing will settle them soon.
 */
const JUDGE_KEY_ORPHAN_MS = 15 * 60_000;

/** A kept key retired: what masq says it spent beside the heat's meter, and nothing more reserved. */
function retiredJudgeKey(key: JudgeKeyFileT, meterMicroUsd: bigint, retired: RetiredTrialKey): JudgeKeyFileT {
  return { ...key, reserved_micro_usd: '0', meter_micro_usd: String(meterMicroUsd), masq_micro_usd: String(retired.spend.microUsd), open: false };
}

/**
 * What a kept judge key counts against its cap, µUSD: a retired key the larger of the heat's meter and masq's spend on
 * it; an open one the larger of its meter and the worst case its heat reserved.
 */
function judgeKeySpend(key: JudgeKeyFileT): bigint {
  const meter = BigInt(key.meter_micro_usd);
  const other = BigInt(key.open ? key.reserved_micro_usd : (key.masq_micro_usd ?? '0'));
  return meter > other ? meter : other;
}

/** A judge pool seat's format (JudgePoolSeatFile, `<id>.json`): what every grader process reads, an old one too. */
const JUDGE_POOL_FORMAT = 'makefun/judge-pool/v1';
/** A judge pool seat's second file's format (JudgePoolSeatFileV2, `<id>.seat`): its class and its sends in flight besides. */
const JUDGE_POOL_FORMAT_V2 = 'makefun/judge-pool/v2';

/** A seat's id, and so its files' name stem (`<id>.json`, `<id>.seat`). */
const JUDGE_POOL_ID_RE = /^[A-Za-z0-9_-]{1,128}$/;
const JUDGE_POOL_FILE_RE = /^([A-Za-z0-9_-]{1,128})\.json$/;
const JUDGE_POOL_FILE_V2_RE = /^([A-Za-z0-9_-]{1,128})\.seat$/;

/**
 * A live judge heat's seat in the platform's one budget of judge sends in flight (the header's `judge heat`;
 * JUDGE_POOL_BUDGET): a file of its own under the blob store (judgePoolDir, `<id>.json`), which every grader process of
 * the deployment reads. `want`: the sends the heat could use right now; `at`: when the file was last written (a seat
 * older than JUDGE_POOL_STALE_MS counts no more: its process died).
 */
const JudgePoolSeatFile = z.strictObject({
  format: z.literal(JUDGE_POOL_FORMAT),
  id: z.string().regex(JUDGE_POOL_ID_RE),
  label: z.string(),
  want: z.int().min(0),
  at: IsoDateTime,
});

/** A judge heat's class in the pool (judgePoolShares): a final's heat goes first; a dev grade's provisional one shares what is left. */
export type JudgePoolClassT = 'final' | 'practice';

/**
 * A seat's second file (`<id>.seat`, beside its `<id>.json`), which only a process that knows classes reads: the seat's
 * want again, its class, and `flying`, the sends its heat held in flight when written (judgePoolAllowance). Its own file,
 * never a change to `<id>.json`: a process from before it parses `<id>.json` strictly at v1 and counts nothing for a
 * file that does not parse (it sweeps it, removed only once 10 minutes old by its mtime, which a live seat's never is),
 * so a seat written only at v2 would drop out of an old process's pool and split it; `<id>.seat` matches no name an old
 * process reads or removes, and it goes on reading `<id>.json` at v1, as today. Written whenever `<id>.json` is and
 * whenever `flying` moved, at most each JUDGE_POOL_REFRESH_MS; a reader takes it over `<id>.json` while it is fresh.
 */
const JudgePoolSeatFileV2 = z.strictObject({
  format: z.literal(JUDGE_POOL_FORMAT_V2),
  id: z.string().regex(JUDGE_POOL_ID_RE),
  label: z.string(),
  class: z.enum(['final', 'practice']),
  want: z.int().min(0),
  flying: z.int().min(0),
  at: IsoDateTime,
});

/** Where the live judge heats' seats are kept (JudgePoolSeatFile): a directory under the blob store's root, which every grader process shares. */
export function judgePoolDir(blobs: Pick<BlobStore, 'root'>): string {
  // Shared today because every grader pod mounts one claim on the cluster's one node (makefun-data, ReadWriteOnce, local-path; checked 2026-11-11): a grader on a second node would not see these seats.
  return join(blobs.root, 'judge-pool');
}

/** A seat as the share rule reads it (judgePoolShares): `class` absent or null for an old process's seat, which names none. */
export interface JudgePoolSeatWantT {
  id: string;
  want: number;
  class?: JudgePoolClassT | null;
}

/** A seat as the overshoot bound reads it (judgePoolAllowance): `flying` the sends it holds in flight, null when not known (an old process's seat). */
export interface JudgePoolSeatCountT extends JudgePoolSeatWantT {
  flying?: number | null;
}

/** A number as the pool reads it: a whole number >= 0, anything else 0. */
const poolWhole = (n: number): number => (Number.isFinite(n) && n > 0 ? Math.floor(n) : 0);

/** `left` split max-min fair over `wants` (ids in code-unit order), each share then at least min(want, least). */
function judgePoolFair(left: number, wants: ReadonlyMap<string, number>, least: number): Map<string, number> {
  const ids = [...wants.keys()].sort(compareCodeUnits);
  const shares = new Map<string, number>(ids.map((id) => [id, 0]));
  let open = ids.filter((id) => wants.get(id)! > 0);
  for (;;) {
    // Each want at most an equal split of what is left (want x seats <= left, in whole numbers) is met at once.
    const fits = open.filter((id) => wants.get(id)! * open.length <= left);
    if (fits.length === 0) break;
    for (const id of fits) {
      shares.set(id, wants.get(id)!);
      left -= wants.get(id)!;
    }
    open = open.filter((id) => !fits.includes(id));
  }
  if (open.length > 0) {
    const each = Math.floor(left / open.length);
    let rest = left - each * open.length;
    for (const id of open) {
      shares.set(id, each + (rest > 0 ? 1 : 0));
      if (rest > 0) rest--;
    }
  }
  for (const id of ids) shares.set(id, Math.max(shares.get(id)!, Math.min(wants.get(id)!, least)));
  return shares;
}

/** The share rule's working (judgePoolShares): each seat's share and the floor it was held to (min(want, its tier's floor)), in code-unit order of ids. */
function judgePoolTiers(budget: number, seats: readonly JudgePoolSeatWantT[], floor: number): { shares: Map<string, number>; floors: Map<string, number> } {
  const wants = new Map<string, number>();
  // A seat in the first tier: a final's, or an old process's (no class), which takes an equal split whatever it is.
  const first = new Set<string>();
  let final = false;
  for (const s of seats) {
    wants.set(s.id, Math.max(wants.get(s.id) ?? 0, poolWhole(s.want)));
    if (s.class !== 'practice') first.add(s.id);
    if (s.class === 'final') final = true;
  }
  const least = poolWhole(floor);
  const ids = [...wants.keys()].sort(compareCodeUnits);
  if (!final) {
    const shares = judgePoolFair(poolWhole(budget), wants, least);
    return { shares, floors: new Map<string, number>(ids.map((id) => [id, Math.min(wants.get(id)!, least)])) };
  }
  const top = judgePoolFair(poolWhole(budget), new Map<string, number>(ids.filter((id) => first.has(id)).map((id) => [id, wants.get(id)!])), least);
  let given = 0;
  for (const n of top.values()) given += n;
  const low = Math.min(least, JUDGE_POOL_PRACTICE_FLOOR);
  const rest = judgePoolFair(Math.max(0, poolWhole(budget) - given), new Map<string, number>(ids.filter((id) => !first.has(id)).map((id) => [id, wants.get(id)!])), low);
  const shares = new Map<string, number>(ids.map((id) => [id, top.get(id) ?? rest.get(id)!]));
  return { shares, floors: new Map<string, number>(ids.map((id) => [id, Math.min(wants.get(id)!, first.has(id) ? least : low)])) };
}

/**
 * The share of a judge pool's `budget` (sends in flight) each seat takes (the header's `judge heat`), max-min fair over
 * the seats' wants in whole sends: a seat wanting no more than an equal split of what is left takes its want, until none
 * does, and the seats left split what remains equally, its indivisible remainder one send each in the code-unit order
 * of their ids, so every process computes the same shares from the same files. Every seat takes at least
 * min(want, floor), even past the budget (many heats at once: none starves). A want is read as a whole number >= 0
 * (anything else 0), a repeated id once at its largest want; a seat wanting 0 takes 0. Under JUDGE_POOL_BUDGET (96): a
 * seat alone wanting 64 takes 64; two wanting 64 take 48 and 48; one wanting 64 beside one wanting 8 (a round in its
 * tail) takes 64, the other 8; three wanting 64 take 32 each.
 *
 * Final first: while a seat of class 'final' is live, the finals' seats (and any seat naming no class, an old process's,
 * which takes an equal split of what it sees whatever the rest decide, so it is reserved one) split the budget as above
 * first, and the 'practice' seats split what is left, max(0, budget - those shares), each floored at
 * min(want, JUDGE_POOL_PRACTICE_FLOOR) (1), not 4: so a final alone wanting 64 beside 25 practice heats takes 64, and the
 * pool holds at most the budget plus one a practice heat. A repeated id is in the first tier when any of its entries
 * is. With no final live, the classes change nothing: the equal shares above, exactly.
 */
export function judgePoolShares(budget: number, seats: readonly JudgePoolSeatWantT[], floor: number = JUDGE_POOL_FLOOR): Map<string, number> {
  return judgePoolTiers(budget, seats, floor).shares;
}

/**
 * The sends in flight seat `id` may hold now (openJudgePoolSeat's share()): its share (judgePoolShares) less the pool's
 * observed excess, what the other seats hold in flight past their own shares (each `flying` known, past its share;
 * an unknown one, an old process's, as within it), never under its floor (min(want, its tier's floor)) and never past
 * its share. A heat cancels nothing in flight when its share falls, it only stops sending: without this a heat that
 * joins (or whose want rises, a final's next Swiss round) would fill to its share at once while the others still hold
 * their old ones, past the budget by what they hold over (a final at 64 beside three full practice heats: 136 for
 * 10-13 s). With it the joiner grows as the others' sends complete, and the pool's total stays within the budget plus
 * the floors, however many join at once (each takes the whole excess off its own share). A seat absent from `seats`: 0.
 */
export function judgePoolAllowance(budget: number, seats: readonly JudgePoolSeatCountT[], id: string, floor: number = JUDGE_POOL_FLOOR): number {
  const { shares, floors } = judgePoolTiers(budget, seats, floor);
  const mine = shares.get(id);
  if (mine === undefined) return 0;
  // Each other seat's sends in flight, a repeated id at its most; past its share, the excess.
  const held = new Map<string, number>();
  for (const s of seats) {
    if (s.id === id || s.flying === undefined || s.flying === null) continue;
    held.set(s.id, Math.max(held.get(s.id) ?? 0, poolWhole(s.flying)));
  }
  let over = 0;
  for (const [other, n] of held) over += Math.max(0, n - (shares.get(other) ?? 0));
  return Math.min(mine, Math.max(floors.get(id)!, mine - over));
}

/** A live heat's seat in the judge pool (openJudgePoolSeat): what the sender reads and tells each turn, and its end. */
export interface JudgePoolSeat {
  /** Its id: its file's name stem, and its place in the shares' remainder order. */
  readonly id: string;
  /**
   * The sends in flight this heat may hold now: its allowance as last computed (judgePoolAllowance: its share less what
   * the others hold past theirs), never under min(want, its tier's floor); the whole budget once the pool's I/O failed.
   */
  share(): number;
  /** The sends the heat could use right now (a whole number, held to the budget): its share recomputed against the seats last read, and written at the next refresh. */
  want(n: number): void;
  /** The sends the heat holds in flight now (a whole number), backups counted: written to its `<id>.seat` at the next refresh, for the others' bound (judgePoolAllowance). */
  flying(n: number): void;
  /**
   * Start one refresh (never awaited, never two at once) once the last began JUDGE_POOL_REFRESH_MS ago or the beat is
   * due (JUDGE_POOL_BEAT_MS since the last write): the file written when its want moved or the beat is due, the
   * directory read, the share recomputed.
   */
  tick(): void;
  /** Remove its file (once its refresh in hand ends); again, the same promise. Never rejects. */
  close(): Promise<void>;
}

export interface JudgePoolSeatOptions {
  /** The seats' directory (judgePoolDir): made when missing. */
  dir: string;
  /** The pool's sends in flight across every seat (default JUDGE_POOL_BUDGET). */
  budget?: number;
  /** The clock the seat's `at` and its refreshes run on (default Date.now). */
  clock?: Pick<JudgeHeatClock, 'now'>;
  /** What the seat's file and its log lines name it (default `a judge heat`). */
  label?: string;
  /** The sends the heat could use as it opens (default the budget). */
  want?: number;
  /** Its heat's class (judgePoolShares: a final's goes first; default 'practice'). */
  class?: JudgePoolClassT;
  /** Where an I/O failure is said, once per line (default console.log). */
  log?: (line: string) => void;
}

/** How old a seat's file (by its `at`; a file that does not read, or a writer's temp file, by its mtime) is removed by whoever reads it. */
const JUDGE_POOL_REMOVE_MS = 10 * 60_000;

/**
 * Take a live heat's seat in the judge pool (the header's `judge heat`): its files written (`<id>.json` at v1 for every
 * process, `<id>.seat` at v2 with its class and sends in flight for those that read it; each a file beside it renamed
 * into place) and the directory read once before it resolves, so its first share() is right. A reader takes a seat's
 * fresh `<id>.seat` over its `<id>.json`, and an `<id>.json` alone (an old process's seat) as naming no class and no
 * count (judgePoolShares, judgePoolAllowance). The pool can never cost a heat:
 * an I/O failure of a write, a read or the removal is logged once per line, and the seat then answers the whole budget
 * (its own width alone then bounds the heat, as before the pool) until a refresh goes through whole; this never rejects.
 */
export async function openJudgePoolSeat(o: JudgePoolSeatOptions): Promise<JudgePoolSeat> {
  const budget = o.budget !== undefined && Number.isSafeInteger(o.budget) && o.budget > 0 ? o.budget : JUDGE_POOL_BUDGET;
  const clock = o.clock;
  const now = (): number => (clock === undefined ? Date.now() : clock.now());
  const log = o.log ?? ((line: string) => console.log(line));
  const label = o.label ?? 'a judge heat';
  const id = uuidv7();
  const path = join(o.dir, `${id}.json`);
  const pathV2 = join(o.dir, `${id}.seat`);
  const cls: JudgePoolClassT = o.class === 'final' ? 'final' : 'practice';
  const held = (n: number): number => (Number.isFinite(n) && n > 0 ? Math.min(budget, Math.floor(n)) : 0);
  let want = held(o.want ?? budget);
  // The sends its heat holds in flight, as last told.
  let flying = 0;
  // The other seats as last read, this seat's allowance against them, whether the pool's I/O failed since.
  let others: JudgePoolSeatCountT[] = [];
  let share = budget;
  let broken = false;
  // The want its `<id>.json` holds (null before its first write) and when it was written; the want and count its
  // `<id>.seat` holds (null before its first write); when the last refresh began.
  let wrote: number | null = null;
  let wroteAt = Number.NEGATIVE_INFINITY;
  let wroteV2: { want: number; flying: number } | null = null;
  let refreshedAt = Number.NEGATIVE_INFINITY;
  let running: Promise<void> | null = null;
  let closing: Promise<void> | null = null;
  const said = new Set<string>();
  const fail = (what: string, err: unknown): void => {
    broken = true;
    const code = (err as NodeJS.ErrnoException | null)?.code;
    const why = typeof code === 'string' ? code : err instanceof Error ? err.message : String(err);
    const line = `judge pool: the seat of ${label} at ${o.dir} could not be ${what} (${why}): its own width alone bounds the heat, as before the pool`;
    if (said.has(line)) return;
    said.add(line);
    try {
      log(line);
    } catch {
      // A log that throws costs the heat nothing either.
    }
  };
  const recompute = (): void => {
    share = judgePoolAllowance(budget, [...others, { id, want, class: cls }], id);
  };
  // One file written whole: a file beside it renamed into place.
  const put = async (file: string, body: Record<string, string | number>): Promise<void> => {
    const tmp = join(o.dir, `.${id}-${uuidv7()}.tmp`);
    try {
      await writeFile(tmp, canonicalJson(body), { mode: 0o644 });
      await rename(tmp, file);
    } catch (err) {
      await unlink(tmp).catch(() => undefined);
      throw err;
    }
  };
  // `<id>.json` when the beat is due or its want moved, `<id>.seat` then too and whenever its count moved.
  const write = async (beat: boolean): Promise<void> => {
    const n = want;
    const f = flying;
    const v1 = beat || n !== wrote;
    if (!v1 && wroteV2 !== null && wroteV2.want === n && wroteV2.flying === f) return;
    const at = now();
    const stamp = new Date(at).toISOString();
    await mkdir(o.dir, { recursive: true });
    if (v1) {
      await put(path, { format: JUDGE_POOL_FORMAT, id, label, want: n, at: stamp });
      wrote = n;
      wroteAt = at;
    }
    await put(pathV2, { format: JUDGE_POOL_FORMAT_V2, id, label, class: cls, want: n, flying: f, at: stamp });
    wroteV2 = { want: n, flying: f };
  };
  // A file that does not read, or a writer's temp file, removed once 10 minutes old by its mtime: best effort.
  const sweep = async (name: string): Promise<void> => {
    try {
      const st = await stat(join(o.dir, name));
      if (Date.now() - st.mtimeMs > JUDGE_POOL_REMOVE_MS) await unlink(join(o.dir, name));
    } catch {
      // Gone already, or another reader's to remove.
    }
  };
  const read = async (): Promise<void> => {
    const t = now();
    const names = await readdir(o.dir);
    const seen = new Map<string, JudgePoolSeatCountT>();
    // A seat's `<id>.seat` first: fresh, it stands for the seat (its class and count), and its `<id>.json` goes unread.
    for (const name of names) {
      const m = JUDGE_POOL_FILE_V2_RE.exec(name);
      if (m === null || m[1] === id) continue;
      let seat: z.infer<typeof JudgePoolSeatFileV2>;
      try {
        seat = JudgePoolSeatFileV2.parse(JSON.parse(await readFile(join(o.dir, name), 'utf8')));
      } catch {
        await sweep(name);
        continue;
      }
      if (seat.id !== m[1]) continue;
      const age = t - Date.parse(seat.at);
      if (age > JUDGE_POOL_REMOVE_MS) {
        await unlink(join(o.dir, name)).catch(() => undefined);
        continue;
      }
      if (age > JUDGE_POOL_STALE_MS) continue;
      seen.set(seat.id, { id: seat.id, want: seat.want, class: seat.class, flying: seat.flying });
    }
    // Then each `<id>.json` with no fresh `<id>.seat`: an old process's seat, naming no class and no count.
    for (const name of names) {
      const m = JUDGE_POOL_FILE_RE.exec(name);
      if (m === null) {
        if (name.startsWith('.') && name.endsWith('.tmp')) await sweep(name);
        continue;
      }
      if (m[1] === id || seen.has(m[1]!)) continue;
      let seat: z.infer<typeof JudgePoolSeatFile>;
      try {
        seat = JudgePoolSeatFile.parse(JSON.parse(await readFile(join(o.dir, name), 'utf8')));
      } catch {
        await sweep(name);
        continue;
      }
      if (seat.id !== m[1]) continue;
      const age = t - Date.parse(seat.at);
      if (age > JUDGE_POOL_REMOVE_MS) {
        await unlink(join(o.dir, name)).catch(() => undefined);
        continue;
      }
      if (age > JUDGE_POOL_STALE_MS) continue;
      seen.set(seat.id, { id: seat.id, want: seat.want, class: null, flying: null });
    }
    others = [...seen.values()];
  };
  const refresh = async (beat: boolean): Promise<void> => {
    try {
      await write(beat);
    } catch (err) {
      fail('written', err);
      return;
    }
    try {
      await read();
    } catch (err) {
      fail('read', err);
      return;
    }
    broken = false;
    recompute();
  };
  const seat: JudgePoolSeat = {
    id,
    share: () => (broken ? budget : share),
    want(n) {
      want = held(n);
      if (!broken) recompute();
    },
    flying(n) {
      flying = poolWhole(n);
    },
    tick() {
      if (closing !== null || running !== null) return;
      const t = now();
      const beat = t - wroteAt >= JUDGE_POOL_BEAT_MS;
      if (!beat && t - refreshedAt < JUDGE_POOL_REFRESH_MS) return;
      refreshedAt = t;
      running = refresh(beat).finally(() => {
        running = null;
      });
    },
    close() {
      closing ??= (async () => {
        if (running !== null) await running;
        if (wrote === null) return;
        // `<id>.seat` first: a reader that finds `<id>.json` alone counts it as an old process's seat until it goes too.
        for (const file of [pathV2, path]) {
          try {
            await unlink(file);
          } catch (err) {
            if ((err as NodeJS.ErrnoException).code !== 'ENOENT') fail('removed', err);
          }
        }
      })();
      return closing;
    },
  };
  try {
    refreshedAt = now();
  } catch (err) {
    fail('timed', err);
  }
  await refresh(true);
  return seat;
}

/**
 * The seat a heat takes in the judge pool while it sends (JudgeWorkerDeps.pool; the header's `judge heat`), of its
 * class (a final's heat 'final', a dev grade's provisional one 'practice'): on the deps' pool, else, with none named,
 * only on the environment's broker; null: none.
 */
async function judgePoolSeatOf(deps: Pick<GradeWorkerDeps, 'judge' | 'blobs'>, label: string, cls: JudgePoolClassT, log: (line: string) => void): Promise<JudgePoolSeat | null> {
  const pool = deps.judge?.pool;
  if (pool === null) return null;
  if (pool === undefined && deps.judge?.broker !== undefined) return null;
  const clock = deps.judge?.clock;
  return openJudgePoolSeat({
    dir: pool?.dir ?? judgePoolDir(deps.blobs),
    ...(pool?.budget === undefined ? {} : { budget: pool.budget }),
    ...(clock === undefined ? {} : { clock }),
    label,
    class: cls,
    log,
  });
}

/**
 * A program/v1 score that passed, built again with its entry's judge heat verdict (performance.judge): grade.ts
 * scoreWithTiming's twin, the score's own facts and inputs as they were, the entry's facts and the rules given. A
 * verdict moves no eligibility, so only performance.judge is new; grader/regrade.ts builds the same from the heat's
 * record (judgeVerdictOf). A TypeError for a score that is no program/v1 one, or did not pass. What createProgramHeatHandler
 * writes on a judged run; with null, the score built again with no verdict, what it writes on a run the heat left out
 * whose score carried one.
 */
export function scoreWithJudge(score: ScoreT, judge: ProgramJudgeScoreT | null, entry: EntryFacts, rules: EligibilityRules): { result: ScoreT; result_sha256: string } {
  const perf = score.performance;
  if (perf.kind !== 'program/v1') throw new TypeError(`a judge verdict is a program/v1 score's, and this score is ${perf.kind}`);
  if (perf.passed !== true) throw new TypeError('a judge verdict is the verdict of an entry that passed the gate, and this score did not pass');
  const result = buildScore(
    {
      harness: score.harness,
      image_digest: score.image_digest,
      dataset_sha256: score.dataset_sha256,
      seed: score.seed,
      deterministic: !score.flags.includes('nondeterministic'),
      execution_flags: score.flags.filter((f) => f !== 'nondeterministic'),
      house: entry.house,
      baseline: entry.baseline,
    },
    { action_log_sha256: score.action_log_sha256, performance: { kind: 'program/v1', scores: perf.scores, ...(judge === null ? {} : { judge }) }, performance_flags: [], cost: score.cost, authorship: score.authorship, size: score.size },
    rules,
    score.scorer_version,
  );
  return { result, result_sha256: scoreDigest(result).sha256 };
}

/** The judge directory a bundle seals, read (readJudgeDir): the judge's prompt, and its house anchors (each file's sha256 and size) with their bytes by sha256. */
export interface JudgeDirInputs {
  prompt: string;
  anchors: { file: string; artifact_sha256: string; artifact_bytes: number }[];
  artifacts: Map<string, Uint8Array>;
}

/**
 * Read the judge directory a bundle seals under the competition's directory (cli/grade-local.ts's local heat):
 * readJudgeTree of judge.dir there.
 */
export function readJudgeDir(compDir: string, judge: ProgramJudgeT): JudgeDirInputs | { refused: string } {
  return readJudgeTree(join(compDir, ...judge.dir.split('/')), judge);
}

/**
 * Read the judge directory a bundle seals at `judgeDir` (judgeHeatInputs, withProvisionalJudge: where judgedTreesOf
 * finds it, the competition's directory or a sponsored judged-artifact competition's materialized one; readJudgeDir),
 * held to its tree digest judge_sha256 (treeSha256): its prompt and its anchors. `refused` when no such directory is
 * there or another one is: no retry mends that.
 */
export function readJudgeTree(judgeDir: string, judge: ProgramJudgeT): JudgeDirInputs | { refused: string } {
  let judgeSha: string;
  try {
    judgeSha = treeSha256(judgeDir);
  } catch (err) {
    return { refused: `the judge directory ${judge.dir} does not read (${err instanceof Error ? err.message : String(err)}): the image holds no judge for this bundle` };
  }
  if (judgeSha !== judge.judge_sha256) {
    return { refused: `the judge directory ${judge.dir} hashes to ${judgeSha}, and the bundle seals ${judge.judge_sha256}: the image holds another judge than the bundle's` };
  }
  const prompt = readFileSync(join(judgeDir, ...judge.agent.prompt.split('/')), 'utf8');
  const artifacts = new Map<string, Uint8Array>();
  // The anchors: regular files flat under anchors/ (server/competitions/load.ts held them so at load, and the digest just matched).
  const anchorsDir = join(judgeDir, PROGRAM_JUDGE_ANCHORS_DIR);
  const anchors = readdirSync(anchorsDir)
    .sort(compareCodeUnits)
    .map((file) => {
      const bytes = new Uint8Array(readFileSync(join(anchorsDir, file)));
      const sha256 = sha256Hex(bytes);
      artifacts.set(sha256, bytes);
      return { file, artifact_sha256: sha256, artifact_bytes: bytes.byteLength };
    });
  return { prompt, anchors, artifacts };
}

/** Why the judge cannot read an artifact (grader/judge-call.ts judgeUserContent: JudgeArtifactRefused, an unknown image type), or null when it can. */
async function judgeArtifactRefusal(media: ProgramJudgeT['media'], art: { sha256: string; bytes: Uint8Array }): Promise<string | null> {
  const { JudgeArtifactRefused, judgeUserContent } = await import('./judge-call.ts');
  try {
    judgeUserContent(media, art, art);
    return null;
  } catch (err) {
    if (err instanceof JudgeArtifactRefused) return err.message;
    throw err;
  }
}

/** A judge heat's field read in: each entry's artifact from its final grade's outputs, the house anchors, and the judge's prompt. */
interface JudgeHeatInputs {
  setup: JudgeHeatSetupT;
  prompt: string;
  /** Every member's bytes, by sha256: what the judge reads. */
  artifacts: Map<string, Uint8Array>;
  /** Each field entry the heat judges, its grade run and artifact, in the field's order. */
  entries: { row: CodeHeatFieldRow; run: RunRow; artifact_sha256: string; artifact_bytes: number }[];
  /** Each field entry left out of the heat, and why: it wrote no artifact, or one the judge cannot read. */
  left: { row: CodeHeatFieldRow; run: RunRow; why: string }[];
}

/**
 * Read a due judge heat's inputs (judgeCodeHeat): the judge directory the bundle seals (judgedTreesOf, readJudgeTree),
 * its prompt and its anchors, and each field entry's artifact, the output file judge.artifact of its final grade
 * (program.ts readOutputFile). An entry that passed and wrote no artifact, or one the judge cannot read
 * (judgeArtifactRefusal), is left out, and says why: its run is linked to the heat's record with no verdict, so it
 * ranks below every judged entry and holds up nothing. A PermanentJobError when the image holds another judge
 * directory (or a sponsored judged-artifact competition's cannot be materialized: judgedTreesOf), a field run ran under
 * another plan, an entry's outputs do not read, or no entry is left to judge: no retry mends those.
 */
async function judgeHeatInputs(deps: GradeWorkerDeps, due: JudgeHeatDue, what: string): Promise<JudgeHeatInputs> {
  const { db, blobs } = deps;
  const { judge, field, bundle } = due;
  const { JudgeHeatError, judgeHeatSetup } = await import('./judge-heat.ts');
  const phaseSetup = await codeHeatPhaseSetup(deps, due);
  const plan = programPlan(phaseSetup);
  // Read where the image or the grader's cache holds it, never the setup's compDir: a k8s setup's is its scorer's stage directory.
  const dir = readJudgeTree((await judgedTreesOf(deps, due.comp.slug, due.harness, judge)).judgeDir, judge);
  if ('refused' in dir) throw new PermanentJobError(`${what}: ${dir.refused}`);
  const { prompt, anchors, artifacts } = dir;
  const runRows = field.length === 0 ? [] : await db.select().from(run).where(inArray(run.id, field.map((f) => f.run_id)));
  const runOf = new Map(runRows.map((r) => [r.id, r]));
  const entries: JudgeHeatInputs['entries'] = [];
  const left: JudgeHeatInputs['left'] = [];
  for (const row of field) {
    const r = runOf.get(row.run_id);
    // A run gone since the field was read: the retry reads the field as it now stands.
    if (r === undefined) throw new Error(`${what}: entry ${row.submission_id}'s grade run ${row.run_id} is gone`);
    if (r.seed !== plan.seed) {
      throw new PermanentJobError(`${what}: entry ${row.submission_id}'s final grade (run ${r.id}) ran under seed ${r.seed}, and the phase's plan is seed ${plan.seed}: regrade the phase, then send the heat again`);
    }
    let art: Awaited<ReturnType<typeof readOutputFile>>;
    try {
      art = await readOutputFile(blobs, row.action_log_sha256, judge.artifact);
    } catch (err) {
      throw new PermanentJobError(`${what}: entry ${row.submission_id}'s outputs (run ${r.id}) do not read: ${err instanceof Error ? err.message : String(err)}`);
    }
    if (art === null) {
      left.push({ row, run: r, why: `it passed its final grade and its outputs hold no ${judge.artifact}, the artifact the judge compares (the scorer's gate is to fail an entry that writes none)` });
      continue;
    }
    const refused = await judgeArtifactRefusal(judge.media, art);
    if (refused !== null) {
      left.push({ row, run: r, why: `the judge cannot read its ${judge.artifact} (${refused}; the scorer's gate is to fail an entry whose artifact the judge cannot read)` });
      continue;
    }
    artifacts.set(art.sha256, art.bytes);
    entries.push({ row, run: r, artifact_sha256: art.sha256, artifact_bytes: art.size });
  }
  if (entries.length === 0 && left.length > 0) {
    throw new PermanentJobError(
      `${what}: no entry of the field has an artifact the judge can read (${left.map((l) => `${l.row.submission_id}: ${l.why}`).join('; ')}), so there is no heat to judge. Mend the gate, regrade the phase, then send the heat again`,
    );
  }
  let setup: JudgeHeatSetupT;
  try {
    setup = judgeHeatSetup({
      stage: 'final',
      phaseSeed: plan.seed,
      judge,
      prizes: bundle.prizes,
      entries: entries.map((e) => ({ entry: e.row.submission_id.toLowerCase(), artifact_sha256: e.artifact_sha256, artifact_bytes: e.artifact_bytes })),
      anchors,
    });
  } catch (err) {
    if (err instanceof JudgeHeatError) throw new PermanentJobError(`${what}: its field does not set up: ${err.message}`, { cause: err });
    throw err;
  }
  return { setup, prompt, artifacts, entries, left };
}

/**
 * The calls an earlier attempt kept for this heat (the header's `judge heat`), when they are this heat's (its resume
 * key) and a prefix of its schedule (judge-heat.ts judgeHeatKeptIssue); else none, said under `say`. Whatever the
 * calls, what the heat spent and the keys it minted carry on: the spend goes on the heat's outcome, and an open key is
 * retired before the next is minted.
 */
async function keptJudgeHeat(store: CodeHeatPartialStore, key: string, setup: JudgeHeatSetupT, say: (line: string) => void): Promise<JudgeHeatPartialT> {
  const { JUDGE_HEAT_PARTIAL_FORMAT, JudgeHeatPartial, judgeHeatKeptIssue } = await import('./judge-heat.ts');
  const fresh: JudgeHeatPartialT = { format: JUDGE_HEAT_PARTIAL_FORMAT, key, calls: [], spent_micro_usd: '0', resent: 0, keys: 0, open_key: null };
  const text = await store.read();
  if (text === null) return fresh;
  let parsed: JudgeHeatPartialT;
  try {
    parsed = JudgeHeatPartial.parse(JSON.parse(text));
  } catch (err) {
    say(`the judge calls kept at ${store.where} do not read (${err instanceof Error ? err.message : String(err)}): the heat is judged from its first call`);
    return fresh;
  }
  const issue = parsed.key !== key ? 'they are another heat\'s (its field, its bundle or its prompt has changed since)' : judgeHeatKeptIssue(setup, parsed.calls, parsed.spares ?? []);
  if (issue !== null) {
    say(`the ${parsed.calls.length} judge calls kept at ${store.where} are dropped: ${issue}; the heat is judged from its first call`);
    return judgeHeatPartialSpares({ ...parsed, key, calls: [], resent: 0 }, []);
  }
  return parsed;
}

/**
 * The most judge sends in flight at once in one heat (the header's `judge heat`): a heat's width
 * (JudgeWorkerDeps.concurrency), inside the wider budget every live heat shares (JUDGE_POOL_BUDGET). A judge call on
 * superbot/high takes ~10-50 s, so a final heat of a few hundred calls sent one at a time would run for hours, past its
 * grade job's expiry. Only the calls already planned can go out together: Swiss rounds are sequential (a 14-member
 * field's round is 14 calls) and the playoff's calls are all known at once (an 11-finalist playoff's 110). At 64 a round
 * goes out in one wave and that playoff in two, so a final heat takes a few minutes: at 8, ai-joke-01's final heat (194
 * calls, p50 8.5 s, p95 26 s) took 6 min 17 s. Wider buys nothing: a ramp on live masq on 2026-11-11 (02:13-02:18Z;
 * superbot at high, max_tokens 12100, 30 ordered pairs of makefun-tagline-01's house texts, W requests held in flight
 * 90 s a stage, no judged heat live) had the pool answer all 708 requests at 64 in flight (p50 5.7 s, p90 19.4, p95
 * 25.3, max 59.8; 101.7 tokens/s a call p50) and all 806 at 96 (p50 7.3 s, p90 25.0, p95 34.6, max 104.5; 81.0
 * tokens/s, 79.6% of the speed at 64), none shed: 96 bought 14% more requests only by slowing every call 20%, so 128
 * was never run and 64 is a heat's most. The model pool is one, though, and two finals closing together would put 128
 * in flight before any backup: so the platform's budget is JUDGE_POOL_BUDGET (96), not 64 a heat. Every live heat (a
 * final's, a dev grade's provisional one) holds a seat in the judge pool (openJudgePoolSeat, a file under the blob
 * store every grader process reads) and takes its share of the 96 (judgePoolShares: max-min fair over what each could
 * use right now, backups counted; a dead grader's seat stops counting JUDGE_POOL_STALE_MS on), and never more than its
 * width: a heat alone still tops at 64 in flight, backups counted, the sender capping both its want and its sends at
 * min(its width in force, its share). A pool that pushes back (a rate-limited re-send, grader/judge-call.ts
 * JudgeHeat.pushbacks) narrows a heat below its share for a while (JUDGE_PUSHBACK_FLOOR and the rest).
 */
export const JUDGE_HEAT_CONCURRENCY = 64;

/**
 * The judge pool's budget (the header's `judge heat`; JudgeWorkerDeps.pool): the judge sends in flight across every live
 * heat on the platform, primaries and backups alike, in every grader process together. Its own number, wider than a
 * heat's width: measured on the live pool 2026-11-11 with no heat live, 64 in flight ran clean (p50 5.7 s, 101.7
 * tokens/s a call); 96 shed nothing and ran each call at 79.6% of that (81.0 tokens/s), about a fifth more work in
 * total; 128 was not measured. Two heats at once get 48 each, and a heat whose round is in its tail gives the rest to
 * the other (judgePoolShares); a heat alone still holds at most its width, JUDGE_HEAT_CONCURRENCY. While a final's heat
 * is live it takes its share first and the practice heats split the rest, at least JUDGE_POOL_PRACTICE_FLOOR each; a
 * heat that joins takes no more than its share less what the others hold past theirs (judgePoolAllowance).
 */
export const JUDGE_POOL_BUDGET = 96;
/** The least share of the pool a seat takes, its want permitting, however many heats are live (judgePoolShares): none starves. */
export const JUDGE_POOL_FLOOR = 4;
/**
 * The least share a practice heat's seat takes while a final's is live (judgePoolShares: final first), its want
 * permitting: 1, not JUDGE_POOL_FLOOR, so 25 practice heats beside a final at 64 put at most 96 + 25 in flight, not 164.
 */
export const JUDGE_POOL_PRACTICE_FLOOR = 1;
/** How often a seat's file is rewritten when its want moved, and the directory read, at most, ms (openJudgePoolSeat); a heat holding a seat turns at least this often. */
export const JUDGE_POOL_REFRESH_MS = 1_000;
/** How often a seat's file is rewritten at least, its want unchanged, ms (openJudgePoolSeat): its heartbeat. */
export const JUDGE_POOL_BEAT_MS = 10_000;
/** How old a seat's file may be and still count, ms (openJudgePoolSeat): past it, its grader died and its share goes back. */
export const JUDGE_POOL_STALE_MS = 30_000;

/**
 * A heat masq's pool pushes back on (a rate-limited request re-sent: grader/judge-call.ts JudgeHeat.pushbacks; the
 * header's `judge heat`): each sender turn that sees the count risen halves the width in force, never under this (nor
 * under a narrower `concurrency`, which it never raises), sends no backup for JUDGE_PUSHBACK_HOLD_MS, and each
 * JUDGE_PUSHBACK_QUIET_MS with no new pushback gives JUDGE_PUSHBACK_STEP back, up to the `concurrency` it started from.
 * Calls in flight are never cancelled for it.
 */
export const JUDGE_PUSHBACK_FLOOR = 16;
/** How long after a pushback no backup is sent, ms (JUDGE_PUSHBACK_FLOOR). */
export const JUDGE_PUSHBACK_HOLD_MS = 30_000;
/** The quiet a heat's width waits for before it widens again after a pushback, ms (JUDGE_PUSHBACK_FLOOR). */
export const JUDGE_PUSHBACK_QUIET_MS = 15_000;
/** The calls each quiet JUDGE_PUSHBACK_QUIET_MS gives back to a width a pushback narrowed (JUDGE_PUSHBACK_FLOOR). */
export const JUDGE_PUSHBACK_STEP = 8;

/** What one call of a heat came to: its answer, or what JudgeHeat.call threw. */
export type JudgeSentT = { ok: true; answer: JudgeCallResult } | { ok: false; err: unknown };

/** What a heat makes of a call that settled, taken in planned order: kept (pushed onto its calls), sent again, or the heat stopped. */
export type JudgeTakenT = 'kept' | 'again' | 'stop';

/** The clock a heat's sends are aged and stamped by (epoch ms), and the sleep its backup wake waits on (rejecting once `signal` aborts). */
export interface JudgeHeatClock {
  now(): number;
  sleep(ms: number, signal?: AbortSignal): Promise<void>;
}

/** The models seen answering a forced form (JudgeHeatCallsRun.formsSeen): a heat on one of them sends its first call with the rest. */
export interface JudgeFormsSeen {
  has(model: string): boolean;
  note(model: string): void;
}

/**
 * A heat's progress as its calls settle (JudgeHeatCallsRun.progress): the calls taken (kept), the answers settled past
 * them in planned order (each with its planned index and call; a fault ahead is not listed), the calls with a send in
 * flight, and the batch (the calls one planning added: a Swiss round, the playoff, an adaptive round) last planned.
 */
export type JudgeHeatProgressT = {
  taken: number;
  ahead: { index: number; planned: JudgePlannedCallT; answer: JudgeCallResult }[];
  flying: number;
  batch: { start: number; size: number };
};

/** A heat's calls to send concurrently and take in order (sendJudgeHeatCalls). */
export interface JudgeHeatCallsRun {
  /**
   * The heat's calls and, where it keeps them, its ledger and its pushback count (an opened heat keeps both): with
   * `requestsLeft` absent (a hand-made heat) no backup is held back for the ledger; with `pushbacks` absent the pool
   * never pushes back (JUDGE_PUSHBACK_FLOOR).
   */
  heat: Pick<JudgeHeat, 'call' | 'forms' | 'requestsLeft' | 'pushbacks'>;
  setup: JudgeHeatSetupT;
  /** The calls kept so far, in the heat's order: `take` pushes each call it keeps onto it. */
  calls: JudgeHeatCallT[];
  /** The most calls in flight at once (1 or more; anything else sends one at a time); a pushback narrows it for a while. */
  concurrency: number;
  /** Aborts the calls in flight: the heat's own (openJudgeHeat's), which each backed-up send's signal joins. */
  signal?: AbortSignal;
  /**
   * Each call as it settles, strictly in planned order (its place is calls.length): 'kept' once pushed onto the calls,
   * 'again' to send it again, 'stop' to stop the heat. `spares` are the call's other sends (grader/judge-heat.ts
   * JudgeHeatSpare, its `call` the planned index), every one ended by then; none for a call that faulted. What it throws
   * stops the heat and propagates.
   */
  take: (planned: JudgePlannedCallT, sent: JudgeSentT, spares: readonly JudgeHeatSpareT[]) => Promise<JudgeTakenT>;
  /**
   * Whether the calls settled but not yet taken (each behind a call still in flight) already fail the heat, whatever the
   * calls before them come to: no more planned calls are sent (a resend `take` asks for still is), and no backup.
   */
  doomed: (ahead: readonly JudgeSentT[]) => boolean;
  /** The backup rule (grader/judge-backup.ts); absent or null: each call is sent once. */
  backup?: JudgeBackupRule | null;
  /** The clock (default Date.now and node:timers/promises). */
  clock?: JudgeHeatClock;
  /** The heat's planned calls, kept ones included (default judgeHeatPlannedCalls(setup)): what the ledger holds back for. */
  callsTotal?: number;
  /** The requests held back for the heat's one fault re-send: JUDGE_CALL_ATTEMPTS while it is unspent, else 0 (default 0). */
  reserveRequests?: () => number;
  /** After each settle and each take: the heat's progress (JudgeHeatProgressT). What it throws is swallowed. */
  progress?: (p: JudgeHeatProgressT) => void;
  /** The models seen answering a forced form: noted as a call's first request in one answers HTTP 200. */
  formsSeen?: JudgeFormsSeen;
  /** Where a backup's odd throw, a spare that does not hold or a rule that throws is said (default console.log). */
  log?: (line: string) => void;
  /**
   * The heat's seat in the platform's one budget of judge sends in flight (openJudgePoolSeat; the header's `judge
   * heat`): told each turn what the heat could use and (with `flying`) what it holds in flight, its share caps the sends
   * in flight, backups counted. Absent: the width alone bounds the heat, as before the pool.
   */
  seat?: Pick<JudgePoolSeat, 'share' | 'want' | 'tick'> & Partial<Pick<JudgePoolSeat, 'flying'>>;
  /**
   * Reporting only (a final heat's live document: judgeCodeHeat's JudgeLiveFeed.flying): the calls in flight (sent, not
   * yet settled), in planned order, each with when it last went out (`now`), told after each batch sent, each call
   * settled and each call sent again, whenever the list moved; [] once the last one settles. It changes nothing the heat
   * does, and must not throw: what it throws is dropped.
   */
  flying?: (out: { planned: JudgePlannedCallT; at: Date }[]) => void;
  /** The clock `flying` stamps a call sent with (default the wall clock, as `clock` reads it). */
  now?: () => Date;
}

/** Forms that ask the forced verdict tool: a model that always thinks refuses them, and the heat learns so from a call. */
const forcedForms = (forms: JudgeForms): boolean => forms.some((f) => f === 'answer' || f === 'tool');

/** The backup wake's bounds, ms: never sooner (a send coming due now waits this long at most), never later. */
const JUDGE_BACKUP_WAKE_MIN_MS = 50;
const JUDGE_BACKUP_WAKE_MAX_MS = 1_000;

/**
 * What a cancelled send's spare says (its `invalid`), and the reason its send is aborted with: it was cancelled, nothing
 * failed, and send `decided` of its call (numbered as the record's `send`, from 0) decided it; null: another send did.
 * It names no call number: the spare's own `call` (from 0) does.
 */
export function judgeSendCancelledText(send: number, decided: number | null): string {
  if (decided === null || decided === send) return 'cancelled: another send of this call decided it first';
  return `cancelled: send ${decided} of this call (${decided < send ? 'an earlier' : 'a later'} send) decided it first`;
}

/**
 * Send a heat's calls still to come (sendJudgeHeat; the provisional heat): the calls grader/judge-heat.ts
 * judgeHeatSchedule has already planned past the kept ones (a Swiss round's, the playoff's, a provisional heat's anchors)
 * go out in planned order, up to `concurrency` at once, and each is handed to `take` strictly in planned order, a call that
 * settles early held until every call before it is taken: the calls kept are a serial run's, byte for byte, and the schedule
 * is planned again (and the calls kept checked against it, as judgeHeatNextCall does) after each. While the heat's forms are
 * forced, no call of this run has been taken and `formsSeen` has not seen its model answer one, one call goes alone: a
 * forced form masq refuses its model (grader/judge-call.ts `no force`) moves the heat's later calls to the unforced forms,
 * as a serial run's second call would be.
 *
 * With a `backup` rule (grader/judge-backup.ts), a call still out may get a backup, a second (or third) send of the same
 * request: after each settle and on a wake (the soonest a send could come due, 50 ms to 1 s on), every call with no
 * verdict yet is weighed by judgeBackupDue over its batch's counts and its newest send's age, and backed up when due, the
 * heat's forms are known, the run is not aborted or doomed, the heat's ledger keeps room for every call still to send and
 * the fault re-send (heat.requestsLeft() >= 2 + 2 x (callsTotal - calls sent, kept ones included) + reserveRequests()),
 * and fewer than width + ceil(width / 4) sends fly (primaries go out only below the width). Each send has its own
 * AbortController, joined to the heat's signal. judgeCallOutcome decides: the first send to answer with a verdict; the
 * call's other sends are then aborted and awaited, and only then is the call settled (for `take`, `doomed` and
 * `progress`), its spares final and its requests back. A send that faults while another flies waits for it: a call faults
 * only when every send faulted (`take` gets the first send's error, and its faulted sends are no spares), and is invalid
 * only when every send is done and none gave a verdict. A backup's throw that is no JudgeCallFault is logged and ends
 * that send faulted; the rule's own throw is logged once and read as no backup. Without a rule each call is sent once,
 * as before backups.
 *
 * The pool's pushback, at every width: each turn (a settle, a take, a wake) reads the heat's count of rate-limited
 * re-sends (grader/judge-call.ts JudgeHeat.pushbacks); risen, the width in force halves, never under
 * min(JUDGE_PUSHBACK_FLOOR, concurrency), the line is logged when it narrows, and no backup goes out for
 * JUDGE_PUSHBACK_HOLD_MS (a call due meanwhile waits for the hold's end); each JUDGE_PUSHBACK_QUIET_MS with no new one
 * gives JUDGE_PUSHBACK_STEP back up to `concurrency`, taken at the next turn (no timer of its own). A call in flight is
 * never cancelled for it, and the re-sends stay what they are (no attempt, no request of the ledger): it only ever
 * lowers what goes out. With no pushback the sends are as before.
 *
 * With a `seat` (the platform's one budget of judge sends, the header's `judge heat`): each turn tells it the heat's
 * want and ticks it (a throw of it logged once, its share then the width), the want being the sends the heat could
 * have in flight now: with U its planned calls in hand not yet settled (sent or not; one settled ahead of the kept
 * prefix is settled), min(width in force, U + min(U x (maxSends - 1), the backups the rule's budget still allows)) (U
 * with no rule, 1 while the first call goes alone, 0 at the end), so a round's tail keeps room for its backups and the
 * rest of the budget goes to the other heats. The sends in flight, primaries and backups together, then never pass
 * max(1, min(width in force, the seat's share)) as a send starts (no quarter of room past the width for backups), a
 * backup due taking a free place before a new primary (the backup pass runs first) and a call sent again waiting for a
 * place like a primary; a share that falls below what flies cancels nothing, and the turns come at least every
 * JUDGE_POOL_REFRESH_MS (a timer cancelled as the backup wake's is), so the seat's beat goes on through one long call
 * and a share that rises is filled. A seat that keeps a count (openJudgePoolSeat's `flying`) is told the sends in
 * flight each turn, before its tick and again after the turn's sends, and 0 at the end: the other seats read it to hold
 * a heat that joins (or whose want rises) under the budget until this one's sends past its share complete
 * (judgePoolAllowance). Without a seat the sends are as before the pool.
 *
 * `flying`, when given, is told the calls in flight as they move (reporting only: nothing above depends on it).
 * They are the calls with a send out and no outcome yet, in planned order, each with when its newest send went out
 * (`now`, else the clock), told whenever that list moved: after the sends a turn makes, a call settled or one sent
 * again, and [] once the last settles; what it throws is dropped.
 *
 * True when every planned call is kept; false when `take` stopped the heat. Before it returns or throws (a `take` that
 * throws, an abort, or a JudgeHeatError when the calls kept are not the heat's), every send in flight has settled, its
 * spend on the heat's meter, and no timer is left armed.
 */
export async function sendJudgeHeatCalls(o: JudgeHeatCallsRun): Promise<boolean> {
  const jh = await import('./judge-heat.ts');
  const { JudgeCallFault } = await import('./judge-call.ts');
  const { judgeBackupDue, judgeBackupThresholdMs, judgeCallOutcome } = await import('./judge-backup.ts');
  const { calls, signal } = o;
  // The width the run starts from, and the pushback's narrowed width (JUDGE_PUSHBACK_FLOOR; `follow` lowers and restores it).
  const ceiling = Number.isSafeInteger(o.concurrency) && o.concurrency > 1 ? o.concurrency : 1;
  let width = ceiling;
  // The width in force: the one place the primary fill and the backup room read it.
  const widthNow = (): number => width;
  const rule = o.backup ?? null;
  const log = o.log ?? ((line: string) => console.log(line));
  let clock: JudgeHeatClock;
  if (o.clock !== undefined) clock = o.clock;
  else {
    const timers = await import('node:timers/promises');
    clock = { now: () => Date.now(), sleep: (ms, sig) => timers.setTimeout(ms, undefined, sig === undefined ? undefined : { signal: sig }) };
  }
  const model = o.setup.agent.model;
  const callsTotal = o.callsTotal ?? jh.judgeHeatPlannedCalls(o.setup);
  const maxSends = rule === null ? 1 : Math.max(1, Math.min(rule.maxSends, jh.JUDGE_HEAT_MAX_SENDS));
  // The heat's seat in the judge pool, and its share as this turn read it.
  const seat = o.seat ?? null;
  let share = Number.POSITIVE_INFINITY;
  // A backup takes room a primary would not: primaries fill the width in force, backups up to a quarter more. With a
  // seat, every send in flight counts against min(width, share), and never fewer than one may fly.
  const sendCap = (): number => (seat === null ? widthNow() + Math.ceil(widthNow() / 4) : Math.max(1, Math.min(widthNow(), share)));
  const plan = (): JudgePlannedCallT[] => {
    const s = jh.judgeHeatSchedule(o.setup, calls);
    if (s.issue !== null) throw new jh.JudgeHeatError(`the calls made are not the heat's: ${s.issue}`);
    return s.planned;
  };
  let planned = plan();
  // The batches: the run of planned calls each planning added (a resumed attempt's first, the calls it has still to settle).
  const batches: { start: number; size: number }[] = [{ start: calls.length, size: Math.max(0, planned.length - calls.length) }];
  const batchOf = (i: number): { start: number; size: number } => {
    for (let k = batches.length - 1; k >= 0; k--) if (batches[k]!.start <= i) return batches[k]!;
    return batches[0]!;
  };

  // One send of a call: its own abort, when it went out, and how it ended (null while it flies).
  interface Send {
    n: number;
    ctl: AbortController;
    sentAt: number;
    /** When it went out, as `flying` tells it (`now`, else the clock). */
    wentAt: Date;
    /** Aborted by this run because another send decided its call: never a fault of the call. */
    cancelled: boolean;
    end: { ok: true; answer: JudgeCallResult; at: number } | { ok: false; err: unknown; at: number } | null;
    done: Promise<void>;
  }
  // A call with a send out: its sends in send order, and the deciding send once one answered with a verdict.
  interface OpenCall {
    sends: Send[];
    decided: number | null;
  }
  // The next planned call not yet sent; the calls sent and not yet settled, and those settled but not yet taken, by their place.
  let next = calls.length;
  const open = new Map<number, OpenCall>();
  const settled = new Map<number, { sent: JudgeSentT; spares: JudgeHeatSpareT[] }>();
  const live = new Set<Send>();
  const ended = new Set<number>();
  let taken = 0;
  // This attempt's counters (the rule's budget and threshold).
  let primariesSent = 0;
  let backupsSent = 0;
  const answeredMs: number[] = [];
  const aborted = (): boolean => signal?.aborted === true;
  const ahead = (): JudgeSentT[] => [...settled.values()].map((s) => s.sent);
  const alone = (): boolean => taken === 0 && forcedForms(o.heat.forms()) && o.formsSeen?.has(model) !== true;
  const said = new Set<string>();
  const sayOnce = (kind: string, line: string): void => {
    if (said.has(kind)) return;
    said.add(kind);
    log(line);
  };
  const messageOf = (err: unknown): string => (err instanceof Error ? err.message : String(err));

  // The pool's pushback (JUDGE_PUSHBACK_FLOOR): the heat's count as last read, when backups may go out again, and since
  // when the narrowed width has been quiet. A count that does not read is no pushback.
  const floor = Math.min(JUDGE_PUSHBACK_FLOOR, ceiling);
  const pushbacksNow = (fallback: number): number => {
    try {
      const n = o.heat.pushbacks?.() ?? fallback;
      return Number.isFinite(n) ? n : fallback;
    } catch (err) {
      sayOnce('pushbacks', `judge heat: the heat's pushback count threw (${messageOf(err)}): read as none`);
      return fallback;
    }
  };
  let pushbacks = pushbacksNow(0);
  let backupsFrom = -Infinity;
  let quietFrom = 0;
  // Each turn: a count risen halves the width in force and holds backups; a width narrowed widens a step a quiet spell.
  const follow = (): void => {
    const seen = pushbacksNow(pushbacks);
    if (seen > pushbacks) {
      pushbacks = seen;
      const now = clock.now();
      backupsFrom = now + JUDGE_PUSHBACK_HOLD_MS;
      quietFrom = now;
      const was = width;
      width = Math.max(floor, Math.floor(width / 2));
      if (width < was) log(`judge heat: masq pushed back (${seen} rate-limited re-sends so far): ${width} calls in flight at most, down from ${was}, and no backup for ${JUDGE_PUSHBACK_HOLD_MS / 1_000} s`);
      return;
    }
    if (width >= ceiling) return;
    const steps = Math.floor((clock.now() - quietFrom) / JUDGE_PUSHBACK_QUIET_MS);
    if (steps <= 0) return;
    width = Math.min(ceiling, width + steps * JUDGE_PUSHBACK_STEP);
    quietFrom += steps * JUDGE_PUSHBACK_QUIET_MS;
  };

  // The wall time a send went out at, as `flying` tells it: `now`, else the clock's (a `now` that throws or answers no
  // time is the clock's).
  const wallNow = (at: number): Date => {
    if (o.now !== undefined) {
      try {
        const d = o.now();
        if (d instanceof Date && Number.isFinite(d.getTime())) return d;
      } catch {
        // Reporting only: the clock's time stands in.
      }
    }
    return new Date(at);
  };
  // The sends the heat could have in flight now (the seat's want): its calls in hand not yet settled, and as many
  // backups of them as the rule's budget still allows (the sender's doc comment).
  const wantNow = (): number => {
    const unsettled = Math.max(0, planned.length - calls.length - settled.size);
    if (unsettled === 0) return 0;
    if (alone()) return 1;
    let spare = 0;
    if (rule !== null) {
      const allowed = Math.max(rule.budgetMin, Math.ceil(rule.budgetShare * primariesSent)) - backupsSent;
      spare = Number.isFinite(allowed) ? Math.max(0, allowed) : 0;
    }
    return Math.min(widthNow(), unsettled + Math.min(unsettled * (maxSends - 1), spare));
  };
  // The seat told the sends in flight (for the other seats' bound: judgePoolAllowance), written at its next refresh.
  const seatFlying = (): void => {
    if (seat === null || seat.flying === undefined) return;
    try {
      seat.flying(live.size);
    } catch (err) {
      sayOnce('seat', `judge heat: its seat in the judge pool threw (${messageOf(err)}): its width alone bounds it`);
    }
  };
  // Each turn: the seat told the heat's want and its sends in flight and ticked, and its share read; a seat that throws is the width's.
  const seatTurn = (): void => {
    if (seat === null) return;
    try {
      seat.want(wantNow());
      seat.flying?.(live.size);
      seat.tick();
      const n = seat.share();
      share = typeof n === 'number' && !Number.isNaN(n) ? n : widthNow();
    } catch (err) {
      sayOnce('seat', `judge heat: its seat in the judge pool threw (${messageOf(err)}): its width alone bounds it`);
      share = widthNow();
    }
  };
  // The calls in flight as last told to `flying`: each planned place and when its newest send went out.
  let told: { i: number; at: number }[] = [];
  const tellFlying = (): void => {
    if (o.flying === undefined) return;
    const now: { i: number; at: Date }[] = [];
    for (const [i, c] of [...open].sort(([a], [b]) => a - b)) {
      if (c.decided !== null || !c.sends.some((s) => s.end === null)) continue;
      now.push({ i, at: c.sends[c.sends.length - 1]!.wentAt });
    }
    if (now.length === told.length && now.every((x, k) => x.i === told[k]!.i && x.at.getTime() === told[k]!.at)) return;
    told = now.map((x) => ({ i: x.i, at: x.at.getTime() }));
    try {
      o.flying(now.map((x) => ({ planned: planned[x.i]!, at: new Date(x.at.getTime()) })));
    } catch {
      // Reporting only: what it throws is dropped.
    }
  };

  const sendOne = (i: number, c: OpenCall): void => {
    const p = planned[i]!;
    const [first, second] = p.slot_order === 'ab' ? [p.a, p.b] : [p.b, p.a];
    const ctl = new AbortController();
    // Without a rule nothing is ever cancelled: the heat's own signal, as before backups.
    const opts = rule === null ? (signal === undefined ? {} : { signal }) : { signal: signal === undefined ? ctl.signal : AbortSignal.any([signal, ctl.signal]) };
    const sentAt = clock.now();
    const s: Send = { n: c.sends.length, ctl, sentAt, wentAt: wallNow(sentAt), cancelled: false, end: null, done: Promise.resolve() };
    let call: Promise<JudgeCallResult>;
    try {
      call = o.heat.call(first, second, opts);
    } catch (err) {
      call = Promise.reject(err);
    }
    s.done = call.then(
      (answer) => {
        const at = clock.now();
        s.end = { ok: true, answer, at };
        answeredMs.push(Math.max(0, at - s.sentAt));
        const t = answer.attempts[0];
        if (t !== undefined && (t.form === 'answer' || t.form === 'tool') && t.status === 200) {
          try {
            o.formsSeen?.note(model);
          } catch (err) {
            sayOnce('forms', `judge heat: the forms memo did not take a note (${messageOf(err)})`);
          }
        }
        live.delete(s);
        ended.add(i);
      },
      (err: unknown) => {
        s.end = { ok: false, err, at: clock.now() };
        if (s.n > 0 && !s.cancelled && !(err instanceof JudgeCallFault)) log(`judge heat: backup ${s.n} of call ${i + 1} threw (${messageOf(err)}): it ends faulted`);
        live.delete(s);
        ended.add(i);
      },
    );
    c.sends.push(s);
    live.add(s);
  };
  const sendPrimary = (i: number): void => {
    const c: OpenCall = { sends: [], decided: null };
    open.set(i, c);
    primariesSent++;
    sendOne(i, c);
  };

  // What a send ended on, as the rule reads it.
  const stateOf = (s: Send): JudgeSendState =>
    s.end === null ? { state: 'flying' } : s.end.ok ? { state: 'answered', verdict: s.end.answer.verdict !== null, atMs: Math.max(0, s.end.at) } : { state: 'faulted' };
  const outcomeOf = (sends: readonly Send[]): JudgeCallOutcome => {
    try {
      return judgeCallOutcome(sends.map(stateOf));
    } catch (err) {
      // The rule cannot fail a heat: the first send's own result, as before backups.
      sayOnce('outcome', `judge heat: the backup rule's outcome threw (${messageOf(err)}): a call is its first send's`);
      const s = stateOf(sends[0]!);
      if (s.state === 'flying') return { kind: 'pending' };
      if (s.state === 'faulted') return { kind: 'fault' };
      return s.verdict ? { kind: 'decided', send: 0 } : { kind: 'invalid', send: 0 };
    }
  };
  // A send that is not its call's decision, as the record keeps it (judge-heat.ts judgeHeatSpareOf); null, said, when it does not hold.
  // `decided` is the send that decided the call, null when none did. A cancelled send's `invalid` says it was cancelled and which
  // send decided (sends numbered as the record's `send`, from 0), never the fault its abort surfaced as (judge-call.ts wraps an
  // aborted fetch as "masq could not be reached": nothing failed).
  const spareOf = (i: number, s: Send, decided: number | null): JudgeHeatSpareT | null => {
    const end = s.end!;
    let how: JudgeSpareEndT;
    let from: JudgeCallResult | { message: string; attempts: readonly JudgeCallResult['attempts'][number][] };
    if (end.ok) {
      how = end.answer.verdict === null ? 'invalid' : 'late';
      from = end.answer;
    } else {
      const message = messageOf(end.err);
      const attempts = end.err instanceof JudgeCallFault ? end.err.attempts : [];
      how = s.cancelled && attempts.length < jh.JUDGE_CALL_MAX_ATTEMPTS && attempts.every((t) => t.invalid !== null) ? 'cancelled' : 'faulted';
      from = { message: how === 'cancelled' ? judgeSendCancelledText(s.n, decided) : message === '' ? 'the send ended with no answer' : message, attempts };
    }
    try {
      return jh.judgeHeatSpareOf(i, s.n, s.sentAt, Math.max(s.sentAt, end.at), how, from);
    } catch (err) {
      log(`judge heat: send ${s.n} of call ${i + 1} is kept as no spare (${messageOf(err)}): the call and its decision stand`);
      return null;
    }
  };
  const finish = (i: number, c: OpenCall, out: Exclude<JudgeCallOutcome, { kind: 'pending' }>): void => {
    open.delete(i);
    if (out.kind === 'fault') {
      const e = c.sends[0]!.end!;
      settled.set(i, { sent: { ok: false, err: e.ok ? new Error('judge heat: a faulted call answered') : e.err }, spares: [] });
      return;
    }
    const e = c.sends[out.send]!.end!;
    const sent: JudgeSentT = e.ok ? { ok: true, answer: e.answer } : { ok: false, err: e.err };
    const spares: JudgeHeatSpareT[] = [];
    for (const s of c.sends) {
      if (s.n === out.send) continue;
      const spare = spareOf(i, s, out.kind === 'decided' ? out.send : null);
      if (spare !== null) spares.push(spare);
    }
    settled.set(i, { sent, spares });
  };
  // The calls whose sends ended since last looked at: decided (its other sends aborted, the call settled once they end),
  // invalid or a fault (settled), or still pending. True when any call settled.
  const settleEnded = (): boolean => {
    let any = false;
    for (const i of [...ended].sort((a, b) => a - b)) {
      ended.delete(i);
      const c = open.get(i);
      if (c === undefined) continue;
      if (c.decided === null) {
        const out = outcomeOf(c.sends);
        if (out.kind === 'pending') continue;
        if (out.kind !== 'decided') {
          finish(i, c, out);
          any = true;
          continue;
        }
        c.decided = out.send;
        for (const s of c.sends) {
          if (s.end !== null) continue;
          s.cancelled = true;
          s.ctl.abort(new Error(`judge heat: ${judgeSendCancelledText(s.n, out.send)}`));
        }
      }
      if (c.sends.some((s) => s.end === null)) continue;
      finish(i, c, { kind: 'decided', send: c.decided });
      any = true;
    }
    return any;
  };
  const report = (): void => {
    if (o.progress === undefined) return;
    try {
      const list: JudgeHeatProgressT['ahead'] = [];
      for (const [index, s] of [...settled].sort(([a], [b]) => a - b)) if (s.sent.ok && planned[index] !== undefined) list.push({ index, planned: planned[index]!, answer: s.sent.answer });
      const flying = [...open.values()].filter((c) => c.sends.some((s) => s.end === null)).length;
      const batch = batches[batches.length - 1]!;
      o.progress({ taken: calls.length, ahead: list, flying, batch: { start: batch.start, size: batch.size } });
    } catch (err) {
      sayOnce('progress', `judge heat: its progress hook threw (${messageOf(err)}): the heat goes on`);
    }
  };
  // Back up every call due (the rule), and say how soon the next could come due: null when none can, or no rule.
  const backUp = (): number | null => {
    if (rule === null || alone() || aborted() || o.doomed(ahead())) return null;
    let thresholdMs: number;
    try {
      thresholdMs = judgeBackupThresholdMs(rule, answeredMs);
    } catch (err) {
      sayOnce('threshold', `judge heat: the backup rule's threshold threw (${messageOf(err)}): no backup now`);
      return null;
    }
    if (backupsSent >= Math.max(rule.budgetMin, Math.ceil(rule.budgetShare * primariesSent))) return null;
    const now = clock.now();
    const counts = new Map<number, { unsettled: number; unsent: number }>();
    const countsOf = (b: { start: number; size: number }): { unsettled: number; unsent: number } => {
      let got = counts.get(b.start);
      if (got === undefined) {
        got = { unsettled: 0, unsent: 0 };
        for (let i = b.start; i < b.start + b.size; i++) {
          if (i >= next) got.unsent++;
          if (i >= calls.length && !settled.has(i)) got.unsettled++;
        }
        counts.set(b.start, got);
      }
      return got;
    };
    let wake: number | null = null;
    for (const [i, c] of [...open].sort(([a], [b]) => a - b)) {
      if (c.decided !== null || c.sends.length >= maxSends || !c.sends.some((s) => s.end === null)) continue;
      const b = batchOf(i);
      const n = countsOf(b);
      const newest = c.sends[c.sends.length - 1]!.sentAt;
      const state = {
        batchSize: b.size,
        batchUnsettled: n.unsettled,
        batchUnsent: n.unsent,
        newestSendAgeMs: Math.max(0, now - newest),
        sends: c.sends.length,
        backupsSent,
        primariesSent,
        thresholdMs,
      };
      let due: boolean;
      try {
        due = judgeBackupDue(rule, state);
      } catch (err) {
        sayOnce('due', `judge heat: the backup rule threw (${messageOf(err)}): no backup now`);
        return null;
      }
      // How old a send of this call must be to come due, as its batch stands now.
      const tail = n.unsent === 0 && n.unsettled <= Math.max(rule.tailMin, Math.ceil(rule.tailShare * b.size));
      const dueAge = tail ? Math.min(thresholdMs, rule.maxAgeMs) : rule.maxAgeMs;
      if (!due) {
        const dueAt = newest + dueAge;
        if (dueAt > now) wake = Math.min(wake ?? Infinity, dueAt - now);
        continue;
      }
      if (live.size >= sendCap()) continue;
      // Held after a pushback: due, and sent once the hold ends should it still be.
      if (now < backupsFrom) {
        wake = Math.min(wake ?? Infinity, backupsFrom - now);
        continue;
      }
      // A heat that keeps no ledger (a hand-made one) is never held back for it.
      if ((o.heat.requestsLeft?.() ?? Number.POSITIVE_INFINITY) < jh.JUDGE_CALL_MAX_ATTEMPTS * (1 + Math.max(0, callsTotal - next)) + (o.reserveRequests?.() ?? 0)) continue;
      backupsSent++;
      sendOne(i, c);
      // Its next send, should it still have no verdict, comes due that much after this one.
      if (c.sends.length < maxSends) wake = Math.min(wake ?? Infinity, dueAge);
      if (backupsSent >= Math.max(rule.budgetMin, Math.ceil(rule.budgetShare * primariesSent))) return null;
    }
    return wake;
  };
  // Wait for a send to end, or, when a backup may come due first, for the wake; the wake's timer cancelled either way.
  const waitForSends = async (wake: number | null): Promise<void> => {
    const sends = [...live].map((s) => s.done);
    if (wake === null) {
      await Promise.race(sends);
      return;
    }
    const nap = new AbortController();
    const slept = clock.sleep(Math.min(JUDGE_BACKUP_WAKE_MAX_MS, Math.max(JUDGE_BACKUP_WAKE_MIN_MS, Math.ceil(wake))), nap.signal).catch(() => undefined);
    try {
      await Promise.race([...sends, slept]);
    } finally {
      nap.abort();
    }
  };

  // With a seat, a call `take` sent again that found no place in flight: it goes out first once one frees.
  let again: number | null = null;
  // The sooner of two wakes (null: none).
  const sooner = (a: number | null, b: number | null): number | null => (a === null ? b : b === null ? a : Math.min(a, b));
  try {
    for (;;) {
      if (settleEnded()) report();
      tellFlying();
      follow();
      seatTurn();
      const head = calls.length;
      const got = settled.get(head);
      if (got === undefined) {
        // The head first, then the calls after it: a call sent again goes out before any call planned after it. The
        // width counts calls in flight (each open call has a send out), so a backup takes room a primary would not;
        // the sends in flight stay under sendCap all the same. Without a rule each call is one send: the two agree.
        const room = alone() ? 1 : widthNow();
        const roomy = (): boolean => open.size < room && live.size < sendCap();
        // With a seat a backup due takes a free place before a new primary does.
        let wake = seat === null ? null : backUp();
        if (again !== null && roomy() && !aborted()) {
          sendPrimary(again);
          again = null;
        }
        if (roomy() && next < planned.length && !aborted() && !o.doomed(ahead())) {
          // A send may abort the attempt (its fetch throws at once): nothing more goes out after it.
          while (roomy() && next < planned.length && !aborted()) sendPrimary(next++);
        }
        wake = sooner(wake, backUp());
        tellFlying();
        // The sends this turn made, told to the seat: its next refresh writes them for the others.
        seatFlying();
        if (live.size > 0) {
          // A seat's beat goes on through a long call, and a share that rose is filled: a turn at least every refresh.
          await waitForSends(seat === null ? wake : sooner(wake, JUDGE_POOL_REFRESH_MS));
          continue;
        }
        if (ended.size > 0) continue;
        if (head >= planned.length) return true;
        // Nothing in flight and the next call not sent: the attempt was given up between calls.
        if (signal !== undefined && aborted()) throw signal.reason instanceof Error ? signal.reason : new Error('the judge heat was aborted');
        throw new Error(`judge heat: call ${head + 1} is neither sent nor settled, and none is in flight`);
      }
      settled.delete(head);
      taken++;
      const took = await o.take(planned[head]!, got.sent, got.spares);
      if (took === 'stop') return false;
      if (took === 'again') {
        // With a seat it waits for a place in flight, as a primary does.
        if (seat !== null && live.size >= sendCap()) again = head;
        else sendPrimary(head);
        report();
        continue;
      }
      if (calls.length !== head + 1) throw new Error(`judge heat: call ${head + 1} was taken as kept, and ${calls.length} calls are kept`);
      const before = planned.length;
      planned = plan();
      if (planned.length > before) batches.push({ start: before, size: planned.length - before });
      report();
    }
  } finally {
    // Every call sent settles before the heat goes on to retire its key or keep its partial: none of them is left unmetered.
    while (live.size > 0) await Promise.allSettled([...live].map((s) => s.done));
    // Nothing flies now, and the heat wants nothing more of the pool.
    tellFlying();
    if (seat !== null) {
      try {
        seat.want(0);
        seat.flying?.(0);
      } catch (err) {
        sayOnce('seat', `judge heat: its seat in the judge pool threw (${messageOf(err)}): its width alone bounds it`);
      }
    }
  }
}

/** An opened judge heat's calls to send (sendJudgeHeat). */
export interface JudgeHeatSend {
  /** The heat openJudgeHeat opened, on its own key. */
  heat: JudgeHeat;
  setup: JudgeHeatSetupT;
  judge: Pick<ProgramJudgeT, 'invalid_share_max'>;
  /** The calls kept so far, in the heat's order: each call that settles is pushed onto it. */
  calls: JudgeHeatCallT[];
  /** The heat's partial as it stands, its key saved open on it. */
  partial: JudgeHeatPartialT;
  /** Keep the partial as each call settles (a resumable heat's store; a local heat's own copy). */
  save: (next: JudgeHeatPartialT) => Promise<void>;
  say: (line: string) => void;
  /** What a PermanentJobError the heat fails with opens with. */
  what: string;
  /**
   * Once the key is retired, a failed heat's or a whole one's, before the partial is saved: what masq said (null when
   * a failed heat's retirement did not answer) and what the heat metered (judgeCodeHeat closes the key's file with it).
   */
  onRetired?: (retired: RetiredTrialKey | null, meterMicroUsd: bigint) => Promise<void>;
  /** Aborts the calls in flight; its abort is thrown, never sent again. */
  signal?: AbortSignal;
  /** The most calls in flight at once (default JUDGE_HEAT_CONCURRENCY). */
  concurrency?: number;
  /** The backup rule (sendJudgeHeatCalls; grader/judge-backup.ts JUDGE_BACKUP): absent or null, each call is sent once. */
  backup?: JudgeBackupRule | null;
  /** The clock the sends are aged and stamped by (default Date.now and a timer). */
  clock?: JudgeHeatClock;
  /** The models seen answering a forced form (sendJudgeHeatCalls: the first call goes alone only on a model not among them). */
  formsSeen?: JudgeFormsSeen;
  /** The heat's progress after each settle and take (JudgeHeatProgressT); what it throws is swallowed. */
  progress?: (p: JudgeHeatProgressT) => void;
  /** The heat's seat in the judge pool (sendJudgeHeatCalls; openJudgePoolSeat): absent, its width alone bounds it. */
  seat?: Pick<JudgePoolSeat, 'share' | 'want' | 'tick'> & Partial<Pick<JudgePoolSeat, 'flying'>>;
  /**
   * Reporting only (sendJudgeHeatCalls' flying: a final heat's live document): the calls in flight in planned order, each
   * with when it went out; [] once the last settles. What it throws is logged (once per message) and the heat goes on.
   * Told after each batch sent, each call settled and each call sent again, whenever the list moved; it changes nothing
   * the heat does.
   */
  flying?: (out: { planned: JudgePlannedCallT; at: Date }[]) => void;
  /** The clock `flying` stamps a call sent with (default the wall clock). */
  now?: () => Date;
}

/** `partial` with `spares` its spares (grader/judge-heat.ts JudgeHeatPartial): the key absent when there are none, never empty. */
function judgeHeatPartialSpares(partial: JudgeHeatPartialT, spares: readonly JudgeHeatSpareT[]): JudgeHeatPartialT {
  const { spares: _dropped, ...rest } = partial;
  return spares.length === 0 ? rest : { ...rest, spares: [...spares] };
}

/**
 * Send an opened heat's calls still to come (judgeCodeHeat; cli/grade-local.ts's local heat), up to `concurrency` at
 * once and kept strictly in planned order as each settles (sendJudgeHeatCalls), then retire its key; the flags its
 * retirement raised are returned. A call that faults is sent once again; a second fault, a call judgeHeatCallOf refuses,
 * or more calls with no verdict than judge.invalid_share_max allows retires the key, once every call in flight has
 * settled, and fails the heat as a PermanentJobError (grader/judge-heat.ts JudgeHeatError its cause), the calls kept the
 * settled prefix before it. An abort, or an error no heat expects, keeps the partial's spend and open key's meter (the
 * calls in flight settled) and propagates, the key left open for the retry to retire. With a `backup` rule a call still
 * out near its batch's end may be sent again (sendJudgeHeatCalls): each kept call's other sends go on the partial's
 * `spares` in the same save as the call, a failed heat that keeps its calls keeps theirs, and a backup never takes the
 * requests the heat's one fault re-send is held to while it is unspent.
 */
export async function sendJudgeHeat(o: JudgeHeatSend): Promise<string[]> {
  const { heat, setup, judge, calls, say, what, signal } = o;
  const jh = await import('./judge-heat.ts');
  const { JudgeCallFault } = await import('./judge-call.ts');
  let p = o.partial;
  const save = async (next: JudgeHeatPartialT): Promise<void> => {
    p = next;
    await o.save(next);
  };
  const planned = jh.judgeHeatPlannedCalls(setup);
  const base = BigInt(p.spent_micro_usd);
  const spentNow = (): string => String(base + heat.meterMicroUsd());
  const openKey = (): JudgeHeatPartialT['open_key'] => ({ id: heat.key.id, label: heat.key.label, meter_micro_usd: String(heat.meterMicroUsd()) });
  // Fail the heat: retire its key, keep its spend (and its calls and their spares, when `keep`), and give up for good.
  const fail = async (cause: Error, keep: boolean): Promise<never> => {
    const retired = await heat.retire().catch((err: unknown) => {
      say(`key ${heat.key.label} could not be retired (${err instanceof Error ? err.message : String(err)}): masq lets it lapse`);
      return null;
    });
    await o.onRetired?.(retired, heat.meterMicroUsd());
    await save(judgeHeatPartialSpares({ ...p, calls: keep ? [...calls] : [], resent: 0, spent_micro_usd: spentNow(), open_key: retired === null ? openKey() : null }, keep ? (p.spares ?? []) : []));
    throw new PermanentJobError(`${what}: ${cause.message}. Nothing is written: the heat is failed, and the job dead`, { cause });
  };
  const fault = (s: JudgeSentT): boolean => !s.ok && s.err instanceof JudgeCallFault;
  const stopped: { failure: { cause: Error; keep: boolean } | null } = { failure: null };
  // The calls in flight, told (reporting only): what goes wrong is logged once per message, as the live feed logs its writes.
  const tellFlying = o.flying;
  let flyingFailed = '';
  const flying =
    tellFlying === undefined
      ? undefined
      : (out: { planned: JudgePlannedCallT; at: Date }[]): void => {
          try {
            tellFlying(out);
            flyingFailed = '';
          } catch (err) {
            const message = err instanceof Error ? err.message : String(err);
            if (message !== flyingFailed) say(`the judge heat's calls in flight could not be told to its live progress (${message}): the heat goes on`);
            flyingFailed = message;
          }
        };
  let whole: boolean;
  try {
    whole = await sendJudgeHeatCalls({
      heat,
      setup,
      calls,
      concurrency: o.concurrency ?? JUDGE_HEAT_CONCURRENCY,
      ...(signal === undefined ? {} : { signal }),
      backup: o.backup ?? null,
      ...(o.clock === undefined ? {} : { clock: o.clock }),
      ...(o.formsSeen === undefined ? {} : { formsSeen: o.formsSeen }),
      ...(o.progress === undefined ? {} : { progress: o.progress }),
      ...(o.seat === undefined ? {} : { seat: o.seat }),
      ...(flying === undefined ? {} : { flying }),
      ...(o.now === undefined ? {} : { now: o.now }),
      callsTotal: planned,
      // The fault re-send's requests, held back from a backup while the heat has not spent it.
      reserveRequests: () => (p.resent === 0 ? jh.JUDGE_CALL_MAX_ATTEMPTS : 0),
      log: say,
      // A second fault, an error no heat expects, or the calls with no verdict already past the share: no call to come mends it.
      doomed: (ahead) =>
        ahead.some((s) => !s.ok && !fault(s)) ||
        p.resent + ahead.filter(fault).length > 1 ||
        jh.judgeHeatInvalidShareOver(calls.filter((c) => c.verdict === null).length + ahead.filter((s) => s.ok && s.answer.verdict === null).length, planned, judge.invalid_share_max),
      take: async (next, sent, spares) => {
        if (!sent.ok) {
          const err = sent.err;
          if (!(err instanceof JudgeCallFault)) throw err;
          // The attempt given up (pg-boss's expiry: its signal aborts the requests in flight): no fault of the gateway's, and the retry goes on from the calls kept.
          if (signal?.aborted === true) throw signal.reason instanceof Error ? signal.reason : err;
          if (p.resent === 0) {
            say(`call ${calls.length + 1} of ${planned} faulted (${err.message}): it is sent again, the heat's one`);
            await save({ ...p, resent: 1, spent_micro_usd: spentNow(), open_key: openKey() });
            return 'again';
          }
          stopped.failure = { cause: new jh.JudgeHeatError(`call ${calls.length + 1} of ${planned} faulted (${err.message}) after the heat had sent one faulted call again`), keep: true };
          return 'stop';
        }
        try {
          calls.push(jh.judgeHeatCallOf(next, sent.answer));
        } catch (err) {
          if (!(err instanceof jh.JudgeHeatError)) throw err;
          stopped.failure = { cause: err, keep: true };
          return 'stop';
        }
        // The call and its spares in one save: a partial's spares name only the calls it keeps.
        await save(judgeHeatPartialSpares({ ...p, calls: [...calls], spent_micro_usd: spentNow(), open_key: openKey() }, [...(p.spares ?? []), ...spares]));
        // The calls with no verdict already past the share the whole heat may hold: no call to come can mend it.
        const invalid = calls.filter((c) => c.verdict === null).length;
        if (jh.judgeHeatInvalidShareOver(invalid, planned, judge.invalid_share_max)) {
          stopped.failure = { cause: new jh.JudgeHeatError(`${invalid} of the heat's ${planned} calls came back with no verdict, over judge.invalid_share_max ${judge.invalid_share_max}`), keep: false };
          return 'stop';
        }
        return 'kept';
      },
    });
  } catch (err) {
    // What the calls in flight spent (each settled by now) goes on the partial, and on its open key's meter, which the
    // retry retires the key against; the calls kept stay the settled prefix.
    if (p.open_key !== null && p.open_key.id === heat.key.id && p.open_key.meter_micro_usd !== String(heat.meterMicroUsd())) {
      await save({ ...p, spent_micro_usd: spentNow(), open_key: openKey() }).catch((e: unknown) => say(`the spend of the calls in flight could not be kept (${e instanceof Error ? e.message : String(e)})`));
    }
    throw err;
  }
  if (!whole) {
    if (stopped.failure === null) throw new Error(`${what}: the heat stopped with no failure`);
    return fail(stopped.failure.cause, stopped.failure.keep);
  }
  const retired = await heat.retire();
  if (retired.flags.length > 0) say(`retired key ${heat.key.label}: ${retired.flags.join('; ')}`);
  await o.onRetired?.(retired, heat.meterMicroUsd());
  await save({ ...p, calls: [...calls], spent_micro_usd: spentNow(), open_key: null });
  return [...retired.flags];
}

/**
 * Judge a due phase's field in one heat (createProgramHeatHandler; the header's `judge heat`): read the field's
 * artifacts and the house anchors, resume from the calls an earlier attempt kept, open the heat (grader/judge-call.ts
 * openJudgeHeat: a key of its own with no dollar cap, the header's `judge keys`, opened whatever its worst case), send
 * the calls still to come, every round its schedule plans, keeping each as it settles, retire the key,
 * then store the record and write each entry's run its score built again with its verdict (scoreWithJudge) and the
 * link to the record, in one transaction, the run of an entry the heat left out (judgeHeatInputs) the link alone. Null when
 * the heat is held at its opening (an unpriced model, or one blind to an image artifact): it hands itself on an hour
 * later and pages (holdJudgeHeat). A call that faults is
 * sent once again; a second fault, or more calls with no verdict than judge.invalid_share_max allows, fails the heat
 * as a PermanentJobError (grader/judge-heat.ts JudgeHeatError its cause): nothing is written, the dead job is paged.
 * A heat that dies (a PermanentJobError, or any throw on its job's last attempt) takes its live document with it
 * (server/competitions/live-judging.ts removeJudgeLive), as a recorded one does: the live board shows no progress of a
 * heat that no longer runs, only the grades' stage until a resend's heat writes its own.
 */
async function judgeCodeHeat(deps: GradeWorkerDeps, due: JudgeHeatDue, jobKey: string, ctx: CodeHeatJobContext | undefined, held: HoldPaged): Promise<JudgeHeatOutcome | null> {
  try {
    return await judgeCodeHeatAttempt(deps, due, jobKey, ctx, held);
  } catch (err) {
    if (err instanceof PermanentJobError || (ctx !== undefined && isLastAttempt(ctx))) {
      const say = (line: string) => (deps.log ?? ((l: string) => console.log(l)))(`[code-heat] ${jobKey}: ${line}`);
      const { removeJudgeLive } = await import('../server/competitions/live-judging.ts');
      await removeJudgeLive(deps.blobs.root, due.ph.id).catch((e: unknown) => say(`the failed judge heat's live progress could not be removed (${e instanceof Error ? e.message : String(e)})`));
    }
    throw err;
  }
}

/** One attempt at judgeCodeHeat's heat: everything it does but take a dead heat's live document. */
async function judgeCodeHeatAttempt(deps: GradeWorkerDeps, due: JudgeHeatDue, jobKey: string, ctx: CodeHeatJobContext | undefined, held: HoldPaged): Promise<JudgeHeatOutcome | null> {
  const { db, blobs } = deps;
  const log = deps.log ?? ((line: string) => console.log(line));
  const now = deps.now ?? (() => new Date());
  const { comp, ph, judge } = due;
  const what = `the judge heat of ${comp.slug}'s final phase (job ${jobKey})`;
  const say = (line: string) => log(`[code-heat] ${jobKey}: ${line}`);
  const jh = await import('./judge-heat.ts');
  const { codeHeatPartialFile } = await import('./code-heat.ts');
  const { JudgeArtifactRefused, openJudgeHeat } = await import('./judge-call.ts');
  const { retireTrialKey } = await import('./gateway/masq.ts');
  const { JUDGE_BACKUP } = await import('./judge-backup.ts');
  const formsSeen = judgeFormsSeenOf(deps);

  const inputs = await judgeHeatInputs(deps, due, what);
  const { setup } = inputs;
  for (const l of inputs.left) say(`entry ${l.row.submission_id} (run ${l.run.id}) is left out of the heat, and ranks below every judged entry: ${l.why}`);
  // What the kept calls are this heat's only under: besides the setup (which names every member by its bytes), the phase, the bundle and the prompt.
  const resumeKey = jh.judgeHeatResumeKey(setup, { phase_id: ph.id.toLowerCase(), bundle_sha256: canonicalSha256(due.bundle), prompt_sha256: sha256Hex(inputs.prompt) });
  const store = codeHeatPartialFile(judgeHeatPartialPath(deps.workRoot, ph.id));
  let p = await keptJudgeHeat(store, resumeKey, setup, say);
  const save = async (next: JudgeHeatPartialT): Promise<void> => {
    p = next;
    await store.write(canonicalJson(next));
  };
  const keptCalls = p.calls.length;
  const planned = jh.judgeHeatPlannedCalls(setup);
  const calls = [...p.calls];
  const broker = await judgeBrokerOf(deps);
  if (broker === null) {
    throw new PermanentJobError(`${what}: this process has no LLM gateway (MAKEFUN_LLM_GATEWAY=masq, its URL and admin key) and no superbot-router pair (MAKEFUN_SUPERBOT_ROUTER_URL and MAKEFUN_SUPERBOT_ROUTER_KEY) to send the house judge's calls through`);
  }
  // The phase's keys as kept (the header's `judge keys`): every attempt's, on whichever host it ran.
  const keysDir = judgeKeysDir(blobs, ph.id);
  let kept = await readJudgeKeys(keysDir, now());
  // A kept key retired: its file says so, and what masq says it spent.
  const keptKey = async (id: string, meter: bigint, retired: RetiredTrialKey): Promise<void> => {
    const k = kept.find((x) => x.key_id === id);
    if (k === undefined) return;
    const closed = await writeJudgeKey(keysDir, retiredJudgeKey(k, meter, retired));
    kept = kept.map((x) => (x === k ? closed : x));
  };
  // A key an earlier attempt left open (it stopped mid-heat): retired first, against what it metered.
  if (p.open_key !== null) {
    const retired = await retireTrialKey(broker, p.open_key.id, BigInt(p.open_key.meter_micro_usd));
    say(`retired key ${p.open_key.label}, which an earlier attempt left open${retired.flags.length === 0 ? '' : ` (${retired.flags.join('; ')})`}`);
    await keptKey(p.open_key.id, BigInt(p.open_key.meter_micro_usd), retired);
    await save({ ...p, open_key: null });
  }
  // So is one an attempt on another host left open (its calls kept there, never here): the phase's heats run one at a time.
  for (const k of kept.filter((x) => x.stage === 'final' && x.open && x.key_id !== null)) {
    const retired = await retireTrialKey(broker, k.key_id!, BigInt(k.meter_micro_usd));
    say(`retired key ${k.label ?? k.key_id}, which an earlier attempt elsewhere left open, masq's spend on it ${retired.spend.microUsd} µUSD${retired.flags.length === 0 ? '' : ` (${retired.flags.join('; ')})`}`);
    await keptKey(k.key_id!, BigInt(k.meter_micro_usd), retired);
  }
  let keyFlags: string[] = [];
  if (calls.length < planned) {
    const mine = await claimJudgeKey(
      keysDir,
      { format: JUDGE_KEY_FORMAT, phase_id: ph.id.toLowerCase(), stage: 'final', at: now().toISOString(), key_id: null, label: null, reserved_micro_usd: '0', meter_micro_usd: '0', masq_micro_usd: null, open: true },
      p.keys + 1,
    );
    const attempt = mine.attempt;
    let opening: Awaited<ReturnType<typeof openJudgeHeat>>;
    try {
      // No cap: the heat opens whatever its worst case, its key with no dollar cap (the header's `judge heat`).
      opening = await openJudgeHeat({
        broker,
        key: { slug: comp.slug, phase: 'final', attempt },
        agent: judge.agent,
        prompt: inputs.prompt,
        media: judge.media,
        house: setup.house_text,
        artifacts: [...inputs.artifacts].map(([sha256, bytes]) => ({ sha256, bytes })),
        // The calls still to come, and room for the one a fault sends again while the heat has not spent it.
        calls: planned - calls.length + (p.resent === 0 ? 1 : 0),
        blobs,
        ...(deps.judge?.fetch === undefined ? {} : { fetch: deps.judge.fetch }),
        ...(deps.judge?.timeoutMs === undefined ? {} : { timeoutMs: deps.judge.timeoutMs }),
        now: () => now().getTime(),
        ...(ctx?.signal === undefined ? {} : { signal: ctx.signal }),
      });
    } catch (err) {
      await dropJudgeKey(keysDir, mine);
      if (err instanceof JudgeArtifactRefused) {
        const whose = inputs.entries.filter((e) => e.artifact_sha256 === err.sha256).map((e) => e.row.submission_id);
        throw new PermanentJobError(
          `${what}: the judge refuses the artifact ${err.sha256}${whose.length === 0 ? ' (a house anchor)' : ` of ${whose.join(', ')}`}: ${err.message}. The scorer's gate must fail an entry whose artifact the judge cannot read`,
          { cause: err },
        );
      }
      throw err;
    }
    if (opening.held !== null) {
      if (opening.retired === null) await dropJudgeKey(keysDir, mine);
      else await writeJudgeKey(keysDir, retiredJudgeKey({ ...mine, key_id: opening.retired.id }, 0n, opening.retired));
      if (opening.retired !== null) await save({ ...p, keys: attempt });
      return holdJudgeHeat(deps, due, jobKey, { hold: opening.held, attempt }, held);
    }
    const heat = opening.heat;
    const minted = await writeJudgeKey(keysDir, { ...mine, key_id: heat.key.id, label: heat.key.label });
    await save({ ...p, keys: attempt, open_key: { id: heat.key.id, label: heat.key.label, meter_micro_usd: '0' } });
    say(`judging ${setup.field.length} members (${inputs.entries.length} entries, ${setup.field.filter((m) => m.anchor).length} anchors) in ${planned} calls, ${keptCalls} kept from an earlier attempt, on key ${heat.key.label}`);
    // The heat's progress for the live board (server/competitions/live-judging.ts): each settled call and the calls in
    // flight (sendJudgeHeat's flying, reporting only), a `judge` change at most every 2 s.
    // The calls settled past the kept prefix (the sender's progress) ride beside them.
    const { judgeLiveAheadOf, openJudgeLiveFeed } = await import('../server/competitions/live-judging.ts');
    const live = openJudgeLiveFeed({ blobRoot: blobs.root, phaseId: ph.id, competitionId: comp.id, db, key: resumeKey, setup, kept: keptCalls, now, log: say });
    live.update(calls);
    let ahead: ReturnType<typeof judgeLiveAheadOf>[] = [];
    // Its seat in the platform's one budget of judge sends in flight (the header's `judge heat`), held while it sends.
    const seat = await judgePoolSeatOf(deps, heat.key.label, 'final', say);
    try {
      keyFlags = await sendJudgeHeat({
        heat,
        setup,
        judge,
        calls,
        partial: p,
        save: async (next) => {
          await save(next);
          live.update(next.calls, ahead);
        },
        progress: (q) => {
          ahead = q.ahead.map((x) => judgeLiveAheadOf(x.index, x.planned, x.answer));
          live.update(calls, ahead);
        },
        ...(seat === null ? {} : { seat }),
        say,
        what,
        // The minted key's file (the header's `judge keys`) closed with what the heat metered, and what masq says it spent.
        onRetired: async (retired, meter) => {
          await writeJudgeKey(keysDir, retired === null ? { ...minted, meter_micro_usd: String(meter) } : retiredJudgeKey(minted, meter, retired));
        },
        ...(ctx?.signal === undefined ? {} : { signal: ctx.signal }),
        ...(deps.judge?.concurrency === undefined ? {} : { concurrency: deps.judge.concurrency }),
        // The house's backup rule unless the deps name another (null: none), on the deps' clock.
        backup: deps.judge?.backup === undefined ? JUDGE_BACKUP : deps.judge.backup,
        ...(deps.judge?.clock === undefined ? {} : { clock: deps.judge.clock }),
        ...(formsSeen === undefined ? {} : { formsSeen }),
        // The calls in flight, for the live board's game being judged now (LiveJudging.now): reporting only.
        flying: (out) => live.flying(out.map(({ planned: c, at }) => ({ stage: c.stage, round: c.round, a: c.a, b: c.b, slot_order: c.slot_order, sent_at: at.toISOString() }))),
        now,
      });
    } finally {
      // Its seat given back whatever ended the send (it never throws).
      await seat?.close();
      // The last calls written before the record is, or before the heat gives up: no write of the feed's timer lands
      // after judgeCodeHeat removes a dead heat's document.
      await live.flush();
    }
  }

  let record: ReturnType<typeof jh.judgeHeatRecordOf>;
  try {
    record = jh.judgeHeatRecordOf(setup, calls, p.spares ?? []);
  } catch (err) {
    if (!(err instanceof jh.JudgeHeatError)) throw err;
    await save(judgeHeatPartialSpares({ ...p, calls: [], resent: 0 }, []));
    throw new PermanentJobError(`${what}: ${err.message}. Nothing is written: the heat is failed, and the job dead`, { cause: err });
  }
  const digest = jh.judgeHeatRecordDigest(record);
  const put = await blobs.put(digest.json);
  if (put.sha256 !== digest.sha256) throw new Error(`${what}: the record stored as ${put.sha256}, not ${digest.sha256}`);
  const verdicts = jh.judgeHeatEntryVerdicts(record);
  const subRows = await db.select().from(submission).where(inArray(submission.id, [...inputs.entries, ...inputs.left].map((e) => e.row.submission_id)));
  const subOf = new Map(subRows.map((s) => [s.id, s]));
  const rules = eligibilityRulesOf(due.bundle);
  const writes = inputs.entries.map((e) => {
    const verdict = verdicts.get(e.row.submission_id.toLowerCase());
    const sub = subOf.get(e.row.submission_id);
    if (verdict === undefined) throw new Error(`${what}: the record holds no verdict on entry ${e.row.submission_id}`);
    if (sub === undefined) throw new Error(`${what}: entry ${e.row.submission_id} is gone`);
    const stored = Score.safeParse(e.run.result);
    if (!stored.success) throw new Error(`${what}: run ${e.run.id}'s result is no score: ${stored.error.issues[0]?.message ?? 'malformed'}`);
    return { e, verdict, ...scoreWithJudge(stored.data, verdict, { house: standingsHouse(sub), baseline: sub.baseline }, rules) };
  });
  // A run the heat left out keeps its score, built again only to drop a verdict an earlier heat gave it.
  const leftWrites = inputs.left.map((l) => {
    const sub = subOf.get(l.row.submission_id);
    if (sub === undefined) throw new Error(`${what}: entry ${l.row.submission_id} is gone`);
    const stored = Score.safeParse(l.run.result);
    if (!stored.success) throw new Error(`${what}: run ${l.run.id}'s result is no score: ${stored.error.issues[0]?.message ?? 'malformed'}`);
    const perf = stored.data.performance;
    const rebuilt = perf.kind === 'program/v1' && perf.judge !== undefined ? scoreWithJudge(stored.data, null, { house: standingsHouse(sub), baseline: sub.baseline }, rules) : null;
    return { e: l, ...(rebuilt === null ? { result: l.run.result, result_sha256: l.run.resultSha256 } : rebuilt) };
  });
  await db.transaction(async (tx) => {
    for (const w of [...writes, ...leftWrites]) {
      const updated = await tx
        .update(run)
        .set({ result: w.result, resultSha256: w.result_sha256, judgeHeatSha256: digest.sha256 })
        .where(and(eq(run.id, w.e.run.id), eq(run.resultSha256, w.e.run.resultSha256 ?? '')))
        .returning({ id: run.id });
      // A run written since the field was read (a regrade, or another heat): the retry judges the field as it now stands, from the calls kept.
      if (updated.length === 0) throw new Error(`${what}: run ${w.e.run.id} of entry ${w.e.row.submission_id} changed while its heat ran`);
    }
    await recordLiveChange(tx, { ...GRADE_CHANGE, scopeId: comp.id });
  });
  await store.remove().catch((err: unknown) => say(`the judge calls kept at ${store.where} could not be removed (${err instanceof Error ? err.message : String(err)})`));
  // The live board reads the record from here on (server/competitions/live-judging.ts): the heat's live document goes.
  const { removeJudgeLive } = await import('../server/competitions/live-judging.ts');
  await removeJudgeLive(blobs.root, ph.id).catch((err: unknown) => say(`the judge heat's live progress could not be removed (${err instanceof Error ? err.message : String(err)})`));
  const outcome: JudgeHeatOutcome = {
    kind: 'judge',
    phase_id: ph.id,
    heat_sha256: digest.sha256,
    calls: record.calls.length,
    kept_calls: keptCalls,
    invalid_calls: record.invalid_calls,
    spent_micro_usd: p.spent_micro_usd,
    finalists: record.finalists,
    key_flags: keyFlags,
    entries: writes.map((w) => ({
      submission_id: w.e.row.submission_id,
      run_id: w.e.run.id,
      artifact_sha256: w.e.artifact_sha256,
      win_rate_micro: w.verdict.win_rate_micro,
      finalist: w.verdict.finalist,
      result_sha256: w.result_sha256,
    })),
    left_out: leftWrites.map((w) => ({ submission_id: w.e.row.submission_id, run_id: w.e.run.id, why: w.e.why, result_sha256: w.result_sha256 })),
  };
  say(
    `judged ${comp.slug}'s final: record ${digest.sha256}, ${outcome.calls} calls (${keptCalls} kept, ${outcome.invalid_calls} with no verdict), ${outcome.spent_micro_usd} µUSD; ` +
      outcome.entries.map((x) => `${x.submission_id} ${winRateFraction(x.win_rate_micro)}${x.finalist ? ' (finalist)' : ''}`).join(', ') +
      outcome.left_out.map((x) => `, ${x.submission_id} left out`).join(''),
  );
  return outcome;
}

/**
 * A judge heat held at its opening (grader/judge-call.ts JudgeHold: an unpriced model, or a model that cannot see an
 * image artifact): the phase's code-heat job sent again for the next JUDGE_HEAT_HOLD_RECHECK_MS slot (codeHeatJobId
 * `judge-hold:<slot>`), which opens the heat again from the calls kept, and the hold paged, once an hour a competition
 * (AGENT_REFUSAL_PAGE_MS; logged between). Once
 * that job is sent, the competition's open pages are told (server/competitions/live-judging.ts JUDGE_LIVE_CHANGE),
 * so they read GET /live again rather than at their next poll, and the board finds the hold from that job (heatHeldOf);
 * it is recorded last, since the board takes this job as the heat's while it runs. A change that fails to record is
 * logged, and the hold holds. Null: nothing recorded.
 */
async function holdJudgeHeat(deps: GradeWorkerDeps, due: JudgeHeatDue, jobKey: string, h: { hold: JudgeHold; attempt: number }, held: HoldPaged): Promise<null> {
  const log = deps.log ?? ((line: string) => console.log(line));
  const page = deps.page ?? ((line: string) => console.error(line));
  const at = (deps.now ?? (() => new Date()))().getTime();
  const { judgeHoldPage } = await import('./judge-call.ts');
  const slot = Math.floor(at / JUDGE_HEAT_HOLD_RECHECK_MS) + 1;
  const until = new Date(slot * JUDGE_HEAT_HOLD_RECHECK_MS);
  let sent: Date | null = null;
  if (deps.jobs !== undefined) {
    await sendCodeHeat(deps.jobs, due.ph.id, { id: codeHeatJobId(due.ph.id, `judge-hold:${slot}`), startAfter: until });
    sent = until;
  }
  const text = judgeHoldPage({ slug: due.comp.slug, phase: 'final', attempt: h.attempt, hold: h.hold, until: sent });
  const last = held.get(due.comp.id);
  if (last === undefined || at - last >= AGENT_REFUSAL_PAGE_MS) {
    held.set(due.comp.id, at);
    page(text);
  } else {
    log(`[code-heat] ${jobKey}: ${text}`);
  }
  if (sent !== null) {
    const { JUDGE_LIVE_CHANGE } = await import('../server/competitions/live-judging.ts');
    await deps.db
      .transaction((tx) => recordLiveChange(tx, { ...JUDGE_LIVE_CHANGE, scopeId: due.comp.id }))
      .catch((err: unknown) => log(`[code-heat] ${jobKey}: the hold's live change could not be recorded (${err instanceof Error ? err.message : String(err)}): open pages see it at their next read`));
  }
  return null;
}

// ---------------------------------------------------------------- scrape/v1: heats

/** What a scrape/v1 grade or heat reads besides GradeWorkerDeps' own (the header's `scrape/v1`). */
export interface ScrapeWorkerDeps {
  /** The host's one lease name, every heat's and every waiting job's (default scrapeLeaseDirFromEnv()): the name of a scrape_heat_lease row. */
  leaseDir?: string;
  /**
   * drand's signature of `round` on `chain` (default server/routes/admin/sealed-window.ts fetchDrandRound over its
   * default relays). Whatever answers, the signature is verified here against the chain's key before a heat draws on it.
   */
  drandRound?: (chain: DrandChain, round: number) => Promise<{ signature: string }>;
  /** The gateway the trials run (default grader/scrape/bundle.ts scrapeGatewayBundle, cached under <workRoot>/scrape-gateway). */
  gateway?: () => Promise<{ dir: string; script: string }>;
  /** The node22 house's launch.ts as text (default grader/scrape/launch.ts launcherSource()). */
  launcherSource?: string;
  /** The heat's pacing (default grader/scrape/heat.ts SCRAPE_PACING_DEFAULTS). */
  pacing?: ScrapePacing;
  /** Passed to every trial as they are (heat.ts ScrapeHeatOptions.trial: a test's upstream port and CA). */
  trial?: ScrapeHeatOptions['trial'];
  /** The heat's own parts (heat.ts ScrapeHeatDeps: its trials, judge, resolver and clock); tests replace them. */
  heat?: ScrapeHeatDeps;
  /** The waits' clock: a job waiting on the host's lease, the final heat waiting for its round (default the wall clock). */
  clock?: ScrapeHeatClock;
  /** How often a job waiting on the host's lease looks again (default SCRAPE_LEASE_POLL_MS). */
  leasePollMs?: number;
  /** Told every event of every heat (heat.ts ScrapeHeatEvent). */
  onEvent?: (e: ScrapeHeatEvent) => void;
  /**
   * grader/scrape/score.ts's judge, performance and disagreement error as an admin's re-judging judges with them
   * (createScrapeHeatHandler's `rejudge`; default that module, loaded at the first re-judging); a test hands in a fake.
   */
  scoring?: Pick<typeof import('./scrape/score.ts'), 'judgeScrapeTrial' | 'scrapePerformance' | 'ScorerDisagreementError'>;
}

/** The environment variable naming the host's scrape lease directory (scrapeLeaseDirFromEnv). */
export const SCRAPE_LEASE_DIR_ENV = 'MAKEFUN_SCRAPE_LEASE_DIR';
/** How often a job waiting on the host's lease looks again. */
export const SCRAPE_LEASE_POLL_MS = 15_000;
/** How long after a drand round's emission the heat asks the relays for it (a relay serves it a moment late). */
export const SCRAPE_DRAND_LAG_MS = 3_000;
/** The run flag of a run whose voids are held for an admin's review before prizes (scrapeVoidsReview): on the run row, never in the score. */
export const SCRAPE_VOIDS_REVIEW_FLAG = 'scrape_voids_review';
/** The run flag of a run its scorer left unscored (a disagreement or a fault, the house's): recorded failed and never published. */
export const SCRAPE_SCORER_FAULT_FLAG = 'scrape_scorer_fault';
/** A practice heat's id stem (scrapeHeatIdOf): its trials' owners, its lease and its record say practice. */
export const SCRAPE_PRACTICE_HEAT_PREFIX = 'practice-';
/** The final phase's heat's id stem. */
export const SCRAPE_FINAL_HEAT_PREFIX = 'final-';

/**
 * The host's scrape lease directory: MAKEFUN_SCRAPE_LEASE_DIR, else <os tmpdir>/makefun-scrape-lease, one name for every
 * process that reaches the upstream from the one egress, so every heat and every grading job of the egress meets the one
 * lease (heat.ts acquireScrapeHostLease: the name of a scrape_heat_lease row).
 */
export function scrapeLeaseDirFromEnv(env: Readonly<Record<string, string | undefined>> = process.env): string {
  const named = (env[SCRAPE_LEASE_DIR_ENV] ?? '').trim();
  return named === '' ? join(tmpdir(), 'makefun-scrape-lease') : resolve(named);
}

/**
 * A module a scrape job reads, loaded at its first use by a specifier esbuild does not follow: the kit's one-file
 * command line bundles this module for its rules (cli/grade-local.ts), and must not carry what only the server's
 * scrape jobs run: the admin modules a heat reads (server/routes/admin/grading.ts, sealed-window.ts) and the gateway's
 * bundler (grader/scrape/bundle.ts). The scrape/v1 runtime a kit command does run (grader/scrape/heat.ts, score.ts,
 * trial.ts: cli/regrade.ts, cli/scrape-local.ts) is in the kit through those commands, its self-starting entry modules
 * (grader/scrape/gateway-main.ts, launch.ts) pinned off there (server/kit/cli-bundle.ts); loaded here the same way, so
 * this module's own load reaches none of it. No kit command runs a heat or a scrape job. `rel` is relative to this
 * module.
 */
async function scrapeRuntime<T>(rel: string): Promise<T> {
  return (await import(new URL(rel, import.meta.url).href)) as T;
}

/** The waits' wall clock: a sleep that an abort ends early, rejecting with the signal's reason (heat.ts ScrapeHeatClock). */
const wallClock: ScrapeHeatClock = {
  now: () => Date.now(),
  sleep: (ms, signal) =>
    new Promise<void>((done, fail) => {
      if (signal?.aborted) {
        fail(signal.reason);
        return;
      }
      const stop = (): void => {
        clearTimeout(timer);
        fail(signal!.reason);
      };
      const timer = setTimeout(() => {
        signal?.removeEventListener('abort', stop);
        done();
      }, Math.max(0, ms));
      signal?.addEventListener('abort', stop, { once: true });
    }),
};

/**
 * Who holds this host's scrape lease live (heat.ts scrapeHostLeaseHolder: a scrape_heat_lease row of the database the
 * egress's pods share, or this process's own take when it was handed none), in a log's words, or null when no heat holds
 * it: what a job that would run beside a heat reads (the header's `scrape/v1`). A database that cannot answer throws.
 */
export async function scrapeHostHeldBy(deps: { db?: ScrapeLeaseDb; scrape?: Pick<ScrapeWorkerDeps, 'leaseDir'> }): Promise<string | null> {
  const { scrapeHostLeaseHolder } = await scrapeRuntime<typeof import('./scrape/heat.ts')>('./scrape/heat.ts');
  const dir = deps.scrape?.leaseDir ?? scrapeLeaseDirFromEnv();
  const held = await scrapeHostLeaseHolder({ dir, db: deps.db });
  if (held === null) return null;
  const who = held.info === null ? 'a lease that does not read' : `heat ${held.info.heat} (pid ${held.info.pid} on ${held.info.hostname}, since ${held.info.acquired_at})`;
  return `${who} holds this host's scrape lease (${dir})`;
}

/**
 * Wait while a live scrape heat holds this host's lease (scrapeHostHeldBy): no other grading runs beside a heat (the
 * header's `scrape/v1`). `what` names the waiting job in the log. `signal` (the job attempt's: JobContext.signal) ends
 * the wait, rejecting with its reason, once pg-boss gives the attempt up (its expiry, or the workers stopping), so a
 * job waiting on a heat never holds a stopping process. Resolves with how long it waited, ms.
 */
export async function scrapeHostQuiet(deps: Pick<GradeWorkerDeps, 'scrape' | 'log'> & { db?: ScrapeLeaseDb }, what: string, signal?: AbortSignal): Promise<number> {
  const clock = deps.scrape?.clock ?? wallClock;
  const poll = deps.scrape?.leasePollMs ?? SCRAPE_LEASE_POLL_MS;
  const log = deps.log ?? ((line: string) => console.log(line));
  const from = clock.now();
  let told = false;
  for (;;) {
    signal?.throwIfAborted();
    const held = await scrapeHostHeldBy(deps);
    if (held === null) return clock.now() - from;
    if (!told) {
      log(`[scrape] ${what} waits: ${held}, and nothing else grades here while a heat runs`);
      told = true;
    }
    await clock.sleep(poll, signal);
  }
}

/**
 * How often a final heat held for its entries' snapshots looks again (scrapeFieldSnapshotted): a snapshot job retries
 * 15, 30 and 60 s on (server/jobs.ts JOB_OPTIONS.snapshot), so a snapshot that lands is in the field within this.
 */
export const SCRAPE_SNAPSHOT_POLL_MS = 15_000;

/**
 * Hold a final heat until no entry of `comp` taken in by the deadline (nor a house baseline) awaits its snapshot or its
 * transcripts gate (admin/grading.ts awaitingSnapshot, handed in as `awaiting`: the predicate codeHeatDue waits on, so
 * an entry whose snapshot failed for good, failed or cancelled, holds nothing): the heat reads its field once
 * (entriesToGrade, which lists only entries with a snapshot), and an entry it ran without is never measured. Looks
 * again every SCRAPE_SNAPSHOT_POLL_MS on the waits' clock, logging the entries waited on whenever they change. `signal`
 * (the job attempt's) ends the wait, rejecting with its reason, so pg-boss retries the job: the same job id, so the
 * same heat id and round. Resolves with how long it waited, ms.
 */
async function scrapeFieldSnapshotted(
  deps: Pick<GradeWorkerDeps, 'db' | 'scrape' | 'log'>,
  comp: Pick<typeof competition.$inferSelect, 'id' | 'slug' | 'deadline' | 'bundle'>,
  awaiting: (typeof import('../server/routes/admin/grading.ts'))['awaitingSnapshot'],
  what: string,
  signal?: AbortSignal,
): Promise<number> {
  const clock = deps.scrape?.clock ?? wallClock;
  const log = deps.log ?? ((line: string) => console.log(line));
  const from = clock.now();
  let told: string | null = null;
  for (;;) {
    signal?.throwIfAborted();
    const ids = await awaiting(deps.db, comp);
    if (ids.length === 0) {
      const waited = clock.now() - from;
      if (told !== null) log(`[scrape] ${what}: no entry of ${comp.slug} taken in by the deadline awaits its snapshot any more; its field is read after ${Math.round(waited / 1000)} s`);
      return waited;
    }
    const named = ids.length <= 5 ? ids.join(', ') : `${ids.slice(0, 5).join(', ')} and ${ids.length - 5} more`;
    if (named !== told) {
      log(
        `[scrape] ${what} waits: ${ids.length === 1 ? '1 entry' : `${ids.length} entries`} of ${comp.slug} taken in by the deadline ${ids.length === 1 ? 'awaits its snapshot or its' : 'await their snapshot or their'} transcripts gate (${named}); it looks again every ${SCRAPE_SNAPSHOT_POLL_MS / 1000} s`,
      );
      told = named;
    }
    await clock.sleep(SCRAPE_SNAPSHOT_POLL_MS, signal);
  }
}

/** How often a grade-trial or hindsight-audit job that a scrape heat holds back looks again (the header's `scrape/v1`): it hands itself on to the next slot of this length. */
export const SCRAPE_HOST_RECHECK_MS = 60_000;

/** The recheck slot a job held back by a heat at `atMs` hands itself on to (SCRAPE_HOST_RECHECK_MS): it starts at slot x SCRAPE_HOST_RECHECK_MS. */
export function scrapeHostRecheckSlot(atMs: number): number {
  return Math.ceil((atMs + SCRAPE_HOST_RECHECK_MS) / SCRAPE_HOST_RECHECK_MS);
}

/** How often a grade-trial job the node had no room for looks again (the header's `node room`): it hands itself on to the next slot of this length. */
export const NODE_ROOM_RECHECK_MS = 60_000;

/** The recheck slot a trial the node had no room for at `atMs` hands itself on to (NODE_ROOM_RECHECK_MS): it starts at slot x NODE_ROOM_RECHECK_MS. */
export function nodeRoomRecheckSlot(atMs: number): number {
  return Math.ceil((atMs + NODE_ROOM_RECHECK_MS) / NODE_ROOM_RECHECK_MS);
}

/** The drand chain a heat draws on: quicknet, or under dev auth the test chain (instanceChainOptions, as instance draws read it). */
function scrapeDrandChain(deps: Pick<GradeWorkerDeps, 'drandChain'>): DrandChain {
  return instanceChainOptions(deps.drandChain).testChain ?? DRAND_QUICKNET;
}

/** The newest round `chain` has emitted at or before `atMs` (a practice heat's round). RangeError before its genesis. */
export function latestDrandRound(chain: DrandChain, atMs: number): number {
  const first = roundMin(new Date(atMs), chain);
  const round = roundTime(first, chain).getTime() <= atMs ? first : first - 1;
  if (round < 1) throw new RangeError(`drand chain ${chain.hash} emits its first round after ${new Date(atMs).toISOString()}`);
  return round;
}

/** A heat's drand round, its signature fetched (ScrapeWorkerDeps.drandRound) and verified against the chain's key. */
async function verifiedDrandRound(deps: Pick<GradeWorkerDeps, 'scrape'>, chain: DrandChain, round: number): Promise<{ chain: string; round: number; signature: string }> {
  const fetchRound = deps.scrape?.drandRound ?? (async (c: DrandChain, r: number) => (await scrapeRuntime<typeof import('../server/routes/admin/sealed-window.ts')>('../server/routes/admin/sealed-window.ts')).fetchDrandRound(c, r));
  const { signature } = await fetchRound(chain, round);
  if (!verifyDrandRound(chain, round, signature)) throw new Error(`the signature served for drand round ${round} of chain ${chain.hash} does not verify against the chain's key: no heat draws on it`);
  return { chain: chain.hash, round, signature };
}

/**
 * The first round `chain` emits at or after the final phase's start (instance.ts scoredBeacon, as a scored instance
 * draw takes it), and when: the final heat's round and the earliest the heat may draw on it.
 */
export function scrapeFinalRound(finalStartsAt: Date, chain: DrandChain): { round: number; at: Date } {
  const round = scoredBeacon(finalStartsAt, chain).round;
  return { round, at: roundTime(round, chain) };
}

/** A UUID (version 8) shaped from the sha256 of `text` (server/jobs.ts's job ids' shape). */
function sha256Uuid(text: string): string {
  const h = createHash('sha256').update(text).digest('hex').split('');
  h[12] = '8';
  h[16] = ((parseInt(h[16]!, 16) & 0x3) | 0x8).toString(16);
  const s = h.join('');
  return `${s.slice(0, 8)}-${s.slice(8, 12)}-${s.slice(12, 16)}-${s.slice(16, 20)}-${s.slice(20, 32)}`;
}

/** The scrape-heat job's payload: the final phase whose one heat it runs. */
export const ScrapeHeatJob = z.strictObject({ phase_id: z.uuid() });
export type ScrapeHeatJobT = z.infer<typeof ScrapeHeatJob>;

/** The scrape-heat job's id: one per final phase, so the phase's heat is sent once however often it is asked for. */
export function scrapeHeatJobId(phaseId: string): string {
  return sha256Uuid(`scrape-heat\0${phaseId.toLowerCase()}`);
}

/**
 * A heat's id (contracts/scrape.ts ScrapeHeatId): `practice-` or `final-` and 31 or 34 hex of sha256 of what it is for
 * (the grade job's id, or the phase's and the heat job's), so a retried job's heat reuses its trials' owners and reaps
 * what a dead attempt left running (trial.ts scrapeTrialOwner).
 */
export function scrapeHeatIdOf(purpose: 'practice' | 'final', key: string): string {
  const prefix = purpose === 'practice' ? SCRAPE_PRACTICE_HEAT_PREFIX : SCRAPE_FINAL_HEAT_PREFIX;
  return `${prefix}${createHash('sha256').update(key).digest('hex').slice(0, 40 - prefix.length)}`;
}

/** A submission's receipt time (ms), +infinity with none: a heat lists its entries in receipt order. */
function receiptMs(sub: Pick<typeof submission.$inferSelect, 'receipt'>): number {
  const t = (sub.receipt as { server_time?: unknown } | null)?.server_time;
  const ms = typeof t === 'string' ? Date.parse(t) : Number.NaN;
  return Number.isNaN(ms) ? Number.POSITIVE_INFINITY : ms;
}

function byReceipt(a: typeof submission.$inferSelect, b: typeof submission.$inferSelect): number {
  return receiptMs(a) - receiptMs(b) || a.createdAt.getTime() - b.createdAt.getTime() || compareCodeUnits(a.id, b.id);
}

/** The competition's house baseline: its latest baseline submission with a snapshot, not cancelled; null when it has none. */
async function scrapeBaselineOf(db: Db, competitionId: string): Promise<typeof submission.$inferSelect | null> {
  const rows = await db
    .select()
    .from(submission)
    .where(and(eq(submission.competitionId, competitionId), eq(submission.baseline, true), ne(submission.status, 'cancelled'), isNotNull(submission.snapshotSha256)));
  return rows.sort(byReceipt).at(-1) ?? null;
}

/**
 * The voids a heat holds for an admin's review before prizes (the header's `scrape/v1`): per timed stage, a run whose
 * voided and re-run trials there number more than twice the stage field's median plus 2 (the main stage's field every
 * entry, the playoff's its finalists). Only attempts of outcome 'void' count: a judged void (grader/scrape/heat.ts: a
 * trial voided at its judging, a short chart the upstream served, its outcome 'run' with judged_void set) is never
 * counted, since such voids hit every entrant in their window, though it re-ran and the run's voids_rerun counts it.
 * Never a penalty: the run is scored as any. Entry id -> what to say.
 */
export function scrapeVoidsReview(heat: Pick<ScrapeHeatT, 'entries' | 'playoff'>, attempts: readonly Pick<ScrapeHeatAttempt, 'stage' | 'entry' | 'outcome'>[]): Map<string, string> {
  const out = new Map<string, string>();
  for (const [stage, field] of [['main', heat.entries], ['playoff', heat.playoff]] as const) {
    if (field.length === 0) continue;
    const voids = new Map(field.map((id) => [id, 0]));
    for (const a of attempts) if (a.stage === stage && a.outcome === 'void' && voids.has(a.entry)) voids.set(a.entry, voids.get(a.entry)! + 1);
    const sorted = [...voids.values()].sort((x, y) => x - y);
    const mid = sorted.length >> 1;
    // Twice the median, a whole number: the two middle counts summed on an even field.
    const twice = sorted.length % 2 === 1 ? 2 * sorted[mid]! : sorted[mid - 1]! + sorted[mid]!;
    for (const id of field) {
      const n = voids.get(id)!;
      if (n <= twice + 2) continue;
      const said = `${n} of its ${stage} trials voided and re-ran, more than twice the field's median (${twice / 2}) plus 2`;
      out.set(id, out.has(id) ? `${out.get(id)!}; ${said}` : said);
    }
  }
  return out;
}

/** A heat's log (regrade.ts SCRAPE_HEAT_LOG_FORMAT, record.ts recordScrapeRuns): what its runs' stderr_sha256 names. */
export function scrapeHeatLog(o: { purpose: 'practice' | 'final'; heatSha256: string; result: ScrapeHeatResult }): Record<string, unknown> {
  const r = o.result;
  return {
    format: SCRAPE_HEAT_LOG_FORMAT,
    heat_sha256: o.heatSha256,
    heat: r.heat.id,
    purpose: o.purpose,
    reference: { ...r.reference },
    ca_sha256: r.ca_sha256,
    started_at: r.started_at,
    ended_at: r.ended_at,
    attempts: r.attempts.map((a) => ({ ...a })),
    runs: r.runs.map((run) => ({
      entry: run.entry,
      finalist: run.finalist,
      voids_rerun: run.voids_rerun,
      scorer_faults: run.scorer_faults.map((f) => ({ ...f })),
      trials_sha256: run.trials === null ? null : canonicalSha256(run.trials),
      // Unscored: its trials as the heat ran them, unjudged, for an L1 re-judging once the scorer is mended.
      unjudged: run.trials === null ? run.runs.map((t) => ({ ...t })) : [],
    })),
  };
}

/** What a scrape/v1 grade job reads (createGradeHandler: `agent/v1`'s AgentRunStart, with the authorship loader). */
interface ScrapeGradeStart {
  deps: GradeWorkerDeps;
  ctx: GradeJobContext | undefined;
  sub: typeof submission.$inferSelect;
  ph: typeof phase.$inferSelect;
  comp: { id: string; slug: string };
  bundle: CompetitionBundleT;
  harness: ScrapeHarnessT;
  index: SnapshotIndex;
  competitionKey: string;
  loadAuthorship: NonNullable<GradeWorkerDeps['loadAuthorship']>;
}

/** One entrant of a heat: its submission, its snapshot's runtime, and (once materialized) its /bot. */
interface ScrapeEntrant {
  sub: typeof submission.$inferSelect;
  index: SnapshotIndex;
  runtime: Runtime;
}

/** A heat to run and record (runScrapeHeatFor). */
interface ScrapeHeatTask {
  deps: GradeWorkerDeps;
  purpose: 'practice' | 'final';
  heatId: string;
  comp: { id: string; slug: string };
  ph: typeof phase.$inferSelect;
  bundle: CompetitionBundleT;
  harness: ScrapeHarnessT;
  competitionKey: string;
  loadAuthorship: NonNullable<GradeWorkerDeps['loadAuthorship']>;
  /** Every entrant, the house baseline among them, in receipt order. */
  entrants: readonly ScrapeEntrant[];
  /** The house baseline: the reference read's reader. */
  baseline: ScrapeEntrant;
  /** The entrants whose runs are recorded (a practice heat's: its entry's alone). */
  recorded: ReadonlySet<string>;
  drand: { chain: string; round: number; signature: string };
  /** The job's owner (regradeOwner of its id): its scratch is named for it, and a dead attempt's removed first. */
  owner: string | null;
  what: string;
  /** The job attempt's signal (JobContext.signal): once pg-boss gives the attempt up, the wait for the lease ends and the heat stops (heat.ts `Abort`). */
  signal?: AbortSignal;
}

/** A heat's recorded runs (runScrapeHeatFor). */
interface ScrapeHeatRecorded {
  heat: ScrapeHeatT;
  heatSha256: string;
  logSha256: string;
  /** Each recorded run: unscored (its scorer faulted: never published), and held for review (why) or not. */
  runs: Array<{ submissionId: string; runId: string; unscored: boolean; held: string | null }>;
}

/** The node22 or python3.13 house's launcher text, as trial.ts runs it for `runtime`. */
async function launcherTextOf(deps: GradeWorkerDeps, runtime: Runtime): Promise<string> {
  const launch = await scrapeRuntime<typeof import('./scrape/launch.ts')>('./scrape/launch.ts');
  if (runtime === 'python3.13') return launch.PYTHON_LAUNCHER_SOURCE;
  return deps.scrape?.launcherSource ?? launch.launcherSource();
}

/**
 * Run one heat and record its runs (the header's `scrape/v1`): the entrants' snapshots materialized in the job's
 * scratch, every image the trials need present, each entrant's env-lane entry secrets opened (the header's `entry
 * secrets`: a house entry's none, its account's never read), the heat run under the host's lease (a lease held by
 * another heat is waited out: the heat is queued behind it), then the heat record and its log stored, and each recorded
 * entrant's run written (record.ts recordScrapeRuns), its score built as every run's, with the secret rows it ran with
 * and the forms its outputs held (ScrapeRunRecord's RunSecrets: one SECRET_IN_OUTPUT_ACTION row a leaking run), in one
 * transaction. The scratch is removed however it ends.
 */
async function runScrapeHeatFor(t: ScrapeHeatTask): Promise<ScrapeHeatRecorded> {
  const { deps } = t;
  const { db, blobs } = deps;
  const log = deps.log ?? ((line: string) => console.log(line));
  const compDir = competitionDirOf(deps, t.comp.slug, t.harness);
  const { runScrapeHeat, ScrapeLeaseBusyError } = await scrapeRuntime<typeof import('./scrape/heat.ts')>('./scrape/heat.ts');
  const leaseDir = deps.scrape?.leaseDir ?? scrapeLeaseDirFromEnv();
  const plan0 = scrapePlan({ harness: t.harness, seed: '0', datasetSha256: null });
  // Every image a trial runs: each entrant's runtime, the gateway's and the launcher's node22, the scorer's.
  for (const runtime of new Set(t.entrants.map((e) => e.runtime))) await preflight(plan0, deps.sandbox, runtime, null);
  await deps.sandbox.preflight('node22');
  // The scorer as the sandbox mounts it, before anything of the heat is made: on the k8s sandbox its stage on the data claim (the header's `k8s data`).
  const scoringSetup = await scrapeScorerSetupFor(deps.sandbox, t.comp.slug, { compDir, harness: t.harness });
  // Each entrant's env-lane entry secrets, opened before anything of the heat is made (the header's `entry secrets`): its
  // every trial runs with its own. One this grader cannot open is an Error naming the rows (its job tries again): no
  // entrant runs without its own. A house entry (housePaysEntryLane: the house baseline among them) runs with none, as
  // an agent/v1 pass does: its account's secrets are never read or opened.
  const sealOf = entrySecretSealOf(deps);
  const secretsOf = new Map<string, EnvSecrets>();
  for (const e of t.entrants) {
    const secrets = housePaysEntryLane(e.sub) ? noEnvSecrets() : await activeEnvSecrets(db, sealOf, { userId: e.sub.userId, competitionId: t.comp.id }, `${t.comp.slug}: submission ${e.sub.id}'s trials in ${t.what}`);
    secretsOf.set(e.sub.id, secrets);
  }

  if (t.owner !== null) {
    const line = scratchReapLine(t.what, 'its heat', await reapGradeScratch(deps.sandbox, deps.workRoot, t.owner));
    if (line !== null) log(line);
  }
  const work = t.owner === null ? await mkdtemp(join(deps.workRoot, EXEC_SCRATCH_PREFIX)) : await ownedScratch(deps.workRoot, EXEC_SCRATCH_PREFIX, t.owner);
  // Held as an owned one is (grade.ts holdScratch, its header's Releasing): its removal below, once the heat's runs are
  // recorded (or it threw), releases it from the sandbox's daemon in one go, every trial's and scorer's scratch with it.
  if (t.owner === null) holdScratch(work);
  try {
    const dirOf = new Map<string, string>();
    for (const e of t.entrants) {
      const dir = join(work, `bot-${e.sub.id}`);
      await materializeSnapshot(e.index, blobs, dir);
      dirOf.set(e.sub.id, dir);
    }
    const heatDir = join(work, 'heat');
    await mkdir(heatDir, { mode: 0o700 });
    const gateway = await (deps.scrape?.gateway ?? (async () => (await scrapeRuntime<typeof import('./scrape/bundle.ts')>('./scrape/bundle.ts')).scrapeGatewayBundle({ cacheDir: join(deps.workRoot, 'scrape-gateway') })))();
    const nodeLauncher = await launcherTextOf(deps, 'node22');
    const harness = t.purpose === 'practice' ? { network: t.harness.network, heat: { ...t.harness.heat, playoff: { places: 0, rounds: 0 } } } : { network: t.harness.network, heat: t.harness.heat };
    const options: ScrapeHeatOptions = {
      id: t.heatId,
      entries: t.entrants.map((e) => {
        const secrets = secretsOf.get(e.sub.id)!;
        return { id: e.sub.id, dir: dirOf.get(e.sub.id)!, runtime: e.runtime, ...(secrets.ids.length === 0 ? {} : { secrets: secrets.env }) };
      }),
      harness,
      drand: t.drand,
      reference: { dir: dirOf.get(t.baseline.sub.id)!, runtime: t.baseline.runtime },
      sandbox: deps.sandbox,
      limits: t.bundle.limits,
      gateway: { dir: gateway.dir, script: gateway.script },
      launcherSource: nodeLauncher,
      workDir: heatDir,
      blobs,
      scoring: { setup: scoringSetup },
      lease: { dir: leaseDir, db },
      ...(deps.scrape?.pacing === undefined ? {} : { pacing: deps.scrape.pacing }),
      ...(deps.scrape?.trial === undefined ? {} : { trial: deps.scrape.trial }),
      ...(deps.scrape?.onEvent === undefined ? {} : { onEvent: deps.scrape.onEvent }),
      ...(deps.scrape?.heat === undefined ? {} : { deps: deps.scrape.heat }),
      ...(t.signal === undefined ? {} : { signal: t.signal }),
    };
    // Queued behind any heat running on this host: its lease waited out, and taken again if another heat took it first.
    let result: ScrapeHeatResult;
    for (;;) {
      await scrapeHostQuiet(deps, t.what, t.signal);
      try {
        result = await runScrapeHeat(options);
        break;
      } catch (err) {
        if (err instanceof ScrapeLeaseBusyError) continue;
        throw err;
      }
    }

    // The heat record (every run's dataset_sha256, served by the archive) and its log (every run's stderr_sha256).
    const heatJson = canonicalJson(result.heat);
    const heatSha256 = (await blobs.put(heatJson)).sha256;
    const logJson = canonicalJson(scrapeHeatLog({ purpose: t.purpose, heatSha256, result }));
    const logSha256 = (await blobs.put(logJson)).sha256;
    const gatewaySha256 = sha256Hex(await readFile(join(gateway.dir, gateway.script)));
    const review = scrapeVoidsReview(result.heat, result.attempts);
    const startedAt = new Date(result.started_at);
    const finishedAt = new Date(result.ended_at);
    /**
     * Each recorded run, with its entry secrets (the header's `entry secrets`, ScrapeRunRecord's RunSecrets): the rows its
     * trials ran with, the forms its error is masked of, and where its outputs held one, which recordScrapeRuns flags
     * secret_in_output with the run's one SECRET_IN_OUTPUT_ACTION row.
     */
    const records: ScrapeRunRecord[] = [];
    for (const e of t.entrants) {
      if (!t.recorded.has(e.sub.id)) continue;
      const r = result.runs.find((x) => x.entry === e.sub.id);
      if (r === undefined) throw new Error(`heat ${t.heatId} returned no run of entry ${e.sub.id}`);
      const secrets = secretsOf.get(e.sub.id)!;
      const forms = entrySecretForms(secrets.env);
      // Redacted here as well as in the record: the admins' page below quotes a left-unscored run's error.
      const redacted = (text: string): string => redactSecrets(text, forms);
      // Its trials' /output as the heat scanned it, every attempt's (heat.ts ScrapeHeatRun.secret_hits), never masked.
      const hits: SecretHit[] = r.secret_hits.map((h) => ({ name: h.name, file: h.file }));
      const seed = phaseSeed(t.competitionKey, t.ph.key, heatSha256);
      const plan = scrapePlan({ harness: t.harness, seed, datasetSha256: heatSha256 });
      const launcherSha256 = sha256Hex(await launcherTextOf(deps, e.runtime));
      const listedNs = (r.trials?.trials ?? r.runs).reduce((s, x) => s + x.wall_ns, 0);
      const base = {
        submissionId: e.sub.id,
        phaseId: t.ph.id,
        exec_count: result.attempts.filter((a) => a.entry === e.sub.id).length,
        wall_ms: Math.round(listedNs / 1e6),
        image_digest: deps.sandbox.imageDigest(e.runtime),
        harness_version: scrapeHarnessVersion(launcherSha256, gatewaySha256),
        scorer_version: scorerVersionOf(plan, deps.sandbox),
        dataset_sha256: heatSha256,
        heat_log_sha256: logSha256,
        seed,
        started_at: startedAt,
        finished_at: finishedAt,
      };
      if (r.trials === null || r.performance === null) {
        const f = r.scorer_faults[0];
        const fault = f === undefined ? 'a fault' : `${f.name} on its ${f.stage} round ${f.round}: ${f.message}`;
        if (hits.length > 0) log(secretHitsLine(`${t.comp.slug}: submission ${e.sub.id}'s run in ${t.what}`, hits));
        records.push({
          ...base,
          status: 'failed',
          error: redacted(`left unscored: the competition's scorer could not judge it (${fault}). That is the house's fault, never the entry's: nothing is published, and its trials are kept unjudged in heat ${t.heatId}'s log (${logSha256})`),
          action_log_json: null,
          action_log_sha256: null,
          result: null,
          result_sha256: null,
          flags: [SCRAPE_SCORER_FAULT_FLAG],
          entry_secret_ids: secrets.ids,
          mask: forms,
          secret_hits: hits,
        });
        continue;
      }
      const actionLog = canonicalJson(r.trials);
      const actionLogSha256 = sha256Hex(actionLog);
      // Its action log (the trials manifest, which names its outputs' paths) scanned as a one-execution run's is (secretHitsOfRun).
      hits.push(...(await secretHitsOfRun(blobs, 'scrape/v1', { json: actionLog, sha256: actionLogSha256 }, secrets.env)));
      if (hits.length > 0) log(secretHitsLine(`${t.comp.slug}: submission ${e.sub.id}'s run in ${t.what}`, hits));
      const { cost, pricingRev } = await entryCostFor(deps, { sub: e.sub, bundle: t.bundle, fresh: true, ...(t.signal === undefined ? {} : { signal: t.signal }) });
      const authorship = await t.loadAuthorship(e.sub.id, pricingRev);
      const score = buildScore(
        {
          harness: { kind: 'scrape/v1', version: base.harness_version },
          image_digest: base.image_digest,
          dataset_sha256: heatSha256,
          seed,
          // Scored: its scorer agreed with itself on every listed trial (a disagreement leaves a run unscored, above).
          deterministic: true,
          execution_flags: [],
          house: standingsHouse(e.sub),
          baseline: e.sub.baseline,
        },
        { action_log_sha256: actionLogSha256, performance: r.performance, performance_flags: [], cost, authorship },
        eligibilityRulesOf(t.bundle),
        base.scorer_version,
      );
      const held = review.get(e.sub.id);
      records.push({
        ...base,
        status: 'finished',
        error: held === undefined ? null : `held for an admin's review before prizes, never a penalty: ${held}; heat ${t.heatId}'s log (${logSha256}) lists every attempt`,
        action_log_json: actionLog,
        action_log_sha256: actionLogSha256,
        result: score,
        result_sha256: scoreDigest(score).sha256,
        // secret_in_output (recordScrapeRuns's, from its hits) beside the hold, on the run row alone, never in its score
        // (regrade.ts RUN_ONLY_FLAGS).
        flags: held === undefined ? [] : [SCRAPE_VOIDS_REVIEW_FLAG],
        entry_secret_ids: secrets.ids,
        mask: forms,
        secret_hits: hits,
      });
    }
    // One transaction (recordScrapeRuns's): the runs, the rows each ran with (run.entry_secret_ids) and each leaking
    // run's one SECRET_IN_OUTPUT_ACTION row (the header's `entry secrets`).
    const ids = await recordScrapeRuns(db, blobs, records);
    // The final's grades landed at once: the live board's count moves (finalGradeLanded).
    if (t.ph.key === 'final') await finalGradeLanded(db, t.comp.id, log);
    const runs = records.map((r, i) => ({ submissionId: r.submissionId, runId: ids[i]!, unscored: r.status === 'failed', held: r.flags.includes(SCRAPE_VOIDS_REVIEW_FLAG) ? r.error : null }));
    // The heat's one line in the grader's log: what an operator reads a heat recorded by.
    log(
      `[scrape] ${t.what}: heat ${t.heatId} recorded on the ${deps.sandbox.kind} sandbox, ${result.attempts.length} attempts from ${result.started_at} to ${result.ended_at} (record ${heatSha256}): ` +
        runs.map((r) => `entry ${r.submissionId}'s run ${r.runId} ${r.unscored ? 'left unscored' : r.held === null ? 'scored' : 'scored, held for review'}`).join('; '),
    );
    // A run its scorer left unscored is the house's to mend: paged, never published.
    const page = deps.page ?? ((line: string) => console.error(line));
    for (const [i, r] of records.entries()) {
      if (r.status !== 'failed') continue;
      page(
        `[scrape] ALERT: ${t.comp.slug}'s ${t.ph.key} phase: entry ${r.submissionId}'s run ${ids[i]} in heat ${t.heatId} ${r.error!.slice('left '.length)}. ` +
          `Mend the scorer (competitions/${t.comp.slug}), then judge the run again from the heat's records: POST /api/admin/runs/${ids[i]}/rejudge {"reason": "<what was mended>"} (server/routes/admin/scrape-holds.ts)`,
      );
    }
    return { heat: result.heat, heatSha256, logSha256, runs };
  } finally {
    for (const e of t.entrants) await removeMaterialized(join(work, `bot-${e.sub.id}`)).catch(() => undefined);
    await removeScratch(deps.sandbox, work);
  }
}

/** A scrape/v1 run's harness_version: the harness source's (version.ts harnessVersion), and the digests of the launcher and the gateway its trials ran. */
export function scrapeHarnessVersion(launcherSha256: string, gatewaySha256: string): string {
  return `${harnessVersion()} launcher@${launcherSha256} gateway@${gatewaySha256}`;
}

/** An entrant from its submission: its snapshot index and the runtime it selects, or why it can run in no heat. */
async function scrapeEntrantOf(deps: GradeWorkerDeps, sub: typeof submission.$inferSelect, harness: ScrapeHarnessT): Promise<ScrapeEntrant | { sub: typeof submission.$inferSelect; error: string }> {
  if (sub.snapshotSha256 === null) return { sub, error: `submission ${sub.id} has no snapshot yet` };
  const index = await readSnapshotIndex(deps.blobs, sub.snapshotSha256);
  const picked = entryRuntime(index, harness.runtimes);
  return 'error' in picked ? { sub, error: picked.error } : { sub, index, runtime: picked.runtime };
}

/**
 * A dev phase's scrape/v1 grade (the header's `scrape/v1`): a practice heat of the entry beside the house baseline over
 * the bundle's warm-up and main rounds, no playoff, its round the newest drand round, queued behind any heat this host
 * runs. The entry's run is recorded and published; the baseline's run in it is not (its own grade job grades it). An
 * entry that selects no runtime fails at once, nothing run; a competition with no house baseline submitted cannot run
 * one (PermanentJobError).
 */
async function gradeScrapePractice(s: ScrapeGradeStart): Promise<{ run_id: string } | null> {
  const { deps, sub, ph, comp, harness } = s;
  const entrant = await scrapeEntrantOf(deps, sub, harness);
  if ('error' in entrant) {
    const plan = scrapePlan({ harness, seed: phaseSeed(s.competitionKey, ph.key, null), datasetSha256: null });
    return { run_id: await recordGrade(deps.db, deps.blobs, refusedGrade(plan, entrant.error), { submissionId: sub.id, phaseId: ph.id }) };
  }
  let baseline: ScrapeEntrant = entrant;
  if (!sub.baseline) {
    const row = await scrapeBaselineOf(deps.db, comp.id);
    if (row === null) throw new PermanentJobError(`${comp.slug} has no house baseline submitted: a practice heat runs an entry beside it, and its read is the heat's reference. Submit the baseline, then resend this grade`);
    const b = await scrapeEntrantOf(deps, row, harness);
    if ('error' in b) throw new PermanentJobError(`${comp.slug}'s house baseline ${row.id} cannot run in a heat: ${b.error}`);
    baseline = b;
  }
  const chain = scrapeDrandChain(deps);
  const clock = deps.scrape?.clock ?? wallClock;
  const drand = await verifiedDrandRound(deps, chain, latestDrandRound(chain, clock.now() - SCRAPE_DRAND_LAG_MS));
  const jobKey = s.ctx?.id ?? uuidv7();
  const what = `submission ${sub.id}'s practice heat on the ${ph.key} phase (job ${jobKey})`;
  const recorded = await runScrapeHeatFor({
    deps,
    purpose: 'practice',
    heatId: scrapeHeatIdOf('practice', jobKey),
    comp,
    ph,
    bundle: s.bundle,
    harness,
    competitionKey: s.competitionKey,
    loadAuthorship: s.loadAuthorship,
    entrants: (baseline === entrant ? [entrant] : [entrant, baseline]).sort((a, b) => byReceipt(a.sub, b.sub)),
    baseline,
    recorded: new Set([sub.id]),
    drand,
    owner: s.ctx === undefined ? null : regradeOwner(s.ctx.id),
    what,
    ...(s.ctx?.signal === undefined ? {} : { signal: s.ctx.signal }),
  });
  const mine = recorded.runs.find((r) => r.submissionId === sub.id)!;
  return mine.unscored ? null : { run_id: mine.runId };
}

/**
 * A final phase's scrape/v1 grade job (kind grade): the phase's one heat grades every final entry
 * (createScrapeHeatHandler), never this job. Once that heat has recorded the entry's run, the job hands it on to
 * publish (null when its scorer left it unscored); before, it hands on nothing. An entry the recorded heat ran without
 * can no longer be graded on the phase (PermanentJobError).
 */
async function scrapeFinalGrade(s: ScrapeGradeStart): Promise<{ run_id: string } | null> {
  const { deps, sub, ph } = s;
  const runs = await deps.db
    .select({ id: run.id, submissionId: run.submissionId, status: run.status, flags: run.flags, attempt: run.attempt })
    .from(run)
    .where(and(eq(run.phaseId, ph.id), eq(run.kind, 'grade'), isNotNull(run.datasetSha256)));
  const mine = runs.filter((r) => r.submissionId === sub.id).sort((a, b) => b.attempt - a.attempt)[0];
  if (mine !== undefined) return mine.flags.includes(SCRAPE_SCORER_FAULT_FLAG) ? null : { run_id: mine.id };
  if (runs.length > 0) throw new PermanentJobError(`the final phase of ${s.comp.slug} ran its one heat without submission ${sub.id}: a scrape/v1 final measures every entry in that heat, and none is measured after it`);
  (deps.log ?? ((line: string) => console.log(line)))(`[scrape] submission ${sub.id}'s final grade waits for the phase's one heat (scrape-heat job ${scrapeHeatJobId(ph.id)}), which grades every final entry: this job hands on nothing`);
  return null;
}

/** A scrape/v1 L1 regrade job (the header's `scrape/v1`): the stored grade run judged again from its record (regrade.ts regradeScrapeL1), recorded as a regrade run. */
async function regradeScrapeRun(s: ScrapeGradeStart & { job: JobPayload<'grade-dev'> }): Promise<{ run_id: string }> {
  const { deps, sub, ph, comp, harness, job } = s;
  const { db, blobs } = deps;
  const stored = await loadStoredRun(db, job.reproduces_run_id!);
  if (stored === null) throw new PermanentJobError(`run ${job.reproduces_run_id} does not exist`);
  if (stored.submissionId !== sub.id || stored.phaseId !== ph.id) throw new PermanentJobError(`run ${stored.id} is not a run of submission ${sub.id} in phase ${ph.id}`);
  const [orig] = await db.select({ kind: run.kind }).from(run).where(eq(run.id, stored.id));
  if (orig?.kind !== 'grade') throw new PermanentJobError(`run ${stored.id} is a ${orig?.kind}; regrade the grade run it reproduces`);
  if (stored.seed === null) throw new PermanentJobError(`run ${stored.id} recorded no seed`);
  // The scorer as the sandbox mounts it: on the k8s sandbox its stage on the data claim (the header's `k8s data`).
  const setup = await scrapeScorerSetupFor(deps.sandbox, comp.slug, { compDir: competitionDirOf(deps, comp.slug, harness), harness });
  const plan = scrapePlan({ harness, seed: stored.seed, datasetSha256: stored.dataset_sha256 });
  const { cost, pricingRev } = await entryCostFor(deps, { sub, bundle: s.bundle, fresh: false, stored: stored.result });
  const version = storedAuthorshipVersion(stored.result);
  let authorship: AuthorshipSummaryT | null = null;
  if (version !== null) {
    authorship = await s.loadAuthorship(sub.id, pricingRev, version);
    if (version !== undefined && authorship?.algo_version !== version) {
      throw new PermanentJobError(`run ${stored.id} was graded with authorship algorithm ${version}, and submission ${sub.id} has no summary of it under pricing_rev ${pricingRev}`);
    }
  }
  const jobId = s.ctx?.id ?? uuidv7();
  const log = deps.log ?? ((line: string) => console.log(line));
  const regrading = `run ${stored.id}'s ${job.kind} regrade (job ${jobId})`;
  try {
    const outcome = await regradeScrapeL1({
      stored,
      plan,
      sandbox: deps.sandbox,
      blobs,
      limits: s.bundle.limits,
      workRoot: deps.workRoot,
      cost,
      authorship,
      entry: { house: standingsHouse(sub), baseline: sub.baseline },
      rules: eligibilityRulesOf(s.bundle),
      entryId: sub.id,
      setup,
      trim: harness.heat.trim,
      scoring: await scrapeRuntime<typeof import('./scrape/score.ts')>('./scrape/score.ts'),
      owner: regradeOwner(jobId),
      onScratchReap: (r) => {
        const line = scratchReapLine(regrading, `attempt ${(s.ctx?.retryCount ?? 0) + 1}`, r);
        if (line !== null) log(line);
      },
    });
    // The re-judging runs to its end (a scrape/v1 L1 takes no signal), and an attempt given up meanwhile records nothing.
    s.ctx?.signal?.throwIfAborted();
    return { run_id: await recordRegrade(db, blobs, outcome, { submissionId: sub.id, phaseId: ph.id }) };
  } catch (err) {
    if (err instanceof RegradeError) throw new PermanentJobError(err.message, { cause: err });
    throw err;
  }
}

/**
 * The final heat's runs, as the scrape-heat job hands them on: every run to publish, and the runs left unscored or held for
 * review. A re-judging's job (`rejudge`) answers its re-judging's end in the same shape: no heat ran, nothing unscored or
 * held to page (its re-judging wrote its outcome to the run and its audit rows), and to publish only a run it judged and
 * could not publish itself.
 */
export interface ScrapeHeatOutcome {
  phase_id: string;
  /**
   * The heat (ScrapeHeat.id) and its record's canonical sha256: every run's dataset_sha256. A re-judging's: its run's
   * heat, each empty where the job ended before reading it.
   */
  heat: string;
  heat_sha256: string;
  /** False when the job found the phase's heat already recorded (a retry, or a second send): nothing ran. A re-judging's: whether it judged the run's trials. */
  ran: boolean;
  /** Each run to publish (AggregatedRun's shape, so the pipeline sends each its publish job), in receipt order. */
  publish: AggregatedRun[];
  /** Runs left unscored by the scorer (never published, the admins paged). */
  unscored: Array<{ run_id: string; submission_id: string }>;
  /** Runs published and held for an admin's review before prizes (SCRAPE_VOIDS_REVIEW_FLAG), with why. */
  held: Array<{ run_id: string; submission_id: string; reason: string }>;
  /** A re-judging's job: how its re-judging ended (server/routes/admin/scrape-holds.ts judgeRejudgeJob); absent on a heat's. */
  rejudge?: RejudgeJobEnd;
}

/** The context a scrape-heat job is handed (JobQueue.work's): its signal, once pg-boss gives the attempt up, ends its waits and stops its heat. */
export type ScrapeHeatJobContext = Pick<JobContext, 'id'> & Partial<Pick<JobContext, 'retryCount' | 'retryLimit' | 'signal'>>;

/**
 * The scrape-heat job handler (the header's `scrape/v1`): the final phase's one heat, for every final entry
 * (admin/grading.ts entriesToGrade, as a lock queues them) and the house baseline, its field read once no entry taken in
 * by the deadline awaits its snapshot (scrapeFieldSnapshotted, as codeHeatDue waits). It draws on the first drand round
 * at or after the phase's scheduled start (scrapeFinalRound, waited for when the job runs early), fetched and
 * verified, runs once this host's lease is free, and records one grade run per entry (an entry that selects no
 * runtime: a failed run, nothing run). A phase whose heat is recorded already is not run again: the job answers its
 * runs. Throws PermanentJobError on what no retry mends: no such phase, not a final phase, not scrape/v1, no house
 * baseline among the entries.
 *
 * The queue's other payload, an admin's re-judging of a run its scorer left unscored (server/jobs.ts ScrapeRejudgeJob),
 * is judged here on this host's own parts, as a heat's trials are: its sandbox (on the cluster the k8s sandbox, which
 * only the worker and grader pods carry), the bundle's sealed scorer as that sandbox mounts it (scrapeScorerSetupFor: on
 * the k8s sandbox its stage on the data claim), the host's scrape lease (ScrapeWorkerDeps.leaseDir, else
 * scrapeLeaseDirFromEnv), the work root and the job's owner (regradeOwner of its id, so a retry reaps what a dead attempt
 * left) by server/routes/admin/scrape-holds.ts judgeRejudgeJob, which writes every outcome to the run and its audit rows
 * and never throws, and hands itself on through `deps.jobs` while a heat holds the lease.
 */
export function createScrapeHeatHandler(deps: GradeWorkerDeps): (data: ScrapeHeatJobT | ScrapeRejudgeJobT, ctx?: ScrapeHeatJobContext) => Promise<ScrapeHeatOutcome> {
  const { db } = deps;
  const loadAuthorship = deps.loadAuthorship ?? ((submissionId: string, pricingRev: string, algoVersion?: number) => loadStoredAuthorship(db, submissionId, pricingRev, algoVersion));
  return async (input, ctx) => {
    if (isScrapeRejudgeJob(input)) return scrapeRejudgeFor(deps, ScrapeRejudgeJob.parse(input), loadAuthorship, ctx);
    const data = ScrapeHeatJob.parse(input);
    const ph = await one(db.select().from(phase).where(eq(phase.id, data.phase_id)), `phase ${data.phase_id}`);
    const comp = await one(db.select().from(competition).where(eq(competition.id, ph.competitionId)), `competition ${ph.competitionId}`);
    if (comp.bundle === null) throw new PermanentJobError(`competition ${comp.slug} has no bundle (a demo row cannot be graded)`);
    let bundle: CompetitionBundleT;
    try {
      bundle = CompetitionBundle.parse(comp.bundle);
    } catch (err) {
      throw new PermanentJobError(`competition ${comp.slug}'s stored bundle does not validate`, { cause: err });
    }
    const harness = bundle.harness;
    if (harness.kind !== 'scrape/v1') throw new PermanentJobError(`${comp.slug} is a ${harness.kind} competition: only a scrape/v1 final phase runs a heat`);
    if (ph.key !== 'final') throw new PermanentJobError(`phase ${ph.key} of ${comp.slug} is not its final phase: a dev phase's entries each run a practice heat of their own`);
    const competitionKey = competitionSeedKey(comp);

    // The phase's heat already recorded: answered, never run again.
    const done = await db
      .select({ id: run.id, submissionId: run.submissionId, status: run.status, flags: run.flags, error: run.error, attempt: run.attempt, datasetSha256: run.datasetSha256 })
      .from(run)
      .where(and(eq(run.phaseId, ph.id), eq(run.kind, 'grade'), isNotNull(run.datasetSha256)));
    if (done.length > 0) {
      const heatSha256 = done.sort((a, b) => b.attempt - a.attempt)[0]!.datasetSha256!;
      const rows = done.filter((r) => r.datasetSha256 === heatSha256);
      const heat = ScrapeHeat.parse(JSON.parse(Buffer.from((await deps.blobs.get(heatSha256, { verify: true })) ?? Buffer.from('null')).toString('utf8')));
      return outcomeOf(ph, heat.id, heatSha256, false, rows.map((r) => ({ submissionId: r.submissionId, runId: r.id, unscored: r.flags.includes(SCRAPE_SCORER_FAULT_FLAG), held: r.flags.includes(SCRAPE_VOIDS_REVIEW_FLAG) ? r.error : null })));
    }

    const { entriesToGrade, awaitingSnapshot } = await scrapeRuntime<typeof import('../server/routes/admin/grading.ts')>('../server/routes/admin/grading.ts');
    const jobKey = ctx?.id ?? uuidv7();
    const what = `the final heat of ${comp.slug} (job ${jobKey})`;
    // Its field is read once: held first while an entry taken in by the deadline awaits its snapshot (the header's `scrape/v1`).
    await scrapeFieldSnapshotted(deps, comp, awaitingSnapshot, what, ctx?.signal);
    const subs = await entriesToGrade(db, comp, bundle.submission_rule.rule);
    const baselineRow = subs.filter((x) => x.baseline).sort(byReceipt).at(-1) ?? (await scrapeBaselineOf(db, comp.id));
    if (baselineRow === null) throw new PermanentJobError(`${comp.slug} has no house baseline submitted: the final heat runs every final entry beside it, and its read is the heat's reference`);
    if (!subs.some((x) => x.id === baselineRow.id)) subs.push(baselineRow);
    const entrants: ScrapeEntrant[] = [];
    const refused: Array<{ sub: typeof submission.$inferSelect; error: string }> = [];
    for (const sub of subs.sort(byReceipt)) {
      const e = await scrapeEntrantOf(deps, sub, harness);
      if ('error' in e) refused.push(e);
      else entrants.push(e);
    }
    const baseline = entrants.find((e) => e.sub.id === baselineRow.id);
    if (baseline === undefined) throw new PermanentJobError(`${comp.slug}'s house baseline ${baselineRow.id} cannot run in a heat: ${refused.find((r) => r.sub.id === baselineRow.id)?.error ?? 'its snapshot does not read'}`);

    // The first drand round at or after the scheduled start, once it is out.
    const chain = scrapeDrandChain(deps);
    const clock = deps.scrape?.clock ?? wallClock;
    const start = scrapeFinalRound(ph.startsAt, chain);
    const early = start.at.getTime() + SCRAPE_DRAND_LAG_MS - clock.now();
    if (early > 0) await clock.sleep(early, ctx?.signal);
    const drand = await verifiedDrandRound(deps, chain, start.round);

    const recorded = await runScrapeHeatFor({
      deps,
      purpose: 'final',
      heatId: scrapeHeatIdOf('final', `${ph.id}\0${jobKey}`),
      comp: { id: comp.id, slug: comp.slug },
      ph,
      bundle,
      harness,
      competitionKey,
      loadAuthorship,
      entrants,
      baseline,
      recorded: new Set(entrants.map((e) => e.sub.id)),
      drand,
      owner: ctx === undefined ? null : regradeOwner(ctx.id),
      what,
      ...(ctx?.signal === undefined ? {} : { signal: ctx.signal }),
    });
    // An entry that can run in no heat fails on its own, as an entry with no runtime does on any kind.
    const plan = scrapePlan({ harness, seed: phaseSeed(competitionKey, ph.key, null), datasetSha256: null });
    const failed: ScrapeHeatRecorded['runs'] = [];
    for (const r of refused) failed.push({ submissionId: r.sub.id, runId: await recordGrade(db, deps.blobs, refusedGrade(plan, r.error), { submissionId: r.sub.id, phaseId: ph.id }), unscored: false, held: null });
    return outcomeOf(ph, recorded.heat.id, recorded.heatSha256, true, [...recorded.runs, ...failed]);
  };
}

function outcomeOf(
  ph: Pick<typeof phase.$inferSelect, 'id' | 'key'>,
  heat: string,
  heatSha256: string,
  ran: boolean,
  runs: ReadonlyArray<{ submissionId: string; runId: string; unscored: boolean; held: string | null }>,
): ScrapeHeatOutcome {
  const phaseKey = ph.key as AggregatedRun['phase'];
  return {
    phase_id: ph.id,
    heat,
    heat_sha256: heatSha256,
    ran,
    publish: runs.filter((r) => !r.unscored).map((r) => ({ run_id: r.runId, submission_id: r.submissionId, phase_id: ph.id, phase: phaseKey })),
    unscored: runs.filter((r) => r.unscored).map((r) => ({ run_id: r.runId, submission_id: r.submissionId })),
    held: runs.filter((r) => !r.unscored && r.held !== null).map((r) => ({ run_id: r.runId, submission_id: r.submissionId, reason: r.held! })),
  };
}

/**
 * A re-judging's scrape-heat job (createScrapeHeatHandler's `rejudge`): server/routes/admin/scrape-holds.ts
 * judgeRejudgeJob on this host's parts, its end answered in a heat job's shape (ScrapeHeatOutcome.rejudge).
 */
async function scrapeRejudgeFor(
  deps: GradeWorkerDeps,
  data: ScrapeRejudgeJobT,
  loadAuthorship: NonNullable<GradeWorkerDeps['loadAuthorship']>,
  ctx: ScrapeHeatJobContext | undefined,
): Promise<ScrapeHeatOutcome> {
  const jobId = ctx?.id ?? uuidv7();
  let end: RejudgeJobEnd;
  try {
    const { judgeRejudgeJob } = await scrapeRuntime<typeof import('../server/routes/admin/scrape-holds.ts')>('../server/routes/admin/scrape-holds.ts');
    end = await judgeRejudgeJob(
      {
        db: deps.db,
        blobs: deps.blobs,
        sandbox: deps.sandbox,
        workRoot: deps.workRoot,
        leaseDir: deps.scrape?.leaseDir ?? scrapeLeaseDirFromEnv(),
        // The scorer as the sandbox mounts it: on the k8s sandbox its stage on the data claim (the header's `k8s data`), as a heat judges.
        scorerSetup: (slug, harness) => scrapeScorerSetupFor(deps.sandbox, slug, { compDir: competitionDirOf(deps, slug, harness), harness }),
        scoring: deps.scrape?.scoring ?? (await scrapeRuntime<typeof import('./scrape/score.ts')>('./scrape/score.ts')),
        loadAuthorship: (submissionId, pricingRev) => loadAuthorship(submissionId, pricingRev),
        owner: regradeOwner(jobId),
        ...(deps.jobs === undefined ? {} : { jobs: deps.jobs }),
        ...(deps.now === undefined ? {} : { now: deps.now }),
        ...(deps.log === undefined ? {} : { log: deps.log }),
      },
      data,
      { id: jobId },
    );
  } catch (err) {
    // A module that does not load: lost, never thrown (judgeRejudgeJob never throws; the stage would page a dead heat).
    console.error(`[scrape] re-judging ${data.rejudge.attempt} of run ${data.rejudge.run_id} (scrape-heat job ${jobId}) could not start:`, err);
    end = { attempt: data.rejudge.attempt, run_id: data.rejudge.run_id, stage: 'lost', heat: null, heat_sha256: null, judged: false, result: null, error: null, refusal: null, next_job_id: null, next_at: null, publish: null };
  }
  return {
    phase_id: data.phase_id,
    heat: end.heat ?? '',
    heat_sha256: end.heat_sha256 ?? '',
    ran: end.judged,
    publish: end.publish === null ? [] : [end.publish],
    unscored: [],
    held: [],
    rejudge: end,
  };
}

// ---------------------------------------------------------------- agent/v1: a run of K trials

/** A series of live passes: the first, and up to AGENT_VOID_RERUNS re-runs of a void; the trial is held once it is spent. A pass cut off (AGENT_INTERRUPTED_RERUNS) is none of them. */
export const AGENT_VOID_RERUNS = 2;
export const AGENT_SERIES_PASSES = 1 + AGENT_VOID_RERUNS;

/** How long a void's re-run waits before its job starts (a broker or provider blip passes meanwhile); an upstream_errors void's: agentVoidRerunDelayMs. */
export const AGENT_VOID_RERUN_DELAY_MS = 60_000;

/** The void reason of a live pass that met upstream errors (grader/agent.ts: any on the house lane, the entry lane's past its void share). */
export const UPSTREAM_ERRORS_VOID_REASON = 'upstream_errors' satisfies TrialVoidReason;

/**
 * How long the first re-run of a series after an upstream_errors void waits (agentVoidRerunDelayMs): each later one
 * waits twice the one before.
 */
export const AGENT_UPSTREAM_VOID_RERUN_DELAY_MS = 5 * 60_000;

/**
 * How long re-run `rerun` of a series (1 for the series' second pass, the first re-run) waits before its job starts,
 * after a void of `reason`. An upstream_errors void's waits AGENT_UPSTREAM_VOID_RERUN_DELAY_MS, doubled for each re-run
 * after the first (5, then 10 minutes for the series' AGENT_VOID_RERUNS; a third would wait 20), so the passes of one
 * series cannot all land in one burst of failing upstream calls (2026-11-11: three bursts of one to three minutes held
 * 38 werewolf-agent-01 trials whose three passes ran a minute apart); every other void's waits
 * AGENT_VOID_RERUN_DELAY_MS. A pass cut off (INTERRUPTED_VOID_REASON) is re-run at once by its caller and comes not here.
 */
export function agentVoidRerunDelayMs(reason: string, rerun: number): number {
  if (reason !== UPSTREAM_ERRORS_VOID_REASON) return AGENT_VOID_RERUN_DELAY_MS;
  return AGENT_UPSTREAM_VOID_RERUN_DELAY_MS * 2 ** Math.max(0, Math.trunc(rerun) - 1);
}

/**
 * How long a trial held for upstream errors (UPSTREAM_ERRORS_VOID_REASON, its series spent) waits, from its last pass's
 * end, before the fan-in re-queues it by itself, once (the header's `held`; createAgentAggregateHandler selfRequeue).
 */
export const TRIAL_SELF_REQUEUE_AFTER_MS = 30 * 60_000;

/**
 * Who an automatic re-queue's trial.requeue audit rows name as their actor (data.actor, with data.automatic true; their
 * actor_user_id null, the system's): the fan-in, whose wait slots sweep its run's held trials.
 */
export const TRIAL_SELF_REQUEUE_ACTOR = 'grade-aggregate';

/** The audit action of a held trial's re-queue: server/routes/admin/grading.ts TRIAL_REQUEUE_ACTION, an admin's or the fan-in's. */
const TRIAL_REQUEUE_ACTION = 'trial.requeue' satisfies AuditAction;

/** The fan-in's wait slot: while a trial is not done it looks again at the end of the next slot (each trial's end looks at once). */
export const AGENT_AGGREGATE_WAIT_MS = 15 * 60_000;

/** A trial job that spent its retries on a refused mint is sent again this much later, so the trial runs once the key is pinned. */
export const AGENT_REFUSAL_RETRY_MS = 15 * 60_000;

/** A refusal of the admin key (or of the engine) is paged at most this often by one process: every trial job meets the same one. */
export const AGENT_REFUSAL_PAGE_MS = 60 * 60_000;

/** What a refusal's trials wait on, and what lets them run (the trial handler's log and page wording of a refusal). */
interface RefusalTerms {
  waitsOn: string;
  once: string;
}
const KEY_REFUSAL: RefusalTerms = { waitsOn: "the admin key's pin", once: 'the key is pinned' };
/** What the isolation lines call the engine, by its driver: grader/sandbox/network.ts ISOLATION_ENGINES, its type pinning the spelling (network.ts is loaded on first use: the header's `isolation`). */
const ISOLATION_ENGINES: typeof SandboxIsolationEngines = { docker: 'Docker engine', k8s: 'Kubernetes cluster' };
/** The driver a sandbox's isolation lines name: k8s's cluster, else docker's engine (IsolationRefusal's default). */
const isolationDriverOf = (sandbox: Pick<Sandbox, 'kind'>): IsolationDriver => (sandbox.kind === 'k8s' ? 'k8s' : 'docker');
/** A refused engine's terms, by the driver whose probe refused it. */
const engineRefusal = (driver: IsolationDriver): RefusalTerms => ({
  waitsOn: `a ${ISOLATION_ENGINES[driver]} that keeps trials apart`,
  once: `the ${driver === 'k8s' ? 'cluster' : 'engine'} keeps trials apart`,
});

/** The void reason of a live pass cut off before it ended (its job attempt stopped or expired): no cassette came back. */
export const INTERRUPTED_VOID_REASON = 'interrupted';

/**
 * How many passes of a trial in a row may be cut off before it is held (the header's `cut off`): a live pass voided
 * INTERRUPTED_VOID_REASON, or a replay found cut off. Each is re-run without spending a pass of the series (a grader
 * restart is the platform's, never the entry's), and the AGENT_INTERRUPTED_RERUNS-th in a row holds the trial under
 * INTERRUPTED_VOID_REASON, so a pass that kills its grader every time cannot loop.
 */
export const AGENT_INTERRUPTED_RERUNS = 6;

/** The words a cut-off pass's error ends with once two or more in a row were cut off (one alone says none): `n` of them. */
const cutOffRunWords = (n: number): string => `; cut off ${n} times in a row (held at ${AGENT_INTERRUPTED_RERUNS})`;
const CUT_OFF_RUN_RE = /; cut off (\d+) times in a row \(held at \d+\)$/;

/**
 * How many live passes in a row, the last of them `pass`, `row` records as cut off: 0 unless its latest void is pass
 * `pass` voided INTERRUPTED_VOID_REASON with the words interrupted() wrote (a void reason and error are kept through the
 * next pass's run until its own void, so a claimed row still tells of the pass before it); else the count its words
 * end with, 1 when they name none. A held or re-queued trial's error is its hold's, so its run starts again at 0.
 */
function liveCutOffRun(row: Pick<TrialRow, 'voidReason' | 'error'>, pass: number): number {
  if (row.voidReason !== INTERRUPTED_VOID_REASON || row.error === null || !row.error.startsWith(`live pass ${pass}, started `)) return 0;
  const m = CUT_OFF_RUN_RE.exec(row.error);
  return m === null ? 1 : Number(m[1]);
}

/** The words a replay found cut off writes on its row (replayCutOff), `n` the replays of its live pass cut off in a row. */
const replayCutOffWords = (row: Pick<TrialRow, 'attempt' | 'replayStartedAt'>, n: number): string =>
  `the replay of live pass ${row.attempt}, started ${row.replayStartedAt?.toISOString() ?? 'at an unknown time'}, was cut off before it ended (its job attempt stopped or expired)${cutOffRunWords(n)}`;

/** How many replays of `row`'s live pass in a row were found cut off before this one (replayCutOffWords on its error), 0 when none. */
function replayCutOffRun(row: Pick<TrialRow, 'attempt' | 'error'>): number {
  if (row.error === null || !row.error.startsWith(`the replay of live pass ${row.attempt}, started `)) return 0;
  const m = CUT_OFF_RUN_RE.exec(row.error);
  return m === null ? 0 : Number(m[1]);
}

/** The hold reason of a trial whose job died for good outside its handler (an attempt expired, its process gone). */
export const DEAD_JOB_HOLD_REASON = 'job_dead';

/** The hold reason of a trial whose job met a fault no retry mended (none more specific said). */
export const HARNESS_FAULT_HOLD_REASON = 'harness_fault';

/** The run flag of a held trial: server/entries/stage.ts TRIAL_HELD_FLAG, its type pinning the spelling (the stage machine is not loaded here: the header's `agent/v1`). */
const TRIAL_HELD_FLAG: typeof StageTrialHeldFlag = 'trial_held';

/**
 * How often a pass waiting on an entrant's provider key checks it again (the header's `entry secrets`): a key its
 * provider refused on the final, or a provider that gave no verdict. Its job's next slot.
 */
export const AGENT_PROVIDER_KEY_RECHECK_MS = 15 * 60_000;

/**
 * The longest a final pass waits for its entrant to push a new key in place of one its provider refused, from the first
 * refusal (the header's `entry secrets`), and never past the final phase's end: then the trial scores 0
 * (PROVIDER_KEY_REFUSED).
 */
export const AGENT_PROVIDER_KEY_HOLD_MS = 24 * 3_600_000;

/**
 * The audit_event action that starts a final pass's wait on a refused provider key (the header's `entry secrets`), once
 * for the trial and pass: the system's (actor null), subject the run_trial row; data {run_id, trial_index, pass, until
 * (when the trial scores 0 if the key is still refused, ISO), entry_secret_ids, providers}, ids and names only. Its `at`
 * is the window's start (server/payouts/audit.ts AuditAction's `entry_secret.held`).
 */
export const ENTRY_SECRET_HELD_ACTION = 'entry_secret.held';

/**
 * The audit_event action of outputs that held a form of one of their entrant's secrets (the header's `entry secrets`;
 * record.ts SECRET_IN_OUTPUT_ACTION), the run flagged SECRET_IN_OUTPUT_FLAG beside it: the system's (actor null). Of an
 * agent/v1 pass, subject the run_trial row; data {run_id, trial_index, pass, mode (live, replay), hits: [{name, file}]},
 * one a pass and mode. Of a run graded as one execution, subject the run row; data {run_id, hits}, one a run. Each hit a
 * secret's NAME and the output's file (agent.ts SecretOutputHit, record.ts SecretHit), never a value.
 */
export { SECRET_IN_OUTPUT_ACTION };

/**
 * The hold reason of a trial whose entrant's entry secrets this grader cannot open (the header's `entry secrets`): no
 * seal private key configured here (server/secrets/seal.ts entrySecretSealRefusal), or a sealed secret it holds no
 * private key for or cannot open. The platform's fault, never the entrant's, and never sent to masq instead.
 */
export const ENTRY_SECRETS_UNOPENED_HOLD_REASON = 'entry_secrets_unopened';

/**
 * The void reason of a live pass whose replay cannot run as it did: an env-lane entry secret it ran with was erased
 * meanwhile (replaced, removed or purged: the header's `entry secrets`). The next pass runs on what the entrant holds then.
 * The same reason an L2 is refused with once a secret its run recorded is erased (regrade.ts ENTRY_SECRETS_ERASED).
 */
export const ENTRY_SECRETS_ERASED_VOID_REASON = ENTRY_SECRETS_ERASED;

/**
 * The run flag of a trial key whose spend masq had not settled when the read stopped (grader/gateway/masq.ts
 * RetiredTrialKey.settled false: the figure still moving at MASQ_SPEND_SETTLE_CAP_MS, kept as its last read gave it and
 * never compared with the forwarder's meter, so never gateway_spend_mismatch). For admins only, as the mismatch is
 * (server/routes/archive/entry.ts ADMIN_RUN_FLAGS; server/api-types/inference.ts GatewaySpendRunFlag, its type pinning
 * the spelling); it changes no score.
 */
export const GATEWAY_SPEND_UNSETTLED_FLAG: Extract<GatewaySpendRunFlag, 'gateway_spend_unsettled'> = 'gateway_spend_unsettled';

/**
 * The run flags a live pass's masq key sets once it is retired (TrialPass.masq): its cross-check's (masq.ts
 * RetiredTrialKey.flags, gateway_spend_mismatch on a settled figure the meter disagrees with), and
 * GATEWAY_SPEND_UNSETTLED_FLAG when its spend read never settled. None with no key, or a key whose retirement failed.
 */
export function masqRunFlags(masq: Pick<NonNullable<TrialPass['masq']>, 'retired' | 'flags'> | null): string[] {
  if (masq === null) return [];
  return masq.retired !== null && !masq.retired.settled ? [...masq.flags, GATEWAY_SPEND_UNSETTLED_FLAG] : [...masq.flags];
}

/**
 * The run flag of a pass on a house clock (TrialPass.house_clock: grader/house-clock.ts houseClockFlag), one a pass of
 * a trial: what the house took, its bound and the credit the entry's deadline stood at. On the run row alone, never in
 * its score (an agent/v1 score's execution flags are none), its trials manifest or any record a result_sha256 covers.
 * None for a pass on no house clock, or whose entry never ran.
 */
export function houseClockRunFlags(p: Pick<TrialPass, 'mode' | 'house_clock'>, trialIndex: number, pass: number): string[] {
  return p.house_clock === undefined ? [] : [houseClockFlag(trialIndex, pass, p.mode, p.house_clock)];
}

/** The format an agent/v1 run's dataset_sha256 digests (agentDatasetSha256). */
export const AGENT_INSTANCES_FORMAT = 'agent-fun/agent-instances/v1';

/** The trial statuses that count: done, nothing more to run (contracts/agent.ts AGENT_TRIAL_STATUSES). */
const DONE_TRIAL_STATUSES: ReadonlySet<string> = new Set(AGENT_TRIAL_STATUSES);

/**
 * An agent/v1 run's dataset_sha256 (and its phase seed's dataset part): canonicalSha256 of {format:
 * AGENT_INSTANCES_FORMAT, trials: [{index, instance_sha256}]} over the instances its trials run on, in
 * index order, so another draw (a redraw) or another phase's instances name another.
 */
export function agentDatasetSha256(trials: readonly { index: number; instance_sha256: string }[]): string {
  return canonicalSha256({ format: AGENT_INSTANCES_FORMAT, trials: trials.map((t) => ({ index: t.index, instance_sha256: t.instance_sha256 })) });
}

/** One trial a phase of an agent/v1 bundle runs (agentPhaseTrials): the draw's trial t, its instance and the directory holding it. */
export interface AgentPhaseTrial {
  index: number;
  instance_sha256: string;
  /** The instance's directory, holding input/ (input/prompt.txt, input/env/) and reference/. */
  dir: string;
}

/** The trials a phase of an agent/v1 bundle runs. */
export interface AgentPhaseTrials {
  /** practice on the dev phase, scored on the final. */
  purpose: 'practice' | 'scored';
  /** The scored draw in force (the newest record's k); null for practice. */
  k: number | null;
  trials: AgentPhaseTrial[];
}

/**
 * The trials an agent/v1 bundle's phase runs (the header's `agent/v1`): its trials sidecar (the
 * competition directory's instance.yaml, parseTrialsSidecar) checked against the bundle
 * (checkInstanceBundle, its trial counts the harness's); the dev phase one trial, on practice trial 0
 * (load.ts practiceTrialDir); any other phase (the final) every trial of the newest scored draw, the
 * whole draw chain verified (verifyInstanceDraws under kind agent/v1), in its scored-<k>/trial-<t>/
 * (scoredTrialDir). Each trial's trees digest to its record's and its directory to its
 * instance_sha256. Throws PermanentJobError: no retry draws an instance or mends one. What is not there at all (no
 * instance.yaml, no draw record yet, a tree) is an InstanceNotDrawnError: the draw mends it.
 */
export async function agentPhaseTrials(input: { slug: string; bundle: CompetitionBundleT; compDir: string; sealedDir: string; phaseKey: string; chain: InstanceChainOptions }): Promise<AgentPhaseTrials> {
  const { slug, bundle } = input;
  const h = bundle.harness;
  if (h.kind !== 'agent/v1') throw new PermanentJobError(`${slug} is not an agent/v1 competition`);
  const sidecarPath = join(input.compDir, INSTANCE_FILE);
  const practiceFix = `draw them with node scripts/competitions/instance.ts practice --competition ${slug} (it re-draws a committed ${INSTANCE_FILE}'s practice trials into a removed practice/)`;
  const bytes = readSmallFile(sidecarPath, MAX_INSTANCE_BYTES, `${slug}'s ${INSTANCE_FILE}`);
  if (bytes === null) throw sidecarNotThere(sidecarPath, `${slug} is an agent/v1 competition, and its competition directory has no ${INSTANCE_FILE} (${sidecarPath}) to say which instances its trials run on: ${practiceFix}`);
  const final = bundle.phases.find((p) => p.key === 'final');
  let sidecar: TrialsSidecarT;
  try {
    sidecar = parseTrialsSidecar(bytes, input.chain);
    if (final === undefined) throw new PermanentJobError(`${slug} is an agent/v1 competition and has no final phase to draw its scored trials for`);
    checkInstanceBundle(sidecar, { generatorSha256: h.generator_sha256, opensAt: bundle.competition.opens_at, finalStartsAt: final.starts_at, finalEndsAt: final.ends_at, trials: h.trials }, input.chain);
  } catch (err) {
    if (isInstanceError(err)) throw new PermanentJobError(`${slug}'s ${INSTANCE_FILE} does not check (${err.code}): ${err.message}`, { cause: err });
    throw err;
  }
  const { instanceSha256: agentInstanceSha256 } = await import('./agent.ts');
  const checked = (t: number, dir: string, rec: { input_sha256: string; reference_sha256: string; instance_sha256: string }, what: string, fix: string): AgentPhaseTrial => {
    checkInstanceTrees(dir, { input: rec.input_sha256, reference: rec.reference_sha256 }, what, fix);
    const digest = agentInstanceSha256(dir);
    if (digest !== rec.instance_sha256) throw new PermanentJobError(`${what} ${dir} has instance digest ${digest}, not its record's instance_sha256 ${rec.instance_sha256}: ${fix}`);
    return { index: t, instance_sha256: rec.instance_sha256, dir };
  };

  if (input.phaseKey === 'dev') {
    const practice = sidecar.practice.trials[0]!;
    return { purpose: 'practice', k: null, trials: [checked(0, practiceTrialDir(input.sealedDir, slug, 0), practice, `${slug}'s practice trial 0`, practiceFix)] };
  }

  const root = instanceRootOf(input.sealedDir, slug);
  const records = readDrawRecords(root, slug);
  if (records.length === 0) {
    throw new InstanceNotDrawnError(
      `the ${input.phaseKey} phase of ${slug} runs its trials on its drawn scored instances, and there is no draw record (${instanceDrawFile(0)}) in ${root}: the final phase is graded once the scored round (${sidecar.scored.beacon.round}, ${sidecar.scored.beacon.at}) is drawn (POST /api/admin/competitions/${slug}/instance/draw)`,
      join(root, instanceDrawFile(0)),
    );
  }
  let draw;
  try {
    draw = verifyInstanceDraws({ sidecar: bytes, records, competition: slug, kind: 'agent/v1', ...input.chain }).at(-1)!;
  } catch (err) {
    if (isInstanceError(err)) throw new PermanentJobError(`${slug}'s draw records do not verify (${err.code}): ${err.message}`, { cause: err });
    throw err;
  }
  const k = draw.k;
  const fix = `it is not the instance ${instanceDrawFile(k)} records; the final phase's trials run only on the draw as recorded`;
  return { purpose: 'scored', k, trials: draw.record.trials.map((tr) => checked(tr.t, scoredTrialDir(input.sealedDir, slug, k, tr.t), tr, `${slug}'s scored trial ${tr.t} of draw ${k}`, fix)) };
}

/** An instance directory as run_trial.instance_ref holds it: relative to the sealed directory, with / between its parts. */
function sealedRef(sealedDir: string, dir: string): string {
  const rel = relative(sealedDir, dir);
  if (rel === '' || isAbsolute(rel) || rel.split(sep).includes('..')) throw new PermanentJobError(`the instance directory ${dir} is not under the sealed directory ${sealedDir}`);
  return rel.split(sep).join('/');
}

interface AgentRunStart {
  deps: GradeWorkerDeps;
  ctx: GradeJobContext | undefined;
  sub: typeof submission.$inferSelect;
  ph: typeof phase.$inferSelect;
  comp: { id: string; slug: string };
  bundle: CompetitionBundleT;
  harness: AgentHarnessT;
  index: SnapshotIndex;
  competitionKey: string;
}

/**
 * An agent/v1 grade job (the header's `agent/v1`): the phase's trials found, the entry's runtime
 * picked (none: a failed run recorded at once, nothing run), every image the trials need present,
 * then the run's row (running) and its trial rows, each trial's job for live pass 1 and the fan-in's
 * first job. Answers null: nothing is published until the fan-in finishes the run.
 */
async function startAgentRun(s: AgentRunStart): Promise<{ run_id: string } | null> {
  const { deps, sub, ph, comp, bundle, harness } = s;
  const compDir = competitionDirOf(deps, comp.slug, harness);
  const sealedDir = deps.sealedDir ?? sealedDirFromEnv();
  const phaseTrials = await agentPhaseTrials({ slug: comp.slug, bundle, compDir, sealedDir, phaseKey: ph.key, chain: instanceChainOptions(deps.drandChain) });
  const datasetSha256 = agentDatasetSha256(phaseTrials.trials);
  const plan = agentPlan({ harness, seed: phaseSeed(s.competitionKey, ph.key, datasetSha256), datasetSha256 });
  const ids = { submissionId: sub.id, phaseId: ph.id };
  const picked = entryRuntime(s.index, plan.runtimes);
  if ('error' in picked) return { run_id: await recordGrade(deps.db, deps.blobs, refusedGrade(plan, picked.error), ids) };
  const jobs = deps.jobs;
  if (jobs === undefined) throw new Error(`${comp.slug} is an agent/v1 competition, and this grader has no job queue to send its trials on (GradeWorkerDeps.jobs)`);
  // The entry's image, the env's and the scorer's: a trial that could not start any of them would only void.
  await preflight(plan, deps.sandbox, picked.runtime, null);

  const startedAt = deps.now?.() ?? new Date();
  const runId = s.ctx === undefined ? uuidv7() : agentRunId(s.ctx.id);
  await startRun(deps.db, {
    id: runId,
    ...ids,
    imageDigest: deps.sandbox.imageDigest(picked.runtime),
    datasetSha256,
    harnessVersion: harnessVersion(),
    scorerVersion: scorerVersionOf(plan, deps.sandbox),
    seed: plan.seed,
    startedAt,
  });
  // Each trial tagged with its place in the grade-trial queue as it is made (record.ts `queue tags`).
  await insertTrials(
    deps.db,
    runId,
    phaseTrials.trials.map((t) => ({ index: t.index, instanceSha256: t.instance_sha256, instanceRef: sealedRef(sealedDir, t.dir) })),
    bundle.limits.wall_budget_sec,
  );
  // The trials as the run holds them: a retried grade job's run keeps those it was made with, their tags and their jobs' ids.
  const expireInSeconds = agentTrialExpirySeconds(bundle.limits.wall_budget_sec, comp.slug);
  for (const t of await loadTrials(deps.db, runId)) {
    const tag = t.queueTag ?? (await retagTrial(deps.db, t, bundle.limits.wall_budget_sec)).tag;
    await jobs.send(
      'grade-trial',
      { run_id: runId, trial_index: t.trialIndex, pass: 1, first_pass: 1 },
      { id: gradeTrialJobId(runId, t.trialIndex, 1), priority: gradeTrialPriority(tag), expireInSeconds },
    );
  }
  await jobs.send('grade-aggregate', { run_id: runId }, { id: gradeAggregateJobId(runId, 'start'), startAfter: new Date(startedAt.getTime() + AGENT_AGGREGATE_WAIT_MS) });
  return null;
}

/** The trial statuses an agent/v1 run replayed (regrade.ts REPLAYED): a timeout never was, so an L2 replays it not. */
const REPLAYED_TRIAL_STATUSES: ReadonlySet<string> = new Set(['finished', 'nondeterministic']);

/**
 * The env-lane entry secrets each trial of an agent/v1 run replays with on an L2 (the header's `entry secrets`): of every
 * trial the run replayed on its entrant's credential, exactly the rows its live pass recorded (run_trial.entry_secret_ids,
 * the env lane's alone: a replay runs on no provider key), retained rows included, re-opened, by trial index. `erased`
 * names the trials and rows erased since (the L2 is then refused unexecuted, regrade.ts ENTRY_SECRETS_ERASED); `forms`
 * every form of every value, what the regrade's record is masked of. One this grader cannot open holds the regrade
 * (EntrySecretsUnopenedError: the job tries again), naming rows, never a value.
 */
async function agentTrialSecrets(
  deps: GradeWorkerDeps,
  who: SecretOwner,
  rows: readonly TrialRow[],
  what: string,
): Promise<{ trialSecrets: Map<number, Record<string, string>>; erased?: string; forms: FormSet | null }> {
  const seal = entrySecretSealOf(deps);
  const trialSecrets = new Map<number, Record<string, string>>();
  const erased: string[] = [];
  const values: string[] = [];
  for (const row of rows) {
    if (row.entryCredential !== 'entrant' || !REPLAYED_TRIAL_STATUSES.has(row.status)) continue;
    const recorded = await recordedEnvSecrets(deps.db, seal, who, row.entrySecretIds);
    if (recorded.erased !== null) {
      erased.push(`trial ${row.trialIndex}: ${recorded.erased}`);
      continue;
    }
    if (recorded.kind === 'unopened') {
      const which = recorded.cause === 'off' ? ` (${recorded.names.join(', ')})` : '';
      throw new EntrySecretsUnopenedError(
        `${what}: the env-lane entry secrets trial ${row.trialIndex}'s live pass ran with${which} cannot be opened here, so it is not replayed without them (its job tries again): ${recorded.why}`,
        recorded.names,
      );
    }
    if (recorded.secrets.ids.length === 0) continue;
    trialSecrets.set(row.trialIndex, recorded.secrets.env);
    values.push(...Object.values(recorded.secrets.env));
  }
  const { secretFormSet } = await import('./gateway/upstream.ts');
  const why = erased.length === 0 ? undefined : `an env-lane entry secret its trials' live passes ran with is erased since (replaced, deleted or purged): ${erased.join('; ')}, so they cannot replay as they did; its L1 stands`;
  return { trialSecrets, ...(why === undefined ? {} : { erased: why }), forms: values.length === 0 ? null : secretFormSet(values) };
}

/**
 * An agent/v1 regrade job (the header's `regrade`): the stored grade run (a grade of this entry on this phase, its
 * seed recorded), the phase's trials as the grade found them (agentPhaseTrials: the same instances, verified, or
 * a dataset_sha256 that differs), each trial's void re-runs from its row, the cost and the authorship its score was
 * built with; then regrade.ts regradeAgentL1 (a rescore of the stored state exports) or regradeAgentL2 (a replay of
 * the stored cassettes with no upstream, then L1), recorded as a regrade run. A run that cannot be re-derived is a
 * PermanentJobError.
 */
async function regradeAgentRun(s: AgentRunStart & { job: JobPayload<'grade-dev'>; loadAuthorship: NonNullable<GradeWorkerDeps['loadAuthorship']> }): Promise<{ run_id: string }> {
  const { deps, sub, ph, comp, bundle, harness, job } = s;
  const { db, blobs } = deps;
  const stored = await loadStoredRun(db, job.reproduces_run_id!);
  if (stored === null) throw new PermanentJobError(`run ${job.reproduces_run_id} does not exist`);
  if (stored.submissionId !== sub.id || stored.phaseId !== ph.id) throw new PermanentJobError(`run ${stored.id} is not a run of submission ${sub.id} in phase ${ph.id}`);
  const [orig] = await db.select({ kind: run.kind }).from(run).where(eq(run.id, stored.id));
  if (orig?.kind !== 'grade') throw new PermanentJobError(`run ${stored.id} is a ${orig?.kind}; regrade the grade run it reproduces`);
  if (stored.seed === null) throw new PermanentJobError(`run ${stored.id} recorded no seed`);

  const compDir = competitionDirOf(deps, comp.slug, harness);
  const phaseTrials = await agentPhaseTrials({ slug: comp.slug, bundle, compDir, sealedDir: deps.sealedDir ?? sealedDirFromEnv(), phaseKey: ph.key, chain: instanceChainOptions(deps.drandChain) });
  const plan = agentPlan({ harness, seed: stored.seed, datasetSha256: agentDatasetSha256(phaseTrials.trials) });
  const dirOf = new Map(phaseTrials.trials.map((t) => [t.index, t.dir]));
  const trialRows = await loadTrials(db, stored.id);
  const trials = trialRows.flatMap((t) => {
    const dir = dirOf.get(t.trialIndex);
    return dir === undefined ? [] : [{ index: t.trialIndex, instanceDir: dir, voids: Math.max(0, t.attempt - 1) }];
  });
  const { cost, pricingRev } = await entryCostFor(deps, { sub, bundle, fresh: false, stored: stored.result });
  const version = storedAuthorshipVersion(stored.result);
  let authorship: AuthorshipSummaryT | null = null;
  if (version !== null) {
    authorship = await s.loadAuthorship(sub.id, pricingRev, version);
    if (version !== undefined && authorship?.algo_version !== version) {
      throw new PermanentJobError(`run ${stored.id} was graded with authorship algorithm ${version}, and submission ${sub.id} has no summary of it under pricing_rev ${pricingRev}`);
    }
  }
  // The job's owner, the same on each of its attempts: a retry removes what an attempt that died left (the header's `regrade`).
  const jobId = s.ctx?.id ?? uuidv7();
  const log = deps.log ?? ((line: string) => console.log(line));
  const regrading = `run ${stored.id}'s ${job.kind} regrade (job ${jobId})`;
  const req: AgentRegradeL1Request = {
    stored,
    plan,
    sandbox: deps.sandbox,
    blobs,
    limits: bundle.limits,
    workRoot: deps.workRoot,
    cost,
    authorship,
    entry: { house: standingsHouse(sub), baseline: sub.baseline },
    rules: eligibilityRulesOf(bundle),
    // The env and the scorer as the sandbox mounts them: on the k8s sandbox their stages on the data claim (the header's `k8s data`).
    setup: await agentSetupFor(deps.sandbox, comp.slug, { compDir, harness, leaderboard: bundle.leaderboard, competition: comp.slug }),
    leaderboard: bundle.leaderboard,
    trials,
    owner: regradeOwner(jobId),
    onScratchReap: (r) => {
      const line = scratchReapLine(regrading, `attempt ${(s.ctx?.retryCount ?? 0) + 1}`, r);
      if (line !== null) log(line);
    },
    // Trials' rows that make no checks trace: logged with why, as the fan-in logged them; the regrade carries none.
    onTraceIssue: (issue) => log(traceIssueLine(regrading, issue)),
  };
  const ids = { submissionId: sub.id, phaseId: ph.id };
  /** Every form of the secrets an L2's replays run with: what its record is masked of (record.ts RunSecrets.mask). */
  let mask: FormSet | null = null;
  try {
    let outcome;
    if (job.kind === 'regrade_l1') {
      outcome = await regradeAgentL1(req);
    } else {
      const picked = entryRuntime(s.index, plan.runtimes);
      if ('error' in picked) throw new PermanentJobError(picked.error);
      // Its replays make trial networks: none on an engine that does not keep trials apart (the header's `isolation`).
      const isolation = deps.isolation !== undefined ? deps.isolation : await sandboxIsolation(deps.sandbox);
      if (isolation !== null) await isolation.require();
      const gateway = await (deps.forwarder ?? (async () => (await import('./gateway/bundle.ts')).gatewayBundle({ cacheDir: join(deps.workRoot, 'gateway') })))();
      const onReap = (index: number, r: ReapResult): void => {
        const line = reapLine(`trial ${index} of run ${stored.id}`, `its replay in ${regrading}`, r);
        if (line !== null) log(line);
      };
      // The attempt's signal stops its replays once pg-boss gives the attempt up (regrade.ts's `stopping`): the reason thrown, retried.
      const stop = s.ctx?.signal === undefined ? {} : { signal: s.ctx.signal };
      // Each replayed trial's env-lane entry secrets, exactly those its live pass recorded, re-opened (the header's `entry
      // secrets`): its replay runs as live did. One erased since refuses the L2 before any trial replays; its L1 stands.
      const opened = await agentTrialSecrets(deps, { userId: sub.userId, competitionId: comp.id }, trialRows, regrading);
      if (opened.erased !== undefined) log(`[grade] ${comp.slug}: ${regrading} is refused unexecuted (${ENTRY_SECRETS_ERASED}): ${opened.erased}`);
      mask = opened.forms;
      outcome = await regradeAgentL2({
        ...req,
        ...stop,
        runtime: picked.runtime,
        snapshot: { index: s.index, blobs },
        gateway,
        onReap,
        trialSecrets: opened.trialSecrets,
        ...(opened.erased === undefined ? {} : { secretsErased: opened.erased }),
      });
    }
    // An attempt given up records nothing, however far it got (an L1, or an L2's re-score, runs to its end): its retry records once.
    s.ctx?.signal?.throwIfAborted();
    return { run_id: await recordRegrade(db, blobs, outcome, ids, [], { mask }) };
  } catch (err) {
    if (err instanceof RegradeError) throw new PermanentJobError(err.message, { cause: err });
    throw err;
  }
}

// ---------------------------------------------------------------- agent/v1: the gateway

/** masq, as agent/v1 trials reach it (openAgentGateway). */
export interface AgentGateway {
  /** The broker each live pass mints its own key at (grader/gateway/masq.ts). */
  broker: MasqBroker;
  /** masq's origin as a trial's forwarder reaches it (config.llmGatewaySandboxUrl: MAKEFUN_LLM_GATEWAY_SANDBOX_URL, else MAKEFUN_LLM_GATEWAY_URL). */
  origin: string;
  /** ms before the first retry of a failed key retirement (default grader/agent.ts MASQ_RETIRE_BACKOFF_MS). */
  retireBackoffMs?: number;
}

/** What openAgentGateway reads of the server's config. */
export type AgentGatewayConfig = Pick<Config, 'llmGateway' | 'llmGatewayUrl' | 'llmGatewayAdminKey' | 'llmGatewaySandboxUrl'>;

/**
 * The gateway agent/v1 trials run against, as the server's config names it; null when
 * MAKEFUN_LLM_GATEWAY is off (server/config.ts agentTrialsRefusal), and then no trial runs in this
 * process. The broker is opened with masq.ts openMasqBroker, which reads the admin key's pin first: an
 * admin key masq reports unpinned, or pinned wider than a /24 (MasqAdminKeyRefusal), is paged at once,
 * and so is one masq itself refuses from this host's address (its 403 source-pin refusal, the same
 * class, problem `source`: the page names the address masq saw and the `masq keys admin-sources` line
 * that adds it); a masq that cannot be asked (MasqBrokerError) is logged. Either way the broker is
 * kept: its every mint reads the pin again until a read is good (a refusal is never held), so the
 * trials run once the operator pins the key, with no restart.
 */
export async function openAgentGateway(config: AgentGatewayConfig, opts: { page?: (line: string) => void; log?: (line: string) => void } = {}): Promise<AgentGateway | null> {
  if (agentTrialsRefusal(config) !== null) return null;
  const page = opts.page ?? ((line: string) => console.error(line));
  const log = opts.log ?? ((line: string) => console.log(line));
  const { MasqAdminKeyRefusal, MasqBrokerError, masqBrokerFromConfig, openMasqBroker } = await import('./gateway/masq.ts');
  let broker: MasqBroker | null;
  try {
    broker = await openMasqBroker(config);
  } catch (err) {
    if (err instanceof MasqAdminKeyRefusal) {
      page(
        err.problem === 'source'
          ? `[grade] ALERT: agent/v1 grading cannot mint a trial key: ${err.message}. Every agent/v1 trial's mint reads the pin again and fails the same way until it admits this host: its live passes void (up to ${AGENT_SERIES_PASSES} a series) and the trial is held, so nothing of the entry is scored. Fix the pin on the masq box, and the next mint picks it up with no restart`
          : `[grade] ALERT: agent/v1 grading is stopped: ${err.message}. No trial runs until then; nothing is marked, and every trial job tries again as it retries`,
      );
    } else if (err instanceof MasqBrokerError) {
      log(`[grade] masq could not be asked for its admin key's pin as the grader started (${err.message}); every trial's mint asks again`);
    } else {
      throw err;
    }
    broker = masqBrokerFromConfig(config);
  }
  const origin = config.llmGatewaySandboxUrl ?? config.llmGatewayUrl;
  if (broker === null || origin === null) return null;
  return { broker, origin };
}

/**
 * At a grader's start, the leftovers of a grader that crashed (Sandbox.networks sweepStale: on the
 * docker driver grader/sandbox/network.ts sweepStale, grader containers and trial networks older than
 * six hours), logged; nothing on the process driver. Never throws.
 */
export async function sweepStaleSandbox(sandbox: Sandbox, log: (line: string) => void = (line) => console.log(line)): Promise<void> {
  const networks = sandbox.networks;
  if (networks === undefined) return;
  try {
    const swept = await networks.sweepStale();
    if (swept.containers.length > 0 || swept.networks.length > 0 || swept.errors.length > 0) {
      log(`[grade] stale sandbox leftovers swept: ${swept.containers.length} containers, ${swept.networks.length} trial networks${swept.errors.length === 0 ? '' : `; not swept: ${swept.errors.join('; ')}`}`);
    }
  } catch (err) {
    log(`[grade] the stale sandbox leftovers could not be swept: ${err instanceof Error ? err.message : String(err)}`);
  }
}

/** A pipeline trial's owner (grader/agent.ts RunTrialOptions.owner, the makefun.trial label of its passes' networks): `<run id>.<trial index>`. */
export function trialOwner(runId: string, trialIndex: number): string {
  if (!Number.isSafeInteger(trialIndex) || trialIndex < 0) throw new TypeError(`trial index ${trialIndex} is not a non-negative integer`);
  return `${runId.toLowerCase()}.${trialIndex}`;
}

/**
 * Where a pipeline trial's pass works under the work root (`dead grader` in the header): its scratch,
 * the snapshot and the pass's own directory, and its scorer's, `trial-<owner>-XXXXXX` (regrade.ts
 * ownedScratch), which the trial's next pass removes should its grader die (regrade.ts reapScratch).
 */
export const TRIAL_SCRATCH_PREFIX = 'trial-';

/**
 * A grader job's owner, by the job's id: `regrade-<job id>`, the same on every attempt of the job and
 * no other job's, so its retry removes what an attempt that died left, and never a grade's trial
 * (`<run id>.<trial index>`) or another job's. An agent/v1 regrade's (regrade.ts
 * AgentRegradeL1Request.owner): its scratch, and each replay's containers and network, which run
 * under `regrade-<job id>.<trial index>`. Any other grade or regrade job's (grade.ts
 * GradeRequest.owner, regrade.ts RegradeL1Request.owner: the header's `scratch`): its executions' and
 * scorer's scratch. A hindsight audit job's: its audit's scratch (HINDSIGHT_SCRATCH_PREFIX). A job id
 * that is no part of a label value (pg-boss's are uuids) goes in as the first 32 hex digits of its
 * sha256.
 */
export function regradeOwner(jobId: string): string {
  const id = jobId.toLowerCase();
  return `regrade-${/^[a-z0-9][a-z0-9-]{0,63}$/.test(id) ? id : createHash('sha256').update(jobId, 'utf8').digest('hex').slice(0, 32)}`;
}

/**
 * The log line naming the scratch a reap of `what` removed before `before` (and what it could not); null when it found
 * nothing. `tag` opens it (default `grade`; a hindsight audit's `hindsight`).
 */
export function scratchReapLine(what: string, before: string, r: ScratchReap, tag = 'grade'): string | null {
  if (r.dirs.length === 0 && r.errors.length === 0) return null;
  return (
    `[${tag}] ${what}: before ${before}, removed the scratch a dead grader left of it (owner ${r.owner}): ` +
    `${r.dirs.length === 0 ? 'none' : r.dirs.join(', ')}${r.errors.length === 0 ? '' : `; not removed: ${r.errors.join('; ')}`}`
  );
}

/** The log line naming what a reap of `what` removed before `before` (and what it could not); null when it found nothing. */
export function reapLine(what: string, before: string, r: ReapResult): string | null {
  if (r.containers.length === 0 && r.networks.length === 0 && r.errors.length === 0) return null;
  const named = (xs: readonly string[]): string => (xs.length === 0 ? 'none' : xs.join(', '));
  return (
    `[grade] ${what}: before ${before}, removed what a dead grader left of it (makefun.trial=${r.owner}): ` +
    `containers ${named(r.containers)}; networks ${named(r.networks)}${r.errors.length === 0 ? '' : `; not removed: ${r.errors.join('; ')}`}`
  );
}

/**
 * What a dead grader left of trial `owner`, removed (Sandbox.networks reap: on the docker driver
 * grader/sandbox/network.ts reapTrial, the networks labelled with the owner and the containers on
 * each); null on the process driver, which makes no network. Never throws for what it could not
 * remove: the result says.
 */
export async function sandboxReap(sandbox: Sandbox, owner: string): Promise<ReapResult | null> {
  const networks = sandbox.networks;
  if (networks === undefined) return null;
  return networks.reap(owner);
}

/**
 * The isolation check of a sandbox's engine (the header's `isolation`): an IsolationCheck of its
 * Sandbox.networks isolation (grader/sandbox/network.ts isolationCheck, loaded here on first use),
 * on the docker driver this process's one EngineIsolation of its CLI, runtime and node22 image; null
 * on the process driver, which makes no network.
 */
export async function sandboxIsolation(sandbox: Sandbox): Promise<IsolationCheck | null> {
  const networks = sandbox.networks;
  if (networks === undefined) return null;
  const { isolationCheck } = await import('./sandbox/network.ts');
  return isolationCheck(networks);
}

// ---------------------------------------------------------------- agent/v1: house spend by lane

/**
 * A model lane a trial's spend is metered on apart (the header's `house lane`): the entry's calls, on harness.inference,
 * or with a target the env's calls to it, on harness.target. No contest-level limit weighs either (the header's `spend`).
 */
export type SpendLane = 'entry' | 'house';

/**
 * A lane's house spend summed over run_trial rows: its counted meter and every voided pass's (server/db/schema.ts runTrial's
 * SPEND). On the entry lane only the house's: a row whose entry lane ran on the entrant's own keys (entry_credential
 * entrant) spent the entrant's money, never the house's (the header's `entry lane`), so it is never counted as house
 * spend (server/routes/admin/inference.ts sums the competition's spend the same way).
 */
export function laneSpentSql(lane: SpendLane) {
  return lane === 'house'
    ? sql<string>`coalesce(sum(coalesce(${runTrial.houseSpendMicroUsd}, 0) + ${runTrial.voidedHouseSpendMicroUsd}), 0)::text`
    : sql<string>`coalesce(sum(case when ${runTrial.entryCredential} = 'house' then coalesce(${runTrial.spendMicroUsd}, 0) + ${runTrial.voidedSpendMicroUsd} else 0 end), 0)::text`;
}

/**
 * housePaysEntryLane over the submission table, for a query joined to it: a house entry, one a house account
 * submitted, or a baseline (standingsHouse || baseline is exactly house || submitted_as_house || baseline).
 */
export function housePaidSql() {
  return or(eq(submission.house, true), eq(submission.submittedAsHouse, true), eq(submission.baseline, true));
}

/** The UTC day of `at`: its date, its start and the next day's start. */
function utcDayOf(at: Date): { day: string; dayStart: Date; nextDay: Date } {
  const dayStart = new Date(Date.UTC(at.getUTCFullYear(), at.getUTCMonth(), at.getUTCDate()));
  return { day: dayStart.toISOString().slice(0, 10), dayStart, nextDay: new Date(dayStart.getTime() + 86_400_000) };
}

// ---------------------------------------------------------------- agent/v1: one trial

export interface AgentTrialDeps {
  db: Db;
  blobs: BlobStore;
  sandbox: Sandbox;
  /**
   * Existing directory for each pass's scratch (the snapshot, the pass's own directory, the scorer's:
   * `trial-<owner>-XXXXXX`, TRIAL_SCRATCH_PREFIX) and the forwarder's cache. A pass removes what a dead
   * grader's pass of its trial left here (the header's `dead grader`), so a grader that restarts on
   * the same work root leaves nothing of the trials it resumes.
   */
  workRoot: string;
  /** Where a void's re-run, a refused mint's later try and the fan-in's wake-ups are sent. */
  jobs: Pick<JobQueue, 'send'>;
  gateway: AgentGateway;
  /** The gateway forwarder (default grader/gateway/bundle.ts gatewayBundle, cached under <workRoot>/gateway). */
  forwarder?: () => Promise<Pick<GatewayBundle, 'dir' | 'script'>>;
  /** A competition's directory (default competitions/<slug>): its env and scorer. */
  competitionDir?(slug: string): string;
  /** MAKEFUN_SEALED_DIR: what each trial's instance_ref is relative to (default as GradeWorkerDeps.sealedDir). */
  sealedDir?: string;
  /** Where a held trial, a refused admin key and a refused engine are paged (default console.error). */
  page?: (line: string) => void;
  log?: (line: string) => void;
  now?: () => Date;
  /** The engine check every live pass and replay passes first (the header's `isolation`; default sandboxIsolation(sandbox), null: none). */
  isolation?: IsolationCheck | null;
  /** The host's scrape lease, which a trial runs nothing beside (the header's `scrape heat`; default scrapeLeaseDirFromEnv(), as GradeWorkerDeps.scrape's). */
  scrape?: Pick<ScrapeWorkerDeps, 'leaseDir'>;
  /** How an entrant's pass opens its entrant's entry secrets and checks its provider keys (the header's `entry secrets`). */
  entrySecrets?: AgentEntrySecretDeps;
  /**
   * The free pod slots on the sandbox's node(s), every namespace's pods counted, or null when unknown (the header's `node
   * room`; default a K8sSandbox's nodePodRoom, none on any other driver).
   */
  podRoom?: () => Promise<number | null>;
}

/** The seal settings entry secrets open with (server/secrets/seal.ts entrySecretSealSettings). */
export type EntrySecretSealSettings = ReturnType<typeof entrySecretSealSettings>;

/** AgentTrialDeps.entrySecrets. */
export interface AgentEntrySecretDeps {
  /**
   * The grader's seal settings, whose private keys open an entrant's secrets (server/secrets/store.ts
   * openEntrySecretRows) and whose public key, or none, says whether an entrant can push one here at all
   * (EntrantKeys.entrySecrets: the no-key 401's words). Default: the environment's (entrySecretSealSettings of
   * loadConfig()), read when an entrant's pass first sets out.
   */
  seal?: EntrySecretSealSettings;
  /**
   * Each provider's origin and the certificates to trust instead of Node's, for both the pre-flight key check and the
   * forwarder's entrant lane (agent.ts EntrantKeys origins and ca): a test's fake provider. Default: each provider's own
   * origin (gateway/providers.ts PROVIDER_ORIGINS), verified against Node's certificates.
   */
  providers?: { origins?: Partial<Record<SecretProvider, string>>; ca?: string };
  /** The pre-flight's budget per key (default gateway/providers.ts KEY_CHECK_TIMEOUT_MS). */
  checkTimeoutMs?: number;
}

/** A grade-trial job's context as its handler reads it (JobQueue.work's): its id, the attempt's signal, its attempt and retry limit (isLastAttempt), and the priority it was sent at (queueTurn). */
export type AgentTrialContext = Pick<JobContext, 'id' | 'signal'> & Partial<Pick<JobContext, 'retryCount' | 'retryLimit' | 'priority'>>;

/** What one grade-trial job did (tests read it). */
export type AgentTrialOutcome =
  | { kind: 'done'; status: AgentTrialStatusT }
  | { kind: 'void'; reason: string; next: { pass: number; job_id: string | null; start_after: Date } }
  | { kind: 'held'; reason: string }
  | { kind: 'stopped'; why: string }
  /**
   * A pass on the entrant's own keys that did not start, waiting on one (the header's `entry secrets`): `refused` a key
   * its provider refused on the final, the run flagged ENTRY_SECRET_HELD_FLAG, `deadline` when the trial scores 0 if it
   * is still refused; `unreachable` a provider that gave no verdict, never the entrant's fault (`deadline` null). Its job
   * sent again for the next AGENT_PROVIDER_KEY_RECHECK_MS slot (`until`), or nothing sent once the competition is
   * resolved (`until` and `job_id` null). `reason`: the providers' words, redacted of every secret.
   */
  | { kind: 'key_wait'; why: 'refused' | 'unreachable'; until: Date | null; job_id: string | null; deadline: Date | null; reason: string }
  /**
   * A scrape heat held the host (scrapeHostHeldBy, `held_by` its words), or the node had no room for the trial's pods
   * (`held_by` saying so): nothing run, or what ran undone and counted as no pass, the job sent again for the next
   * recheck slot (the header's `scrape heat` and `node room`).
   */
  | { kind: 'waiting'; until: Date; job_id: string | null; held_by: string }
  /**
   * A pass that woke with no place in the queue (record.ts `queue tags`), sent ahead of the place it took (`tag`): its job
   * sent again at that place's priority, nothing run.
   */
  | { kind: 'queued'; tag: number; job_id: string | null };

/** A trial another attempt claimed while this one was minting its key: this one runs nothing. */
class TrialTaken extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'TrialTaken';
  }
}

/**
 * A final pass whose entrant removed or replaced an env-lane entry secret it opened before it claimed the trial, its
 * sealed copy erased (erasedSinceOpened; the header's `entry secrets`): nothing claimed, and the pass sets out again
 * with the secrets as they stand, so no final trial records a row its challenge re-run cannot open.
 */
class PassSecretsErased extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'PassSecretsErased';
  }
}

/** A fault after the live pass is recorded (its replay voided): retried, then held under `reason`, never a live re-run. */
class TrialHarnessFault extends Error {
  readonly reason: string;
  constructor(reason: string, message: string) {
    super(message);
    this.name = 'TrialHarnessFault';
    this.reason = reason;
  }
}

/**
 * A broker whose mint, once it has a key, claims the trial for the pass (claim) before the pass goes on, the entry's
 * key claiming and a target's house key (spec.role house, minted after it) recorded beside it (house; on an entrant's
 * pass, which mints no entry key, the house key's callback claims instead: the header's `entry lane`); the key is
 * disabled when either fails.
 */
function claimingBroker(broker: MasqBroker, claim: (minted: MintedTrialKey) => Promise<void>, house: (minted: MintedTrialKey) => Promise<void>): MasqBroker {
  return {
    origin: broker.origin,
    verifyAdminKey: (opts) => broker.verifyAdminKey(opts),
    async mint(spec, opts) {
      const minted = await broker.mint(spec, opts);
      try {
        await (spec.role === 'house' ? house(minted) : claim(minted));
      } catch (err) {
        await broker.disable(minted.id).catch(() => undefined);
        throw err;
      }
      return minted;
    },
    disable: (id, opts) => broker.disable(id, opts),
    spend: (id, opts) => broker.spend(id, opts),
  };
}

/** A blob's bytes as JSON, or an Error naming it (the store must hold what a trial row names). */
async function blobJson(blobs: BlobStore, sha256: string, what: string): Promise<unknown> {
  const bytes = await blobs.get(sha256, { verify: true });
  if (bytes === null) throw new Error(`the blob store holds no ${what} ${sha256}`);
  return JSON.parse(Buffer.from(bytes).toString('utf8')) as unknown;
}

/** A trial row's live pass is recorded and whole (what its replay and scoring read). */
function liveRecorded(row: TrialRow): boolean {
  return row.cassetteSha256 !== null && row.envLogSha256 !== null && row.stateSha256 !== null && row.outputsSha256 !== null && row.liveFinishedAt !== null;
}

/**
 * A claim of `row` for live pass `pass` undone (the header's `node room`): every field the claim set (passStart's, the
 * status, the lanes' keys and credential, a target's house key recorded after it) back as `row` had it, so the trial
 * stands as the pass found it and its next pass is the same `pass`.
 */
function unclaimed(row: TrialRow, pass: number, at: Date): TrialUpdate {
  const started = Object.keys(passStart(row, pass, at)) as (keyof TrialUpdate & keyof TrialRow)[];
  return {
    ...(Object.fromEntries(started.map((k) => [k, row[k]])) as TrialUpdate),
    status: row.status,
    masqKeyId: row.masqKeyId,
    houseMasqKeyId: row.houseMasqKeyId,
    entryCredential: row.entryCredential,
    entrySecretIds: row.entrySecretIds,
  };
}

/**
 * A live pass's start from `row` (a trial pending, or void): pass `pass` begins, and the void it
 * re-runs is cleared, its spend counted as voided spend (server/db/schema.ts runTrial).
 */
function passStart(row: TrialRow, pass: number, at: Date): TrialUpdate {
  return {
    attempt: pass,
    liveStartedAt: at,
    liveFinishedAt: null,
    replayStartedAt: null,
    replayFinishedAt: null,
    cassetteSha256: null,
    envLogSha256: null,
    stateSha256: null,
    outputsSha256: null,
    promptSha256: null,
    baselinePrompt: null,
    score: null,
    scoreSha256: null,
    checks: null,
    checksIssue: null,
    requests: null,
    spendMicroUsd: null,
    upstreamErrors: null,
    wallMs: null,
    voidedSpendMicroUsd: row.voidedSpendMicroUsd + (row.spendMicroUsd ?? 0n),
    houseCassetteSha256: null,
    houseSpendMicroUsd: null,
    voidedHouseSpendMicroUsd: row.voidedHouseSpendMicroUsd + (row.houseSpendMicroUsd ?? 0n),
  };
}

/**
 * What a live pass recorded, as a trial row holds it: the brief it copied among it (the header's `brief`), none when it
 * copied none, and with a target the house lane's cassette with its spend (houseSpend, that cassette's totals: houseSpendOf).
 */
function passRecord(p: TrialPass, at: Date, houseSpend: bigint | null): TrialUpdate {
  return {
    liveFinishedAt: at,
    wallMs: p.entry?.wall_ms ?? null,
    cassetteSha256: p.cassette_sha256,
    envLogSha256: p.env_log_sha256,
    stateSha256: p.state_sha256,
    outputsSha256: p.outputs_sha256,
    promptSha256: p.prompt_sha256,
    baselinePrompt: p.prompt_sha256 === null ? null : p.baseline_prompt,
    requests: p.totals?.requests ?? null,
    spendMicroUsd: p.totals === null ? null : BigInt(p.totals.micro_usd),
    upstreamErrors: p.totals?.upstream_errors ?? null,
    ...(p.masq === null ? {} : { masqKeyId: p.masq.key_id }),
    houseCassetteSha256: p.house_cassette_sha256,
    houseSpendMicroUsd: p.house_cassette_sha256 === null ? null : houseSpend,
    ...(p.house_masq === null ? {} : { houseMasqKeyId: p.house_masq.key_id }),
  };
}

/**
 * A pass's ending as the trial row records it (the header's `cut off`): live_done or timeout from a live pass,
 * finished or nondeterministic from a replay, with that ending's own reason and nothing older. A row keeps the void
 * reason and error of the void it re-runs while its next pass runs (liveCutOffRun reads them), a re-queued one its
 * hold's, and a replay claimed again the words of the replay cut off before it (replayCutOffRun): once a pass ends
 * otherwise they told of an attempt that no longer stands, so the void reason goes and the error holds only a
 * nondeterministic replay's fault (none for any other ending).
 */
export function trialEnding(status: 'live_done' | 'timeout' | 'finished'): TrialUpdate;
export function trialEnding(status: 'nondeterministic', error: string): TrialUpdate;
export function trialEnding(status: 'live_done' | 'timeout' | 'finished' | 'nondeterministic', error?: string): TrialUpdate {
  return { status, voidReason: null, error: status === 'nondeterministic' ? error! : null };
}

/** What a pass's calls to the target cost the house: its house cassette's totals (null with no house cassette). */
async function houseSpendOf(blobs: BlobStore, p: TrialPass): Promise<bigint | null> {
  if (p.house_cassette_sha256 === null) return null;
  const { readCassette } = await import('./gateway/cassette.ts');
  return BigInt((await readCassette(blobs, p.house_cassette_sha256)).totals.micro_usd);
}

/** A held trial's row: its void's record moved out (spend counted as voided), so it holds a live pass only when that pass is whole and its replay is what is left. */
function voidHeld(row: TrialRow): TrialUpdate {
  return {
    cassetteSha256: null,
    envLogSha256: null,
    stateSha256: null,
    outputsSha256: null,
    promptSha256: null,
    baselinePrompt: null,
    score: null,
    scoreSha256: null,
    checks: null,
    checksIssue: null,
    requests: null,
    spendMicroUsd: null,
    upstreamErrors: null,
    voidedSpendMicroUsd: row.voidedSpendMicroUsd + (row.spendMicroUsd ?? 0n),
    houseCassetteSha256: null,
    houseSpendMicroUsd: null,
    voidedHouseSpendMicroUsd: row.voidedHouseSpendMicroUsd + (row.houseSpendMicroUsd ?? 0n),
  };
}

/** What a trial job knows of the run it belongs to. */
/**
 * Whether the house pays an entry's own model calls (the header's `entry lane`): a house entry (submission.house), an
 * entry a house account submitted (submitted_as_house) or a baseline (the house's reference, whoever entered
 * it). Its live pass then runs on a masq key of its own. Any other entry is an entrant's, whose model calls house money
 * never pays: its live pass runs its entry lane on the entrant's own keys, model-free while none is pushed. The house
 * here is standingsHouse's (server/payouts/standings.ts), baselines added: a baseline no house account entered is
 * placed as no house entry, and the house still runs it. The house's entries run with no entry secret of any lane.
 */
export function housePaysEntryLane(sub: HouseFacts): boolean {
  return standingsHouse(sub) || sub.baseline;
}

/**
 * The entrant's own keys an entry's live passes start from (the header's `entry lane`), or null for an entry the house
 * pays (housePaysEntryLane): none, which is what a pass runs on while its entrant has no provider key pushed (model-free,
 * each call answered 401 by the forwarder). The keys a pass runs on are read from the entrant's secrets as the pass sets
 * out (the header's `entry secrets`: the handler's entrantLane), never from the entry.
 */
export function entrantKeysOf(sub: HouseFacts): EntrantKeys | null {
  return housePaysEntryLane(sub) ? null : { keys: {}, mask: [] };
}

/**
 * An entrant's entry whose passes ran on no provider key (entrantKeysOf): each model call of theirs was answered 401 by
 * the gateway. Given the run's trials, only when none of their latest passes ran with a provider-lane entry secret: none
 * of their entry_secret_ids among `providerSecretIds` (the provider-lane rows of those ids; an env-lane secret pays for
 * no model call). A run of it refused for calling no model then says which key is missing.
 */
export function keylessEntry(sub: HouseFacts, trials: readonly Pick<TrialRow, 'entrySecretIds'>[] = [], providerSecretIds: ReadonlySet<string> = new Set()): boolean {
  const own = entrantKeysOf(sub);
  return own !== null && Object.values(own.keys).every((k) => k === undefined) && trials.every((t) => (t.entrySecretIds ?? []).every((id) => !providerSecretIds.has(id)));
}

/** Of `ids` (entry_secret rows), those on the provider lane: what keylessEntry weighs a run's trials by. */
async function providerSecretIdsOf(db: Pick<Db, 'select'>, ids: readonly string[]): Promise<Set<string>> {
  const wanted = [...new Set(ids)];
  if (wanted.length === 0) return new Set();
  const rows = await db
    .select({ id: entrySecret.id })
    .from(entrySecret)
    .where(and(inArray(entrySecret.id, wanted), eq(entrySecret.lane, 'provider')));
  return new Set(rows.map((r) => r.id));
}

/** A provider key a pass opened (the header's `entry secrets`): its row's id, NAME, provider and hint, and the key, which is never stored, logged or thrown. */
interface OpenedProviderKey {
  id: string;
  name: string;
  provider: SecretProvider;
  hint: string;
  key: string;
}

/** A key's provider's verdict on it (gateway/providers.ts KeyCheck), its words redacted of every secret of the pass. */
interface ProviderKeyVerdict {
  id: string;
  name: string;
  provider: SecretProvider;
  hint: string;
  check: KeyCheck;
}

/**
 * The entry secrets a pass runs with (the header's `entry secrets`), opened: `ids` every row it runs with, both lanes
 * (run_trial.entry_secret_ids), `env` the env lane's NAME to value (the entry's SandboxSpec.secrets), `forms` every form
 * of every value the pass holds (both lanes, and the ids the key check learned) for what it says and stores, and
 * `byName` each value by NAME, for the scan of its outputs. No value is stored, logged or thrown.
 */
interface PassSecrets {
  ids: string[];
  env: Record<string, string>;
  forms: FormSet;
  byName: Record<string, string>;
}

/**
 * Whose keys a live pass's entry lane runs on (the header's `entry lane`): the house's on masq, with no entry secret, or
 * the entrant's own (`own` what the forwarder is given, `secrets` the entry secrets the pass runs with).
 */
type EntryLane = { credential: 'house' } | { credential: 'entrant'; own: EntrantKeys; secrets: PassSecrets };

/**
 * What the trial row records of a pass's entry lane as it claims it (server/db/schema.ts runTrial's CREDENTIAL): the
 * credential, and the entry_secret rows an entrant's pass runs with (a list, empty with none pushed, as the table's
 * run_trial_entry_secrets_entrant check holds entry_credential to it; null on the house's).
 */
function laneCredential(lane: EntryLane): Pick<TrialUpdate, 'entryCredential' | 'entrySecretIds'> {
  return lane.credential === 'house' ? { entryCredential: 'house', entrySecretIds: null } : { entryCredential: 'entrant', entrySecretIds: lane.secrets.ids };
}

/**
 * What an entrant's pass found as it set out (the handler's entrantLane; the header's `entry secrets`): `run` on these
 * keys and secrets (none pushed: none, model-free), or why not now: `unopened` this grader cannot open them (`error`
 * naming no value), `refused` a provider refused a key, `unreachable` a provider gave no verdict on one (`verdicts`
 * those keys', their words redacted of every secret; `ids` every row the pass would run with; `forms` every secret's
 * forms, to redact what is said of them).
 */
type EntrantLaneVerdict =
  | { kind: 'run'; lane: Extract<EntryLane, { credential: 'entrant' }> }
  | { kind: 'unopened'; ids: string[]; error: string }
  | { kind: 'refused'; ids: string[]; verdicts: ProviderKeyVerdict[]; forms: FormSet }
  | { kind: 'unreachable'; ids: string[]; verdicts: ProviderKeyVerdict[]; forms: FormSet };

/** A verdict on a key in a message: the provider's words (already redacted), and which secret it was (its NAME and hint, never the key). */
function keyVerdictWords(v: ProviderKeyVerdict): string {
  const name = SECRET_PROVIDER_NAME[v.provider];
  const said = v.check.state === 'valid' ? `${name} accepted the key` : v.check.reason;
  return `${said} (its entry secret ${v.name}, ${v.hint})`;
}

/** What pushes a working key in place of each refused one, in a message: its NAME in a .env, and the command. */
function keyFixWords(slug: string, verdicts: readonly ProviderKeyVerdict[]): string {
  const names = [...new Set(verdicts.map((v) => v.name))];
  return `${names.map((n) => `${n}=<a working key>`).join(' and ')} in a .env, pushed with \`makefun secrets push ${slug} --env-file .env\``;
}

/** What a refused key's trial exports (keyRefusedRecord): an empty store state, canonical JSON with its newline, as an env's export ends. */
const KEY_REFUSED_STATE = '{}\n';

/**
 * The record of a trial that scores 0 for a key its provider refused (the header's `entry secrets`), nothing run: a cassette
 * with no entry (with a target, the house lane's the same), an empty env log and an export of an empty state.json, each
 * stored as a pass stores them, so the fan-in, the trials manifest and a regrade read the trial as any timeout's: its
 * points 0 on every column, its export never scored, never replayed. Nothing was spent: its meter is 0.
 */
async function keyRefusedRecord(blobs: BlobStore, row: Pick<TrialRow, 'trialIndex' | 'instanceSha256'>, target: boolean): Promise<TrialUpdate> {
  const [{ CassetteWriter }, { pricingRev }] = await Promise.all([import('./gateway/cassette.ts'), import('../pricing/price.ts')]);
  const trial = { index: row.trialIndex, instance_sha256: row.instanceSha256 };
  const cassette = await new CassetteWriter({ trial, pricing_rev: pricingRev, blobs }).finish();
  const house = target ? await new CassetteWriter({ trial, pricing_rev: pricingRev, blobs }).finish() : null;
  const state = await blobs.put(KEY_REFUSED_STATE);
  const envLog = await blobs.put(new Uint8Array(0));
  const outputs: TrialOutputsT = { format: TRIAL_OUTPUTS_FORMAT, files: [{ path: 'state.json', size: state.size, sha256: state.sha256 }] };
  const manifest = await blobs.put(canonicalJson(outputs));
  return {
    cassetteSha256: cassette.sha256,
    envLogSha256: envLog.sha256,
    stateSha256: state.sha256,
    outputsSha256: manifest.sha256,
    requests: 0,
    spendMicroUsd: 0n,
    upstreamErrors: 0,
    wallMs: null,
    houseCassetteSha256: house?.sha256 ?? null,
    houseSpendMicroUsd: house === null ? null : 0n,
  };
}

/**
 * `text` with every form of the pass's secrets redacted (gateway/upstream.ts redactForms, with the keys' echoed runs:
 * gateway/providers.ts redactKeys, loaded by then); as it is when there are none.
 */
type Redact = (text: string) => string;

/** The identity Redact: a pass that holds no secret. */
const NO_REDACT: Redact = (text) => text;

/** `err` with its message and stack redacted (`redact`), so what is thrown on carries no secret: the same object when nothing changed. */
function redactedError(err: unknown, redact: Redact): unknown {
  if (!(err instanceof Error)) return typeof err === 'string' ? redact(err) : err;
  const message = redact(err.message);
  const stack = err.stack === undefined ? undefined : redact(err.stack);
  if (message === err.message && stack === err.stack) return err;
  try {
    err.message = message;
    if (stack !== undefined) err.stack = stack;
    return err;
  } catch {
    // A frozen error: a plain one in its place, its words redacted.
    return new Error(message);
  }
}

/** A Redact over `forms` (every form of the pass's secrets) and `keys` (the provider keys, whose echoed runs go too); NO_REDACT with neither. */
async function redactorOf(forms: FormSet | null, keys: readonly string[] = []): Promise<Redact> {
  if (forms === null && keys.length === 0) return NO_REDACT;
  const [{ redactForms }, { redactKeys }] = await Promise.all([import('./gateway/upstream.ts'), import('./gateway/providers.ts')]);
  const held = keys.filter((k) => k !== '');
  return (text) => {
    const k = held.length === 0 ? text : redactKeys(text, held);
    return forms === null ? k : redactForms(k, forms);
  };
}

interface TrialRunContext {
  run: RunRow;
  sub: typeof submission.$inferSelect;
  ph: typeof phase.$inferSelect;
  slug: string;
  /** The competition's status as the job read it: a resolved one sends no pass waiting on its entrant's provider key again (the header's `entry secrets`). */
  competitionStatus: (typeof competition.$inferSelect)['status'];
  bundle: CompetitionBundleT;
  harness: AgentHarnessT;
  setup: AgentSetup;
  index: SnapshotIndex;
  runtime: Runtime;
}

/**
 * The grade-trial job handler (the header's `agent/v1`): it moves one trial on from where its row
 * stands, as far as this job's pass reaches, and answers what it did. Run by JobQueue.work, it is
 * handed the attempt's signal, which runTrial stops every program of the pass on.
 */
export function createAgentTrialHandler(deps: AgentTrialDeps): (data: JobPayload<'grade-trial'>, ctx: AgentTrialContext) => Promise<AgentTrialOutcome> {
  const { db, blobs, sandbox } = deps;
  const now = deps.now ?? (() => new Date());
  const page = deps.page ?? ((line: string) => console.error(line));
  const log = deps.log ?? ((line: string) => console.log(line));
  const sealedDir = deps.sealedDir ?? sealedDirFromEnv();
  let forwarder: Promise<Pick<GatewayBundle, 'dir' | 'script'>> | null = null;
  const forwarderOf = (): Promise<Pick<GatewayBundle, 'dir' | 'script'>> => {
    if (forwarder === null) {
      const building = (deps.forwarder ?? (async () => (await import('./gateway/bundle.ts')).gatewayBundle({ cacheDir: join(deps.workRoot, 'gateway') })))();
      forwarder = building;
      building.catch(() => {
        if (forwarder === building) forwarder = null;
      });
    }
    return forwarder;
  };
  /** When each refusal message was last paged (AGENT_REFUSAL_PAGE_MS). */
  const refusalsPaged = new Map<string, number>();
  /** What the isolation lines call this sandbox's engine (its driver's). */
  const engineName = ISOLATION_ENGINES[isolationDriverOf(sandbox)];
  /** When each set of providers no entrant's key could be checked with was last paged (AGENT_REFUSAL_PAGE_MS). */
  const unreachablePaged = new Map<string, number>();
  /** The seal settings an entrant's secrets open with (AgentEntrySecretDeps.seal, else the environment's), read when an entrant's pass first sets out. */
  let sealSettings: EntrySecretSealSettings | null = null;
  const sealOf = async (): Promise<EntrySecretSealSettings> => {
    if (sealSettings === null) {
      const own = deps.entrySecrets?.seal;
      sealSettings = own ?? (await import('../server/secrets/seal.ts')).entrySecretSealSettings(loadConfig());
    }
    return sealSettings;
  };

  /** The engine check (the header's `isolation`): the deps', else this process's probe of a docker sandbox's engine; null on the process driver. */
  let isolationOf: Promise<IsolationCheck | null> | null = null;
  const isolation = (): Promise<IsolationCheck | null> => (isolationOf ??= deps.isolation !== undefined ? Promise.resolve(deps.isolation) : sandboxIsolation(sandbox));
  /** Before a pass mints, claims or makes a network: an IsolationRefusal on an engine that does not keep trials apart. */
  const requireIsolation = async (): Promise<void> => {
    const check = await isolation();
    if (check !== null) await check.require();
  };

  // As the grader starts: the engine probed in the background (the first pass waits on that same probe), a refusal paged at once.
  void (async () => {
    const check = await isolation();
    if (check === null) return;
    let v: IsolationVerdict;
    try {
      v = await check.verdict();
    } catch (err) {
      log(`[grade] this ${engineName}'s trial isolation could not be probed as the grader started (${err instanceof Error ? err.message : String(err)}); every live pass and replay probes it again first`);
      return;
    }
    if (v.enforced) {
      log(`[grade] trial isolation holds on this ${engineName} (${v.engine}): ${v.detail}`);
      return;
    }
    const refusal = new (await import('./sandbox/network.ts')).IsolationRefusal(v);
    refusalsPaged.set(refusal.message, now().getTime());
    page(`[grade] ALERT: agent/v1 grading is stopped: ${refusal.message}. No trial runs in this process until then: nothing is marked, and each trial job tries again as it retries.`);
  })().catch((err: unknown) => console.error('[grade] the isolation probe at the grader\'s start could not report:', err));

  const trialRow = async (data: JobPayload<'grade-trial'>): Promise<TrialRow | null> => {
    const [row] = await db
      .select()
      .from(runTrial)
      .where(and(eq(runTrial.runId, data.run_id), eq(runTrial.trialIndex, data.trial_index)));
    return row ?? null;
  };

  /** The run's facts, or why there is nothing to run (the run is over, or its entry is out). */
  const runContext = async (data: JobPayload<'grade-trial'>): Promise<TrialRunContext | { stopped: string }> => {
    const [r] = await db.select().from(run).where(eq(run.id, data.run_id));
    if (r === undefined) return { stopped: `run ${data.run_id} does not exist` };
    if (r.status !== 'running') return { stopped: `run ${r.id} is ${r.status}: its trials run no more` };
    const sub = await one(db.select().from(submission).where(eq(submission.id, r.submissionId)), `submission ${r.submissionId}`);
    if (sub.status === 'cancelled') return { stopped: `submission ${sub.id} was cancelled: its trials run no more` };
    // A refusal that stands (server/pipeline/publish.ts isRefused): a duplicate snapshot, a committed secret, or an admin's security-audit refusal.
    const refusal = await import('../server/pipeline/publish.ts');
    if (refusal.isRefused(sub)) {
      const why = refusal.isRefusedDuplicate(sub) ? 'refused as a duplicate snapshot' : 'refused for a secret committed in its code';
      return { stopped: `submission ${sub.id} was ${why}: its trials run no more` };
    }
    const ph = await one(db.select().from(phase).where(eq(phase.id, r.phaseId)), `phase ${r.phaseId}`);
    const comp = await one(db.select().from(competition).where(eq(competition.id, ph.competitionId)), `competition ${ph.competitionId}`);
    const parsed = comp.bundle === null ? null : CompetitionBundle.safeParse(comp.bundle);
    if (parsed === null || !parsed.success) throw new PermanentJobError(`competition ${comp.slug} has no bundle that validates`);
    const bundle = parsed.data;
    if (bundle.harness.kind !== 'agent/v1') throw new PermanentJobError(`${comp.slug} is a ${bundle.harness.kind} competition: it runs no agent/v1 trial`);
    if (sub.snapshotSha256 === null) throw new PermanentJobError(`submission ${sub.id} has no snapshot`);
    const index = await readSnapshotIndex(blobs, sub.snapshotSha256);
    const picked = entryRuntime(index, bundle.harness.runtimes);
    if ('error' in picked) throw new PermanentJobError(`submission ${sub.id}: ${picked.error}`);
    const compDir = competitionDirOf(deps, comp.slug, bundle.harness);
    return {
      run: r,
      sub,
      ph,
      slug: comp.slug,
      competitionStatus: comp.status,
      bundle,
      harness: bundle.harness,
      // Its slug keys its house clock (grader/house-clock.ts): a competition with a row there has its passes' walls moved by it.
      setup: { compDir, harness: bundle.harness, leaderboard: bundle.leaderboard, competition: comp.slug },
      index,
      runtime: picked.runtime,
    };
  };

  const instanceDirOf = (row: TrialRow): string => join(sealedDir, ...row.instanceRef.split('/'));
  const trialRef = (row: TrialRow) => ({ index: row.trialIndex, instance_sha256: row.instanceSha256 });
  /**
   * A trial's job sent again: its expiry, and its priority from its place in the queue (record.ts `queue tags`), which a
   * platform `fault` keeps (faultTrialQueueTag: one charge behind the head at most) and a `deferral` its contest's own
   * policy made clears (deferTrialQueueTag: the job that wakes takes a fresh one, queueTurn).
   */
  const sendOptions = async (c: TrialRunContext, trial: Pick<TrialRow, 'runId' | 'trialIndex'>, why: 'fault' | 'deferral') => {
    const wall = c.bundle.limits.wall_budget_sec;
    const tag = why === 'fault' ? await faultTrialQueueTag(db, trial, wall) : await deferTrialQueueTag(db, trial);
    return { priority: gradeTrialPriority(tag ?? 0), expireInSeconds: agentTrialExpirySeconds(wall, c.slug) };
  };
  const what = (row: Pick<TrialRow, 'runId' | 'trialIndex'>) => `trial ${row.trialIndex} of run ${row.runId}`;
  /** The trial's owner: the makefun.trial label of its passes' networks and the name of its scratch, by which the next pass removes what a dead grader left. */
  const ownerOf = (row: Pick<TrialRow, 'runId' | 'trialIndex'>) => trialOwner(row.runId, row.trialIndex);
  /** A reap's names logged (reapLine), when it found anything. */
  const logReap =
    (row: Pick<TrialRow, 'runId' | 'trialIndex'>, before: string) =>
    (r: ReapResult): void => {
      const line = reapLine(what(row), before, r);
      if (line !== null) log(line);
    };
  /**
   * The scratch a dead grader left of the trial (every `trial-<owner>-XXXXXX` under the work root but
   * `keep`, this pass's own) removed and logged by name (scratchReapLine). Run once the trial is the
   * pass's (its row claimed, or a cut-off pass declared over), so what carries its owner then is a dead pass's.
   * What it removed is released from the sandbox's daemon as the reap ends (regrade.ts reapScratch), or, given
   * `released`, handed there for the pass to release with its own scratch once it is over (grade.ts releaseScratch).
   */
  const reapDeadScratch = async (row: Pick<TrialRow, 'runId' | 'trialIndex'>, before: string, keep: string | null = null, released?: string[]): Promise<void> => {
    const line = scratchReapLine(what(row), before, await reapScratch(sandbox, deps.workRoot, TRIAL_SCRATCH_PREFIX, ownerOf(row), keep, released));
    if (line !== null) log(line);
  };

  /**
   * A pass in a fresh scratch directory of its own, named for the trial's owner (`trial-<owner>-XXXXXX`):
   * the snapshot materialized at <dir>/bot, the pass's work directory beside it; all removed after, and released from
   * the sandbox's daemon then (grade.ts removeScratch), or, given `released`, handed there for the pass's one release.
   */
  const inScratch = async <T>(c: TrialRunContext, row: Pick<TrialRow, 'runId' | 'trialIndex'>, fn: (dirs: { dir: string; botDir: string; workDir: string }) => Promise<T>, released?: string[]): Promise<T> => {
    const dir = await ownedScratch(deps.workRoot, TRIAL_SCRATCH_PREFIX, ownerOf(row));
    const botDir = join(dir, 'bot');
    const workDir = join(dir, 'work');
    try {
      await materializeSnapshot(c.index, blobs, botDir);
      await mkdir(workDir, { mode: 0o700 });
      return await fn({ dir, botDir, workDir });
    } finally {
      await removeMaterialized(botDir).catch(() => undefined);
      await removeScratch(sandbox, dir, released);
    }
  };

  /** The fan-in, told a trial is done (each trial's end once: the wait slot looks again either way), and the grader's log. */
  const poke = async (row: TrialRow): Promise<void> => {
    log(`[grade] ${what(row)}: ${row.status} after live pass ${row.attempt} on the ${sandbox.kind} sandbox; its run's fan-in is told`);
    try {
      await deps.jobs.send('grade-aggregate', { run_id: row.runId }, { id: gradeAggregateJobId(row.runId, `trial:${row.trialIndex}:${row.attempt}:${row.status}`) });
    } catch (err) {
      log(`[grade] ${what(row)} is ${row.status}, and its run's fan-in could not be told (${err instanceof Error ? err.message : String(err)}); its next wait slot looks`);
    }
  };

  /** Hold the trial (the run flagged trial_held in the same transaction) and page the admins; 'again' when the row moved meanwhile. */
  const hold = async (row: TrialRow, reason: string, error: string, c: TrialRunContext | null, extra: TrialUpdate = {}): Promise<AgentTrialOutcome | 'again'> => {
    const held = await db.transaction(async (tx) => {
      const moved = await moveTrial(tx, row, { ...extra, status: 'held', voidReason: reason, error });
      if (moved === null) return null;
      await addRunFlags(tx, row.runId, [TRIAL_HELD_FLAG]);
      return moved;
    });
    if (held === null) return 'again';
    // Whether the fan-in re-queues it by itself (an audit read that fails pages it as one for an admin alone).
    page(trialHeldPage(held, heldTrialOf(c), await selfRequeueOf(db, held).catch(() => null)));
    return { kind: 'held', reason };
  };

  /**
   * A void of pass `row.attempt` recorded: the series spent, the trial is held; else the next pass is sent its job. A
   * pass cut off (INTERRUPTED_VOID_REASON: its grader died, or its attempt stopped or expired; the header's `cut off`)
   * spends no pass of the series: the next pass's series starts one later (first_pass + 1), so the passes it counts are
   * the same; the AGENT_INTERRUPTED_RERUNS-th cut off in a row holds the trial instead. An upstream_errors void's next
   * pass waits longer for each re-run of its series (agentVoidRerunDelayMs), whatever `delayMs` its caller gave.
   */
  const voided = async (c: TrialRunContext, row: TrialRow, data: JobPayload<'grade-trial'>, delayMs: number): Promise<AgentTrialOutcome | 'again'> => {
    const reason = row.voidReason ?? 'void';
    const pass = row.attempt + 1;
    let firstPass = data.first_pass;
    let spends = '';
    let waitMs = delayMs;
    if (reason === INTERRUPTED_VOID_REASON) {
      const inARow = Math.max(1, liveCutOffRun(row, row.attempt));
      if (inARow >= AGENT_INTERRUPTED_RERUNS) {
        return hold(row, reason, `${inARow} live passes in a row voided, the last (pass ${row.attempt}) of ${reason}: ${row.error ?? 'no detail'}`, c, voidHeld(row));
      }
      firstPass = Math.min(data.first_pass + 1, pass);
      spends = `, ${inARow} of ${AGENT_INTERRUPTED_RERUNS} cut off in a row, which spends no pass of its series`;
    } else {
      const spent = row.attempt - data.first_pass + 1;
      if (spent >= AGENT_SERIES_PASSES) {
        return hold(row, reason, `${spent} live passes in a row voided, the last (pass ${row.attempt}) of ${reason}: ${row.error ?? 'no detail'}`, c, voidHeld(row));
      }
      // The next pass is re-run `spent` of the series.
      if (reason === UPSTREAM_ERRORS_VOID_REASON) waitMs = agentVoidRerunDelayMs(reason, spent);
    }
    const startAfter = new Date(now().getTime() + waitMs);
    const jobId = await deps.jobs.send('grade-trial', { ...data, pass, first_pass: firstPass }, { id: gradeTrialJobId(row.runId, row.trialIndex, pass), startAfter, ...(await sendOptions(c, row, 'fault')) });
    log(`[grade] ${what(row)}: live pass ${row.attempt} voided (${reason}${spends}); pass ${pass} of ${firstPass + AGENT_SERIES_PASSES - 1} runs from ${startAfter.toISOString()}`);
    return { kind: 'void', reason, next: { pass, job_id: jobId, start_after: startAfter } };
  };

  /**
   * A scrape heat holds the host (the header's `scrape heat`): nothing run, the job sent again for the next recheck slot
   * (one job of a pass and series a slot), so the trial spends none of its expiry on the heat.
   */
  const waitOutHeat = async (c: TrialRunContext, data: JobPayload<'grade-trial'>, heldBy: string): Promise<AgentTrialOutcome> => {
    const slot = scrapeHostRecheckSlot(now().getTime());
    const until = new Date(slot * SCRAPE_HOST_RECHECK_MS);
    // A trial yet to start its live pass waits on the host's policy and takes a fresh place as it wakes; one further on keeps its own.
    const row = await trialRow(data);
    const why = row !== null && (row.status === 'pending' || row.status === 'void') ? 'deferral' : 'fault';
    const jobId = await deps.jobs.send('grade-trial', data, {
      id: gradeTrialJobId(data.run_id, data.trial_index, data.pass, `scrape-wait:${data.first_pass}:${slot}`),
      startAfter: until,
      ...(await sendOptions(c, { runId: data.run_id, trialIndex: data.trial_index }, why)),
    });
    log(`[grade] ${what({ runId: data.run_id, trialIndex: data.trial_index })}: pass ${data.pass} waits for ${until.toISOString()}: ${heldBy}, and nothing else grades here while a heat runs`);
    return { kind: 'waiting', until, job_id: jobId, held_by: heldBy };
  };

  /** The node's free pod slots (the header's `node room`): the deps', else a K8sSandbox's own read; none on any other driver. */
  const podRoom: (() => Promise<number | null>) | null = deps.podRoom ?? (sandbox instanceof K8sSandbox ? () => sandbox.nodePodRoom() : null);
  /** Why the node has no room for `pods` more sandbox pods now (nodeHasRoom: NODE_POD_HEADROOM kept free), or null when it has, or none can be told. */
  const roomShort = async (pods: number): Promise<string | null> => {
    if (podRoom === null) return null;
    const room = await podRoom().catch(() => null);
    return nodeHasRoom(room, pods) ? null : `the node has ${room} pod slots free, ${NODE_POD_HEADROOM} of them kept free, and this needs ${pods}`;
  };

  /**
   * The node had no room for the trial's pods (the header's `node room`): nothing more run, the job sent again for the
   * next recheck slot (one job of a pass, series and slot), so the trial waits for room spending no pass and none of its
   * expiry.
   */
  const waitForRoom = async (c: TrialRunContext, data: JobPayload<'grade-trial'>, why: string): Promise<AgentTrialOutcome> => {
    const slot = nodeRoomRecheckSlot(now().getTime());
    const until = new Date(slot * NODE_ROOM_RECHECK_MS);
    const jobId = await deps.jobs.send('grade-trial', data, {
      id: gradeTrialJobId(data.run_id, data.trial_index, data.pass, `node-room:${data.first_pass}:${slot}`),
      startAfter: until,
      ...(await sendOptions(c, { runId: data.run_id, trialIndex: data.trial_index }, 'fault')),
    });
    const heldBy = `the node has no room for its pods: ${why}`;
    log(`[grade] ${what({ runId: data.run_id, trialIndex: data.trial_index })}: pass ${data.pass} waits for ${until.toISOString()}: ${heldBy}; no pass is spent on it`);
    return { kind: 'waiting', until, job_id: jobId, held_by: heldBy };
  };

  /**
   * What masq metered on a lane's key a pass handed back (its retirement's figure, else read now, the key disabled
   * first: retireTrialKey); 0 for no key, or one whose spend cannot be read (said in the log).
   */
  const keySpend = async (key: TrialPass['masq'], whose: string, row: Pick<TrialRow, 'runId' | 'trialIndex'>, signal: AbortSignal): Promise<bigint> => {
    if (key === null) return 0n;
    if (key.retired !== null) return key.retired.spend.microUsd;
    try {
      const { retireTrialKey } = await import('./gateway/masq.ts');
      const retired = await retireTrialKey(deps.gateway.broker, key.key_id, 0n, { signal });
      if (!retired.settled) await addRunFlags(db, row.runId, [GATEWAY_SPEND_UNSETTLED_FLAG]);
      return retired.spend.microUsd;
    } catch (err) {
      if (signal.aborted) throw err;
      log(`[grade] ${what(row)}: ${whose} ${key.key_id}, of a pass the node had no room for, could not be read (${err instanceof Error ? err.message : String(err)}); it lapses on its own`);
      return 0n;
    }
  };

  /**
   * As a pass claims its trial (or a refused key's trial scores 0), in `tx`: the run's `flag` (ENTRY_SECRET_HELD_FLAG)
   * taken off once no other trial of it is left to start (pending, or void before its re-run), so the
   * flag stays while any of them may still be waiting on what it says. Nothing written on a run that does not carry it.
   */
  const dropFlagOnceStarted = async (tx: Pick<Db, 'select' | 'update'>, row: Pick<TrialRow, 'runId' | 'trialIndex'>, flag: string): Promise<void> => {
    const [r] = await tx.select({ flags: run.flags }).from(run).where(eq(run.id, row.runId));
    if (r === undefined || !r.flags.includes(flag)) return;
    const [left] = await tx
      .select({ n: count() })
      .from(runTrial)
      .where(and(eq(runTrial.runId, row.runId), ne(runTrial.trialIndex, row.trialIndex), inArray(runTrial.status, ['pending', 'void'])));
    if (Number(left?.n ?? 0) === 0) await dropRunFlag(tx, row.runId, flag);
  };

  /**
   * What an entrant's pass runs with, read as it sets out (the header's `entry secrets`): its account's active entry
   * secrets in the competition, both lanes, each opened with the grader's private keys; of the provider lane only a
   * provider its allowlist serves (contracts/entry-secrets.ts providersOfModels: a key for any other could pay for no
   * call of the pass, so it is neither opened, checked nor recorded), each such key then checked with its provider. None
   * pushed: none (model-free, no variable). Either way the forwarder is told whether an entrant can push a secret on this
   * deployment at all (EntrantKeys.entrySecrets: `off` with no seal public key, where a push answers 503), so a no-key 401
   * never names `makefun secrets push` where that cannot work. Every word it answers is redacted of every form of every
   * secret; no value is logged, stored or thrown.
   */
  const entrantLane = async (c: TrialRunContext, signal: AbortSignal): Promise<EntrantLaneVerdict> => {
    const providers = deps.entrySecrets?.providers;
    const [{ entrySecretSealRefusal, EntrySecretSealError }, { openEntrySecretRows, sealedEntrySecretsFor }, { secretFormSet }] = await Promise.all([
      import('../server/secrets/seal.ts'),
      import('../server/secrets/store.ts'),
      import('./gateway/upstream.ts'),
    ]);
    const seal = await sealOf();
    const entrySecrets: EntrySecretsOpenT = entrySecretSealRefusal(seal, 'seal') === null ? 'on' : 'off';
    const reach = { ...(providers?.origins === undefined ? {} : { origins: providers.origins }), ...(providers?.ca === undefined ? {} : { ca: providers.ca }) };
    const serves = providersOfModels(c.harness.inference.models);
    const { secrets: held } = await sealedEntrySecretsFor(db, { userId: c.sub.userId, competitionId: c.ph.competitionId });
    const rows = held.filter((r) => r.lane === 'env' || (r.provider !== null && serves.includes(r.provider)));
    const none: PassSecrets = { ids: [], env: {}, forms: secretFormSet([]), byName: {} };
    if (rows.length === 0) return { kind: 'run', lane: { credential: 'entrant', own: { keys: {}, mask: [], ...reach, entrySecrets }, secrets: none } };
    const ids = rows.map((r) => r.id);
    const named = rows.map((r) => `${r.name} (entry_secret ${r.id})`).join(', ');
    const off = entrySecretSealRefusal(seal, 'open');
    if (off !== null) return { kind: 'unopened', ids, error: `the entry secrets its entrant pushed (${named}) cannot be opened, so its live pass does not run (never on the house's key instead): ${off}` };
    let opened: OpenedEntrySecret[];
    try {
      opened = openEntrySecretRows(seal.privateKeys, rows);
    } catch (err) {
      if (!(err instanceof EntrySecretSealError)) throw err;
      return { kind: 'unopened', ids, error: `an entry secret its entrant pushed cannot be opened here, so its live pass does not run (never on the house's key instead): ${err.message}` };
    }
    const keys: OpenedProviderKey[] = [];
    const env: Record<string, string> = {};
    const byName: Record<string, string> = {};
    for (const s of opened) {
      byName[s.name] = s.value;
      if (s.lane === 'env') env[s.name] = s.value;
      else keys.push({ id: s.id, name: s.name, provider: s.provider!, hint: rows.find((r) => r.id === s.id)!.hint, key: s.value });
    }
    const values = opened.map((s) => s.value);
    const forms = secretFormSet(values);
    const redact = await redactorOf(forms, keys.map((k) => k.key));
    const { checkProviderKey } = await import('./gateway/providers.ts');
    const timeout = deps.entrySecrets?.checkTimeoutMs === undefined ? {} : { timeoutMs: deps.entrySecrets.checkTimeoutMs };
    const verdicts: ProviderKeyVerdict[] = await Promise.all(
      keys.map(async (k): Promise<ProviderKeyVerdict> => {
        const check = await checkProviderKey(k.provider, k.key, { signal, ...reach, ...timeout });
        return { id: k.id, name: k.name, provider: k.provider, hint: k.hint, check: check.state === 'valid' ? check : { ...check, reason: redact(check.reason) } };
      }),
    );
    // The attempt is over: nothing is decided on a check it cut short.
    if (signal.aborted) throw signal.reason ?? new Error("the trial job was stopped while its entrant's keys were checked");
    const refused = verdicts.filter((v) => v.check.state === 'refused');
    if (refused.length > 0) return { kind: 'refused', ids, verdicts: refused, forms };
    const unreachable = verdicts.filter((v) => v.check.state === 'unreachable');
    if (unreachable.length > 0) return { kind: 'unreachable', ids, verdicts: unreachable, forms };
    const byProvider: Partial<Record<SecretProvider, string>> = {};
    for (const k of keys) byProvider[k.provider] = k.key;
    // The org and project ids each provider named for its key: masked with the keys out of every answer the forwarder relays.
    const mask = [...new Set(verdicts.flatMap((v) => (v.check.state === 'valid' ? v.check.identifiers : [])))].sort(compareCodeUnits);
    const secrets: PassSecrets = { ids, env, forms: mask.length === 0 ? forms : secretFormSet([...values, ...mask]), byName };
    return { kind: 'run', lane: { credential: 'entrant', own: { keys: byProvider, mask, ...reach, entrySecrets }, secrets } };
  };

  /**
   * The env-lane entry secrets a replay of `row`'s live pass runs with (the header's `entry secrets`): exactly the rows
   * that pass recorded (run_trial.entry_secret_ids; none on a house-paid pass), opened as it opened them. `erased` the
   * env-lane ones whose ciphertext is gone meanwhile, by NAME and row (the replay cannot run as live did); `unopened`
   * why this grader cannot open them. A provider-lane row is never opened: the replay runs on no key.
   */
  const replaySecrets = async (c: TrialRunContext, row: TrialRow): Promise<{ secrets: PassSecrets } | { erased: string } | { unopened: string }> => {
    const ids = row.entryCredential === 'entrant' ? (row.entrySecretIds ?? []) : [];
    const { secretFormSet } = await import('./gateway/upstream.ts');
    const recorded = await recordedEnvSecrets(db, sealOf, { userId: c.sub.userId, competitionId: c.ph.competitionId }, ids);
    if (recorded.erased !== null) return { erased: `an env-lane entry secret its live pass ran with is erased now (replaced, removed or purged): ${recorded.erased}, so its replay cannot run as it did` };
    if (recorded.kind === 'unopened') {
      return { unopened: recorded.cause === 'off' ? `the entry secrets its live pass ran with cannot be opened for its replay: ${recorded.why}` : `an entry secret its live pass ran with cannot be opened for its replay: ${recorded.why}` };
    }
    const { env } = recorded.secrets;
    return { secrets: { ids: [...ids], env, forms: secretFormSet(Object.values(env)), byName: { ...env } } };
  };

  /**
   * Best effort, for words about a pass that ran with `ids` (a cut-off pass's): every form of those secrets this grader can
   * still open, or null when it can open none (erased, or no private key here). Never throws on a secret it cannot open.
   */
  const recordedForms = async (c: TrialRunContext, ids: readonly string[]): Promise<FormSet | null> => {
    if (ids.length === 0) return null;
    try {
      const [{ openEntrySecretRows, sealedEntrySecretsFor }, { secretFormSet }] = await Promise.all([import('../server/secrets/store.ts'), import('./gateway/upstream.ts')]);
      const seal = await sealOf();
      if (seal.privateKeys === null) return null;
      const read = await sealedEntrySecretsFor(db, { userId: c.sub.userId, competitionId: c.ph.competitionId, ids });
      const values: string[] = [];
      for (const r of read.secrets) {
        try {
          values.push(...openEntrySecretRows(seal.privateKeys, [r]).map((s) => s.value));
        } catch {
          // A secret this grader cannot open is masked of nothing: its words never held it (it never reached this process).
        }
      }
      return values.length === 0 ? null : secretFormSet(values);
    } catch {
      return null;
    }
  };

  /**
   * After a pass that stands (its record kept: live_done, timeout; finished, nondeterministic), its outputs scanned for
   * its secrets (agent.ts secretsInPassOutputs: the env's export and call log, never masked): a hit flags the run
   * SECRET_IN_OUTPUT_FLAG and writes a SECRET_IN_OUTPUT_ACTION row naming each secret's NAME and the file (the header's
   * `entry secrets`), and is logged by NAME. Nothing with no secret.
   */
  const scanOutputs = async (row: Pick<TrialRow, 'id' | 'runId' | 'trialIndex'>, pass: number, p: Pick<TrialPass, 'mode' | 'outputs' | 'env_log_sha256'>, secrets: PassSecrets): Promise<SecretOutputHit[]> => {
    if (Object.keys(secrets.byName).length === 0) return [];
    const { secretScanIndex, secretsInPassOutputs } = await import('./agent.ts');
    const index: FormIndex = secretScanIndex(secrets.byName);
    const hits = await secretsInPassOutputs(blobs, p, index);
    if (hits.length === 0) return hits;
    await db.transaction(async (tx) => {
      await addRunFlags(tx, row.runId, [SECRET_IN_OUTPUT_FLAG]);
      await tx.insert(auditEvent).values({
        at: now(),
        actorUserId: null,
        action: SECRET_IN_OUTPUT_ACTION,
        subjectType: 'run_trial',
        subjectId: row.id,
        data: { run_id: row.runId, trial_index: row.trialIndex, pass, mode: p.mode, hits: hits.map((h) => ({ name: h.name, file: h.file })) },
      });
    });
    const named = [...new Set(hits.map((h) => h.name))].join(', ');
    log(`[grade] ${what(row)}: the ${p.mode} pass ${pass}'s outputs hold a form of entry secret ${named} (${[...new Set(hits.map((h) => h.file))].join(', ')}), never masked: its run is flagged ${SECRET_IN_OUTPUT_FLAG}`);
    return hits;
  };

  /** The next provider-key recheck slot after `at` (AGENT_PROVIDER_KEY_RECHECK_MS) and its start. */
  const keyRecheckSlot = (at: Date): { slot: number; start: Date } => {
    const slot = Math.ceil((at.getTime() + AGENT_PROVIDER_KEY_RECHECK_MS) / AGENT_PROVIDER_KEY_RECHECK_MS);
    return { slot, start: new Date(slot * AGENT_PROVIDER_KEY_RECHECK_MS) };
  };

  /**
   * When pass data.pass of the trial first met a refused key on the final: its ENTRY_SECRET_HELD_ACTION audit row's time,
   * or `at`, that row written now with when the wait ends (`deadline` of that start).
   */
  const keyHeldSince = async (c: TrialRunContext, row: TrialRow, data: JobPayload<'grade-trial'>, v: { ids: string[]; verdicts: readonly ProviderKeyVerdict[] }, at: Date): Promise<Date> => {
    const [first] = await db
      .select({ at: auditEvent.at })
      .from(auditEvent)
      .where(and(eq(auditEvent.action, ENTRY_SECRET_HELD_ACTION), eq(auditEvent.subjectType, 'run_trial'), eq(auditEvent.subjectId, row.id), sql`${auditEvent.data}->>'pass' = ${String(data.pass)}`))
      .orderBy(asc(auditEvent.at), asc(auditEvent.id))
      .limit(1);
    if (first !== undefined) return first.at;
    await db.insert(auditEvent).values({
      at,
      actorUserId: null,
      action: ENTRY_SECRET_HELD_ACTION,
      subjectType: 'run_trial',
      subjectId: row.id,
      data: { run_id: row.runId, trial_index: row.trialIndex, pass: data.pass, until: keyHoldDeadline(c, at).toISOString(), entry_secret_ids: v.ids, providers: [...new Set(v.verdicts.map((x) => x.provider))] },
    });
    return at;
  };

  /** When a final pass that first met a refused key at `since` stops waiting: AGENT_PROVIDER_KEY_HOLD_MS on, never past the final phase's end. */
  const keyHoldDeadline = (c: TrialRunContext, since: Date): Date => new Date(Math.min(since.getTime() + AGENT_PROVIDER_KEY_HOLD_MS, c.ph.endsAt?.getTime() ?? Number.POSITIVE_INFINITY));

  /**
   * A pass whose entrant's key its provider refused (the header's `entry secrets`): on the final it waits for the entrant
   * to push a new one, the run flagged ENTRY_SECRET_HELD_FLAG and its job sent again for the next
   * AGENT_PROVIDER_KEY_RECHECK_MS slot, until AGENT_PROVIDER_KEY_HOLD_MS after the first refusal (capped at the final
   * phase's end); past that, once the competition is resolved, or on the dev phase at once, the trial scores 0
   * (keyRefusedZero). Its words are redacted of every form of every secret the pass holds (`v.forms`).
   */
  const keyRefused = async (c: TrialRunContext, row: TrialRow, data: JobPayload<'grade-trial'>, v: { ids: string[]; verdicts: ProviderKeyVerdict[]; forms: FormSet }): Promise<AgentTrialOutcome | 'again'> => {
    const at = now();
    const redact = await redactorOf(v.forms);
    const words = redact(v.verdicts.map(keyVerdictWords).join('; '));
    const fix = `push a working key: ${keyFixWords(c.slug, v.verdicts)}`;
    if (c.ph.key !== 'final') {
      return keyRefusedZero(c, row, data, v.ids, `the live pass did not run: ${words}, so trial ${row.trialIndex} scores 0 (${PROVIDER_KEY_REFUSED}); ${fix}, then submit again`, redact);
    }
    if (c.competitionStatus === 'resolved') {
      return keyRefusedZero(c, row, data, v.ids, `the final live pass did not run: ${words}, and the competition is resolved, so trial ${row.trialIndex} scores 0 (${PROVIDER_KEY_REFUSED})`, redact);
    }
    const since = await keyHeldSince(c, row, data, v, at);
    const deadline = keyHoldDeadline(c, since);
    if (at.getTime() >= deadline.getTime()) {
      return keyRefusedZero(
        c,
        row,
        data,
        v.ids,
        `the final live pass did not run: ${words}; it was first refused at ${since.toISOString()} and still was at ${deadline.toISOString()}, the end of the wait for a new key (${AGENT_PROVIDER_KEY_HOLD_MS / 3_600_000} hours, never past the final phase's end), so trial ${row.trialIndex} scores 0 (${PROVIDER_KEY_REFUSED})`,
        redact,
      );
    }
    const { slot, start } = keyRecheckSlot(at);
    const until = new Date(Math.min(start.getTime(), deadline.getTime()));
    const jobId = await deps.jobs.send('grade-trial', data, { id: gradeTrialJobId(row.runId, row.trialIndex, data.pass, `provider-key:${data.first_pass}:${slot}`), startAfter: until, ...(await sendOptions(c, row, 'deferral')) });
    await addRunFlags(db, row.runId, [ENTRY_SECRET_HELD_FLAG]);
    log(
      redact(
        `[grade] ${what(row)}: final pass ${data.pass} waits for its entrant to push a new key in place of a refused one (${words}): checked again at ${until.toISOString()}, and the trial scores 0 (${PROVIDER_KEY_REFUSED}) if it is still refused at ${deadline.toISOString()}; the entrant's fix: ${fix}`,
      ),
    );
    return { kind: 'key_wait', why: 'refused', until, job_id: jobId, deadline, reason: words };
  };

  /**
   * A refused key's trial scored 0 (the header's `entry secrets`), nothing run: its record keyRefusedRecord's, its points
   * 0 on every column (agent.ts timeoutScores) as a timeout's, void_reason PROVIDER_KEY_REFUSED and `note`, the readable
   * why, as its error (redacted, `redact`). The rows the pass would have run with recorded (entry_secret_ids); the run's
   * ENTRY_SECRET_HELD_FLAG taken off once no other trial of it is left to start; the fan-in told.
   */
  const keyRefusedZero = async (c: TrialRunContext, row: TrialRow, data: JobPayload<'grade-trial'>, ids: string[], note: string, redact: Redact): Promise<AgentTrialOutcome | 'again'> => {
    const at = now();
    const record = await keyRefusedRecord(blobs, row, c.harness.target !== undefined);
    const scores = (await import('./agent.ts')).timeoutScores(c.bundle.leaderboard);
    const error = redact(note);
    const moved = await db.transaction(async (tx) => {
      const m = await moveTrial(tx, row, {
        ...passStart(row, data.pass, at),
        ...record,
        status: 'timeout',
        liveFinishedAt: at,
        score: scores,
        scoreSha256: canonicalSha256(scores),
        masqKeyId: null,
        houseMasqKeyId: null,
        entryCredential: 'entrant',
        entrySecretIds: ids,
        voidReason: PROVIDER_KEY_REFUSED,
        error,
      });
      if (m !== null) await dropFlagOnceStarted(tx, row, ENTRY_SECRET_HELD_FLAG);
      return m;
    });
    if (moved === null) return 'again';
    log(`[grade] ${what(row)}: ${error}`);
    await poke(moved);
    return { kind: 'done', status: 'timeout' };
  };

  /**
   * A pass whose entrant's key its provider gave no verdict on (the header's `entry secrets`): never the entrant's fault,
   * so never scored for it. Its job sent again for the next AGENT_PROVIDER_KEY_RECHECK_MS slot, unless the competition is
   * resolved; the admins paged at most once an hour for the same providers, else logged; every word redacted of the
   * pass's secrets.
   */
  const keyUnreachable = async (c: TrialRunContext, row: TrialRow, data: JobPayload<'grade-trial'>, v: { verdicts: ProviderKeyVerdict[]; forms: FormSet }): Promise<AgentTrialOutcome> => {
    const at = now();
    const redact = await redactorOf(v.forms);
    const words = redact(v.verdicts.map(keyVerdictWords).join('; '));
    const { slot, start } = keyRecheckSlot(at);
    const until = c.competitionStatus === 'resolved' ? null : start;
    const jobId = until === null ? null : await deps.jobs.send('grade-trial', data, { id: gradeTrialJobId(row.runId, row.trialIndex, data.pass, `provider-key:${data.first_pass}:${slot}`), startAfter: until, ...(await sendOptions(c, row, 'deferral')) });
    const line = `[grade] ${what(row)}: ${c.ph.key} pass ${data.pass} waits: its entrant's provider key could not be checked (${words}), which is never the entrant's fault${until === null ? ', and its competition is resolved, so nothing is sent again' : `; checked again at ${until.toISOString()}`}`;
    const providers = [...new Set(v.verdicts.map((x) => x.provider))];
    const pageKey = providers.join(',');
    const last = unreachablePaged.get(pageKey);
    if (last !== undefined && at.getTime() - last < AGENT_REFUSAL_PAGE_MS) {
      log(line);
    } else {
      unreachablePaged.set(pageKey, at.getTime());
      page(
        `[grade] ALERT: ${c.slug}: ${providers.map((p) => SECRET_PROVIDER_NAME[p]).join(' and ')} gave no verdict on an entrant's provider key from this grader (${words}). ` +
          `Live passes on entrants' own keys wait and check again every ${AGENT_PROVIDER_KEY_RECHECK_MS / 60_000} minutes: nothing is run, marked or scored meanwhile, and it is never the entrant's fault (${what(row)} is one). ` +
          `Fix: mend the grader's egress to the provider, or wait out its outage`,
      );
    }
    return { kind: 'key_wait', why: 'unreachable', until, job_id: jobId, deadline: null, reason: words };
  };

  /**
   * Live pass data.pass from a pending or void row: a house-paid entry's on a key of its own, the row claimed as the key
   * comes back; an entrant's on its own keys and with its env-lane secrets (read, opened and checked first: the header's
   * `entry secrets`), the row claimed as its house key comes back, or as it sets out with no target (the header's `entry
   * lane`).
   */
  const livePass = async (c: TrialRunContext, row: TrialRow, data: JobPayload<'grade-trial'>, ctx: AgentTrialContext): Promise<AgentTrialOutcome | 'again'> => {
    const pass = data.pass;
    // Nothing minted, claimed or networked on an engine that does not keep trials apart.
    await requireIsolation();
    // Nothing minted or claimed while the node has no room for the pass's pods: it waits for the next slot, as no pass.
    const short = await roomShort((await import('./agent.ts')).trialPods(c.harness));
    if (short !== null) return waitForRoom(c, data, short);
    // No spend is weighed (the header's `spend`): the pass's own budget alone bounds it. Whether the house pays the entry lane.
    const housePaid = housePaysEntryLane(c.sub);
    // An entrant's pass runs with the secrets its entrant pushed, each opened (its provider keys checked with their
    // providers) before anything is minted or claimed; a key that cannot run it now holds, waits or zeroes the trial,
    // never sending it to masq. A house-paid entry's pass runs with none.
    let lane: EntryLane = { credential: 'house' };
    if (!housePaid) {
      const found = await entrantLane(c, ctx.signal);
      if (found.kind === 'unopened') return hold(row, ENTRY_SECRETS_UNOPENED_HOLD_REASON, found.error, c, passStart(row, pass, now()));
      if (found.kind === 'refused') return keyRefused(c, row, data, found);
      if (found.kind === 'unreachable') return keyUnreachable(c, row, data, found);
      lane = found.lane;
    }
    const started = now();
    /**
     * What the pass removes of the trial's scratch, a dead pass's (removed as the key is claimed, mid-pass) and its own,
     * released from the sandbox's daemon in one go once the pass is over and its outcome recorded, or it threw (grade.ts
     * releaseScratch, its header's Releasing): never while the agent runs, and never before the pass's end is read
     * (liveFinishedAt), which a release would move.
     */
    const removed: string[] = [];
    try {
      return await livePassIn(c, row, data, ctx, pass, lane, started, removed);
    } finally {
      await releaseScratch(sandbox, removed);
    }
  };

  /**
   * livePass's pass and its record, every scratch dir it removes handed to `removed` (for livePass's one release);
   * `lane` whose keys its entry lane runs on (the house's, when the house pays it: housePaysEntryLane; else the
   * entrant's: the header's `entry lane`).
   */
  const livePassIn = async (
    c: TrialRunContext,
    row: TrialRow,
    data: JobPayload<'grade-trial'>,
    ctx: AgentTrialContext,
    pass: number,
    lane: EntryLane,
    started: Date,
    removed: string[],
  ): Promise<AgentTrialOutcome | 'again'> => {
    const housePaid = lane.credential === 'house';
    // Every word of the pass stored, logged or thrown, redacted of every form of the entrant's secrets (none on the house's).
    const secrets = lane.credential === 'entrant' ? lane.secrets : null;
    const ownKeys = lane.credential === 'entrant' ? Object.values(lane.own.keys).filter((k): k is string => typeof k === 'string') : [];
    const redact: Redact = secrets === null || secrets.forms.forms.length === 0 ? NO_REDACT : await redactorOf(secrets.forms, ownKeys);
    let claimed: TrialRow | null = null;
    /** This pass's own scratch (inScratch's), which the removal of a dead pass's spares. */
    let ownScratch: string | null = null;
    /**
     * The trial claimed for this pass on the keys it holds then (`masqKeyId` its entry lane's, null on an entrant's pass;
     * `houseMasqKeyId` a target's house key when that is what claims), whose they are recorded beside them (laneCredential:
     * an entrant's pass the entry_secret rows it runs with, minting none for its entry lane); then what a dead pass left
     * of the trial removed. `doing`: what the pass was doing, for the words of a claim another attempt took first.
     */
    const claim = async (keys: { masqKeyId: string | null; houseMasqKeyId: string | null }, doing: string): Promise<void> => {
      claimed = await db.transaction(async (tx) => {
        const moved = await moveTrial(tx, row, { ...passStart(row, pass, started), status: 'live_running', ...keys, ...laneCredential(lane) });
        // A final pass's rows recorded only while each it opened still holds its ciphertext, under its entrant's account
        // lock, so a challenge's re-run of the trial can always open them (the header's `entry secrets`).
        if (moved !== null && c.ph.key === 'final' && lane.credential === 'entrant') {
          const erased = await erasedSinceOpened(tx, { userId: c.sub.userId, competitionId: c.ph.competitionId }, lane.secrets.ids);
          if (erased !== null) {
            throw new PassSecretsErased(
              `${what(row)}: live pass ${pass} opened an env-lane entry secret its entrant removed or replaced before the pass claimed the trial, whose sealed copy is erased (${erased}): nothing is claimed, and the pass sets out again with the secrets as they stand`,
            );
          }
        }
        // Its keys passed their check: a wait on a refused one is over once no other trial of the run is left to start.
        if (moved !== null && !housePaid) await dropFlagOnceStarted(tx, row, ENTRY_SECRET_HELD_FLAG);
        return moved;
      });
      if (claimed === null) throw new TrialTaken(`${what(row)} moved on from ${row.status} while pass ${pass} ${doing}`);
      // The trial is this pass's now: what a dead grader's pass of it left under the work root goes first (its containers go as the pass makes its network).
      await reapDeadScratch(row, `live pass ${pass}`, ownScratch, removed);
    };
    const broker = claimingBroker(
      deps.gateway.broker,
      (minted) => claim({ masqKeyId: minted.id, houseMasqKeyId: null }, 'minted its key'),
      async (minted) => {
        // An entrant's pass mints no entry-lane key: its target's house key, the one key it mints, claims the trial.
        if (!housePaid) return claim({ masqKeyId: null, houseMasqKeyId: minted.id }, 'minted its house key');
        // A target's house key, minted after the entry's claimed the trial: recorded beside it, so a pass cut off retires both (interrupted).
        const mine = claimed as TrialRow | null;
        if (mine === null) throw new Error(`live pass ${pass} of ${what(row)} minted its house key before its own claimed the trial`);
        const moved = await moveTrial(db, mine, { houseMasqKeyId: minted.id });
        if (moved === null) throw new TrialTaken(`${what(row)} moved on from live_running while pass ${pass} minted its house key`);
        claimed = moved;
      },
    );
    const key: TrialKeySpec = {
      slug: c.slug,
      runId: row.runId,
      trialIndex: row.trialIndex,
      attempt: pass,
      budgetUsdPerTrial: c.harness.inference.budget_usd_per_trial,
      models: c.harness.inference.models,
      wallBudgetSec: c.bundle.limits.wall_budget_sec,
    };
    const masq: MasqTrialUpstream = { broker, key, origin: deps.gateway.origin, ...(deps.gateway.retireBackoffMs === undefined ? {} : { retireBackoffMs: deps.gateway.retireBackoffMs }) };
    // House-paid: the entry lane on a masq key of the pass's own (and a target's house lane on another), and no entry
    // secret. An entrant's: its entry lane on the keys its entrant pushed (none: every model call of it answered 401 by the
    // forwarder itself), the org and project ids their providers named masked with them, and its env-lane secrets in the
    // entry's own sandbox; a target's house lane still on a masq key, derived from `key` (role house).
    const upstream: PassUpstream = lane.credential === 'house' ? { masq } : { provider: lane.own, ...(c.harness.target === undefined ? {} : { house: { masq } }) };
    const envSecrets = secrets === null || Object.keys(secrets.env).length === 0 ? {} : { secrets: secrets.env };
    const gateway = await forwarderOf();
    const { runTrial: runAgentTrial, NODE_CAPACITY_VOID_REASON } = await import('./agent.ts');
    let p: TrialPass;
    try {
      p = await inScratch(c, row, async ({ dir, botDir, workDir }) => {
        ownScratch = dir;
        // An entrant's pass with no target mints nothing, so no key coming back claims the trial: it is claimed here, before anything runs.
        if (!housePaid && c.harness.target === undefined) await claim({ masqKeyId: null, houseMasqKeyId: null }, 'set out');
        return runAgentTrial({
          mode: 'live',
          sandbox,
          snapshot: { dir: botDir, runtime: c.runtime, imageDigest: c.run.imageDigest },
          instanceDir: instanceDirOf(row),
          trial: trialRef(row),
          // A house baseline's pass reads the instance's baseline brief when it has one (the header's `brief`).
          baseline: c.sub.baseline,
          setup: c.setup,
          limits: c.bundle.limits,
          upstream,
          ...envSecrets,
          gateway,
          workDir,
          blobs,
          signal: ctx.signal,
          score: false,
          owner: ownerOf(row),
          onReap: logReap(row, `live pass ${pass}`),
        });
      }, removed);
    } catch (err) {
      // Another job claimed the pass first (the key that would have claimed it, if any, disabled here): that job runs it.
      if (err instanceof TrialTaken) return { kind: 'stopped', why: err.message };
      // A final pass whose entrant erased a secret it opened before it claimed (any key it minted disabled here): it sets out again, the row read afresh.
      if (err instanceof PassSecretsErased) {
        log(`[grade] ${err.message}`);
        return 'again';
      }
      // Anything else goes on as it was, its words redacted of the entrant's secrets (a held trial's error stores them).
      throw redactedError(err, redact);
    }
    // The pass's end, read as it returns: its scratch is released once the row records it (livePass).
    const at = now();
    const mine = claimed as TrialRow | null;
    const error = p.error === null ? null : redact(p.error);
    // The node had no room for one of its pods, so the entry never ran (agent.ts NODE_CAPACITY_VOID_REASON; the header's
    // `node room`): no pass of the trial's. Its claim, if it made one, undone, what masq metered on its keys counted as
    // voided spend, and its job sent again for the next recheck slot.
    const noRoom = p.status === 'void' && p.reason === NODE_CAPACITY_VOID_REASON;
    if (mine === null) {
      if (noRoom) return waitForRoom(c, data, error ?? 'one of its pods found none');
      // No key came back (an entrant's pass with no target claims before it runs, so never here): the pass voided before
      // anything ran (the instance, the sandbox, the broker).
      if (p.status !== 'void') throw new Error(`live pass ${pass} of ${what(row)} ended ${p.status} with no key minted`);
      const moved = await moveTrial(db, row, { ...passStart(row, pass, started), status: 'void', liveFinishedAt: at, voidReason: p.reason, error, ...laneCredential(lane) });
      return moved === null ? 'again' : voided(c, moved, data, AGENT_VOID_RERUN_DELAY_MS);
    }
    if (noRoom) {
      const roomFlags = [...new Set([...masqRunFlags(p.masq), ...masqRunFlags(p.house_masq)])];
      if (roomFlags.length > 0) await addRunFlags(db, row.runId, roomFlags);
      const spent = await keySpend(p.masq, 'its key', row, ctx.signal);
      const houseSpent = await keySpend(p.house_masq, 'its house key', row, ctx.signal);
      const undone = await moveTrial(db, mine, {
        ...unclaimed(row, pass, started),
        voidedSpendMicroUsd: row.voidedSpendMicroUsd + spent,
        voidedHouseSpendMicroUsd: row.voidedHouseSpendMicroUsd + houseSpent,
      });
      if (undone === null) return 'again';
      return waitForRoom(c, data, error ?? 'one of its pods found none');
    }
    // The entrant's secrets a pass ran with are marked used, its keys validated (their pre-flight had each provider answer 200).
    if (secrets !== null && secrets.ids.length > 0) {
      try {
        await (await import('../server/secrets/store.ts')).markUsed(db, secrets.ids, at, { validated: true });
      } catch (e) {
        log(`[grade] ${what(row)}: the entry secrets live pass ${pass} ran with (${secrets.ids.join(', ')}) could not be marked used (${redact(e instanceof Error ? e.message : String(e))}); nothing else hangs on it`);
      }
    }
    // Each lane's key retired as runPass ended: either's flags are the run's; on a house clock, the pass's own besides.
    const flags = [...new Set([...masqRunFlags(p.masq), ...masqRunFlags(p.house_masq), ...houseClockRunFlags(p, row.trialIndex, pass)])];
    if (flags.length > 0) await addRunFlags(db, row.runId, flags);
    const houseSpend = await houseSpendOf(blobs, p);
    if (p.status === 'live_done') {
      // Its outputs scanned for its secrets, never masked (the header's `entry secrets`); then scored and replayed next (a
      // row another attempt moved meanwhile is read again either way).
      if (secrets !== null) await scanOutputs(mine, pass, p, secrets);
      await moveTrial(db, mine, { ...passRecord(p, at, houseSpend), ...trialEnding('live_done') });
      return 'again';
    }
    if (p.status === 'timeout') {
      if (secrets !== null) await scanOutputs(mine, pass, p, secrets);
      const scores = (await import('./agent.ts')).timeoutScores(c.bundle.leaderboard);
      const moved = await moveTrial(db, mine, { ...passRecord(p, at, houseSpend), ...trialEnding('timeout'), score: scores, scoreSha256: canonicalSha256(scores) });
      if (moved === null) return 'again';
      await poke(moved);
      return { kind: 'done', status: 'timeout' };
    }
    if (p.status === 'void') {
      const moved = await moveTrial(db, mine, { ...passRecord(p, at, houseSpend), status: 'void', voidReason: p.reason, error });
      return moved === null ? 'again' : voided(c, moved, data, AGENT_VOID_RERUN_DELAY_MS);
    }
    throw new Error(`live pass ${pass} of ${what(row)} ended ${p.status}, which no live pass ends`);
  };

  /**
   * This job's live pass found running: its earlier attempt was cut off (the pass is over, whatever it
   * spent). What its grader left running, if it died, removed first (so its forwarder spends nothing
   * more before the key's spend is read), and the scratch it left; then a void, its key retired. That scratch is released
   * from the sandbox's daemon once the void is recorded, or it threw (grade.ts releaseScratch, its header's Releasing).
   */
  const interrupted = async (c: TrialRunContext, row: TrialRow, data: JobPayload<'grade-trial'>, ctx: AgentTrialContext): Promise<AgentTrialOutcome | 'again'> => {
    const before = `live pass ${row.attempt} is voided as cut off`;
    const reaped = await sandboxReap(sandbox, ownerOf(row));
    if (reaped !== null) logReap(row, before)(reaped);
    const removed: string[] = [];
    try {
      await reapDeadScratch(row, before, null, removed);
      /** A lane's key retired: what masq metered on it, and why it could not be read. */
      const retire = async (keyId: string | null, whose: string): Promise<{ spent: bigint; note: string }> => {
        if (keyId === null) return { spent: 0n, note: '' };
        let settled = true;
        let spent = 0n;
        let note = '';
        try {
          const { retireTrialKey } = await import('./gateway/masq.ts');
          // No meter came back to check the figure against: only whether it settled is kept.
          const retired = await retireTrialKey(deps.gateway.broker, keyId, 0n, { signal: ctx.signal });
          spent = retired.spend.microUsd;
          settled = retired.settled;
        } catch (err) {
          if (ctx.signal.aborted) throw err;
          note = `; ${whose} ${keyId} could not be retired (${err instanceof Error ? err.message : String(err)}) and lapses on its own`;
        }
        if (!settled) await addRunFlags(db, row.runId, [GATEWAY_SPEND_UNSETTLED_FLAG]);
        return { spent, note };
      };
      const own = await retire(row.masqKeyId, 'its key');
      // A target's house key (the header's `house lane`): its meter is the house lane's voided spend.
      const house = await retire(row.houseMasqKeyId, 'its house key');
      const spent = own.spent;
      // An entrant's pass held no key for its entry lane (the header's `entry lane`): nothing of the house's was metered
      // there, and what it spent on the entrant's own keys is the entrant's, unmetered here (no cassette came back).
      const entrantSecrets = row.entryCredential === 'entrant' ? (row.entrySecretIds ?? []) : [];
      const ownWords =
        row.masqKeyId !== null
          ? `masq metered ${spent} µUSD on its key, counted as voided spend`
          : entrantSecrets.length > 0
            ? `its entry lane ran with its entrant's own entry secrets (entry_secret ${entrantSecrets.join(', ')}), so what it spent on a provider key there is the entrant's and unmetered here: no key of the house's to retire`
            : "its entry lane held no key of the house's (an entrant's pass, on its own keys), so nothing was metered there";
      const houseWords =
        row.houseMasqKeyId === null
          ? ''
          : row.masqKeyId === null
            ? `; masq metered ${house.spent} µUSD on its house key, counted as the house lane's voided spend`
            : `, and ${house.spent} µUSD on its house key, counted as the house lane's`;
      const started = row.liveStartedAt?.toISOString() ?? 'at an unknown time';
      // Its words redacted of every secret the cut-off pass ran with that this grader can still open (the header's `entry secrets`).
      const redact = await redactorOf(await recordedForms(c, entrantSecrets));
      // The passes cut off in a row, this one with them (the header's `cut off`): the row still tells of the pass before it.
      const inARow = liveCutOffRun(row, row.attempt - 1) + 1;
      const moved = await moveTrial(db, row, {
        status: 'void',
        liveFinishedAt: now(),
        voidReason: INTERRUPTED_VOID_REASON,
        error:
          redact(`live pass ${row.attempt}, started ${started}, was cut off before it ended (its job attempt stopped or expired) and recorded no cassette; ${ownWords}${houseWords}${own.note}${house.note}`) +
          (inARow > 1 ? cutOffRunWords(inARow) : ''),
        voidedSpendMicroUsd: row.voidedSpendMicroUsd + spent,
        voidedHouseSpendMicroUsd: row.voidedHouseSpendMicroUsd + house.spent,
      });
      return moved === null ? 'again' : voided(c, moved, data, 0);
    } finally {
      await releaseScratch(sandbox, removed);
    }
  };

  /**
   * The recorded live pass's export scored by the bundle's scorer, in the integer points the run counts (a ScorerError
   * otherwise: the competition's fault), with the per-check rows it wrote beside them (agent.ts scoreTrialWithChecks;
   * the header's `checks`): kept on the row with the score, or why a malformed checks.json was dropped, never a fault.
   * The scorer works in a scratch named for the trial's owner, which the replay's removal of a dead pass's scratch takes
   * should the grader die meanwhile; removed once it scored, it is released from the sandbox's daemon once the score is
   * recorded, or it threw (grade.ts releaseScratch, its header's Releasing). The scorer reads the export as the entry left
   * it (never masked: the header's `entry secrets`), so what it throws is redacted of the secrets the pass ran with
   * before it goes on (a held trial's error stores it).
   */
  const scorePass = async (c: TrialRunContext, row: TrialRow): Promise<void> => {
    try {
      await scorePassIn(c, row);
    } catch (err) {
      const ids = row.entryCredential === 'entrant' ? (row.entrySecretIds ?? []) : [];
      throw ids.length === 0 ? err : redactedError(err, await redactorOf(await recordedForms(c, ids)));
    }
  };

  /** scorePass's scoring, its errors as they came. */
  const scorePassIn = async (c: TrialRunContext, row: TrialRow): Promise<void> => {
    const outputs = TrialOutputs.parse(await blobJson(blobs, row.outputsSha256!, 'state export manifest'));
    const { scoreTrialWithChecks } = await import('./agent.ts');
    const dir = await ownedScratch(deps.workRoot, TRIAL_SCRATCH_PREFIX, ownerOf(row));
    const removed: string[] = [];
    try {
      let scored: TrialScored;
      try {
        scored = await scoreTrialWithChecks({ sandbox, setup: c.setup, instanceDir: instanceDirOf(row), outputs, blobs, limits: c.bundle.limits, workDir: dir });
      } finally {
        await removeScratch(sandbox, dir, removed);
      }
      const { scores } = scored;
      // aggregateTrials's own check of one trial's points: integers, and a working column of 0 or 1.
      aggregateTrials(
        [{ index: row.trialIndex, instance_sha256: row.instanceSha256, cassette_sha256: row.cassetteSha256!, state_sha256: row.stateSha256!, status: 'finished', scores, pricing_rev: 'check', requests: 0, spend_micro_usd: '0', voids: 0 }],
        c.bundle.leaderboard,
      );
      // The rows as canonical JSON (their keys in code-unit order), beside the score they were read with.
      await moveTrial(db, row, { score: scores, scoreSha256: canonicalSha256(scores), checks: scored.checks === null ? null : JSON.parse(canonicalJson(scored.checks)), checksIssue: scored.checks_issue });
    } finally {
      await releaseScratch(sandbox, removed);
    }
  };

  /**
   * The replay of the recorded live pass (from live_done, or again from an interrupted replay): finished or nondeterministic.
   * It copies the brief its live pass recorded (the header's `brief`), and a replay that copied another is a harness fault.
   * It runs with exactly the env-lane entry secrets its live pass ran with (the header's `entry secrets`): one erased
   * meanwhile voids the live pass (ENTRY_SECRETS_ERASED_VOID_REASON, a fresh one sent), and one this grader cannot open
   * holds the trial (ENTRY_SECRETS_UNOPENED_HOLD_REASON), never a replay on other values. Its outputs are scanned as the
   * live pass's were, and its words redacted of every form of those secrets.
   */
  const replay = async (c: TrialRunContext, row: TrialRow, data: JobPayload<'grade-trial'>, ctx: AgentTrialContext, cutOff: string | null = null): Promise<AgentTrialOutcome | 'again'> => {
    // Nothing claimed or networked on an engine that does not keep trials apart.
    await requireIsolation();
    // Nothing claimed while the node has no room for the replay's pods: it waits for the next slot.
    const short = await roomShort((await import('./agent.ts')).trialPods(c.harness));
    if (short !== null) return waitForRoom(c, data, short);
    const opened = await replaySecrets(c, row);
    if ('erased' in opened) {
      const at = now();
      const error = `${opened.erased}: live pass ${row.attempt} is voided, and the next runs with what its entrant holds now`;
      const moved = await moveTrial(db, row, { status: 'void', voidReason: ENTRY_SECRETS_ERASED_VOID_REASON, error, replayStartedAt: null, replayFinishedAt: null, liveFinishedAt: row.liveFinishedAt ?? at });
      return moved === null ? 'again' : voided(c, moved, data, 0);
    }
    if ('unopened' in opened) return hold(row, ENTRY_SECRETS_UNOPENED_HOLD_REASON, opened.unopened, c);
    const secrets = opened.secrets;
    const redact = await redactorOf(secrets.forms.forms.length === 0 ? null : secrets.forms);
    // A replay found cut off is counted as this one claims (replayCutOff's words), so a wait before it counts nothing.
    const claimed = await moveTrial(db, row, { status: 'replaying', replayStartedAt: now(), replayFinishedAt: null, ...(cutOff === null ? {} : { error: cutOff }) });
    if (claimed === null) return 'again';
    // What the replay removes of the trial's scratch, a dead pass's and its own, released in one go once its outcome is
    // recorded, or it threw (grade.ts releaseScratch, its header's Releasing): never before its end is read (replayFinishedAt).
    const removed: string[] = [];
    try {
      // The trial is this replay's now: what a dead grader's pass of it (or its scorer) left under the work root goes first.
      await reapDeadScratch(claimed, `the replay of live pass ${claimed.attempt}`, null, removed);
      const gateway = await forwarderOf();
      const { runTrial: runAgentTrial, NODE_CAPACITY_VOID_REASON } = await import('./agent.ts');
      const p = await inScratch(
        c,
        claimed,
        ({ botDir, workDir }) =>
          runAgentTrial({
            mode: 'replay',
            sandbox,
            snapshot: { dir: botDir, runtime: c.runtime, imageDigest: c.run.imageDigest },
            instanceDir: instanceDirOf(claimed),
            trial: trialRef(claimed),
            // The live pass's choice, never the flag as it stands now; a row recorded before the choice was replays on the flag.
            baseline: claimed.baselinePrompt ?? c.sub.baseline,
            setup: c.setup,
            limits: c.bundle.limits,
            // A target's replay serves the house lane its own cassette too, both wholly consumed (agent.ts ReplaySource).
            cassette: {
              cassette_sha256: claimed.cassetteSha256!,
              state_sha256: claimed.stateSha256!,
              ...(claimed.houseCassetteSha256 === null ? {} : { house_cassette_sha256: claimed.houseCassetteSha256 }),
            },
            // The env-lane secrets its live pass ran with: the entry's variables, and its forwarder's request mask.
            ...(Object.keys(secrets.env).length === 0 ? {} : { secrets: secrets.env }),
            gateway,
            workDir,
            blobs,
            signal: ctx.signal,
            owner: ownerOf(claimed),
            onReap: logReap(claimed, `the replay of live pass ${claimed.attempt}`),
          }),
        removed,
      ).catch((err: unknown) => {
        throw redactedError(err, redact);
      });
      // The node had no room for one of its pods (the header's `node room`): the replay's claim undone, the job sent again.
      if (p.status === 'void' && p.reason === NODE_CAPACITY_VOID_REASON) {
        const back = await moveTrial(db, claimed, { status: row.status, replayStartedAt: row.replayStartedAt, replayFinishedAt: row.replayFinishedAt, error: row.error });
        if (back === null) return 'again';
        return await waitForRoom(c, data, redact(p.error ?? 'one of its pods found none'));
      }
      // On a house clock, what the replay ran on: a run flag, as its live pass's is.
      const clockFlags = houseClockRunFlags(p, claimed.trialIndex, claimed.attempt);
      if (clockFlags.length > 0) await addRunFlags(db, claimed.runId, clockFlags);
      if (p.status === 'void') throw new TrialHarnessFault(`replay_${p.reason ?? 'void'}`, redact(`the replay of live pass ${claimed.attempt} voided (${p.reason}): ${p.error ?? 'no detail'}`));
      if (p.status !== 'finished' && p.status !== 'nondeterministic') throw new Error(`the replay of ${what(claimed)} ended ${p.status}, which no replay ends`);
      // Its outputs scanned for its secrets, never masked (the header's `entry secrets`).
      await scanOutputs(claimed, claimed.attempt, p, secrets);
      if (claimed.promptSha256 !== null && p.prompt_sha256 !== claimed.promptSha256) {
        throw new TrialHarnessFault(
          'replay_brief',
          `the replay of live pass ${claimed.attempt} copied the brief ${p.prompt_sha256 ?? 'none'} (${p.baseline_prompt ? "the instance's baseline brief" : 'input/prompt.txt'}), not the ${claimed.promptSha256} its live pass read: it replays nothing that pass did`,
        );
      }
      const done = await moveTrial(db, claimed, { ...(p.status === 'nondeterministic' ? trialEnding(p.status, redact(`${p.reason}: ${p.error}`)) : trialEnding(p.status)), replayFinishedAt: now() });
      if (done === null) return 'again';
      await poke(done);
      return { kind: 'done', status: p.status };
    } catch (err) {
      // A replay that met a fault ended (the header's `cut off`): its end recorded, so the next attempt retries it as a
      // fault, never as a replay cut off. An attempt stopped or expired writes nothing more: that one was cut off.
      if (!ctx.signal.aborted) await moveTrial(db, claimed, { replayFinishedAt: now() }).catch(() => undefined);
      throw err;
    } finally {
      await releaseScratch(sandbox, removed);
    }
  };

  /**
   * A replay found cut off (the header's `cut off`: the row replaying with no end, the attempt that ran it stopped or
   * expired, or its grader died): replayed again, which spends nothing, the replays of its live pass cut off in a row
   * counted on the row as the next claims it (replayCutOffWords); the AGENT_INTERRUPTED_RERUNS-th in a row holds the
   * trial (INTERRUPTED_VOID_REASON), its recorded live pass kept, so a re-queue replays it again.
   */
  const replayCutOff = async (c: TrialRunContext, row: TrialRow, data: JobPayload<'grade-trial'>, ctx: AgentTrialContext): Promise<AgentTrialOutcome | 'again'> => {
    const inARow = replayCutOffRun(row) + 1;
    const words = replayCutOffWords(row, inARow);
    if (inARow >= AGENT_INTERRUPTED_RERUNS) {
      return hold(row, INTERRUPTED_VOID_REASON, `${inARow} replays of live pass ${row.attempt} in a row voided, the last of ${INTERRUPTED_VOID_REASON}: ${words}`, c);
    }
    log(`[grade] ${what(row)}: the replay of live pass ${row.attempt} was cut off before it ended (${inARow} of ${AGENT_INTERRUPTED_RERUNS} in a row): it is replayed again, spending nothing`);
    return replay(c, row, data, ctx, words);
  };

  /**
   * A dev-phase trial's scored live pass, its trial's end (the header's `practice once`): finished with no replay, its
   * run flagged REPLAY_SKIPPED_FLAG in the same transaction, then the fan-in told. What a dead grader's pass of the
   * trial (or its scorer) left under the work root goes once the trial is finished, as a replay's claim would have
   * taken it, released from the sandbox's daemon in one go (grade.ts releaseScratch, its header's Releasing).
   */
  const practiceOnce = async (row: TrialRow): Promise<AgentTrialOutcome | 'again'> => {
    const done = await db.transaction(async (tx) => {
      const moved = await moveTrial(tx, row, { ...trialEnding('finished'), replayStartedAt: null, replayFinishedAt: null });
      if (moved !== null) await addRunFlags(tx, row.runId, [REPLAY_SKIPPED_FLAG]);
      return moved;
    });
    if (done === null) return 'again';
    const removed: string[] = [];
    try {
      await reapDeadScratch(done, `the end of live pass ${done.attempt}, a practice trial run once`, null, removed);
    } finally {
      await releaseScratch(sandbox, removed);
    }
    await poke(done);
    return { kind: 'done', status: 'finished' };
  };

  /**
   * A live pass about to set out from a trial with no place in the queue (record.ts `queue tags`: it woke from a deferral
   * its contest's policy made, or was made before the column): tagged afresh at max(V, F), and when this job was sent
   * ahead of that (its priority above the tag's), sent again at it under an id of this job's (one hop, a poll or so) and
   * nothing run, so a wave of deferred trials waking at once never jumps the line. Null: the pass goes on.
   */
  const queueTurn = async (c: TrialRunContext, row: TrialRow, data: JobPayload<'grade-trial'>, ctx: AgentTrialContext): Promise<AgentTrialOutcome | null> => {
    if (row.queueTag !== null) return null;
    const { tag } = await retagTrial(db, row, c.bundle.limits.wall_budget_sec);
    const priority = gradeTrialPriority(tag);
    if (ctx.priority === undefined || ctx.priority <= priority) return null;
    const jobId = await deps.jobs.send('grade-trial', data, { id: gradeTrialJobId(row.runId, row.trialIndex, data.pass, `queue:${ctx.id}`), priority, expireInSeconds: agentTrialExpirySeconds(c.bundle.limits.wall_budget_sec, c.slug) });
    log(`[grade] ${what(row)}: pass ${data.pass} takes its place in the queue afresh (tag ${tag}), behind the trials ahead of it: sent again as job ${jobId ?? '(sent already)'}`);
    return { kind: 'queued', tag, job_id: jobId };
  };

  /** Move the trial on as far as this job's pass reaches (see createAgentTrialHandler). */
  const advance = async (c: TrialRunContext, data: JobPayload<'grade-trial'>, ctx: AgentTrialContext): Promise<AgentTrialOutcome> => {
    // Each step moves the row once; a row another attempt moved meanwhile is read again.
    for (let step = 0; step < 12; step++) {
      const row = await trialRow(data);
      if (row === null) return { kind: 'stopped', why: `run ${data.run_id} has no trial ${data.trial_index}` };
      const notMine = (state: string): AgentTrialOutcome => ({ kind: 'stopped', why: `${what(row)} is ${state}: not this job's (pass ${data.pass})` });
      let next: AgentTrialOutcome | 'again';
      switch (row.status) {
        case 'finished':
        case 'timeout':
        case 'nondeterministic':
          await poke(row);
          return { kind: 'done', status: row.status };
        case 'held':
          return { kind: 'stopped', why: `${what(row)} is held (${row.voidReason}): it waits for an admin's re-queue` };
        case 'pending':
        case 'void':
          // This job's own void, its next pass maybe never sent (the send failed): sent now, or the trial held.
          if (row.status === 'void' && row.attempt === data.pass) {
            next = await voided(c, row, data, row.voidReason === INTERRUPTED_VOID_REASON ? 0 : AGENT_VOID_RERUN_DELAY_MS);
            break;
          }
          if (row.attempt !== data.pass - 1) return notMine(`${row.status} after pass ${row.attempt}`);
          {
            const turn = await queueTurn(c, row, data, ctx);
            if (turn !== null) return turn;
          }
          next = await livePass(c, row, data, ctx);
          break;
        case 'live_running':
          if (row.attempt !== data.pass) return notMine(`running pass ${row.attempt}`);
          next = await interrupted(c, row, data, ctx);
          break;
        case 'live_done':
        case 'replaying':
          if (row.attempt !== data.pass) return notMine(`${row.status} on pass ${row.attempt}`);
          if (!liveRecorded(row)) throw new PermanentJobError(`${what(row)} is ${row.status} with its live pass not whole on record`);
          // A target's pass is whole only with its house lane's cassette (what the replay serves the env again).
          if (c.harness.target !== undefined && row.houseCassetteSha256 === null) throw new PermanentJobError(`${what(row)} is ${row.status} with no house lane cassette on record, under a harness with a target`);
          if (row.score === null) {
            // The scorer is one pod: while the node has no room for it, the job waits for the next slot.
            const short = await roomShort(1);
            if (short !== null) return waitForRoom(c, data, short);
            await scorePass(c, row);
            next = 'again';
          } else if (row.status === 'replaying' && row.replayFinishedAt === null) {
            // A replay with no end found here: the attempt that ran it was cut off (a faulted one records its end).
            next = await replayCutOff(c, row, data, ctx);
          } else if (row.status === 'live_done' && c.ph.key === 'dev') {
            // A dev trial runs once (the header's `practice once`); one a release before claimed for its replay replays on.
            next = await practiceOnce(row);
          } else {
            next = await replay(c, row, data, ctx);
          }
          break;
      }
      if (next !== 'again') return next;
    }
    throw new Error(`${what({ runId: data.run_id, trialIndex: data.trial_index })} kept moving under this job; the next attempt takes it from where it stands`);
  };

  /**
   * A refused admin key (masq.ts MasqAdminKeyRefusal) or engine (network.ts IsolationRefusal): paged
   * (once an hour per refusal), the trial left as it is; a last attempt hands the job on, later.
   */
  const refused = async (data: JobPayload<'grade-trial'>, ctx: AgentTrialContext, err: MasqAdminKeyRefusal | IsolationRefusal, c: TrialRunContext, terms: RefusalTerms): Promise<void> => {
    const at = now();
    let again = '';
    if (isLastAttempt(ctx)) {
      const startAfter = new Date(at.getTime() + AGENT_REFUSAL_RETRY_MS);
      const slot = Math.ceil(startAfter.getTime() / AGENT_REFUSAL_RETRY_MS);
      try {
        await deps.jobs.send('grade-trial', data, { id: gradeTrialJobId(data.run_id, data.trial_index, data.pass, `refused:${slot}`), startAfter, ...(await sendOptions(c, { runId: data.run_id, trialIndex: data.trial_index }, 'fault')) });
        again = ` This trial's job has spent its retries and is sent again for ${startAfter.toISOString()}.`;
      } catch (e) {
        again = ` This trial's job has spent its retries, and sending it again failed (${e instanceof Error ? e.message : String(e)}): re-queue it once ${terms.once}.`;
      }
    }
    const last = refusalsPaged.get(err.message);
    if (last !== undefined && at.getTime() - last < AGENT_REFUSAL_PAGE_MS) {
      log(`[grade] ${ctx.id}: trial ${data.trial_index} of run ${data.run_id} (${c.slug}) waits on ${terms.waitsOn}: ${err.message}.${again}`);
      return;
    }
    refusalsPaged.set(err.message, at.getTime());
    page(
      `[grade] ALERT: agent/v1 grading is stopped: ${err.message}. ` +
        `Trial ${data.trial_index} of run ${data.run_id} (${c.slug}, entry ${c.sub.id}) and every other agent/v1 trial wait: nothing of theirs is marked, and each trial job tries again as it retries, so the trials run once ${terms.once}.${again}`,
    );
  };

  /** A fault no retry mended (or a PermanentJobError): the trial held, under the fault's reason, unless it moved on or is not this job's. */
  const heldOnFault = async (data: JobPayload<'grade-trial'>, err: unknown, c: TrialRunContext | null): Promise<AgentTrialOutcome | null> => {
    const reason = err instanceof TrialHarnessFault ? err.reason : err instanceof ScorerError ? 'scorer' : HARNESS_FAULT_HOLD_REASON;
    const message = err instanceof Error ? err.message : String(err);
    for (let step = 0; step < 3; step++) {
      const row = await trialRow(data);
      if (row === null || DONE_TRIAL_STATUSES.has(row.status) || row.status === 'held') return null;
      const mine = row.status === 'pending' || row.status === 'void' ? row.attempt === data.pass - 1 || row.attempt === data.pass : row.attempt === data.pass;
      if (!mine) return null;
      // A void's record is not a live pass to replay: moved out as the trial is held (voidHeld).
      const out = await hold(row, reason, `${reason === HARNESS_FAULT_HOLD_REASON ? 'a fault no retry mended' : reason} on pass ${row.attempt} (${row.status}): ${message}`, c, row.status === 'void' ? voidHeld(row) : {});
      if (out !== 'again') return out;
    }
    return null;
  };

  return async (data, ctx) => {
    let c: TrialRunContext | null = null;
    try {
      const loaded = await runContext(data);
      if ('stopped' in loaded) return { kind: 'stopped', why: loaded.stopped };
      c = loaded;
      // While a scrape heat holds this host, no pass runs beside it (the header's `scrape heat`).
      const heldBy = await scrapeHostHeldBy(deps);
      if (heldBy !== null) return await waitOutHeat(c, data, heldBy);
      // The env and the scorer as the sandbox mounts them: on the k8s sandbox their stages on the data claim (the header's
      // `k8s data`); an image that does not hold them as sealed is a PlatformFaultError, the trial held as on any fault.
      c = { ...c, setup: await agentSetupFor(sandbox, c.slug, c.setup) };
      return await advance(c, data, ctx);
    } catch (err) {
      // The attempt is over (expired, stopped): nothing more is written; the next attempt takes the trial from where it stands.
      if (ctx.signal.aborted) throw err;
      if (err instanceof (await import('./gateway/masq.ts')).MasqAdminKeyRefusal) {
        if (c !== null) await refused(data, ctx, err, c, KEY_REFUSAL).catch((e: unknown) => console.error(`[grade] ${ctx.id}: a refused admin key could not be paged:`, e));
        throw err;
      }
      if (err instanceof (await import('./sandbox/network.ts')).IsolationRefusal) {
        if (c !== null) await refused(data, ctx, err, c, engineRefusal(err.driver)).catch((e: unknown) => console.error(`[grade] ${ctx.id}: a refused engine could not be paged:`, e));
        throw err;
      }
      if (err instanceof PermanentJobError || isLastAttempt(ctx)) {
        const out = await heldOnFault(data, err, c);
        if (out !== null) return out;
      }
      throw err;
    }
  };
}

/** Who a held trial's page names: its competition, entry and phase (null when they could not be read). */
interface HeldTrialOf {
  slug: string;
  submissionId: string;
  phaseKey: string;
}

const heldTrialOf = (c: TrialRunContext | null): HeldTrialOf | null => (c === null ? null : { slug: c.slug, submissionId: c.sub.id, phaseKey: c.ph.key });

/**
 * The page of a held trial (stage.ts TRIAL_HELD_EXPECTED_MS: an admin re-queues it within the day the entrant is
 * promised); `selfAt`, when the fan-in re-queues it by itself (selfRequeueOf), says so and from when.
 */
function trialHeldPage(row: TrialRow, c: HeldTrialOf | null, selfAt: Date | null = null): string {
  const where = c === null ? `agent/v1 run ${row.runId}` : `entry ${c.submissionId}'s agent/v1 run ${row.runId} on the ${c.phaseKey} phase`;
  const resumes = liveRecorded(row) ? 'its recorded live pass is scored and replayed again' : `a fresh series of up to ${AGENT_SERIES_PASSES} live passes runs`;
  const self =
    selfAt === null
      ? ''
      : `Upstream errors come in bursts, so its run's fan-in re-queues it by itself once, at its first look from ${selfAt.toISOString()} (${TRIAL_SELF_REQUEUE_AFTER_MS / 60_000} minutes on), unless an admin does first; held again after that, it waits for an admin. `;
  return (
    `[grade] ALERT: ${c === null ? '' : `${c.slug}: `}trial ${row.trialIndex} of ${where} is held (${row.voidReason}) after live pass ${row.attempt}: ${row.error ?? 'no detail'}. ` +
    `The run waits on it unpublished, and the entry shows as held (run flag ${TRIAL_HELD_FLAG}); the fault is the platform's, never the entry's, and a re-queue is expected within a day. ` +
    self +
    `Fix: mend what failed, then re-queue the trial at POST /api/admin/runs/${row.runId}/trials/${row.trialIndex}/requeue ({"reason": "<what was mended>"}): ${resumes}`
  );
}

/**
 * Whether `runId`'s trial `trialIndex` was re-queued by itself already (the fan-in's selfRequeue): an automatic
 * trial.requeue row of it (data.automatic) whose re-queue did not end `not_sent`. A `sending` row with no ending counts
 * (its process may have died after the trial moved on), so a trial is never re-queued by itself twice.
 */
export async function selfRequeueSpent(db: Pick<Db, 'select'>, runId: string, trialIndex: number): Promise<boolean> {
  const rows = await db
    .select({ data: auditEvent.data })
    .from(auditEvent)
    .where(
      and(
        eq(auditEvent.action, TRIAL_REQUEUE_ACTION),
        eq(auditEvent.subjectType, 'run'),
        eq(auditEvent.subjectId, runId),
        sql`${auditEvent.data}->>'automatic' = 'true'`,
        sql`${auditEvent.data}->>'trial_index' = ${String(trialIndex)}`,
      ),
    );
  const stages = new Map<string, Set<string>>();
  for (const { data } of rows) {
    const d = (data ?? {}) as { attempt?: unknown; stage?: unknown };
    if (typeof d.attempt !== 'string' || typeof d.stage !== 'string') continue;
    stages.set(d.attempt, (stages.get(d.attempt) ?? new Set()).add(d.stage));
  }
  return [...stages.values()].some((s) => !s.has('not_sent'));
}

/**
 * When the fan-in may re-queue held trial `row` by itself (TRIAL_SELF_REQUEUE_AFTER_MS from its last pass's end, which
 * its series' hold follows at once): null for a trial held for any reason but UPSTREAM_ERRORS_VOID_REASON, with no pass
 * end on record, or re-queued by itself already (selfRequeueSpent), which waits for an admin.
 */
async function selfRequeueOf(db: Pick<Db, 'select'>, row: Pick<TrialRow, 'runId' | 'trialIndex' | 'status' | 'voidReason' | 'liveFinishedAt'>): Promise<Date | null> {
  if (row.status !== 'held' || row.voidReason !== UPSTREAM_ERRORS_VOID_REASON || row.liveFinishedAt === null) return null;
  if (await selfRequeueSpent(db, row.runId, row.trialIndex)) return null;
  return new Date(row.liveFinishedAt.getTime() + TRIAL_SELF_REQUEUE_AFTER_MS);
}

/**
 * Re-queue a held trial (the admins' fix for one, POST /api/admin/runs/:runId/trials/:index/requeue:
 * server/routes/admin/grading.ts registerTrialRequeue; see trialHeldPage): back to live_done when its
 * live pass is whole on record (only its replay, or its scoring, is left), else to pending, a fresh
 * series of live passes from the next one; the run's trial_held flag taken off once no trial of it is
 * held; and its job sent under `key` (the re-queue's own id: an audit row's, so each re-queue is one
 * job). Throws RangeError when the trial is not held (or does not exist); a job the queue throws on or
 * does not take puts the trial back on hold (its flag on again) and throws, so the re-queue can be
 * asked for again.
 */
export async function requeueHeldTrial(deps: { db: Db; jobs: Pick<JobQueue, 'send'> }, input: { runId: string; trialIndex: number; key: string }): Promise<{ status: 'pending' | 'live_done'; pass: number; job_id: string }> {
  const { db } = deps;
  const [row] = await db
    .select()
    .from(runTrial)
    .where(and(eq(runTrial.runId, input.runId), eq(runTrial.trialIndex, input.trialIndex)));
  if (row === undefined || row.status !== 'held') throw new RangeError(`trial ${input.trialIndex} of run ${input.runId} is ${row?.status ?? 'not there'}, not held: only a held trial is re-queued`);
  const [r] = await db.select({ phaseId: run.phaseId }).from(run).where(eq(run.id, row.runId));
  const [ph] = r === undefined ? [] : await db.select({ competitionId: phase.competitionId }).from(phase).where(eq(phase.id, r.phaseId));
  const [comp] = ph === undefined ? [] : await db.select({ slug: competition.slug, bundle: competition.bundle }).from(competition).where(eq(competition.id, ph.competitionId));
  const bundle = comp?.bundle == null ? null : CompetitionBundle.safeParse(comp.bundle);
  if (bundle === null || !bundle.success) throw new RangeError(`run ${row.runId}'s competition has no bundle that validates`);
  const status = liveRecorded(row) ? ('live_done' as const) : ('pending' as const);
  const moved = await db.transaction(async (tx) => {
    const m = await moveTrial(tx, row, { status, replayStartedAt: null, replayFinishedAt: null });
    if (m === null) return null;
    const [still] = await tx
      .select({ n: count() })
      .from(runTrial)
      .where(and(eq(runTrial.runId, row.runId), eq(runTrial.status, 'held')));
    if (Number(still?.n ?? 0) === 0) await dropRunFlag(tx, row.runId, TRIAL_HELD_FLAG);
    return m;
  });
  if (moved === null) throw new RangeError(`trial ${input.trialIndex} of run ${input.runId} moved on while it was re-queued`);
  const pass = status === 'live_done' ? row.attempt : row.attempt + 1;
  const id = gradeTrialJobId(row.runId, row.trialIndex, pass, `requeue:${input.key}`);
  /** The job not queued: the trial held again as it stood (no job will take it on), its run flagged again. */
  const putBack = async (why: string, cause?: unknown): Promise<never> => {
    const back = await db.transaction(async (tx) => {
      const b = await moveTrial(tx, moved, { status: 'held', replayStartedAt: row.replayStartedAt, replayFinishedAt: row.replayFinishedAt });
      if (b !== null) await addRunFlags(tx, row.runId, [TRIAL_HELD_FLAG]);
      return b;
    });
    const where = back === null ? 'and it moved on meanwhile, so it was not put back on hold' : 'so it is held again';
    throw new Error(`trial ${input.trialIndex} of run ${input.runId} was not re-queued: ${why}, ${where}`, cause === undefined ? undefined : { cause });
  };
  let jobId: string | null;
  try {
    jobId = await deps.jobs.send(
      'grade-trial',
      { run_id: row.runId, trial_index: row.trialIndex, pass, first_pass: pass },
      // A held trial is the platform's fault, never the entry's: it keeps its place in the queue (record.ts `queue tags`).
      { id, priority: gradeTrialPriority((await faultTrialQueueTag(db, row, bundle.data.limits.wall_budget_sec)) ?? 0), expireInSeconds: agentTrialExpirySeconds(bundle.data.limits.wall_budget_sec, comp?.slug) },
    );
  } catch (err) {
    return putBack(`the grade-trial queue could not take job ${id} (${err instanceof Error ? err.message : String(err)})`, err);
  }
  if (jobId === null) return putBack(`the grade-trial queue did not take job ${id}`);
  return { status, pass, job_id: jobId };
}

// ---------------------------------------------------------------- agent/v1: the fan-in

export interface AgentAggregateDeps {
  db: Db;
  blobs: BlobStore;
  /** Where the fan-in hands itself on while a trial is not done. */
  jobs: Pick<JobQueue, 'send'>;
  /** The entry's authorship summary (default as GradeWorkerDeps.loadAuthorship). */
  loadAuthorship?: GradeWorkerDeps['loadAuthorship'];
  /** Where a run that cannot be aggregated, and a trial whose job died, are paged (default console.error). */
  page?: (line: string) => void;
  log?: (line: string) => void;
  now?: () => Date;
}

/** A grade-aggregate job's context as its handler reads it: its id, and its attempt and retry limit (isLastAttempt). */
export type AgentAggregateContext = Pick<JobContext, 'id'> & Partial<Pick<JobContext, 'retryCount' | 'retryLimit'>>;

/** The run statuses a finished agent/v1 run is published under (publish.ts PUBLISHED_STATUS's). */
const PUBLISHED_RUN_STATUSES: ReadonlySet<string> = new Set(['finished', 'failed', 'nondeterministic', 'timeout', 'cancelled']);

/**
 * The grade-aggregate job handler (the header's `agent/v1`): the run to publish once every trial is
 * done and the run is finished (or was, by an earlier fan-in); null while it waits, handed on.
 */
export function createAgentAggregateHandler(deps: AgentAggregateDeps): (data: JobPayload<'grade-aggregate'>, ctx: AgentAggregateContext) => Promise<AggregatedRun | null> {
  const { db, blobs } = deps;
  const now = deps.now ?? (() => new Date());
  const page = deps.page ?? ((line: string) => console.error(line));
  const log = deps.log ?? ((line: string) => console.log(line));
  const loadAuthorship = deps.loadAuthorship ?? ((submissionId: string, pricingRev: string, algoVersion?: number) => loadStoredAuthorship(db, submissionId, pricingRev, algoVersion));

  /**
   * The run's trials that wait on a job pg-boss holds dead (failed for good outside its handler): held and paged, so the
   * run waits on an admin, not on nothing. One whose pass that job's last attempt was running when it died (the trial
   * live_running, or replaying with no end: its grader died, the header's `cut off`) is no fault of anyone's: its pass's
   * job is sent again instead (`wallBudgetSec` its expiry's, null when the bundle cannot be read: held as before), once
   * per cut-off pass (its start in the job id), and only while no other job of the trial is waiting or running; that job
   * voids the live pass as interrupted or replays it again, counted toward AGENT_INTERRUPTED_RERUNS as any cut-off is.
   */
  const holdDead = async (r: RunRow, open: readonly TrialRow[], slug: string, phaseKey: string, sub: string, wallBudgetSec: number | null): Promise<void> => {
    const [table] = rowsOf<{ present: boolean }>(await db.execute(sql`select to_regclass(${JOB_TABLE}) is not null as present`));
    if (table?.present !== true) return;
    for (const t of open) {
      if (t.status === 'held') continue;
      const [job] = rowsOf<{ id: string; state: string; output: unknown; data: unknown }>(
        await db.execute(
          sql`select j.id::text as id, j.state, j.output, j.data from ${sql.raw(JOB_TABLE)} j
            where j.name = ${'grade-trial'} and j.data->>'run_id' = ${r.id} and j.data->>'trial_index' = ${String(t.trialIndex)}
            order by j.created_on desc, j.id desc limit 1`,
        ),
      );
      if (job === undefined || (job.state !== 'failed' && job.state !== 'cancelled')) continue;
      const cutAt = t.status === 'live_running' ? t.liveStartedAt : t.status === 'replaying' && t.replayFinishedAt === null ? t.replayStartedAt : null;
      if (job.state === 'failed' && cutAt !== null && wallBudgetSec !== null) {
        const [busy] = rowsOf<{ n: number | string }>(
          await db.execute(
            sql`select count(*) as n from ${sql.raw(JOB_TABLE)} j
              where j.name = ${'grade-trial'} and j.data->>'run_id' = ${r.id} and j.data->>'trial_index' = ${String(t.trialIndex)} and j.state in ('created', 'retry', 'active')`,
          ),
        );
        if (Number(busy?.n ?? 0) === 0) {
          const named = (job.data as { first_pass?: unknown } | null)?.first_pass;
          const firstPass = typeof named === 'number' && Number.isSafeInteger(named) && named >= 1 && named <= t.attempt ? named : t.attempt;
          const id = gradeTrialJobId(t.runId, t.trialIndex, t.attempt, `cut-off:${cutAt.getTime()}`);
          const sent = await deps.jobs.send(
            'grade-trial',
            { run_id: t.runId, trial_index: t.trialIndex, pass: t.attempt, first_pass: firstPass },
            // A grader that died is the platform's fault: the trial keeps its place in the queue (record.ts `queue tags`).
            { id, priority: gradeTrialPriority((await faultTrialQueueTag(db, t, wallBudgetSec)) ?? 0), expireInSeconds: agentTrialExpirySeconds(wallBudgetSec, slug) },
          );
          if (sent !== null) {
            const doing = t.status === 'live_running' ? `live pass ${t.attempt}` : `the replay of live pass ${t.attempt}`;
            log(`[grade] trial ${t.trialIndex} of run ${r.id}: its job ${job.id} died for good outside its handler with ${doing} cut off (its grader died): sent again as job ${sent}, which takes it on as any cut-off pass; not held`);
            continue;
          }
          // Sent once already for this very pass, and that job died too before it moved the trial on: held, as below.
        }
      }
      const error = `its job ${job.id} is held ${job.state} by pg-boss (its last attempt expired or was stopped, outside its handler)${jobErrorOf(job.output) === null ? '' : `: ${jobErrorOf(job.output)}`}`;
      const held = await db.transaction(async (tx) => {
        const moved = await moveTrial(tx, t, { ...(t.status === 'void' ? voidHeld(t) : {}), status: 'held', voidReason: DEAD_JOB_HOLD_REASON, error });
        if (moved === null) return null;
        await addRunFlags(tx, t.runId, [TRIAL_HELD_FLAG]);
        return moved;
      });
      if (held !== null) page(trialHeldPage(held, { slug, submissionId: sub, phaseKey }));
    }
  };

  /**
   * The run's trials held for upstream errors (UPSTREAM_ERRORS_VOID_REASON: a series spent in a burst of failing
   * upstream calls, never the entry's fault) re-queued by themselves once TRIAL_SELF_REQUEUE_AFTER_MS has passed since
   * their last pass ended (selfRequeueOf), each once: through requeueHeldTrial, as an admin's re-queue (its queue tag
   * kept: record.ts faultQueueTag), under trial.requeue audit rows of its own as the admin route writes them (subject
   * the run; a `sending` row committed before anything moves, whose id is the re-queue's, then `sent` or `not_sent`),
   * naming the fan-in as their actor (data.actor TRIAL_SELF_REQUEUE_ACTOR, data.automatic true, actor null). One held
   * again after that waits for an admin, paged as any held trial is; one held for any other reason is never re-queued
   * here. A re-queue that ends not_sent (the trial moved on meanwhile, or the queue did not take its job and put it back
   * on hold) is no re-queue: the next wait slot may try again.
   */
  const selfRequeue = async (r: RunRow, open: readonly TrialRow[], who: { slug: string; competitionId: string; phaseId: string; phaseKey: string; submissionId: string }): Promise<void> => {
    for (const t of open) {
      const due = await selfRequeueOf(db, t);
      if (due === null || now().getTime() < due.getTime()) continue;
      const attempt = uuidv7();
      const reason = `${TRIAL_SELF_REQUEUE_AFTER_MS / 60_000} minutes held for upstream errors, which come in bursts: re-queued by itself once (grader/worker.ts TRIAL_SELF_REQUEUE_AFTER_MS)`;
      const record = (stage: 'sending' | 'sent' | 'not_sent', extra: Record<string, unknown> = {}) =>
        recordAudit(db, {
          ...(stage === 'sending' ? { id: attempt } : {}),
          actorUserId: null,
          action: TRIAL_REQUEUE_ACTION,
          subjectType: 'run',
          subjectId: r.id,
          at: now(),
          data: {
            competition: who.slug,
            competition_id: who.competitionId,
            submission_id: who.submissionId,
            phase: who.phaseKey,
            phase_id: who.phaseId,
            run_id: r.id,
            trial_index: t.trialIndex,
            held: { attempt: t.attempt, void_reason: t.voidReason, error: t.error },
            reason,
            attempt,
            stage,
            sent: stage === 'sent',
            automatic: true,
            actor: TRIAL_SELF_REQUEUE_ACTOR,
            ...extra,
          },
        });
      // Recorded before anything moves: one that cannot be written re-queues nothing (the caller logs it; the next slot tries again).
      await record('sending');
      let out: Awaited<ReturnType<typeof requeueHeldTrial>>;
      try {
        out = await requeueHeldTrial({ db, jobs: deps.jobs }, { runId: r.id, trialIndex: t.trialIndex, key: attempt });
      } catch (err) {
        const error = err instanceof Error ? err.message : String(err);
        await record('not_sent', { error }).catch((e: unknown) => console.error(`[grade] the ${TRIAL_REQUEUE_ACTION} row (not_sent) of re-queue ${attempt} of trial ${t.trialIndex} of run ${r.id} could not be written:`, e));
        log(`[grade] trial ${t.trialIndex} of run ${r.id}, held (${t.voidReason}), was not re-queued by itself: ${error}`);
        continue;
      }
      await record('sent', { status: out.status, pass: out.pass, job_id: out.job_id }).catch((e: unknown) =>
        console.error(`[grade] the ${TRIAL_REQUEUE_ACTION} row (sent) of re-queue ${attempt} of trial ${t.trialIndex} of run ${r.id} could not be written; its sending row stands:`, e),
      );
      log(`[grade] trial ${t.trialIndex} of run ${r.id}, held (${t.voidReason}) since live pass ${t.attempt} ended at ${t.liveFinishedAt!.toISOString()}, is re-queued by itself (${TRIAL_REQUEUE_ACTION} ${attempt}): ${out.status}, pass ${out.pass} as job ${out.job_id}; held again, it waits for an admin`);
    }
  };

  /** Look again at the end of the next wait slot: every wait landing in one slot is one job. */
  const wait = async (r: RunRow, open: readonly TrialRow[]): Promise<null> => {
    const slot = Math.ceil((now().getTime() + AGENT_AGGREGATE_WAIT_MS) / AGENT_AGGREGATE_WAIT_MS);
    const startAfter = new Date(slot * AGENT_AGGREGATE_WAIT_MS);
    await deps.jobs.send('grade-aggregate', { run_id: r.id }, { id: gradeAggregateJobId(r.id, `wait:${slot}`), startAfter });
    const by = new Map<string, number>();
    for (const t of open) by.set(t.status, (by.get(t.status) ?? 0) + 1);
    log(`[grade] run ${r.id} waits on ${open.length} trials (${[...by].map(([s, n]) => `${n} ${s}`).join(', ')}); it looks again at ${startAfter.toISOString()}`);
    return null;
  };

  // Its executions: every live pass, and a replay where one ran (a dev trial runs once: the header's `practice once`).
  const counted = (trials: readonly TrialRow[]) => ({
    exec_count: trials.reduce((s, t) => s + t.attempt + (t.replayFinishedAt === null ? 0 : 1), 0),
    wall_ms: trials.reduce((s, t) => s + (DONE_TRIAL_STATUSES.has(t.status) ? (t.wallMs ?? 0) : 0), 0),
  });

  /** Every trial done: the trials manifest, the performance, the score, and the run's verdict. */
  const finish = async (r: RunRow, sub: typeof submission.$inferSelect, bundle: CompetitionBundleT, trials: readonly TrialRow[]): Promise<void> => {
    if (r.seed === null || r.harnessVersion === null || r.scorerVersion === null) throw new PermanentJobError(`run ${r.id} was started without its seed, harness or scorer version`);
    const records: AgentTrialRecordT[] = [];
    const results: AgentTrialResult[] = [];
    const { cassetteModelCalls, readCassette } = await import('./gateway/cassette.ts');
    const target = bundle.harness.kind === 'agent/v1' && bundle.harness.target !== undefined;
    for (const t of trials) {
      if (!liveRecorded(t)) throw new PermanentJobError(`trial ${t.trialIndex} of run ${r.id} is ${t.status} with its live pass not whole on record`);
      if (target && t.houseCassetteSha256 === null) throw new PermanentJobError(`trial ${t.trialIndex} of run ${r.id} is ${t.status} with no house lane cassette on record, under a harness with a target`);
      const cassette = await readCassette(blobs, t.cassetteSha256!);
      const outputs = TrialOutputs.parse(await blobJson(blobs, t.outputsSha256!, 'state export manifest'));
      const status = t.status as AgentTrialStatusT;
      // The brief its live pass read, named when the row recorded it (a row from before that names none), and a target's
      // house lane cassette (what an L2 regrade replays beside its own).
      records.push({
        index: t.trialIndex,
        instance_sha256: t.instanceSha256,
        status,
        cassette_sha256: t.cassetteSha256!,
        state_sha256: t.stateSha256!,
        env_log_sha256: t.envLogSha256!,
        outputs,
        ...(t.promptSha256 === null ? {} : { prompt_sha256: t.promptSha256 }),
        ...(t.houseCassetteSha256 === null ? {} : { house_cassette_sha256: t.houseCassetteSha256 }),
      });
      results.push({
        index: t.trialIndex,
        instance_sha256: t.instanceSha256,
        cassette_sha256: t.cassetteSha256!,
        state_sha256: t.stateSha256!,
        status,
        scores: t.score as ProgramScores | null,
        // The rows its scorer wrote beside those scores, or why they were dropped (the header's `checks`): the breakdown's, never the score's.
        checks: t.checks as ScorerChecksT | null,
        checks_issue: t.checksIssue,
        pricing_rev: cassette.pricing_rev,
        requests: t.requests ?? cassette.totals.requests,
        // The LLM agent floor's count, off the stored cassette alone, as a regrade counts it.
        model_calls: cassetteModelCalls(cassette),
        spend_micro_usd: (t.spendMicroUsd ?? 0n).toString(),
        voids: Math.max(0, t.attempt - 1),
      });
    }
    const manifest = trialsManifest(records);
    // The harness's waivers of the floor (a target, model_calls: optional), read off it as a regrade reads them (agent-score.ts agentHarnessFloorFacts).
    const entry = { house: standingsHouse(sub), baseline: sub.baseline, ...(bundle.harness.kind === 'agent/v1' ? agentHarnessFloorFacts(bundle.harness) : {}) };
    // An entrant's trial with no model call scores 0, its store unscored (agent-score.ts agentTrialSilent).
    const performance = aggregateTrials(results, bundle.leaderboard, entry);
    // An entrant's run none of whose trials made a model call is refused whole (agent-score.ts agentModelCallRefusal), the
    // reason naming the missing key when its passes ran on no provider key (the header's `entry lane`).
    const providerIds = await providerSecretIdsOf(db, trials.flatMap((t) => t.entrySecretIds ?? []));
    const refusal = agentModelCallRefusal(results, entry, { keyless: keylessEntry(sub, trials, providerIds) });
    if (refusal !== null) {
      await finishRun(db, blobs, r.id, { status: 'failed', action_log_json: null, action_log_sha256: null, result: null, result_sha256: null, ...counted(trials), error: refusal, finished_at: now() });
      log(`[grade] entry ${sub.id}'s agent/v1 run ${r.id} is refused: ${refusal}`);
      return;
    }
    // The run's checks trace beside the performance (agent-score.ts agentChecksBreakdown; the header's `checks`): rows that
    // make none are logged with why, the run then storing none, and the score is the same as without them.
    const checks = agentChecksBreakdown(results, entry);
    const trace = checks.trace === null ? null : encodeTrace(checks.trace);
    if (checks.reason !== null) log(`[grade] entry ${sub.id}'s agent/v1 run ${r.id} stores ${checks.reason}`);
    const deterministic = agentDeterministic(performance);
    const { cost, pricingRev } = await entryCostFor({ db, blobs }, { sub, bundle, fresh: true });
    const authorship = await loadAuthorship(sub.id, pricingRev);
    const result = buildScore(
      {
        harness: { kind: 'agent/v1', version: r.harnessVersion },
        image_digest: r.imageDigest,
        dataset_sha256: r.datasetSha256,
        seed: r.seed,
        deterministic,
        execution_flags: [],
        house: standingsHouse(sub),
        baseline: sub.baseline,
      },
      { action_log_sha256: manifest.sha256, performance, performance_flags: [], cost, authorship },
      eligibilityRulesOf(bundle),
      r.scorerVersion,
    );
    const odd = trials.filter((t) => t.status === 'nondeterministic');
    // The trials the floor scored 0, named for whoever reads the run (agent-score.ts agentSilentNote).
    const silent = agentSilentNote(results, entry);
    const notes = [deterministic ? null : `${odd.length} of the run's ${trials.length} trials replayed otherwise than their live pass: ${odd.map((t) => `trial ${t.trialIndex} (${t.error ?? 'no detail'})`).join('; ')}`, silent].filter((n) => n !== null);
    await finishRun(db, blobs, r.id, {
      status: deterministic ? 'finished' : 'nondeterministic',
      action_log_json: manifest.json,
      action_log_sha256: manifest.sha256,
      result,
      result_sha256: scoreDigest(result).sha256,
      // Beside the result, never in it: buildScore never sees the trace, so result_sha256 is what it is without one.
      trace_json: trace?.json ?? null,
      trace_sha256: trace?.sha256 ?? null,
      ...counted(trials),
      error: notes.length === 0 ? null : notes.join('; '),
      finished_at: now(),
    });
    if (silent !== null) log(`[grade] entry ${sub.id}'s agent/v1 run ${r.id} is scored with silent trials: ${silent}`);
  };

  return async (data, ctx) => {
    const [r] = await db.select().from(run).where(eq(run.id, data.run_id));
    if (r === undefined) {
      log(`[grade] ${ctx.id}: run ${data.run_id} does not exist: nothing to aggregate`);
      return null;
    }
    const ph = await one(db.select().from(phase).where(eq(phase.id, r.phaseId)), `phase ${r.phaseId}`);
    const out: AggregatedRun = { run_id: r.id, submission_id: r.submissionId, phase_id: r.phaseId, phase: ph.key };
    const finalGrade = r.kind === 'grade' && ph.key === 'final';
    // Finished by an earlier fan-in: published again (publish is idempotent), in case that one's send was lost.
    if (r.status !== 'running') return r.kind === 'grade' && PUBLISHED_RUN_STATUSES.has(r.status) ? out : null;
    const sub = await one(db.select().from(submission).where(eq(submission.id, r.submissionId)), `submission ${r.submissionId}`);
    const [comp] = await db.select().from(competition).where(eq(competition.id, ph.competitionId));
    const slug = comp?.slug ?? `competition ${ph.competitionId}`;
    const trials = await loadTrials(db, r.id);
    if (sub.status === 'cancelled') {
      await finishRun(db, blobs, r.id, { status: 'cancelled', action_log_json: null, action_log_sha256: null, result: null, result_sha256: null, ...counted(trials), error: 'the entry was cancelled while its trials ran', finished_at: now() });
      if (finalGrade) await finalGradeLanded(db, ph.competitionId, log);
      return out;
    }
    const open = trials.filter((t) => !DONE_TRIAL_STATUSES.has(t.status));
    if (trials.length > 0 && open.length > 0) {
      const bundle = comp?.bundle == null ? null : CompetitionBundle.safeParse(comp.bundle);
      await holdDead(r, open, slug, ph.key, sub.id, bundle?.success === true ? bundle.data.limits.wall_budget_sec : null).catch((err: unknown) => console.error(`[grade] ${ctx.id}: run ${r.id}'s dead trial jobs could not be read; its next wait looks again:`, err));
      await selfRequeue(r, open, { slug, competitionId: ph.competitionId, phaseId: ph.id, phaseKey: ph.key, submissionId: sub.id }).catch((err: unknown) =>
        console.error(`[grade] ${ctx.id}: run ${r.id}'s trials held for upstream errors could not be re-queued by themselves; its next wait looks again:`, err),
      );
      return wait(r, open);
    }
    try {
      if (trials.length === 0) throw new PermanentJobError(`run ${r.id} has no trials`);
      const parsed = comp?.bundle == null ? null : CompetitionBundle.safeParse(comp.bundle);
      if (parsed === null || !parsed.success) throw new PermanentJobError(`${slug} has no bundle that validates`);
      if (parsed.data.harness.kind !== 'agent/v1') throw new PermanentJobError(`${slug} is a ${parsed.data.harness.kind} competition, not agent/v1`);
      await finish(r, sub, parsed.data, trials);
      // A final grade moves the live board's grades count (finalGradeLanded): the page reads /live again.
      if (finalGrade) await finalGradeLanded(db, ph.competitionId, log);
      return out;
    } catch (err) {
      if (!(err instanceof PermanentJobError) && !isLastAttempt(ctx)) throw err;
      const error = err instanceof Error ? err.message : String(err);
      const failed = await finishRun(db, blobs, r.id, { status: 'failed', action_log_json: null, action_log_sha256: null, result: null, result_sha256: null, ...counted(trials), error: `the fan-in: ${error}`, finished_at: now() });
      if (failed) {
        page(
          `[grade] ALERT: ${slug}: entry ${r.submissionId}'s agent/v1 run ${r.id} on the ${ph.key} phase could not be aggregated once its ${trials.length} trials were done: ${error}. ` +
            `The run is failed, and its publish job marks the entry failed with it; every trial's records (cassettes, state exports, scores) stay on its run_trial rows. Fix: mend what failed, then grade the entry again`,
        );
        if (finalGrade) await finalGradeLanded(db, ph.competitionId, log);
      }
      return out;
    }
  };
}

// ---------------------------------------------------------------- the hindsight audit

/** The HKDF label of an audit's master seed (hindsightSeedMaster). */
export const HINDSIGHT_SEED_LABEL = 'agent-fun/hindsight-audit/v1 master';

/**
 * The prefix of a hindsight audit's scratch under the work root: `hindsight-<owner>-XXXXXX`, its owner its job's
 * (regradeOwner of the job's id; regrade.ts ownedScratch), which the job's next attempt removes should its grader die
 * (regrade.ts reapScratch), and the workers' start (server/pipeline/index.ts sweepDeadWork) only once all three hold
 * (removeIfDead): no active job on the start's database holds its owner, no one has touched it for six hours (its
 * newest change, its own or a direct entry's, older than grader/sandbox/network.ts STALE_AFTER_MS), and no live process
 * holds it open or as its cwd (processesHolding); one younger, held or not to be asked about is kept and logged.
 */
export const HINDSIGHT_SCRATCH_PREFIX = 'hindsight-';

/**
 * The master secret an audit's surrogate seeds derive from (grader/hindsight-audit.ts auditSeeds):
 * hex of HKDF-SHA256(ikm = the fail-key secret, salt = empty, info = label 0x00 kind 0x00 entry 0x00
 * run 0x00 appeal attempt), 32 bytes. Fixed for one entry, run and kind (a retried job rebuilds the
 * same surrogates), another for the appeal; without the secret nothing predicts it.
 */
export function hindsightSeedMaster(secret: string, kind: HindsightAuditKind, submissionId: string, runId: string, attempt: string | null): string {
  if (secret.length === 0) throw new RangeError('the fail-key secret is empty');
  return Buffer.from(hkdfSync('sha256', secret, Buffer.alloc(0), `${HINDSIGHT_SEED_LABEL}\0${kind}\0${submissionId}\0${runId}\0${attempt ?? ''}`, 32)).toString('hex');
}

export interface HindsightAuditDeps {
  db: Db;
  blobs: BlobStore;
  sandbox: Sandbox;
  /** Existing directory for each audit's scratch directory (the snapshot and the surrogates). */
  workRoot: string;
  /** Where the sweep sends each entry's job. */
  jobs: Pick<JobQueue, 'send'>;
  /**
   * The server secret (config.betterAuthSecret): a server-secret/v1 run's fail key when it kept none, and the audit
   * seeds on either scheme (hindsightSeedMaster; default as GradeWorkerDeps.failKeySecret).
   */
  failKeySecret?: string;
  /** A phase-secret+beacon/v1 run's fail key when it kept none (phaseFailKey): the competition's directory, holding its sealed-window.yaml (default competitions/<slug>, as GradeWorkerDeps.competitionDir). */
  competitionDir?(slug: string): string;
  /** That key's draw record is <sealedDir>/<slug>/draw.json (default as GradeWorkerDeps.sealedDir). */
  sealedDir?: string;
  /** The drand chain that draw's beacon may name besides quicknet (default as GradeWorkerDeps.drandChain). */
  drandChain?: DrandChain;
  /** A relative dataset path resolves against this (default the project root, as the grader's dataset loader). */
  datasetRoot?: string;
  /** The check's parameters (default CHEAT_CHECK; a test hands in a copy). */
  check?: CheatCheck;
  /** The audit (default grader/hindsight-audit.ts auditEntry). */
  audit?: (o: AuditOptions) => Promise<HindsightAuditRecordT>;
  /** Surrogate runs at once within one audit (default 1). */
  concurrency?: number;
  now?: () => Date;
  log?: (line: string) => void;
  /** Where an entry job that died for good is paged, one line each (the header's `dead`), and a fail key that cannot be derived (the header's `fail key`; default console.error, as the chain sync pages). */
  page?: (line: string) => void;
  /** The host's scrape lease, which an entry's audit runs nothing beside (the header's `one entry`; default scrapeLeaseDirFromEnv(), as GradeWorkerDeps.scrape's). */
  scrape?: Pick<ScrapeWorkerDeps, 'leaseDir'>;
  /**
   * This server's cluster (config.solanaCluster), on which the sweep and a dead job's page read the audit targets'
   * standings escrowed or not (server/routes/admin/hindsight.ts hindsightTargets, prizesEscrowed: with no escrow an
   * unsigned entry is paid, so audited); absent, an escrow of the competition on any cluster.
   */
  cluster?: SolanaCluster;
  /**
   * How an entry's audit re-opens the env-lane entry secrets its run recorded (the header's `one entry`): the grader's
   * seal settings, whose private keys open them (default the environment's, as GradeWorkerDeps.entrySecrets; read only
   * for a run that recorded some).
   */
  entrySecrets?: Pick<AgentEntrySecretDeps, 'seal'>;
}

/** An entry job that died for good, paged (subject the submission; once per job: the header's `dead`). */
export const HINDSIGHT_AUDIT_DEAD_ACTION = 'hindsight.audit_dead' satisfies AuditAction;

/** What one hindsight-audit job did (the handler logs it; tests read it). */
export type HindsightAuditOutcome =
  | { kind: 'skipped'; why: string }
  | { kind: 'grading'; awaiting: string[] }
  | {
      kind: 'swept';
      targets: number;
      sent: { submission_id: string; kind: HindsightAuditKind; job_id: string; queued: boolean }[];
      /** The dead audit jobs this sweep paged (the header's `dead`): none it or a job's handler paged before. */
      paged: { submission_id: string; job_id: string }[];
    }
  | { kind: 'recorded'; submission_id: string; audit: HindsightAuditKind; record_sha256: string; flagged: boolean; check: 'pass' | 'fail' | 'skip' | null; already: boolean }
  /** A scrape heat held the host (scrapeHostHeldBy, `held_by` its words): nothing run, the job sent again for the next recheck slot (the header's `one entry`). */
  | { kind: 'waiting'; submission_id: string; audit: HindsightAuditKind; until: Date; job_id: string | null; held_by: string };

/**
 * A hindsight-audit job's context as the runner reads it: its id, its attempt and retry limit (a job dies for good on
 * its last: isLastAttempt; without them no attempt is the last), and the attempt's signal, which stops an entry's audit
 * once pg-boss gives the attempt up (the header's `one entry`; without one the audit is never stopped).
 */
export type HindsightJobContext = Pick<JobContext, 'id'> & Partial<Pick<JobContext, 'retryCount' | 'retryLimit' | 'signal'>>;

/** An entry job that died for good, as its page names it (the header's `dead`). */
interface DeadEntryJob {
  comp: { id: string; slug: string };
  final: { id: string; endsAt: Date | null };
  submissionId: string;
  runId: string;
  kind: HindsightAuditKind;
  /** The audit target's rank on the final phase's board; null for an appeal. */
  rank: number | null;
  /** The appeal's attempt; null for an audit. */
  attempt: string | null;
  jobId: string;
  /** How it died, in the page's words ("was refused for good ...", "failed its last attempt (3 of 3)", "is held failed by pg-boss since ..."). */
  how: string;
  error: string | null;
  /** Who found it dead: the job's own handler, or a sweep. */
  found: 'handler' | 'sweep';
}

/** The page of a dead entry job at `at` (the header's `dead`): what died, why finalize waits on it, and the verdict that lets finalize through. */
function deadJobPage(d: DeadEntryJob, at: Date): string {
  const route = `POST /api/admin/submissions/${d.submissionId}/hindsight ({"verdict": "clear" or "disqualify", "reason": "..."})`;
  const ends = d.final.endsAt;
  const ended = ends !== null && ends.getTime() <= at.getTime();
  const died = `job ${d.jobId} ${d.how}${d.error === null ? '' : `: ${d.error}`}`;
  // A verdict past a dead job (this one) stays open past ends_at, until finalize (admin/hindsight.ts): said when ends_at has passed.
  const still = (what: string) => (ended ? `. The final phase ended at ${ends.toISOString()}, and that route still takes this verdict (${what}) until the final phase is finalized` : '');
  if (d.kind === 'audit') {
    return (
      `[hindsight] ALERT: ${d.comp.slug}: the hindsight audit of entry ${d.submissionId} (run ${d.runId}, ranked ${d.rank} on the final phase) died for good, ${died}. ` +
      `No audit record will come, so the entry carries no hindsight_clean, and finalize of ${d.comp.slug}'s final phase is refused until it does. ` +
      `Fix: give a verdict at ${route} before the final phase is finalized; it is given with no audit record, and finalize waits for the entry no more${still('with no audit record')}`
    );
  }
  return (
    `[hindsight] ALERT: ${d.comp.slug}: the re-run of entry ${d.submissionId}'s appeal (attempt ${d.attempt}, run ${d.runId}) died for good, ${died}. ` +
    `The appeal waits for a re-run that will not record, so finalize of ${d.comp.slug}'s final phase is refused while it waits. ` +
    `Fix: decide the appeal without it, with a verdict at ${route} before the final phase is finalized; a refused finalize sends the re-run again, should its numbers be wanted first${still('the appeal decided without its re-run')}`
  );
}

/** The hindsight-audit job handler (see the header). */
export function createHindsightAuditHandler(deps: HindsightAuditDeps): JobHandler<'hindsight-audit'> {
  const runner = createHindsightAuditRunner(deps);
  return async (data, ctx) => {
    await runner(data, ctx);
  };
}

/** The handler's body, answering what it did (and paging an entry job that dies for good: the header's `dead`). */
export function createHindsightAuditRunner(deps: HindsightAuditDeps): (data: JobPayload<'hindsight-audit'>, ctx: HindsightJobContext) => Promise<HindsightAuditOutcome> {
  const { db, blobs } = deps;
  const check = deps.check ?? CHEAT_CHECK;
  const audit = deps.audit ?? auditEntry;
  const now = deps.now ?? (() => new Date());
  const log = deps.log ?? ((line: string) => console.log(line));
  const page = deps.page ?? ((line: string) => console.error(line));
  const failKeyPaged = failKeyPager({ page, log, now }, '[hindsight]');
  const sealOf = entrySecretSealOf(deps);
  const root = deps.datasetRoot ?? PROJECT_ROOT;
  /** The scan's index per (source, background) window pair, the two latest kept. */
  const indexes = new Map<string, Promise<HindsightIndex>>();
  const indexOf = (source: DatasetRow, background: DatasetRow | null): Promise<HindsightIndex> => {
    const key = `${source.sha256}\0${background?.sha256 ?? ''}`;
    const hit = indexes.get(key);
    if (hit !== undefined) return hit;
    const building = (async () => {
      const src = loadHindsightSource(resolve(root, source.path), background === null ? [] : [resolve(root, background.path)]);
      return buildHindsightIndex(src, check);
    })();
    indexes.set(key, building);
    building.catch(() => {
      if (indexes.get(key) === building) indexes.delete(key);
    });
    while (indexes.size > 2) indexes.delete(indexes.keys().next().value!);
    return building;
  };
  // The rules' module is loaded on the first job: it reaches the leaderboard's code, which nothing else here needs.
  const rules = () => import('../server/routes/admin/hindsight.ts');

  const sweep = async (phaseId: string, ctx: Pick<JobContext, 'id'>): Promise<HindsightAuditOutcome> => {
    const hs = await rules();
    const [ph] = await db.select().from(phase).where(eq(phase.id, phaseId));
    if (ph === undefined) return { kind: 'skipped', why: `phase ${phaseId} does not exist` };
    const [comp] = await db.select().from(competition).where(eq(competition.id, ph.competitionId));
    const bundle = comp?.bundle == null ? null : CompetitionBundle.safeParse(comp.bundle);
    if (comp === undefined || bundle === null || !bundle.success || bundle.data.harness.kind !== 'pumpfun-replay/v2') return { kind: 'skipped', why: `phase ${phaseId} is not a replay competition's` };
    if ((await hs.drawnFinal(db, comp, ph)) === null) return { kind: 'skipped', why: `the ${ph.key} phase of ${comp.slug} does not score a drawn sealed window` };
    const t = await hs.hindsightTargets(db, comp, bundle.data, ph, check, deps.cluster);
    if (t.awaiting.length > 0) {
      log(`[hindsight] ${ctx.id}: ${comp.slug}'s final phase is still grading (${t.awaiting.length} entries): no audit yet`);
      return { kind: 'grading', awaiting: t.awaiting };
    }
    const at = now();
    const sent: Extract<HindsightAuditOutcome, { kind: 'swept' }>['sent'] = [];
    for (const target of t.unchecked) {
      const id = hindsightAuditJobId(target.submission_id, target.run_id, 'audit', at);
      const queued = await deps.jobs.send('hindsight-audit', { submission_id: target.submission_id, run_id: target.run_id, kind: 'audit' }, { id });
      sent.push({ submission_id: target.submission_id, kind: 'audit', job_id: id, queued: queued !== null });
    }
    for (const target of t.targets) {
      const h = await hs.hindsightHistoryOf(db, target.submission_id);
      for (const a of h.appeals) {
        if (h.records.some((r) => r.kind === 'appeal' && r.attempt === a.attempt)) continue;
        const id = hindsightAuditJobId(target.submission_id, a.run_id, 'appeal', at, a.attempt);
        const queued = await deps.jobs.send('hindsight-audit', { submission_id: target.submission_id, run_id: a.run_id, kind: 'appeal' }, { id });
        sent.push({ submission_id: target.submission_id, kind: 'appeal', job_id: id, queued: queued !== null });
      }
    }
    // After the sends: a target the day's send could not queue again (its id held by the dead job)
    // still has the dead job as its latest, which is what lets a verdict past it (deadAuditOf).
    const paged: { submission_id: string; job_id: string }[] = [];
    try {
      for (const target of t.unchecked) {
        const job = await hs.latestAuditJobOf(db, target.submission_id, target.run_id);
        if (job === null || job.state !== 'failed') continue;
        const dead: DeadEntryJob = {
          comp,
          final: ph,
          submissionId: target.submission_id,
          runId: target.run_id,
          kind: 'audit',
          rank: target.rank,
          attempt: null,
          jobId: job.id,
          how: `is held failed by pg-boss since ${(job.completed_on ?? job.created_on).toISOString()} (its retries spent, or refused for good)`,
          error: job.error,
          found: 'sweep',
        };
        if (await pageDead(dead)) paged.push({ submission_id: target.submission_id, job_id: job.id });
      }
      // And every appeal still waiting whose latest re-run job died outside its handler (an appeal job names no
      // attempt: the run's latest appeal job is the latest filing's, or a refused finalize's resend of it).
      for (const a of t.appeals) {
        const job = await hs.latestAuditJobOf(db, a.submission_id, a.run_id, 'appeal');
        if (job === null || job.state !== 'failed') continue;
        const dead: DeadEntryJob = {
          comp,
          final: ph,
          submissionId: a.submission_id,
          runId: a.run_id,
          kind: 'appeal',
          rank: null,
          attempt: a.attempt,
          jobId: job.id,
          how: `is held failed by pg-boss since ${(job.completed_on ?? job.created_on).toISOString()} (its retries spent, or refused for good)`,
          error: job.error,
          found: 'sweep',
        };
        if (await pageDead(dead)) paged.push({ submission_id: a.submission_id, job_id: job.id });
      }
    } catch (err) {
      log(`[hindsight] ${ctx.id}: ${comp.slug}'s dead audit jobs could not be read to page them: ${err instanceof Error ? err.message : String(err)}`);
      console.error(`[hindsight] ${ctx.id}: ${comp.slug}'s dead audit jobs could not be read to page them; the next sweep looks again:`, err);
    }
    log(`[hindsight] ${ctx.id}: ${comp.slug}'s final phase: ${t.targets.length} audit targets, ${t.unchecked.length} unchecked, ${t.appeals.length} appeals waiting; ${sent.length} jobs sent${paged.length === 0 ? '' : `; ${paged.length} dead audit or appeal jobs paged`}`);
    return { kind: 'swept', targets: t.targets.length, sent, paged };
  };

  const auditOne = async (data: { submission_id: string; run_id: string; kind: HindsightAuditKind }, ctx: HindsightJobContext): Promise<HindsightAuditOutcome> => {
    // The job's owner, the same on each of its attempts: before anything else, what an attempt of it that died left
    // goes (the header's `one entry`).
    const owner = regradeOwner(ctx.id);
    const reaped = scratchReapLine(
      `the hindsight ${data.kind} of submission ${data.submission_id} (run ${data.run_id}, job ${ctx.id})`,
      `attempt ${(ctx.retryCount ?? 0) + 1}`,
      await reapScratch(deps.sandbox, deps.workRoot, HINDSIGHT_SCRATCH_PREFIX, owner),
      'hindsight',
    );
    if (reaped !== null) log(reaped);
    const hs = await rules();
    const sub = await one(db.select().from(submission).where(eq(submission.id, data.submission_id)), `submission ${data.submission_id}`);
    const r = await one(db.select().from(run).where(eq(run.id, data.run_id)), `run ${data.run_id}`);
    if (r.submissionId !== sub.id || r.kind !== 'grade') throw new PermanentJobError(`run ${r.id} is not a grade run of submission ${sub.id}`);
    const ph = await one(db.select().from(phase).where(eq(phase.id, r.phaseId)), `phase ${r.phaseId}`);
    const comp = await one(db.select().from(competition).where(eq(competition.id, ph.competitionId)), `competition ${ph.competitionId}`);
    const parsed = comp.bundle === null ? null : CompetitionBundle.safeParse(comp.bundle);
    if (parsed === null || !parsed.success) throw new PermanentJobError(`competition ${comp.slug} has no bundle that validates`);
    const bundle = parsed.data;
    if (bundle.harness.kind !== 'pumpfun-replay/v2') throw new PermanentJobError(`${comp.slug} is not a replay competition: the hindsight check re-runs a replay entry`);
    const drawn = await hs.drawnFinal(db, comp, ph);
    if (drawn === null) throw new PermanentJobError(`run ${r.id} is on the ${ph.key} phase of ${comp.slug}, which does not score a drawn sealed window`);
    const score = r.status === 'finished' ? Score.safeParse(r.result) : null;
    const net = score?.success ? hs.netPnlOf(score.data) : null;
    if (net === null) throw new PermanentJobError(`run ${r.id} is ${r.status} with no replay score: only a finished run is audited`);
    if (r.seed === null) throw new PermanentJobError(`run ${r.id} recorded no seed`);

    const history = await hs.hindsightHistoryOf(db, sub.id);
    let attempt: string | null = null;
    if (data.kind === 'audit') {
      if (history.records.some((x) => x.kind === 'audit' && x.run_id === r.id) && hs.hindsightCheckOf(sub.checks) !== null) {
        return { kind: 'skipped', why: `run ${r.id} of submission ${sub.id} is audited already` };
      }
    } else {
      const open = history.appeals.find((a) => a.run_id === r.id && !history.records.some((x) => x.kind === 'appeal' && x.attempt === a.attempt));
      if (open === undefined) return { kind: 'skipped', why: `submission ${sub.id} has no appeal awaiting its re-run` };
      attempt = open.attempt;
    }

    // While a scrape heat holds this host, the audit runs nothing beside it: handed on to the next recheck slot (the header's `one entry`).
    const heldBy = await scrapeHostHeldBy(deps);
    if (heldBy !== null) {
      const slot = scrapeHostRecheckSlot(now().getTime());
      const until = new Date(slot * SCRAPE_HOST_RECHECK_MS);
      const jobId = await deps.jobs.send('hindsight-audit', data, { id: hindsightAuditWaitJobId(sub.id, r.id, data.kind, slot), startAfter: until });
      log(`[hindsight] ${ctx.id}: the ${data.kind} of submission ${sub.id} (run ${r.id}) waits for ${until.toISOString()}: ${heldBy}, and nothing else grades here while a heat runs`);
      return { kind: 'waiting', submission_id: sub.id, audit: data.kind, until, job_id: jobId, held_by: heldBy };
    }

    const masked = await one(db.select().from(dataset).where(eq(dataset.id, ph.datasetId!)), `dataset ${ph.datasetId}`);
    if (r.datasetSha256 !== null && r.datasetSha256 !== masked.sha256) throw new PermanentJobError(`run ${r.id} was graded on dataset ${r.datasetSha256}, not the final phase's ${masked.sha256}`);
    const source = await one(db.select().from(dataset).where(eq(dataset.id, drawn.source_dataset_id)), `dataset ${drawn.source_dataset_id} (the drawn window's source)`);
    const [dev] = await db.select().from(phase).where(and(eq(phase.competitionId, comp.id), eq(phase.key, 'dev')));
    const background = dev?.datasetId == null ? null : ((await db.select().from(dataset).where(eq(dataset.id, dev.datasetId)))[0] ?? null);
    if (sub.snapshotSha256 === null) throw new PermanentJobError(`submission ${sub.id} has no snapshot`);
    const index = await readSnapshotIndex(blobs, sub.snapshotSha256);
    const picked = entryRuntime(index, bundle.harness.runtimes);
    if ('error' in picked) throw new PermanentJobError(`submission ${sub.id}: ${picked.error}`);
    // The env-lane entry secrets the run ran the entry with, re-opened as an L2 re-opens them (the header's `entry
    // secrets`): every surrogate run gets them, or none runs. One erased since cannot run it as it was graded.
    const recorded = await recordedEnvSecrets(db, sealOf, { userId: sub.userId, competitionId: comp.id }, r.entrySecretIds);
    if (recorded.erased !== null) {
      throw new PermanentJobError(
        `the hindsight ${data.kind} of submission ${sub.id}: run ${r.id} ran the entry with an env-lane entry secret that is erased since (replaced, deleted or purged): ${recorded.erased}, so no surrogate can run it as it was graded`,
      );
    }
    if (recorded.kind === 'unopened') {
      throw new Error(`the hindsight ${data.kind} of submission ${sub.id}: the env-lane entry secrets run ${r.id} ran the entry with cannot be opened here, so no surrogate runs it without them (the job tries again): ${recorded.why}`);
    }
    const entrySecrets = recorded.secrets.ids.length === 0 ? {} : { secrets: recorded.secrets.env };
    const secretForms = entrySecretForms(recorded.secrets.env);
    const secret = deps.failKeySecret ?? (await defaultFailKeySecret());
    // The run's own key; else derived again as grading derives it, by the phase's scheme (the header's `fail key`).
    const seed = r.seed;
    const failKey =
      r.failKey ??
      (await failKeyPaged(`${comp.slug}: the hindsight ${data.kind} of submission ${sub.id} (run ${r.id})`, () =>
        phaseFailKey({
          phase: ph,
          slug: comp.slug,
          seed,
          datasetSha256: masked.sha256,
          compDir: competitionDirOf(deps, comp.slug, bundle.harness),
          sealedDir: deps.sealedDir ?? sealedDirFromEnv(),
          chain: instanceChainOptions(deps.drandChain),
          serverSecret: () => secret,
        }),
      ));
    // The entrant's own wallets, which the scan never counts as hits: its entry wallets (an agent wallet signs its entries too) and its payout wallet.
    const wallets = await entryWallets(db, sub.userId);
    if (sub.payoutWallet !== null && !wallets.includes(sub.payoutWallet)) wallets.push(sub.payoutWallet);
    const scanIndex = await indexOf(source, background);

    // The attempt's signal stops the audit once pg-boss gives the attempt up (the header's `one entry`): given up
    // already, nothing is materialized or run.
    const signal = ctx.signal;
    signal?.throwIfAborted();
    const dir = await ownedScratch(deps.workRoot, HINDSIGHT_SCRATCH_PREFIX, owner);
    const botDir = join(dir, 'bot');
    // The audit's scratch, removed once it ran, released from the sandbox's daemon once its record is kept, or it threw
    // (grade.ts releaseScratch, its header's Releasing): a release never stands between the audit and its record, where
    // an attempt given up meanwhile would record nothing.
    const removed: string[] = [];
    try {
      let record: HindsightAuditRecordT;
      try {
        await materializeSnapshot(index, blobs, botDir);
        record = await audit({
          // Bound to the signal (grade.ts stoppableSandbox): its abort kills the replay running, and no later one starts.
          sandbox: stoppableSandbox(deps.sandbox, signal),
          runtime: picked.runtime,
          botDir,
          harness: bundle.harness,
          limits: bundle.limits,
          real: { dataset: resolve(root, masked.path), dataset_sha256: masked.sha256, seed: r.seed, failKey, net_pnl_lamports: net },
          source: scanIndex,
          ignoreAddresses: wallets,
          m: data.kind === 'audit' ? check.m : check.appeal_m,
          seeds: hindsightSeedMaster(secret, data.kind, sub.id, r.id, attempt),
          check,
          workDir: join(dir, 'work'),
          concurrency: deps.concurrency ?? 1,
          label: `hindsight-${sub.id.slice(0, 8)}`,
          imageDigest: r.imageDigest,
          ...entrySecrets,
        });
      } catch (err) {
        // Given up: whatever the stopped audit threw is the stop's doing, so the signal's reason (retried, never permanent).
        if (signal?.aborted === true) throw signal.reason;
        // Whatever else it threw says none of the secrets it ran with (the header's `entry secrets`): a dead job's page quotes it.
        redactThrown(err, secretForms);
        if (err instanceof AuditError) throw new PermanentJobError(`the hindsight ${data.kind} of submission ${sub.id}: ${err.message} (${err.code})`, { cause: err });
        throw err;
      } finally {
        await removeMaterialized(botDir).catch(() => undefined);
        await removeScratch(deps.sandbox, dir, removed);
      }
      // An attempt given up records nothing, however far its audit got (a killed replay reads as a failed copy): its
      // retry audits again, and records once.
      signal?.throwIfAborted();
      const verified = checkAuditRecord(record, check);
      if (!verified.ok) throw new PermanentJobError(`the hindsight ${data.kind} of submission ${sub.id} made a record that does not check: ${verified.problems.join('; ')}`);
      const kept = await hs.recordHindsightAudit(db, blobs, { comp, phaseId: ph.id, submissionId: sub.id, runId: r.id, kind: data.kind, attempt, record, at: now(), check });
      log(
        `[hindsight] ${ctx.id}: ${comp.slug} submission ${sub.id} ${data.kind} on ${record.m} + ${record.m} copies: ${record.verdict.flagged ? `flagged (${record.verdict.reasons.length} reasons)` : 'not flagged'}; record ${kept.record_sha256}${kept.check === null ? '' : `, hindsight_clean ${kept.check.status}`}`,
      );
      return { kind: 'recorded', submission_id: sub.id, audit: data.kind, record_sha256: kept.record_sha256, flagged: record.verdict.flagged, check: kept.check?.status ?? null, already: kept.already };
    } finally {
      await releaseScratch(deps.sandbox, removed);
    }
  };

  /**
   * Page `d` unless it was paged before (the header's `dead`): its HINDSIGHT_AUDIT_DEAD_ACTION row,
   * written under the submission row's lock unless one names the job already, then the line. True
   * when this call paged it. A row that cannot be written is logged with its stack, and the page
   * stands (a later sweep may page the job again).
   */
  const pageDead = async (d: DeadEntryJob): Promise<boolean> => {
    const at = now();
    const line = deadJobPage(d, at);
    let fresh = true;
    try {
      fresh = await db.transaction(async (tx) => {
        await tx.select({ id: submission.id }).from(submission).where(eq(submission.id, d.submissionId)).for('update');
        const [seen] = await tx
          .select({ id: auditEvent.id })
          .from(auditEvent)
          .where(and(eq(auditEvent.action, HINDSIGHT_AUDIT_DEAD_ACTION), eq(auditEvent.subjectType, 'submission'), eq(auditEvent.subjectId, d.submissionId), sql`${auditEvent.data}->>'job_id' = ${d.jobId}`))
          .limit(1);
        if (seen !== undefined) return false;
        await recordAudit(tx, {
          actorUserId: null,
          action: HINDSIGHT_AUDIT_DEAD_ACTION,
          subjectType: 'submission',
          subjectId: d.submissionId,
          at,
          data: {
            competition: d.comp.slug,
            competition_id: d.comp.id,
            phase_id: d.final.id,
            run_id: d.runId,
            kind: d.kind,
            attempt: d.attempt,
            rank: d.rank,
            job_id: d.jobId,
            how: d.how,
            error: d.error,
            found: d.found,
            ends_at: d.final.endsAt?.toISOString() ?? null,
            page: line,
          },
        });
        return true;
      });
    } catch (err) {
      console.error(`[hindsight] the ${HINDSIGHT_AUDIT_DEAD_ACTION} row of job ${d.jobId} (submission ${d.submissionId}) could not be written; the page below stands, and a later sweep may page it again:`, err);
    }
    if (!fresh) return false;
    page(line);
    return true;
  };

  /**
   * An entry job dying for good with `err` (the header's `dead`): paged when its entry holds
   * finalize up on it, an unchecked audit target on that run with no newer audit job held (an
   * audit) or an appeal waiting for that re-run (an appeal); otherwise logged, with why not.
   */
  const dying = async (data: { submission_id: string; run_id: string; kind: HindsightAuditKind }, ctx: HindsightJobContext, err: unknown): Promise<void> => {
    // isLastAttempt knows both; a PermanentJobError may come with neither.
    const n = ctx.retryCount === undefined ? null : `${ctx.retryCount + 1}${ctx.retryLimit === undefined ? '' : ` of ${ctx.retryLimit + 1}`}`;
    const how = err instanceof PermanentJobError ? `was refused for good${n === null ? '' : ` on attempt ${n}`} (no retry can help)` : `failed its last attempt${n === null ? '' : ` (${n})`}`;
    const error = err instanceof Error ? err.message : String(err);
    const notPaged = (why: string): void => log(`[hindsight] ${ctx.id}: the ${data.kind} job of submission ${data.submission_id} (run ${data.run_id}) ${how}: ${error}; not paged: ${why}`);
    const hs = await rules();
    const [sub] = await db.select({ id: submission.id }).from(submission).where(eq(submission.id, data.submission_id));
    const [r] = sub === undefined ? [] : await db.select({ submissionId: run.submissionId, phaseId: run.phaseId }).from(run).where(eq(run.id, data.run_id));
    if (sub === undefined || r === undefined || r.submissionId !== sub.id) return notPaged(`no run ${data.run_id} of a submission ${data.submission_id} exists to decide`);
    const [ph] = await db.select().from(phase).where(eq(phase.id, r.phaseId));
    const [comp] = ph === undefined ? [] : await db.select().from(competition).where(eq(competition.id, ph.competitionId));
    const bundle = comp?.bundle == null ? null : CompetitionBundle.safeParse(comp.bundle);
    if (ph === undefined || comp === undefined || bundle === null || !bundle.success || bundle.data.harness.kind !== 'pumpfun-replay/v2' || (await hs.drawnFinal(db, comp, ph)) === null) {
      return notPaged(`run ${data.run_id} is on no drawn sealed window's final phase, which is all finalize waits on`);
    }
    const t = await hs.hindsightTargets(db, comp, bundle.data, ph, check, deps.cluster);
    if (t.awaiting.length > 0) return notPaged(`${comp.slug}'s final phase is grading again; the sweep sent once it settles pages the entry if its latest audit job is still dead`);
    const dead = { comp, final: ph, submissionId: sub.id, runId: data.run_id, kind: data.kind, jobId: ctx.id, how, error, found: 'handler' as const };
    if (data.kind === 'audit') {
      const target = t.unchecked.find((x) => x.submission_id === sub.id && x.run_id === data.run_id);
      if (target === undefined) return notPaged(`the entry is no audit target lacking hindsight_clean on run ${data.run_id}, so finalize does not wait on it`);
      const latest = await hs.latestAuditJobOf(db, sub.id, data.run_id);
      if (latest !== null && latest.id !== ctx.id) return notPaged(`a newer audit job of the run, ${latest.id}, is the one a verdict waits for (paged in turn should it die)`);
      await pageDead({ ...dead, rank: target.rank, attempt: null });
      return;
    }
    const waiting = t.appeals.find((a) => a.submission_id === sub.id && a.run_id === data.run_id);
    if (waiting === undefined) return notPaged('no appeal of the entry waits for this re-run');
    const latest = await hs.latestAuditJobOf(db, sub.id, data.run_id, 'appeal');
    if (latest !== null && latest.id !== ctx.id) return notPaged(`a newer re-run job of the appeal, ${latest.id}, is the one a verdict past the end waits for (paged in turn should it die)`);
    await pageDead({ ...dead, rank: null, attempt: waiting.attempt });
  };

  return async (data, ctx) => {
    if ('phase_id' in data) return sweep(data.phase_id, ctx);
    try {
      return await auditOne(data, ctx);
    } catch (err) {
      // Dying for good (pg-boss retries it no more): paged, then the job's own error stands.
      if (err instanceof PermanentJobError || isLastAttempt(ctx)) {
        await dying(data, ctx, err).catch((e: unknown) => {
          log(`[hindsight] ${ctx.id}: submission ${data.submission_id}'s ${data.kind} job died for good, and paging it failed: ${e instanceof Error ? e.message : String(e)}`);
          console.error(`[hindsight] ${ctx.id}: submission ${data.submission_id}'s ${data.kind} job died for good, and paging it failed; the next sweep pages a dead audit job:`, e);
        });
      }
      throw err;
    }
  };
}

type DatasetRow = typeof dataset.$inferSelect;

// ---------------------------------------------------------------- a dead grade job

/**
 * A grade job that died for good (the header's `dead grade job`; the system's, subject the
 * submission): one row per job and attempt it died on, written before its page goes out, or with
 * why it is not paged (its entry is out). The competition, the phase, the queue, the job's kind and
 * the run a regrade reproduces, the job, its attempt, how it died and its last error, who found it,
 * whether it was paged (why_not when not) and the page text.
 */
export const GRADE_JOB_DEAD_ACTION = 'grade.job_dead' satisfies AuditAction;

/** pg-boss's job table: server/jobs.ts JobQueue runs pg-boss in the server's own database under its default schema, as server/routes/admin/hindsight.ts reads it. */
const JOB_TABLE = 'pgboss.job';

/** The grade queues (server/jobs.ts gradeQueue). */
const GRADE_QUEUES = ['grade-dev', 'grade-final'] as const satisfies readonly QueueName[];

/** The dead grade jobs one sweep decides at most, the oldest death first; the rest wait for the next sweep. */
export const DEAD_GRADE_SWEEP_LIMIT = 100;

/**
 * A grade job's context as its handler reads it (JobQueue.work's): its id and queue, its attempt, its retry limit (a
 * job dies for good on its last: isLastAttempt; without one no attempt is the last), and the attempt's signal, which
 * ends a wait on a scrape heat and stops a practice heat once pg-boss gives the attempt up (the header's `scrape/v1`).
 */
export type GradeJobContext = Pick<JobContext, 'id' | 'queue' | 'retryCount'> & Partial<Pick<JobContext, 'retryLimit' | 'signal' | 'priority'>>;

/** A grade job that died for good, as its row and page name it. */
export interface DeadGradeJob {
  job: JobPayload<'grade-dev'>;
  jobId: string;
  queue: string;
  /** The attempt it died on, from 1 (pg-boss's retry_count + 1). */
  attempt: number;
  /** Its attempts in all (pg-boss's retry_limit + 1), or null when not known. */
  attempts: number | null;
  /** How it died, in the page's words ("was refused for good on attempt 1 of 3 ...", "failed its last attempt (3 of 3)", "is held failed by pg-boss since ..."). */
  how: string;
  /** Its last error, or null when pg-boss holds none. */
  error: string | null;
  /** Who found it dead: the job's own handler, or a sweep. */
  found: 'handler' | 'sweep';
}

/** What one sweep decided: the deaths it paged, and those it recorded without a page (an entry that is out). Deaths a row records already are neither. */
export interface DeadGradeSweep {
  paged: { submission_id: string; job_id: string; attempt: number }[];
  quiet: { submission_id: string; job_id: string; attempt: number; why: string }[];
}

/** node-postgres returns a QueryResult, PGlite a Results object: both carry `rows`. */
function rowsOf<T>(result: unknown): T[] {
  return ((result as { rows?: T[] }).rows ?? []) as T[];
}

/** The error a failed pg-boss job holds in its output: a PermanentJobError's `error`, a thrown error's `message`, an expiry's `value.message`; else null. */
function jobErrorOf(output: unknown): string | null {
  const o = output as { error?: unknown; message?: unknown; value?: unknown } | null;
  if (typeof o?.error === 'string') return o.error;
  if (typeof o?.message === 'string') return o.message;
  const value = o?.value as { message?: unknown } | null | undefined;
  return typeof value?.message === 'string' ? value.message : null;
}

/**
 * The page of dead grade job `d` on `slug`'s `phaseKey` phase: what died and how, what it leaves
 * undone, and the admin route that queues it again (a grade's server/routes/admin/grading.ts
 * registerGradeResend, a regrade's the regrade route).
 */
function deadGradeJobPage(d: DeadGradeJob, slug: string, phaseKey: string): string {
  if (isEntrySecretsHold(d.error)) return heldGradeJobPage(d, slug, phaseKey);
  const died = `died for good, job ${d.jobId} (${d.queue}) ${d.how}${d.error === null ? '' : `: ${d.error}`}`;
  const own = 'pg-boss will not run it again on its own';
  if (d.job.rejudge !== undefined) {
    return (
      `[grade] ALERT: ${slug}: the provisional rejudge of run ${d.job.reproduces_run_id} (entry ${d.job.submission_id}, the ${phaseKey} phase, phase ${d.job.phase_id}) ${died}. ` +
      `It wrote nothing: the run keeps the provisional verdict it had, and ${own}. ` +
      `Fix: mend what it died of; while the competition takes entries, the provisional-rejudge-sweep (every 15 minutes) sends the run again on the next UTC day under a fresh job id, or rejudge the competition's provisional heats yourself at POST /api/admin/competitions/${slug}/rejudge-provisional ({}) on a later UTC day, which sends every run not yet judged on the current judge`
    );
  }
  if (d.job.kind === 'grade') {
    return (
      `[grade] ALERT: ${slug}: the grading of entry ${d.job.submission_id} on the ${phaseKey} phase (phase ${d.job.phase_id}) ${died}. ` +
      `It recorded no run: the entry is not graded on the ${phaseKey} phase by it, and ${own}. ` +
      `Fix: mend what it died of, then send it again at POST /api/admin/submissions/${d.job.submission_id}/grade/resend ({"job_id": "${d.jobId}", "reason": "<what was mended>"}), which grades the entry afresh under a new job id`
    );
  }
  const reproduces = d.job.reproduces_run_id;
  const level = d.job.kind === 'regrade_l1' ? 'L1' : 'L2';
  return (
    `[grade] ALERT: ${slug}: the ${level} regrade of run ${reproduces} (entry ${d.job.submission_id}, the ${phaseKey} phase, phase ${d.job.phase_id}) ${died}. ` +
    `It recorded no regrade run: run ${reproduces} is not reproduced by it, and ${own}. ` +
    `Fix: mend what it died of, then queue the regrade again at POST /api/admin/runs/${reproduces}/regrade ({"level": "${level}"})`
  );
}

/** Where the seal private keys a grader opens entry secrets with are mounted (server/secrets/seal.ts entrySecretSealRefusal's words), as a held page's fix names them. */
const SEAL_PRIVATE_KEYS_MOUNT = 'MAKEFUN_ENTRY_SECRET_SEAL_PRIVATE_KEYS_FILE; on the cluster, Secret makefun-entry-secret-seal, holding every key a secret is still sealed to';

/**
 * The page of grade job `d`, dead while held on its entrant's entry secrets (its error opening
 * ENTRY_SECRETS_UNOPENED_HOLD_REASON: the header's `entry secrets`), on `slug`'s `phaseKey` phase: the hold and its
 * secrets as the error names them (by NAME and row, and why: never a value), that nothing failed the entry, and the fix
 * (the seal private keys that open them, then the resend or the regrade). Sent once, on its last attempt.
 */
function heldGradeJobPage(d: DeadGradeJob, slug: string, phaseKey: string): string {
  const held = `is held on its entrant's entry secrets: job ${d.jobId} (${d.queue}) ${d.how}${d.error === null ? '' : `: ${d.error}`}`;
  const fault = "the fault is the platform's key configuration, never the entrant's";
  const keys = `give the grading workers the seal private keys that open the entry secrets named above (${SEAL_PRIVATE_KEYS_MOUNT}) and restart them, since a process reads its keys as it starts`;
  if (d.job.kind === 'grade') {
    return (
      `[grade] ALERT: ${slug}: the grading of entry ${d.job.submission_id} on the ${phaseKey} phase (phase ${d.job.phase_id}) ${held}. ` +
      `It recorded no run and never failed the entry, which waits ungraded on the ${phaseKey} phase, never graded without its secrets; ${fault}, and pg-boss will not run it again on its own. ` +
      `Fix: ${keys}, then send it again at POST /api/admin/submissions/${d.job.submission_id}/grade/resend ({"job_id": "${d.jobId}", "reason": "<what was mended>"}), which grades the entry afresh under a new job id`
    );
  }
  const reproduces = d.job.reproduces_run_id;
  const level = d.job.kind === 'regrade_l1' ? 'L1' : 'L2';
  return (
    `[grade] ALERT: ${slug}: the ${level} regrade of run ${reproduces} (entry ${d.job.submission_id}, the ${phaseKey} phase, phase ${d.job.phase_id}) ${held}. ` +
    `It recorded no regrade run: run ${reproduces} is not re-executed without its secrets, and its standing is untouched; ${fault}, and pg-boss will not run it again on its own. ` +
    `Fix: ${keys}, then queue the regrade again at POST /api/admin/runs/${reproduces}/regrade ({"level": "${level}"})`
  );
}

/** A grade job's attempt as a page or a log line names it: "2", or "2 of 3" when its retry limit is known. */
function attemptWords(ctx: GradeJobContext): string {
  return `${ctx.retryCount + 1}${ctx.retryLimit === undefined ? '' : ` of ${ctx.retryLimit + 1}`}`;
}

/**
 * The admins' page of grade jobs that die for good (the header's `dead grade job`): `dying` as a
 * job's own handler sees it die, `sweep` over every grade job pg-boss holds failed that no
 * GRADE_JOB_DEAD_ACTION row records (none when the database has no pg-boss table).
 */
export function createDeadGradeJobPager(deps: Pick<GradeWorkerDeps, 'db' | 'page' | 'log' | 'now'>): {
  dying(job: JobPayload<'grade-dev'>, ctx: GradeJobContext, err: unknown): Promise<void>;
  sweep(): Promise<DeadGradeSweep>;
} {
  const { db } = deps;
  const page = deps.page ?? ((line: string) => console.error(line));
  const log = deps.log ?? ((line: string) => console.log(line));
  const now = deps.now ?? (() => new Date());

  /**
   * Decide `d` once (its job and attempt): its row, written under the submission row's lock unless
   * one records that death already, then the page, unless its entry is out. A row that cannot be
   * written is logged with its stack, and the page stands (a later sweep may page it again).
   */
  const record = async (d: DeadGradeJob): Promise<{ outcome: 'paged' | 'quiet' | 'seen'; why: string | null }> => {
    const at = now();
    const subId = d.job.submission_id;
    const [sub] = await db.select({ status: submission.status, error: submission.error, checks: submission.checks, competitionId: submission.competitionId }).from(submission).where(eq(submission.id, subId));
    const [ph] = await db.select({ key: phase.key, competitionId: phase.competitionId }).from(phase).where(eq(phase.id, d.job.phase_id));
    const compId = ph?.competitionId ?? sub?.competitionId ?? null;
    const [comp] = compId === null ? [] : await db.select({ id: competition.id, slug: competition.slug }).from(competition).where(eq(competition.id, compId));
    const phaseKey = ph?.key ?? (d.queue === 'grade-dev' ? 'dev' : 'final');
    // An entry that is out was never to be graded: its death is recorded, not paged. (The pipeline's rules are loaded only here.)
    let why: string | null = null;
    if (sub?.status === 'cancelled') why = 'the entry was cancelled';
    else if (sub !== undefined) {
      // A refusal that stands (server/pipeline/publish.ts isRefused): a duplicate snapshot, a committed secret, or an admin's security-audit refusal.
      const refusal = await import('../server/pipeline/publish.ts');
      if (refusal.isRefusedDuplicate(sub)) why = 'the entry was refused as a duplicate snapshot';
      else if (refusal.isRefused(sub)) why = 'the entry was refused for a secret committed in its code';
    }
    const line = why === null ? deadGradeJobPage(d, comp?.slug ?? `competition ${compId ?? 'unknown'}`, phaseKey) : null;
    let fresh = true;
    try {
      fresh = await db.transaction(async (tx) => {
        await tx.select({ id: submission.id }).from(submission).where(eq(submission.id, subId)).for('update');
        const [seen] = await tx
          .select({ id: auditEvent.id })
          .from(auditEvent)
          .where(
            and(
              eq(auditEvent.action, GRADE_JOB_DEAD_ACTION),
              eq(auditEvent.subjectType, 'submission'),
              eq(auditEvent.subjectId, subId),
              sql`${auditEvent.data}->>'job_id' = ${d.jobId}`,
              sql`${auditEvent.data}->>'attempt' = ${String(d.attempt)}`,
            ),
          )
          .limit(1);
        if (seen !== undefined) return false;
        await recordAudit(tx, {
          actorUserId: null,
          action: GRADE_JOB_DEAD_ACTION,
          subjectType: 'submission',
          subjectId: subId,
          at,
          data: {
            competition: comp?.slug ?? null,
            competition_id: compId,
            phase_id: d.job.phase_id,
            phase: ph?.key ?? null,
            queue: d.queue,
            kind: d.job.kind,
            reproduces_run_id: d.job.reproduces_run_id,
            job_id: d.jobId,
            attempt: d.attempt,
            attempts: d.attempts,
            how: d.how,
            error: d.error,
            found: d.found,
            paged: line !== null,
            why_not: why,
            page: line,
          },
        });
        return true;
      });
    } catch (err) {
      console.error(`[grade] the ${GRADE_JOB_DEAD_ACTION} row of job ${d.jobId} (submission ${subId}, attempt ${d.attempt}) could not be written; ${line === null ? 'it is not paged' : 'the page below stands'}, and a later sweep may decide it again:`, err);
    }
    if (!fresh) return { outcome: 'seen', why };
    if (line === null) {
      log(`[grade] job ${d.jobId} (${d.queue}) of submission ${subId} died for good on attempt ${d.attempt}${d.error === null ? '' : `: ${d.error}`}; not paged: ${why}`);
      return { outcome: 'quiet', why };
    }
    page(line);
    return { outcome: 'paged', why: null };
  };

  const dying = async (job: JobPayload<'grade-dev'>, ctx: GradeJobContext, err: unknown): Promise<void> => {
    const n = attemptWords(ctx);
    const how = isEntrySecretsHold(err)
      ? `spent its last attempt (${n}) held, never failed`
      : err instanceof PermanentJobError
        ? `was refused for good on attempt ${n} (no retry can help)`
        : `failed its last attempt (${n})`;
    const error = err instanceof Error ? err.message : String(err);
    await record({ job, jobId: ctx.id, queue: ctx.queue, attempt: ctx.retryCount + 1, attempts: ctx.retryLimit === undefined ? null : ctx.retryLimit + 1, how, error, found: 'handler' });
  };

  const sweep = async (): Promise<DeadGradeSweep> => {
    const out: DeadGradeSweep = { paged: [], quiet: [] };
    const [table] = rowsOf<{ present: boolean }>(await db.execute(sql`select to_regclass(${JOB_TABLE}) is not null as present`));
    if (table?.present !== true) return out;
    const queues = sql.join(
      GRADE_QUEUES.map((q) => sql`${q}`),
      sql`, `,
    );
    // Every grade job pg-boss holds failed (its retries spent, or refused for good) whose death no row records yet.
    const rows = rowsOf<{ id: string; name: string; retry_count: number; retry_limit: number; data: unknown; created_on: Date | string; completed_on: Date | string | null; output: unknown }>(
      await db.execute(
        sql`select j.id::text as id, j.name, j.retry_count, j.retry_limit, j.data, j.created_on, j.completed_on, j.output from ${sql.raw(JOB_TABLE)} j
          where j.name in (${queues}) and j.state = 'failed'
            and not exists (select 1 from ${auditEvent} e where e.action = ${GRADE_JOB_DEAD_ACTION} and e.subject_type = 'submission' and e.subject_id = j.data->>'submission_id'
              and e.data->>'job_id' = j.id::text and e.data->>'attempt' = (j.retry_count + 1)::text)
          order by j.completed_on asc nulls first, j.created_on asc, j.id asc
          limit ${DEAD_GRADE_SWEEP_LIMIT}`,
      ),
    );
    for (const r of rows) {
      const parsed = GradeJob.safeParse(r.data);
      // A payload that is no grade job's (only a raw send makes one) names no entry to page.
      if (!parsed.success) continue;
      const attempt = Number(r.retry_count) + 1;
      const attempts = Number(r.retry_limit) + 1;
      const since = new Date(r.completed_on ?? r.created_on).toISOString();
      const d: DeadGradeJob = {
        job: parsed.data,
        jobId: r.id,
        queue: r.name,
        attempt,
        attempts,
        how: `is held failed by pg-boss since ${since}, after attempt ${attempt} of ${attempts} (its retries spent, refused for good, expired, or failed by hand)`,
        error: jobErrorOf(r.output),
        found: 'sweep',
      };
      try {
        const { outcome, why } = await record(d);
        if (outcome === 'paged') out.paged.push({ submission_id: d.job.submission_id, job_id: d.jobId, attempt });
        else if (outcome === 'quiet') out.quiet.push({ submission_id: d.job.submission_id, job_id: d.jobId, attempt, why: why! });
      } catch (err) {
        console.error(`[grade] dead grade job ${r.id} (${r.name}) could not be decided; the next sweep looks again:`, err);
      }
    }
    return out;
  };

  return { dying, sweep };
}
