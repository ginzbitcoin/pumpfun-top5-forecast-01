// OpenAI Chat Completions to Anthropic Messages and back: how the house lane's forwarder
// (grader/gateway/server.ts) dials a Claude model in its own dialect for a sealed env that speaks Chat
// Completions. Pure: no I/O, no clock; each answer a function of the bytes given.
//
//   chatToMessages(body)       a Chat Completions request as a Messages request, or null when it says
//                              something Messages cannot say as it was meant (the forwarder then sends
//                              the request on as it came, on Chat Completions)
//   messagesToChat(bytes, s)   a Messages answer (or error document) as the Chat Completions answer a
//                              Chat Completions client reads, with the status it is answered at
//   chatMessagesWithoutBlankTurns(messages)
//                              a Chat Completions request's turns with its empty or blank assistant
//                              turns left out and the user turns either side merged, as the Messages
//                              request below says them, for a request the forwarder sends on as Chat
//
// The request (Anthropic's docs, platform.claude.com, read 2026-11-10):
//   system      the leading system (or developer) messages as top-level `system` text blocks, the LAST
//               block carrying `cache_control: {type: 'ephemeral'}`: a breakpoint on the prefix every
//               call of a conversation shares. Never the top-level automatic breakpoint, which would sit
//               on the user turn, new every call. A prompt under the model's minimum (512 tokens on the
//               5.5 models) is simply not cached, with no error
//   messages    user and assistant turns, consecutive turns of one role merged into one; the first and
//               the last a user turn (a 5.5 model answers an assistant prefill 400). An empty or blank
//               assistant turn (a reply cut off before any text, or one of whitespace alone, sent back in
//               a retry) is left out, and the user turns either side of it merge: Messages takes no empty
//               turn, and an absent one says the same. A blank text part (empty, or whitespace alone) in a
//               message that holds other content is left out: Messages answers a text block of it 400
//               ("text content blocks must be non-empty", "... must contain non-whitespace text"; the
//               reference gives TextBlockParam.text minLength 1, the API refuses whitespace alone too, in
//               `messages` and in `system`). A user turn's image_url part with a base64 data URL (PNG,
//               JPEG, GIF, WebP) is an image block
//   max_tokens  max_completion_tokens, else max_tokens (thinking counts toward it, as on Chat)
//   effort      reasoning_effort low, medium, high, xhigh or max as `output_config.effort`, `thinking`
//               left out (adaptive: each model's default). Sent whenever the request names one, since
//               the defaults differ (medium on Haiku 5.5 and Opus 5.5, high on Sonnet 5.5). `none` and
//               `minimal` are effort low, with `thinking: {type: 'disabled'}` on a model that takes it
//               (Haiku 5.5, at high effort or below); Sonnet 5.5 and Opus 5.5 answer that 400 at any
//               effort, so there the lowest effort is all
//   sampling    temperature, top_p, top_k, frequency_penalty, presence_penalty and seed are dropped
//               (a 5.5 model may answer a sampling parameter 400)
//   tools       function tools as Messages tools (parameters as input_schema); tool_choice auto, none,
//               required as `any` and a named function as `tool` (Opus 5.5 and Sonnet 5.5 answer a forced
//               one 400 "tool_choice: type "tool" and "any" are not supported for this model.", as they do
//               through Chat Completions; Haiku 5.5 takes it and skips thinking); parallel_tool_calls false
//               as disable_parallel_tool_use
//   json        a json_schema response_format as `output_config.format` {type: json_schema, schema}
//               (structured outputs: constrained decoding, which a thinking model takes), its schema as
//               Anthropic's SDKs send one (messagesSchemaOf): the constraints Messages does not take moved
//               into the description as `{minimum: 1, maximum: 5}`, additionalProperties false on every
//               object. Read 2026-11-10 at platform.claude.com/docs/en/build-with-claude/structured-outputs
//               and /agents-and-tools/tool-use/define-tools (forcing tool use), /api/errors
// and null for anything else: a stream, n over 1, a json_object response_format (Messages has no "any
// JSON object"), a schema messagesSchemaOf cannot say, a tool call or tool result in the history, a part
// that is not text or a data-URL image, a user turn or system message with nothing but blank text (left
// out, it would say what Chat Completions did not; kept, Messages answers it 400), a system message after the conversation
// began, a field this file does not know, or a model not in MODEL_FACTS (whose effort and thinking rules it
// has not read).
//
// The answer: the text blocks joined as choices[0].message.content (thinking blocks dropped), tool_use
// blocks as tool_calls; stop_reason end_turn and stop_sequence `stop`, max_tokens and
// model_context_window_exceeded `length`, tool_use `tool_calls`, refusal `content_filter`, anything else
// `stop`. usage.prompt_tokens is input + cache read + cache write (every prompt token, as Chat counts
// them), prompt_tokens_details.cached_tokens the cache read, completion_tokens the output (thinking
// included), completion_tokens_details.reasoning_tokens the thinking when the usage names it. The id and
// model are the message's; `created` is 0 (no clock here). An Anthropic error document is the OpenAI
// error shape at the same status; a body that is neither is an upstream_error document, a 2xx one
// answered 502 (MessagesAnswer.kind `unreadable`).

/** The Messages API version the translated request is sent under (its `anthropic-version` header). */
export const MESSAGES_API_VERSION = '2023-06-01';

/** The effort levels Messages takes (`output_config.effort`). */
export const EFFORT_LEVELS: readonly string[] = Object.freeze(['low', 'medium', 'high', 'xhigh', 'max']);

/** What each Claude model this file translates for takes: whether `thinking: {type: 'disabled'}` is allowed (at high effort or below). */
export interface ModelFacts {
  thinking_off: boolean;
}

/** The models chatToMessages translates for, by id (a dated snapshot of one reads as it): their effort and thinking rules, from the docs above. */
export const MODEL_FACTS: Readonly<Record<string, Readonly<ModelFacts>>> = Object.freeze({
  'claude-haiku-5-5': Object.freeze({ thinking_off: true }),
  'claude-sonnet-5-5': Object.freeze({ thinking_off: false }),
  'claude-opus-5-5': Object.freeze({ thinking_off: false }),
});

const RELEASE_DATE = /-\d{8}$/;

/** A model's MODEL_FACTS row: the id itself, or it under a release date; null for any other model. */
export function modelFacts(model: string): Readonly<ModelFacts> | null {
  const id = model.replace(RELEASE_DATE, '');
  return Object.hasOwn(MODEL_FACTS, id) ? MODEL_FACTS[id]! : null;
}

type Json = Record<string, unknown>;
const isRecord = (v: unknown): v is Json => v !== null && typeof v === 'object' && !Array.isArray(v);
const said = (v: unknown): boolean => v !== undefined && v !== null;
const isCount = (v: unknown): v is number => typeof v === 'number' && Number.isSafeInteger(v) && v >= 0;

/** The request fields chatToMessages reads; any other field present makes it null. */
const REQUEST_KEYS = new Set([
  'model',
  'messages',
  'max_tokens',
  'max_completion_tokens',
  'reasoning_effort',
  'stream',
  'n',
  'stop',
  'tools',
  'tool_choice',
  'parallel_tool_calls',
  'response_format',
  'service_tier',
  'store',
  'logprobs',
  'top_logprobs',
  'logit_bias',
  // Sampling: dropped.
  'temperature',
  'top_p',
  'top_k',
  'frequency_penalty',
  'presence_penalty',
  'seed',
]);

/** A Messages content block: text, or a base64 image. */
type Block = { type: 'text'; text: string } | { type: 'image'; source: { type: 'base64'; media_type: string; data: string } };

/** A base64 data URL of an image type Messages takes. */
const IMAGE_DATA_URL = /^data:(image\/(?:png|jpeg|gif|webp));base64,([A-Za-z0-9+/]+={0,2})$/;

/** An image_url part as an image block: a data URL of a type Messages takes, detail unsaid or auto; null otherwise. */
function imageOf(part: Json): Block | null {
  if (Object.keys(part).some((k) => k !== 'type' && k !== 'image_url') || !isRecord(part.image_url)) return null;
  const img = part.image_url;
  if (Object.keys(img).some((k) => k !== 'url' && k !== 'detail') || (said(img.detail) && img.detail !== 'auto')) return null;
  const m = typeof img.url === 'string' ? IMAGE_DATA_URL.exec(img.url) : null;
  return m === null ? null : { type: 'image', source: { type: 'base64', media_type: m[1]!, data: m[2]! } };
}

/** Text Messages takes in no text block: empty, or whitespace alone (the header). */
const blank = (text: string): boolean => text.trim() === '';

/** A text part as Chat says one: `{type: 'text', text}` and nothing else. */
const isTextPart = (part: unknown): part is { type: 'text'; text: string } =>
  isRecord(part) && part.type === 'text' && typeof part.text === 'string' && Object.keys(part).every((k) => k === 'type' || k === 'text');

/**
 * A message's blocks: a string with text in it, or text parts and, when `images`, data-URL image parts (a blank text
 * part left out, the message keeping at least one block); null for anything else.
 */
function blocksOf(content: unknown, images: boolean): Block[] | null {
  if (typeof content === 'string') return blank(content) ? null : [{ type: 'text', text: content }];
  if (!Array.isArray(content)) return null;
  const out: Block[] = [];
  for (const part of content) {
    if (!isRecord(part)) return null;
    if (images && part.type === 'image_url') {
      const image = imageOf(part);
      if (image === null) return null;
      out.push(image);
      continue;
    }
    if (!isTextPart(part)) return null;
    if (!blank(part.text)) out.push({ type: 'text', text: part.text });
  }
  return out.length === 0 ? null : out;
}

/** A message's text: blocksOf with no images, as strings. */
function textOf(content: unknown): string[] | null {
  const blocks = blocksOf(content, false);
  return blocks === null ? null : blocks.map((b) => (b as { text: string }).text);
}

/**
 * An assistant turn that says nothing: no text (empty or blank, null, or no parts but blank text parts) and nothing else
 * (no tool call, refusal, name or audio). Left out of a Messages request (chatRequestToMessages) and, on the house lane,
 * out of a Chat Completions request sent on as Chat (chatMessagesWithoutBlankTurns).
 */
export const emptyAssistant = (m: Json): boolean =>
  m.role === 'assistant' &&
  onlyKeys(m, ['role', 'content']) &&
  (!said(m.content) || (typeof m.content === 'string' && blank(m.content)) || (Array.isArray(m.content) && m.content.every((p) => isTextPart(p) && blank(p.text))));

/** Whether a message says nothing but `keys` (a field null, absent or an empty list says nothing). */
const onlyKeys = (doc: Json, keys: readonly string[]): boolean => Object.entries(doc).every(([k, v]) => keys.includes(k) || !said(v) || (Array.isArray(v) && v.length === 0));

/** A user turn two may merge into: a role and its content (a string or a list of parts), nothing else said. */
const mergeableUser = (m: unknown): m is Json & { content: string | unknown[] } =>
  isRecord(m) && m.role === 'user' && onlyKeys(m, ['role', 'content']) && (typeof m.content === 'string' || Array.isArray(m.content));

/** A user turn's content as Chat Completions parts: a string as one text part, a list as it is. */
const partsOf = (content: string | unknown[]): unknown[] => (typeof content === 'string' ? [{ type: 'text', text: content }] : content);

/**
 * A Chat Completions request's `messages` with every assistant turn that says nothing (emptyAssistant) left out, and the
 * user turns either side of each one merged into one user turn whose content is the parts of both in order (a string
 * as one text part): what Chat Completions says when such a turn goes, as chatRequestToMessages says it on Messages. A
 * user turn that says more than its role and content is not merged (two user turns stand). Null when no turn is left
 * out, so the caller sends the request as it came. The retry an env makes after a reply cut off before any text sends
 * that reply back as an empty or blank assistant turn, which masq answers 400 for superbot ("carries no content, no
 * reasoning and no tool call") and Anthropic's Chat Completions 400 when blank ("text content blocks must contain
 * non-whitespace text"). Pure: `messages` is never changed.
 */
export function chatMessagesWithoutBlankTurns(messages: readonly unknown[]): unknown[] | null {
  const out: unknown[] = [];
  let dropped = false;
  let gap = false;
  for (const m of messages) {
    if (isRecord(m) && emptyAssistant(m)) {
      dropped = true;
      gap = true;
      continue;
    }
    const last = out.at(-1);
    if (gap && mergeableUser(last) && mergeableUser(m)) out[out.length - 1] = { role: 'user', content: [...partsOf(last.content), ...partsOf(m.content)] };
    else out.push(m);
    gap = false;
  }
  return dropped ? out : null;
}

/** max_completion_tokens, else max_tokens: a positive integer; both, they agree. */
function outputCap(doc: Json): number | null {
  const a = doc.max_completion_tokens;
  const b = doc.max_tokens;
  if (said(a) && said(b) && a !== b) return null;
  const cap = said(a) ? a : b;
  return isCount(cap) && cap > 0 ? cap : null;
}

/** tools and tool_choice as Messages says them; null when it cannot. */
function toolsOf(doc: Json): { tools?: Json[]; tool_choice?: Json } | null {
  const parallel = doc.parallel_tool_calls;
  if (said(parallel) && typeof parallel !== 'boolean') return null;
  if (!said(doc.tools)) return said(doc.tool_choice) || said(parallel) ? null : {};
  if (!Array.isArray(doc.tools) || doc.tools.length === 0) return null;
  const tools: Json[] = [];
  for (const t of doc.tools) {
    if (!isRecord(t) || t.type !== 'function' || !isRecord(t.function) || Object.keys(t).some((k) => k !== 'type' && k !== 'function')) return null;
    const f = t.function;
    if (Object.keys(f).some((k) => !['name', 'description', 'parameters', 'strict'].includes(k)) || (said(f.strict) && f.strict !== false)) return null;
    if (typeof f.name !== 'string' || f.name === '') return null;
    if (said(f.description) && typeof f.description !== 'string') return null;
    if (said(f.parameters) && !isRecord(f.parameters)) return null;
    tools.push({
      name: f.name,
      ...(typeof f.description === 'string' && f.description !== '' ? { description: f.description } : {}),
      input_schema: isRecord(f.parameters) ? f.parameters : { type: 'object', properties: {} },
    });
  }
  const choice = doc.tool_choice;
  let tool_choice: Json;
  if (!said(choice) || choice === 'auto') tool_choice = { type: 'auto' };
  else if (choice === 'none') tool_choice = { type: 'none' };
  else if (choice === 'required') tool_choice = { type: 'any' };
  else if (isRecord(choice) && choice.type === 'function' && Object.keys(choice).length === 2 && isRecord(choice.function) && Object.keys(choice.function).length === 1) {
    const name = choice.function.name;
    if (typeof name !== 'string' || !tools.some((t) => t.name === name)) return null;
    tool_choice = { type: 'tool', name };
  } else return null;
  if (parallel === false && tool_choice.type !== 'none') tool_choice.disable_parallel_tool_use = true;
  return { tools, tool_choice };
}

// ------------------------------------------------------------------ structured outputs

/** The types a schema names (structured outputs' supported features). */
const SCHEMA_TYPES: readonly string[] = ['object', 'array', 'string', 'integer', 'number', 'boolean', 'null'];
/** The string formats Messages takes; another is moved into the description. */
const STRING_FORMATS: readonly string[] = ['date-time', 'time', 'date', 'duration', 'email', 'hostname', 'uri', 'ipv4', 'ipv6', 'uuid'];
/** Constraints Messages does not take: moved into the description, as Anthropic's SDKs move them. */
const NOTED_KEYS: readonly string[] = ['minimum', 'maximum', 'exclusiveMinimum', 'exclusiveMaximum', 'multipleOf', 'minLength', 'maxLength', 'minItems', 'maxItems', 'uniqueItems', 'minProperties', 'maxProperties'];
/** The deepest schema messagesSchemaOf walks. */
const SCHEMA_DEPTH = 32;

const isPrimitive = (v: unknown): boolean => v === null || typeof v === 'string' || typeof v === 'boolean' || (typeof v === 'number' && Number.isFinite(v));

/** One schema node as Messages takes it (messagesSchemaOf); null when it cannot. */
function schemaNode(node: unknown, depth: number): Json | null {
  if (!isRecord(node) || depth > SCHEMA_DEPTH) return null;
  const sub = (v: unknown): Json | null => schemaNode(v, depth + 1);
  const subs = (v: unknown): Json[] | null => {
    if (!Array.isArray(v) || v.length === 0) return null;
    const out = v.map(sub);
    return out.some((s) => s === null) ? null : (out as Json[]);
  };
  const map = (v: unknown): Json | null => {
    if (!isRecord(v)) return null;
    const out: Json = {};
    for (const [k, s] of Object.entries(v)) {
      const t = sub(s);
      if (t === null) return null;
      out[k] = t;
    }
    return out;
  };
  const out: Json = {};
  const notes: string[] = [];
  for (const [k, v] of Object.entries(node)) {
    let kept: unknown = v;
    switch (k) {
      case 'type':
        if (!(typeof v === 'string' ? SCHEMA_TYPES.includes(v) : Array.isArray(v) && v.length > 0 && v.every((t) => typeof t === 'string' && SCHEMA_TYPES.includes(t)))) return null;
        break;
      case 'description':
      case 'pattern':
        if (typeof v !== 'string') return null;
        break;
      case 'required':
        if (!Array.isArray(v) || !v.every((r) => typeof r === 'string')) return null;
        break;
      case 'additionalProperties':
        if (v !== false) return null;
        break;
      case 'enum':
        if (!Array.isArray(v) || v.length === 0 || !v.every(isPrimitive)) return null;
        break;
      case 'const':
        if (!isPrimitive(v)) return null;
        break;
      case 'default':
        break;
      case '$ref':
        if (typeof v !== 'string' || !v.startsWith('#')) return null;
        break;
      case 'items':
        kept = sub(v);
        break;
      case 'anyOf':
      case 'allOf':
        kept = subs(v);
        break;
      case 'properties':
      case '$defs':
      case 'definitions':
        kept = map(v);
        break;
      case 'format':
        if (typeof v !== 'string') return null;
        if (!STRING_FORMATS.includes(v)) {
          notes.push(`${k}: ${JSON.stringify(v)}`);
          continue;
        }
        break;
      default:
        if (!NOTED_KEYS.includes(k)) return null;
        if (k === 'minItems' && (v === 0 || v === 1)) break;
        notes.push(`${k}: ${JSON.stringify(v)}`);
        continue;
    }
    if (kept === null) return null;
    out[k] = kept;
  }
  const isObject = node.type === 'object' || (Array.isArray(node.type) && node.type.includes('object')) || said(node.properties);
  if (isObject) {
    // An object Messages holds to additionalProperties false: one that names no property and does not say so is open to
    // any key, which it could not be.
    const named = isRecord(node.properties) && Object.keys(node.properties).length > 0;
    if (!named && node.additionalProperties !== false) return null;
    if (!('additionalProperties' in out)) out.additionalProperties = false;
  }
  if (notes.length > 0) {
    const note = `{${notes.join(', ')}}`;
    out.description = typeof out.description === 'string' && out.description !== '' ? `${out.description}\n\n${note}` : note;
  }
  return out;
}

/**
 * A JSON schema as structured outputs take it (the header's `json`), or null when it says something they cannot: an
 * object open to other keys, a keyword they do not know, or a root that is not an object schema.
 */
export function messagesSchemaOf(schema: unknown): Json | null {
  if (!isRecord(schema) || schema.type !== 'object') return null;
  return schemaNode(schema, 0);
}

/** response_format as `output_config.format`: undefined for none or text, null for one Messages cannot say. */
function formatOf(doc: Json): Json | null | undefined {
  const f = doc.response_format;
  if (!said(f)) return undefined;
  if (!isRecord(f)) return null;
  if (f.type === 'text' && Object.keys(f).length === 1) return undefined;
  if (f.type !== 'json_schema' || Object.keys(f).length !== 2 || !isRecord(f.json_schema)) return null;
  const js = f.json_schema;
  if (Object.keys(js).some((k) => !['name', 'strict', 'schema'].includes(k)) || (said(js.strict) && typeof js.strict !== 'boolean')) return null;
  const schema = messagesSchemaOf(js.schema);
  return schema === null ? null : { type: 'json_schema', schema };
}

/** reasoning_effort as `output_config` and `thinking`; null for a value Messages has no word for. */
function effortOf(doc: Json, facts: Readonly<ModelFacts>): { output_config?: Json; thinking?: Json } | null {
  const e = doc.reasoning_effort;
  if (!said(e)) return {};
  if (typeof e !== 'string') return null;
  if (EFFORT_LEVELS.includes(e)) return { output_config: { effort: e } };
  if (e === 'none' || e === 'minimal') return facts.thinking_off ? { thinking: { type: 'disabled' }, output_config: { effort: 'low' } } : { output_config: { effort: 'low' } };
  return null;
}

/** stop as stop_sequences; null for an empty or blank one. */
function stopOf(doc: Json): string[] | null | undefined {
  const s = doc.stop;
  if (!said(s)) return undefined;
  const list = typeof s === 'string' ? [s] : Array.isArray(s) ? s : null;
  if (list === null || list.length === 0) return null;
  for (const v of list) if (typeof v !== 'string' || v.trim() === '') return null;
  return list as string[];
}

/** A parsed Chat Completions request as a Messages request (see the header), or null. */
export function chatRequestToMessages(doc: unknown): Json | null {
  if (!isRecord(doc)) return null;
  for (const k of Object.keys(doc)) if (!REQUEST_KEYS.has(k)) return null;
  const model = doc.model;
  if (typeof model !== 'string') return null;
  const facts = modelFacts(model);
  if (facts === null) return null;
  if (said(doc.stream) && doc.stream !== false) return null;
  if (said(doc.n) && doc.n !== 1) return null;
  if (said(doc.logprobs) && doc.logprobs !== false) return null;
  if (said(doc.top_logprobs)) return null;
  if (said(doc.logit_bias) && !(isRecord(doc.logit_bias) && Object.keys(doc.logit_bias).length === 0)) return null;
  if (said(doc.store) && doc.store !== false) return null;
  if (said(doc.service_tier) && doc.service_tier !== 'auto' && doc.service_tier !== 'default') return null;
  const format = formatOf(doc);
  if (format === null) return null;
  const max_tokens = outputCap(doc);
  if (max_tokens === null) return null;
  const effort = effortOf(doc, facts);
  if (effort === null) return null;
  const tools = toolsOf(doc);
  if (tools === null) return null;
  const stop = stopOf(doc);
  if (stop === null) return null;

  if (!Array.isArray(doc.messages) || doc.messages.length === 0) return null;
  const system: string[] = [];
  const turns: { role: 'user' | 'assistant'; blocks: Block[] }[] = [];
  for (const m of doc.messages) {
    if (!isRecord(m)) return null;
    const role = m.role;
    if (role === 'system' || role === 'developer') {
      // Messages has one system prompt, before the conversation.
      if (turns.length > 0 || !onlyKeys(m, ['role', 'content'])) return null;
      const text = textOf(m.content);
      if (text === null) return null;
      system.push(...text);
      continue;
    }
    // An empty or blank reply sent back in a retry: left out, so the user turns either side merge.
    if (emptyAssistant(m)) continue;
    // A tool turn, or a name, refusal, tool call or audio on a turn, is not text this file carries.
    if ((role !== 'user' && role !== 'assistant') || !onlyKeys(m, ['role', 'content'])) return null;
    const blocks = blocksOf(m.content, role === 'user');
    if (blocks === null) return null;
    const last = turns.at(-1);
    if (last !== undefined && last.role === role) last.blocks.push(...blocks);
    else turns.push({ role, blocks: [...blocks] });
  }
  if (turns.length === 0 || turns[0]!.role !== 'user' || turns.at(-1)!.role !== 'user') return null;

  const out: Json = { model, max_tokens };
  if (system.length > 0) {
    out.system = system.map((text, i) => (i === system.length - 1 ? { type: 'text', text, cache_control: { type: 'ephemeral' } } : { type: 'text', text }));
  }
  out.messages = turns.map((t) => ({ role: t.role, content: t.blocks.length === 1 && t.blocks[0]!.type === 'text' ? t.blocks[0]!.text : t.blocks }));
  if (tools.tools !== undefined) {
    out.tools = tools.tools;
    out.tool_choice = tools.tool_choice;
  }
  if (stop !== undefined) out.stop_sequences = stop;
  if (effort.thinking !== undefined) out.thinking = effort.thinking;
  if (effort.output_config !== undefined || format !== undefined) out.output_config = { ...effort.output_config, ...(format !== undefined ? { format } : {}) };
  return out;
}

const encoder = new TextEncoder();

/** A Chat Completions request body as a Messages request body (see the header), or null when it is not one this file can say faithfully. */
export function chatToMessages(body: Uint8Array): Uint8Array | null {
  let doc: unknown;
  try {
    doc = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(body));
  } catch {
    return null;
  }
  const out = chatRequestToMessages(doc);
  return out === null ? null : encoder.encode(JSON.stringify(out));
}

// ------------------------------------------------------------------ the answer

/** Messages' stop_reason as Chat's finish_reason (see the header). */
export function finishReason(stop: unknown): string {
  switch (stop) {
    case 'max_tokens':
    case 'model_context_window_exceeded':
      return 'length';
    case 'tool_use':
      return 'tool_calls';
    case 'refusal':
      return 'content_filter';
    default:
      return 'stop';
  }
}

/** Messages usage as Chat usage (see the header); null when it carries no counts. */
export function chatUsage(usage: unknown): Json | null {
  if (!isRecord(usage)) return null;
  const n = (v: unknown): number => (isCount(v) ? v : 0);
  const input = n(usage.input_tokens);
  const read = n(usage.cache_read_input_tokens);
  const write = n(usage.cache_creation_input_tokens);
  const output = n(usage.output_tokens);
  const prompt = input + read + write;
  const out: Json = { prompt_tokens: prompt, completion_tokens: output, total_tokens: prompt + output, prompt_tokens_details: { cached_tokens: read } };
  const thinking = isRecord(usage.output_tokens_details) ? usage.output_tokens_details.thinking_tokens : undefined;
  if (isCount(thinking)) out.completion_tokens_details = { reasoning_tokens: thinking };
  return out;
}

/** An OpenAI error document. */
function chatError(message: string, type: string): Json {
  return { error: { message, type, param: null, code: type } };
}

/** What messagesToChat answers: the status and body the Chat client gets, and what the bytes were. */
export interface MessagesAnswer {
  status: number;
  body: Uint8Array;
  /** `message` a Messages answer, `error` an error document, `unreadable` neither (a 2xx one answered 502). */
  kind: 'message' | 'error' | 'unreadable';
}

/** A Messages answer at `status` as a Chat Completions answer (see the header). */
export function messagesToChat(bytes: Uint8Array, status: number): MessagesAnswer {
  let doc: unknown = null;
  try {
    doc = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes));
  } catch {
    doc = null;
  }
  const ok = status >= 200 && status < 300;
  const done = (s: number, d: Json, kind: MessagesAnswer['kind']): MessagesAnswer => ({ status: s, body: encoder.encode(JSON.stringify(d)), kind });
  if (isRecord(doc) && (doc.type === 'error' || isRecord(doc.error))) {
    const e = isRecord(doc.error) ? doc.error : {};
    const type = typeof e.type === 'string' && e.type !== '' ? e.type : 'api_error';
    const message = typeof e.message === 'string' ? e.message : `the model provider answered HTTP ${status} with an error`;
    return done(status, chatError(message, type), 'error');
  }
  if (!isRecord(doc) || doc.type !== 'message' || !Array.isArray(doc.content)) {
    const message = `the model provider answered HTTP ${status} with a body that is no Messages ${ok ? 'answer' : 'error document'}`;
    return done(ok ? 502 : status, chatError(message, 'upstream_error'), 'unreadable');
  }
  const text: string[] = [];
  const calls: Json[] = [];
  for (const block of doc.content) {
    if (!isRecord(block)) continue;
    if (block.type === 'text' && typeof block.text === 'string') text.push(block.text);
    else if (block.type === 'tool_use' && typeof block.id === 'string' && typeof block.name === 'string') {
      calls.push({ id: block.id, type: 'function', function: { name: block.name, arguments: JSON.stringify(block.input ?? {}) } });
    }
  }
  const message: Json = { role: 'assistant', content: text.length === 0 && calls.length > 0 ? null : text.join(''), refusal: null };
  if (calls.length > 0) message.tool_calls = calls;
  const usage = chatUsage(doc.usage);
  return done(
    status,
    {
      id: typeof doc.id === 'string' ? doc.id : '',
      object: 'chat.completion',
      created: 0,
      model: typeof doc.model === 'string' ? doc.model : '',
      choices: [{ index: 0, message, logprobs: null, finish_reason: finishReason(doc.stop_reason) }],
      ...(usage === null ? {} : { usage }),
    },
    'message',
  );
}
