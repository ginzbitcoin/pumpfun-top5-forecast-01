// A program/v1 judge heat's pure core (contracts/competition.ts ProgramJudge): the house judge compares two
// artifacts at a time, and every field member's score (contracts/score.ts ProgramJudgeScore) is read off the
// verdicts. No clock and no I/O here: the heat job (grader/worker.ts) sends each call through grader/judge-call.ts,
// keeps what came back as a JudgeHeatCall, and asks judgeHeatNextCall for the next one; the record it then stores
// (agent-fun/judge-heat/v2, JUDGE_HEAT_FORMAT) rebuilds every score (judgeHeatVerdicts), by the heat and by any regrade
// alike, as grader/code-heat.ts's record rebuilds a timing. An agent-fun/judge-heat/v1 record (JUDGE_HEAT_FORMAT_V1:
// verdicts with no margin, the binary fold below) still parses, holds and scores to the same bytes it always did, so
// the v1 heats already stored keep verifying; no heat writes one again. An agent-fun/judge-heat/v3 record
// (JUDGE_HEAT_FORMAT_V3) is a ladder's (below): a calibration's, or a provisional heat's on a ladder. Its calls, games
// and verdicts are v2's (judgeHeatVerdictFormat: v2); final heats keep writing v2.
//
//   the field        one member per distinct artifact (judgeHeatField): the final phase's kept entries that passed
//                    the gate, grouped by their artifact's sha256 (byte-identical copies share one member and one
//                    score, so the board's exact-tie rule, the earlier receipt, keeps the original first), and the
//                    house anchors (<judge.dir>/anchors/, `anchor: true`), in sha256 order. An entry whose artifact
//                    is an anchor's joins the anchor's member: it plays, and is scored, as that anchor, and never
//                    enters the playoff. A provisional heat's field is one dev entry's artifact and the anchors
//   the seed         judgeHeatSeed(phase seed) = sha256(utf8(the record's format) || 0x00 || utf8(the phase seed, u64
//                    decimal)), so a v1 record re-derives its v1 seed; the phase seed is the one the phase's grade
//                    runs carry (grader/worker.ts programPlan: a final
//                    heat's runs hold it, and a regrade holds the record to it). Round 1's order (judgeHeatOrder) is grader/scrape/heat.ts scrapeHeatOrder
//                    of that seed, stage `main`, round 0, over the members' places in sha256 order: a Fisher-Yates
//                    shuffle drawn from a sha256 stream. Which slot order of a pair runs first (judgeSlotOrder) is
//                    a bit of sha256(utf8('slot') || 0x00 || seed || stage || 0x00 || u32be(round) || a || b)
//   a game           one pair judged twice, once in each slot order (the A/B assignment of a call: `ab` puts `a`
//                    in slot A). Each call answers a winner and a margin, 1 (by a hair) to 5 (overwhelmingly),
//                    and is worth 10 tenths of a win between the two (judgeCallTenths): 5 + margin to the member it
//                    picks, 5 - margin to the other; a call with no verdict gives each 5. The game's a_points is
//                    `a`'s tenths from its two calls summed, twentieths of a game from 0 to 20 (judgeGamePoints):
//                    above 10 `a` wins, below 10 `b` does, and exactly 10 is a draw, which only two calls that
//                    cancel exactly make (opposite picks at one margin, or neither answering). The judge is never
//                    offered a tie (GenArena's forced choice), and a split decides by its margins: the call surer
//                    of its pick carries the game. A v1 record's game is the binary fold its calls had no margin
//                    for: both calls valid and naming the same artifact, that artifact wins; anything else (the
//                    slots disagree, or a call came back with no verdict) is a draw, and it holds no a_points
//   the Swiss        `rounds` rounds over the whole field, anchors included (judgeSwissPairs): round 1 in the
//                    seed's order, every later round ranked by the current expected win rate (below, over the
//                    games so far), ties by sha256. Walking down the ranking, each member takes the nearest member
//                    below it that it has not played: a backtracking search, so no pairing repeats a game while a
//                    pairing without one exists (within JUDGE_SWISS_SEARCH_STEPS; past them, or when none exists,
//                    each takes the nearest member it has played least). On an odd field the bye goes to the lowest
//                    ranked member among those with the fewest byes that leaves the rest such a pairing
//   the playoff      the first playoff_places members by expected win rate after the Swiss (judgePlayoffPlaces;
//                    anchors never), ties by sha256, at least two of them: every pair of them is one game per
//                    repeat, playoff_repeats times, its two calls in the drawn order. They are the finalists
//                    (`finalist: true`); with fewer than two entrant members, no playoff runs
//   provisional      a dev entry's artifact plays every other member (the anchors) once, both slot orders: two
//                    calls an anchor, the same judge, prompt and anchors as the final's Swiss, so dev and final
//                    share one scale. Its score is `provisional: true`: shown, never weighed
//   the ladder       (v3) members of FIXED strength a dev entry is rated against (grader/judge-ladder.ts), sealed in the
//                    bundle's ladder dir: the judge anchors and the rungs (house artifacts under <ladder dir>/rungs/, a
//                    member's `rung_files`). A calibration heat (stage `calibration`, no entries, at least two members)
//                    judges every pair i < j in sha256 order, both slot orders, `repeats` times, the first order drawn
//                    by judgeSlotOrder(seed, `calibration`, repeat, a, b); judgeLadderFitOf reads each member's strength
//                    off judgeFit over its games, as Fixed9, and the pooled within-pair dispersion phi. A provisional
//                    heat on a ladder (its setup's `ladder`: the ladder's and calibration's digests, every other
//                    member's strength in sha256 order, phi, and rounds, games and spread) plays the judge anchors
//                    (never the rungs) in round 0 as above, then `rounds` x `games` adaptive games k = 1, 2, ...: at
//                    each round's start the estimate p^ over the games so far (judgeLadderEstimate), the round's games
//                    cycling over the `spread` members most informative at it (judgeLadderNext), each a game of stage
//                    `adaptive`, round k, its first order judgeSlotOrder(seed, `adaptive`, k, entry, member). Its one
//                    score is the entry's, judgeLadderScore against the record's own strengths and phi: E over the
//                    judge anchors, provisional
//   the fit          Bradley-Terry by Hunter's MM (Hunter 2004, Annals of Statistics 32(1):384-406) over every game
//                    of the record, its outcomes soft: a v2 game gives `a` a_points twentieths of a win and `b` the
//                    other 20 - a_points (a game decided 12 to 8 is 0.6 of a win to one side, 0.4 to the other); a
//                    v1 game a whole win to its winner, or half a win each for a draw. Every member has one virtual
//                    draw against a virtual player of strength 1 (half a win: it fixes the scale and keeps every
//                    strength finite). W_i, the wins so summed, is counted in whole twentieths and divided by 20
//                    once (exact in binary64, so a v1 record's W_i is the same bits its half-wins gave), and
//                    p_i <- W_i / (1/(p_i + 1) + sum_j n_ij/(p_i + p_j)), all members at once from the last
//                    iterate, JUDGE_BT_ITERATIONS (200) times from p = 1. Only + - * / and Math.sqrt, each of
//                    which ES2025 (§6.1.6.1, §21.3.2.33) rounds correctly in binary64, every sum in member order:
//                    the fit is the same bits on every host
//   the score        E_i = (1/(n-1)) sum_{j != i} p_i/(p_i + p_j) over the whole field, anchors included; its
//                    standard error by the delta method, SE = d_i / sqrt(I_i), with d_i = dE_i/dlog p_i = (1/(n-1))
//                    sum_{j != i} p_i p_j/(p_i + p_j)^2 and I_i = p_i/(p_i + 1)^2 + sum_j n_ij p_i p_j/(p_i + p_j)^2
//                    (the virtual draw is part of the fit, so of its curvature); the 90% interval E +- 1.6449 SE
//                    clamped to [0, 1]; each rounded to millionths (JUDGE_MICRO). A member that played no game has
//                    no score
//   the exact tie    what breaks a tie of win_rate_micro to the millionth (a statistical tie stays display-only): a
//                    v2 record's field holds each member's artifact_bytes, and its scores carry them, and, for an
//                    entrant member of a final heat with exact-tie peers (the other entrant members scored with the
//                    same win_rate_micro and the same finalist flag), head_to_head: per peer in sha256 order its
//                    twentieths of a win summed over the PLAYOFF games against that peer (the Swiss pairs by the
//                    standing, unevenly, so its games never count). The board's chain is head-to-head among the tied
//                    entries, then the smaller artifact, then the earlier receipt. A v1 record holds and scores neither
//   the record       JudgeHeatRecord: the stage, the phase seed and the heat's seed, the house judge (its agent,
//                    judge_sha256, media and artifact, and the house text its requests were built from:
//                    house_text, so a request is rebuilt from the record's own words, never the code's current
//                    ones), the heat's numbers, the field, every call in the order it ran (its pair and slot order,
//                    then grader/judge-call.ts's JudgeCallResult: the verdict, its margin (a v2 call's; a v1 call
//                    has none), reason and invalid, the last request's hashes and model, the usage and price summed,
//                    and each request sent as its JudgeAttempt; judgeHeatCallOf builds one, judgeHeatCallIssues holds
//                    it), the games (a v2 game with its a_points), the finalists, the totals and the invalid calls.
//                    The verdict's shape follows the format (judgeHeatVerdictFormat: a request rebuilds in the
//                    record's own schema), and judgeHeatRecordIssues holds every call and game to it; it re-derives every
//                    pairing, slot order, game, the finalists and the totals from the rest; judgeHeatVerdicts
//                    rebuilds the scores from a record that holds, twice, and refuses two that differ by a byte
//   spares           a planned call may be sent more than once, its first send and up to two backups
//                    (JUDGE_HEAT_MAX_SENDS in all). Its decision is the first send to answer with a verdict (a tie to
//                    the earlier send): that send is the call `calls` keeps, one a planned call and shaped as ever.
//                    Every other send of it is cancelled at once and kept in the record's optional `spares`, ordered by
//                    call, then send (JudgeHeatSpare: its call's index and send number, when it was sent and when it
//                    ended, how it ended, its attempts and their usage and price summed; judgeHeatSpareOf builds one,
//                    judgeHeatSpareIssues holds it). It ended `cancelled` (aborted when another send decided its call:
//                    no attempt, or one that gave no verdict), `invalid` (both its requests answered, neither with a
//                    verdict), `faulted` (a grader/judge-call.ts JudgeCallFault, its attempts the ones that completed),
//                    or `late` (a verdict that was not the first: in the same tick as the decision's, where the tie
//                    went to the earlier send, or just after it, answered before its cancel reached it: the one spare
//                    with a verdict, margin and reason). A spare is never scored: the games, the fit and
//                    every score read `calls` alone, so a record scores the same with its spares as without them. The
//                    totals count their attempts, usage and price (the heat paid for them), never a call. `spares` is
//                    absent, never empty, when a call had no other send, so such a record is the bytes it always was;
//                    a v1 record has none
//   invalid calls   a call with no verdict (grader/judge-call.ts: unparseable, refused, cut at the length limit or
//                    answered by another model, its answer and then its `verdict` tool, forced or offered). More than
//                    invalid_share_max of a heat's calls (judgeHeatInvalidShareOver) and the heat does not count:
//                    no record holds, no score is written
//   the resume       an attempt keeps each call as it settles (JudgeHeatPartial, under judgeHeatResumeKey), with what
//                    the heat spent and the key it holds open, and each kept call's spares; the next attempt checks the
//                    kept calls against the schedule and their spares to them (judgeHeatKeptIssue) and sends only the
//                    calls still to come
//
// Faults: a record out of shape, a call that is not the one the heat makes next, a heat whose judge answered too
// few calls are the house's (JudgeHeatError), never an entry's.

import { createHash } from 'node:crypto';
import { z } from 'zod';
import {
  BundlePath,
  HouseAgent,
  PROGRAM_JUDGE_LADDER_MAX,
  PROGRAM_JUDGE_MEDIA,
  PROGRAM_JUDGE_MIN_PLAYOFF_PLACES,
  PROGRAM_JUDGE_MIN_ROUNDS,
  type PrizeT,
  type ProgramJudgeT,
} from '../contracts/competition.ts';
import { CassetteUsage, type CassetteUsageT } from '../contracts/agent.ts';
import { Fixed9, FIXED9_SCALE, IsoDateTime, parseFixed9, Sha256Hex, U64 } from '../contracts/primitives.ts';
import { JUDGE_MICRO, ProgramJudgeScore, type ProgramJudgeScoreT } from '../contracts/score.ts';
import { ScrapeEntryId } from '../contracts/scrape.ts';
import { judgePlayoffPlaces } from '../server/competitions/load.ts';
import { canonicalJson, compareCodeUnits, sha256Hex } from '../sim/canonical.ts';
import { JUDGE_HOUSE_TEXT, JUDGE_MARGIN_MAX, JUDGE_MARGIN_MIN, JUDGE_REASON_MAX, type JudgeVerdictFormat } from './judge-call.ts';
// grader/judge-ladder.ts imports this module's constants back: its bindings are read only inside functions here.
import {
  judgeLadderDispersion,
  judgeLadderEstimate,
  judgeLadderFromFixed9,
  judgeLadderNext,
  judgeLadderScore,
  judgeLadderStrengths,
  judgeLadderToFixed9,
} from './judge-ladder.ts';
import { scrapeHeatOrder } from './scrape/heat.ts';

// ---------------------------------------------------------------- constants

/**
 * The heat record's format every final heat and every provisional heat with no ladder writes, and the seed's domain:
 * verdicts with a margin, games with their points.
 */
export const JUDGE_HEAT_FORMAT = 'agent-fun/judge-heat/v2';
/** The format of the records written before the margin (the header): read, held and scored, never written again. */
export const JUDGE_HEAT_FORMAT_V1 = 'agent-fun/judge-heat/v1';
/**
 * The ladder's format (the header's ladder): a calibration heat's record and a provisional heat's on a ladder. Its
 * calls, games and field are v2's (the same verdict and margin), plus the rungs, the calibration's repeats and the
 * provisional heat's fixed strengths; a final heat never writes it.
 */
export const JUDGE_HEAT_FORMAT_V3 = 'agent-fun/judge-heat/v3';
/** Every format a record may carry. */
export const JUDGE_HEAT_FORMATS = [JUDGE_HEAT_FORMAT_V1, JUDGE_HEAT_FORMAT, JUDGE_HEAT_FORMAT_V3] as const;
export type JudgeHeatFormatT = (typeof JUDGE_HEAT_FORMATS)[number];
/** The formats a final heat's record may carry: v3 is the ladder's alone. */
export const JUDGE_HEAT_FINAL_FORMATS = [JUDGE_HEAT_FORMAT_V1, JUDGE_HEAT_FORMAT] as const;
/** A call's worth between its two members, in tenths of a win (the header's game): 5 + margin and 5 - margin. */
export const JUDGE_CALL_TENTHS = 10;
/** A game's worth, in twentieths of a win (its two calls' tenths): a_points runs 0 to this, a draw at half. */
export const JUDGE_GAME_POINTS = 20;
/**
 * A record's stage: the final phase's heat, a dev entry's provisional heat against the anchors (and, on a ladder, its
 * rungs), or the house's calibration of a ladder's members against each other.
 */
export const JUDGE_HEAT_STAGES = ['final', 'provisional', 'calibration'] as const;
export type JudgeHeatStageT = (typeof JUDGE_HEAT_STAGES)[number];
/**
 * A call's stage: a final heat's Swiss rounds, then its playoff; a provisional heat's round against the anchors, then
 * on a ladder its adaptive games; a calibration's repeats.
 */
export const JUDGE_CALL_STAGES = ['swiss', 'playoff', 'provisional', 'calibration', 'adaptive'] as const;
export type JudgeCallStageT = (typeof JUDGE_CALL_STAGES)[number];
/** A call's slot order: `ab` shows the pair's `a` as Entry A and `b` as Entry B, `ba` the other way round. */
export const JUDGE_SLOT_ORDERS = ['ab', 'ba'] as const;
export type JudgeSlotOrderT = (typeof JUDGE_SLOT_ORDERS)[number];
/** What the judge answers: the slot it prefers. It has no tie. */
export const JUDGE_VERDICTS = ['A', 'B'] as const;
export type JudgeVerdictT = (typeof JUDGE_VERDICTS)[number];
/** A game's result: its pair's `a` won, its `b` won, or a draw. */
export const JUDGE_GAME_RESULTS = ['a', 'b', 'draw'] as const;
export type JudgeGameResultT = (typeof JUDGE_GAME_RESULTS)[number];

/** The fit's MM iterations (the header's fit): fixed, so the fit is the same bits wherever it runs. */
export const JUDGE_BT_ITERATIONS = 200;
/** The normal quantile of the 90% two-sided interval (the header's score). */
export const JUDGE_Z90 = 1.6449;
/**
 * The form a request was sent in (grader/judge-call.ts JudgeForm): the answer asked for as a response_format and the
 * forced `verdict` tool, or, for a model that takes no forced tool, the answer the system prompt alone asks for and the
 * verdict tool offered with tool_choice auto.
 */
export const JUDGE_CALL_FORMS = ['answer', 'tool', 'answer_plain', 'tool_auto'] as const;
export type JudgeCallFormT = (typeof JUDGE_CALL_FORMS)[number];
/**
 * A call's requests in the order sent (grader/judge-call.ts sendJudgeCall), by the answer's form: the answer, then,
 * when it gave no verdict, one of its retries. A forced answer retries as the forced tool, or as the offered one when
 * masq refused the forced form for its model; an unforced answer only as the offered tool.
 */
export const JUDGE_CALL_RETRY_FORMS: Readonly<Partial<Record<JudgeCallFormT, readonly JudgeCallFormT[]>>> = Object.freeze({
  answer: ['tool', 'tool_auto'],
  answer_plain: ['tool_auto'],
});
/** The requests a call sends at most (grader/judge-call.ts JUDGE_CALL_ATTEMPTS): its answer and one retry. */
export const JUDGE_CALL_MAX_ATTEMPTS = 2;
/**
 * The sends one planned call may have at most (the header's spares): its decision and at most two spares, its first
 * send and two backups. A spare's `send` is 0 to JUDGE_HEAT_MAX_SENDS - 1, and a call has at most JUDGE_HEAT_MAX_SENDS
 * - 1 spares. The sender's backup rule (grader/judge-backup.ts) sends no more than this.
 */
export const JUDGE_HEAT_MAX_SENDS = 3;
/**
 * How a spare send ended (the header's spares): aborted when another send decided its call, answered with no verdict
 * after its requests, a JudgeCallFault, or a verdict that was not its call's first (the header's `late`).
 */
export const JUDGE_SPARE_ENDS = ['cancelled', 'invalid', 'faulted', 'late'] as const;
export type JudgeSpareEndT = (typeof JUDGE_SPARE_ENDS)[number];
/** The candidate pairings a Swiss round's search examines before it takes the nearest-least-played walk instead. */
export const JUDGE_SWISS_SEARCH_STEPS = 1_000_000;

/** The heat cannot go on, or a record does not hold: the house's fault, never an entry's. */
export class JudgeHeatError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'JudgeHeatError';
  }
}

/** Whether `format` is a record format this code reads. */
function isHeatFormat(format: string): format is JudgeHeatFormatT {
  return (JUDGE_HEAT_FORMATS as readonly string[]).includes(format);
}

/**
 * The verdict a record of `format` asked for and reads (grader/judge-call.ts JudgeVerdictFormat): what its requests
 * rebuild in (judgeRequestBody's `verdict`) and its response bodies read as (judgeVerdictOf). RangeError on another.
 */
export function judgeHeatVerdictFormat(format: string): JudgeVerdictFormat {
  if (format === JUDGE_HEAT_FORMAT_V1) return 'v1';
  if (format === JUDGE_HEAT_FORMAT || format === JUDGE_HEAT_FORMAT_V3) return 'v2';
  throw new RangeError(`${JSON.stringify(format)} is not a judge heat record's format (${JUDGE_HEAT_FORMATS.join(', ')})`);
}

// ---------------------------------------------------------------- the record

const whenValid = { when: (payload: { issues: readonly unknown[] }): boolean => payload.issues.length === 0 };

/**
 * One request of a call, in the order sent: grader/judge-call.ts JudgeAttempt, field for field. What was sent and
 * what came back (the response stored as a blob before it was read), the model that answered, its usage in the
 * cassette's token classes and its price (priceUsage at `at`, micro-USD), and why it gave no verdict.
 */
export const JudgeHeatAttempt = z.strictObject({
  form: z.enum(JUDGE_CALL_FORMS),
  request_sha256: Sha256Hex,
  request_bytes: z.int().min(0),
  at: IsoDateTime,
  status: z.int().min(100).max(599),
  response_body_sha256: Sha256Hex,
  model_answered: z.string().nullable(),
  finish_reason: z.string().nullable(),
  /** Null when the answer carried none. */
  usage: CassetteUsage.nullable(),
  /** A u64 decimal; null when a 2xx answer carried no usage it could be priced by. */
  micro_usd: U64.nullable(),
  /** Null for the attempt that gave the verdict. */
  invalid: z.string().min(1).nullable(),
});
export type JudgeHeatAttemptT = z.infer<typeof JudgeHeatAttempt>;

/**
 * One call of the heat, in the order it ran: its pair and slot order, then grader/judge-call.ts JudgeCallResult's
 * verdict, margin (a v2 call's), reason, invalid, the last attempt's request, response blob and answering model, the
 * attempts' usage and price summed, and every attempt (judgeHeatCallIssues holds them together; judgeHeatCallOf builds
 * one).
 */
export const JudgeHeatCall = z.strictObject({
  stage: z.enum(JUDGE_CALL_STAGES),
  round: z.int().min(0),
  a: Sha256Hex,
  b: Sha256Hex,
  slot_order: z.enum(JUDGE_SLOT_ORDERS),
  /** The slot that won; null when no attempt gave a verdict (an invalid call). */
  verdict: z.enum(JUDGE_VERDICTS).nullable(),
  /**
   * How far the winner is ahead, JUDGE_MARGIN_MIN (by a hair) to JUDGE_MARGIN_MAX (overwhelmingly); null exactly when
   * the verdict is. Present on every call of a v2 record, absent on every call of a v1 record (judgeHeatRecordIssues).
   */
  margin: z.int().min(JUDGE_MARGIN_MIN).max(JUDGE_MARGIN_MAX).nullable().optional(),
  /** The judge's reason; null with the verdict. */
  reason: z.string().max(JUDGE_REASON_MAX).nullable(),
  /** Why the last attempt gave no verdict; null when one did. */
  invalid: z.string().min(1).nullable(),
  request_sha256: Sha256Hex,
  response_body_sha256: Sha256Hex,
  model_answered: z.string().nullable(),
  /** Every attempt's usage summed; null when none carried any. */
  usage: CassetteUsage.nullable(),
  /** Every attempt's price summed, a u64 decimal (an unpriced attempt adds nothing). */
  micro_usd: U64,
  attempts: z.array(JudgeHeatAttempt).min(1).max(JUDGE_CALL_MAX_ATTEMPTS),
});
export type JudgeHeatCallT = z.infer<typeof JudgeHeatCall>;

/** One game: a pair's two calls (the header's game), its `a` and `b` as the pairing named them. */
export const JudgeHeatGame = z.strictObject({
  stage: z.enum(JUDGE_CALL_STAGES),
  round: z.int().min(0),
  a: Sha256Hex,
  b: Sha256Hex,
  result: z.enum(JUDGE_GAME_RESULTS),
  /**
   * `a`'s twentieths of the game, 0 to JUDGE_GAME_POINTS (judgeGamePoints): its two calls' tenths summed, `b` holding the
   * rest. Present on every game of a v2 record, absent on every game of a v1 record (judgeHeatRecordIssues).
   */
  a_points: z.int().min(0).max(JUDGE_GAME_POINTS).optional(),
});
export type JudgeHeatGameT = z.infer<typeof JudgeHeatGame>;

/**
 * One field member (the header's field): a distinct artifact, its size, the anchor files that hold it (`anchor` exactly
 * when there is one), the ladder's rung files that hold it (a v3 record's, present exactly when there is one) and the
 * entries whose artifact it is, each list in code-unit order. A member is an anchor, a rung or an entry (or several:
 * byte-identical artifacts share one member).
 */
export const JudgeFieldMember = z
  .strictObject({
    artifact_sha256: Sha256Hex,
    /**
     * The artifact's size in bytes: what an exact win-rate tie falls to after head-to-head (the smaller first). Present
     * on every member of a v2 or v3 record, absent on every member of a v1 record (judgeHeatRecordIssues).
     */
    artifact_bytes: z.int().min(0).optional(),
    anchor: z.boolean(),
    /** Paths under <judge.dir>/anchors/. */
    anchor_files: z.array(BundlePath),
    /** Paths under <ladder dir>/rungs/: a v3 record's only, and only on a member a rung file holds. */
    rung_files: z.array(BundlePath).min(1).optional(),
    entries: z.array(ScrapeEntryId),
  })
  .refine((m) => m.anchor === m.anchor_files.length > 0, { message: 'a member is an anchor exactly when an anchor file holds it', path: ['anchor'], ...whenValid })
  .refine((m) => m.anchor_files.length + (m.rung_files?.length ?? 0) + m.entries.length > 0, { message: 'a member is an anchor, a rung or an entry', path: ['entries'], ...whenValid });
export type JudgeFieldMemberT = z.infer<typeof JudgeFieldMember>;

const Share = Fixed9.refine((s) => parseFixed9(s) >= 0n && parseFixed9(s) <= FIXED9_SCALE, {
  message: 'a share: at least 0, at most 1',
  when: (payload) => payload.issues.length === 0,
});

/**
 * The house's own words in every request of a heat (grader/judge-call.ts JudgeHouseText): the system prompt's
 * suffix, the user message's last line, an entry's heading (`{slot}` filled), a text entry's frame line (`{tag}`,
 * `{slot}` filled) and the verdict tool's description. A request is rebuilt from the record's, never from the
 * code's current wording; the verdict's JSON schema and the entry tag are structure, and stay the code's.
 */
export const JudgeHouseText = z.strictObject({
  verdict_instructions: z.string(),
  answer_line: z.string(),
  entry_heading: z.string(),
  entry_frame: z.string(),
  verdict_tool_description: z.string(),
});
export type JudgeHouseTextT = z.infer<typeof JudgeHouseText>;

/** A ladder member's fixed strength (the header's ladder): its artifact and the calibration's strength, Fixed9. */
export const JudgeLadderStrength = z.strictObject({
  artifact_sha256: Sha256Hex,
  /** Above 0 and below 2^53 billionths (grader/judge-ladder.ts judgeLadderFromFixed9). */
  strength: Fixed9,
});
export type JudgeLadderStrengthT = z.infer<typeof JudgeLadderStrength>;

/**
 * What a provisional heat on a ladder plays against and rates by (the header's ladder): the sealed ladder dir's tree
 * digest and its calibration record's sha256, every other member's fixed strength in sha256 order, the calibration's
 * dispersion, and the adaptive design: `rounds` rounds of `games` games, each round over the `spread` most informative
 * members. Each number is held to the bundle's bounds (contracts/competition.ts PROGRAM_JUDGE_LADDER_MAX), so a record
 * read from outside cannot plan a call list longer than a bundle's ladder makes.
 */
export const JudgeHeatLadder = z.strictObject({
  ladder_sha256: Sha256Hex,
  calibration_sha256: Sha256Hex,
  strengths: z.array(JudgeLadderStrength),
  /** phi, the calibration's pooled within-pair dispersion (grader/judge-ladder.ts judgeLadderDispersion). */
  dispersion: Fixed9,
  rounds: z.int().min(0).max(PROGRAM_JUDGE_LADDER_MAX.rounds),
  games: z.int().min(1).max(PROGRAM_JUDGE_LADDER_MAX.games),
  spread: z.int().min(1).max(PROGRAM_JUDGE_LADDER_MAX.spread),
});
export type JudgeHeatLadderT = z.infer<typeof JudgeHeatLadder>;

/** What a heat is before its calls: everything that plans them. */
const setupShape = {
  /**
   * JUDGE_HEAT_FORMAT for a final heat and a provisional heat with no ladder run now; JUDGE_HEAT_FORMAT_V3 for a
   * calibration and a provisional heat on a ladder; JUDGE_HEAT_FORMAT_V1 for a record written before the margin.
   */
  format: z.enum(JUDGE_HEAT_FORMATS),
  stage: z.enum(JUDGE_HEAT_STAGES),
  phase_seed: U64,
  /** judgeHeatSeed(phase_seed, format). */
  seed: Sha256Hex,
  /** The house judge: the model call (its model, prompt file and parameters) and the judge directory's tree digest. */
  agent: HouseAgent,
  judge_sha256: Sha256Hex,
  media: z.enum(PROGRAM_JUDGE_MEDIA),
  /** The house text the heat's requests are built from (JUDGE_HOUSE_TEXT when it ran). */
  house_text: JudgeHouseText,
  /** The output file each entry's artifact is read from. */
  artifact: BundlePath,
  /** The Swiss rounds (a provisional heat's and a calibration's: 0; a ladder's adaptive rounds are its `ladder.rounds`). */
  rounds: z.int().min(0),
  /** judgePlayoffPlaces: the most finalists the playoff takes (a provisional heat's and a calibration's: 0). */
  playoff_places: z.int().min(0),
  /** The times each playoff pair is judged (a provisional heat's and a calibration's: 0). */
  playoff_repeats: z.int().min(0),
  invalid_share_max: Share,
  /** The members, in sha256 order. */
  field: z.array(JudgeFieldMember),
  /** A calibration's (and only a calibration's): the times every pair of members is judged, both slot orders each time. */
  repeats: z.int().min(1).optional(),
  /** A provisional heat's on a ladder (a v3 one's, and only its): what it plays against and rates by. */
  ladder: JudgeHeatLadder.optional(),
};

/** A heat's setup: a record before its calls. What the schedule (judgeHeatSchedule) plans from. */
export const JudgeHeatSetup = z.strictObject(setupShape);
export type JudgeHeatSetupT = z.infer<typeof JudgeHeatSetup>;

/**
 * The calls' totals: how many, and every attempt the heat sent (its calls' and its spares'), counted, their usage and
 * price summed (micro-USD, a u64 decimal).
 */
export const JudgeHeatTotals = z.strictObject({
  calls: z.int().min(0),
  attempts: z.int().min(0),
  usage: CassetteUsage,
  micro_usd: U64,
});
export type JudgeHeatTotalsT = z.infer<typeof JudgeHeatTotals>;

/**
 * A send of a call that is not its decision (the header's spares): which call and which send, when it was sent and
 * ended, how it ended, what it answered (a verdict, margin and reason only when `late`), why it gave no verdict
 * (null only when `late`), its attempts' usage and price summed, and its attempts, none to JUDGE_CALL_MAX_ATTEMPTS
 * (judgeHeatSpareIssues holds them together; judgeHeatSpareOf builds one). Never scored.
 */
export const JudgeHeatSpare = z.strictObject({
  /** The index into the record's (or the partial's) `calls` of the call it was a send of. */
  call: z.int().min(0),
  /** 0 the call's first send, 1 and 2 its backups; the call's decision holds the send number its spares do not. */
  send: z.int().min(0).max(JUDGE_HEAT_MAX_SENDS - 1),
  sent_at: IsoDateTime,
  /** When it answered, faulted or was cancelled: not before sent_at. */
  ended_at: IsoDateTime,
  ended: z.enum(JUDGE_SPARE_ENDS),
  /** A `late` spare's verdict; null on any other. */
  verdict: z.enum(JUDGE_VERDICTS).nullable(),
  /** A `late` spare's margin, JUDGE_MARGIN_MIN to JUDGE_MARGIN_MAX; null on any other. */
  margin: z.int().min(JUDGE_MARGIN_MIN).max(JUDGE_MARGIN_MAX).nullable(),
  /** A `late` spare's reason; null on any other. */
  reason: z.string().max(JUDGE_REASON_MAX).nullable(),
  /** Why it gave no verdict: an `invalid` spare's last attempt's why, a `faulted` or `cancelled` one's fault; null when `late`. */
  invalid: z.string().min(1).nullable(),
  /** Every attempt's usage summed; null when none carried any. */
  usage: CassetteUsage.nullable(),
  /** Every attempt's price summed, a u64 decimal (an unpriced attempt adds nothing). */
  micro_usd: U64,
  attempts: z.array(JudgeHeatAttempt).max(JUDGE_CALL_MAX_ATTEMPTS),
});
export type JudgeHeatSpareT = z.infer<typeof JudgeHeatSpare>;

/** The heat record (the header's record): canonical JSON, stored as a blob named by its sha256. */
export const JudgeHeatRecord = z.strictObject({
  ...setupShape,
  calls: z.array(JudgeHeatCall),
  games: z.array(JudgeHeatGame),
  /** The playoff's members in Swiss-standing order; empty when no playoff ran. */
  finalists: z.array(Sha256Hex),
  totals: JudgeHeatTotals,
  /** The calls with no verdict. */
  invalid_calls: z.int().min(0),
  /** The calls' other sends, ordered by call, then send (the header's spares); absent, never empty, when there are none. */
  spares: z.array(JudgeHeatSpare).min(1).optional(),
});
export type JudgeHeatRecordT = z.infer<typeof JudgeHeatRecord>;

/** The record's canonical JSON and its sha256: the blob it is stored as. */
export function judgeHeatRecordDigest(record: JudgeHeatRecordT): { json: string; sha256: string } {
  const json = canonicalJson(JudgeHeatRecord.parse(record));
  return { json, sha256: sha256Hex(json) };
}

// ---------------------------------------------------------------- the seed and the draws

/**
 * The heat's seed (the header's seed): sha256(utf8(format) || 0x00 || utf8(phase seed)), lowercase hex. `format` is the
 * record's own (default JUDGE_HEAT_FORMAT, a heat run now): a v1 record re-derives its v1 seed.
 */
export function judgeHeatSeed(phaseSeed: string, format: JudgeHeatFormatT = JUDGE_HEAT_FORMAT): string {
  if (!U64.safeParse(phaseSeed).success) throw new RangeError(`the phase seed ${JSON.stringify(phaseSeed)} is not a u64 decimal`);
  if (!isHeatFormat(format)) throw new RangeError(`${JSON.stringify(format)} is not a judge heat record's format (${JUDGE_HEAT_FORMATS.join(', ')})`);
  return createHash('sha256').update(format, 'utf8').update(Buffer.from([0])).update(phaseSeed, 'utf8').digest('hex');
}

function checkSeed(seed: string): void {
  if (!Sha256Hex.safeParse(seed).success) throw new RangeError('the seed is 64 lowercase hex');
}

function checkRound(round: number): void {
  if (!Number.isSafeInteger(round) || round < 0 || round > 0xffff_ffff) throw new RangeError(`round ${String(round)} is not a whole number from 0 to ${0xffff_ffff}`);
}

function checkMembers(members: readonly string[]): void {
  for (const m of members) if (!Sha256Hex.safeParse(m).success) throw new TypeError(`${JSON.stringify(m)} is not a member (an artifact's lowercase hex sha256)`);
  if (new Set(members).size !== members.length) throw new TypeError('the field lists a member twice');
}

/**
 * Round 1's order (the header's seed): scrapeHeatOrder of the seed, stage `main`, round 0, over the members' places
 * in sha256 order (equal-width decimal labels, which sort as the places do), mapped back to the members. order[0]
 * ranks first.
 */
export function judgeHeatOrder(seed: string, members: readonly string[]): string[] {
  checkSeed(seed);
  checkMembers(members);
  if (members.length === 0) return [];
  const sorted = [...members].sort(compareCodeUnits);
  const width = String(sorted.length - 1).length;
  const labels = sorted.map((_, i) => String(i).padStart(width, '0'));
  return scrapeHeatOrder(seed, 'main', 0, labels).map((label) => sorted[Number(label)]!);
}

function u32be(n: number): Buffer {
  const b = Buffer.alloc(4);
  b.writeUInt32BE(n);
  return b;
}

/** Which slot order of the pair (a, b) runs first in a stage's round (the header's seed). The other runs second. */
export function judgeSlotOrder(seed: string, stage: JudgeCallStageT, round: number, a: string, b: string): JudgeSlotOrderT {
  checkSeed(seed);
  if (!(JUDGE_CALL_STAGES as readonly string[]).includes(stage)) throw new RangeError(`stage ${JSON.stringify(stage)} is not one of ${JUDGE_CALL_STAGES.join(', ')}`);
  checkRound(round);
  checkMembers([a, b]);
  const digest = createHash('sha256')
    .update('slot', 'utf8')
    .update(Buffer.from([0]))
    .update(Buffer.from(seed, 'hex'))
    .update(stage, 'utf8')
    .update(Buffer.from([0]))
    .update(u32be(round))
    .update(Buffer.from(a, 'hex'))
    .update(Buffer.from(b, 'hex'))
    .digest();
  return (digest[0]! & 1) === 0 ? 'ab' : 'ba';
}

function otherOrder(o: JudgeSlotOrderT): JudgeSlotOrderT {
  return o === 'ab' ? 'ba' : 'ab';
}

// ---------------------------------------------------------------- the fit

/** One member's fit: its strength p, its expected win rate E against the field and E's standard error. */
export interface JudgeFitT {
  p: number;
  e: number;
  se: number;
}

/**
 * Bradley-Terry over `games` (the header's fit and score): every member's strength, expected win rate and standard
 * error, keyed by member. A game with a_points (v2) is the soft outcome a_points / 20 to `a` and the rest to `b`; one
 * without (v1) a whole win to its result's side, or half each for a draw. The members are taken in sha256 order and the
 * games folded into counts first, so the result is the same bits for any order of either. At least two members; every
 * game between two of them, its a_points (when present) a whole number from 0 to JUDGE_GAME_POINTS.
 */
export function judgeFit(members: readonly string[], games: readonly Pick<JudgeHeatGameT, 'a' | 'b' | 'result' | 'a_points'>[]): Map<string, JudgeFitT> {
  checkMembers(members);
  if (members.length < 2) throw new RangeError('a fit takes at least two members');
  const sorted = [...members].sort(compareCodeUnits);
  const n = sorted.length;
  const at = new Map(sorted.map((m, i) => [m, i]));
  // Twentieths of a win, the virtual draw's half a win (10) each: whole numbers, so the fold is exact in any order.
  const half = JUDGE_GAME_POINTS / 2;
  const units = new Array<number>(n).fill(half);
  const counts = new Map<number, number>();
  for (const g of games) {
    const i = at.get(g.a);
    const j = at.get(g.b);
    if (i === undefined || j === undefined) throw new RangeError(`a game between ${g.a} and ${g.b} names a member outside the field`);
    if (i === j) throw new RangeError(`a game of ${g.a} against itself`);
    if (g.a_points !== undefined) {
      if (!Number.isSafeInteger(g.a_points) || g.a_points < 0 || g.a_points > JUDGE_GAME_POINTS) throw new RangeError(`a game's a_points ${String(g.a_points)} is not a whole number from 0 to ${JUDGE_GAME_POINTS}`);
      units[i] += g.a_points;
      units[j] += JUDGE_GAME_POINTS - g.a_points;
    } else if (g.result === 'a') units[i] += JUDGE_GAME_POINTS;
    else if (g.result === 'b') units[j] += JUDGE_GAME_POINTS;
    else {
      units[i] += half;
      units[j] += half;
    }
    const key = i < j ? i * n + j : j * n + i;
    counts.set(key, (counts.get(key) ?? 0) + 1);
  }
  // Each member's opponents in member order, with the games against each.
  const opponents: Array<Array<[number, number]>> = sorted.map(() => []);
  for (const [key, c] of [...counts].sort((x, y) => x[0] - y[0])) {
    const i = Math.floor(key / n);
    const j = key - i * n;
    opponents[i]!.push([j, c]);
    opponents[j]!.push([i, c]);
  }
  for (const list of opponents) list.sort((x, y) => x[0] - y[0]);
  // One division each, exact: a v1 record's wins are the same bits its half-wins / 2 gave.
  const wins = units.map((u) => u / JUDGE_GAME_POINTS);
  let p = new Array<number>(n).fill(1);
  for (let iter = 0; iter < JUDGE_BT_ITERATIONS; iter++) {
    const next = new Array<number>(n);
    for (let i = 0; i < n; i++) {
      const pi = p[i]!;
      let denom = 1 / (pi + 1);
      for (const [j, c] of opponents[i]!) denom += c / (pi + p[j]!);
      next[i] = wins[i]! / denom;
    }
    p = next;
  }
  const out = new Map<string, JudgeFitT>();
  for (let i = 0; i < n; i++) {
    const pi = p[i]!;
    let e = 0;
    let slope = 0;
    for (let j = 0; j < n; j++) {
      if (j === i) continue;
      const s = pi + p[j]!;
      e += pi / s;
      slope += (pi * p[j]!) / (s * s);
    }
    let info = pi / ((pi + 1) * (pi + 1));
    for (const [j, c] of opponents[i]!) {
      const s = pi + p[j]!;
      info += (c * pi * p[j]!) / (s * s);
    }
    out.set(sorted[i]!, { p: pi, e: e / (n - 1), se: slope / (n - 1) / Math.sqrt(info) });
  }
  return out;
}

// ---------------------------------------------------------------- the Swiss

/** A Swiss pair: `a` ranked above `b`, and the slot order its first call runs in. */
export interface JudgeSwissPairT {
  a: string;
  b: string;
  first: JudgeSlotOrderT;
}

/** One Swiss round's pairing: its pairs from the top of the ranking down, and the member with the bye (null on an even field). */
export interface JudgeSwissRoundT {
  pairs: JudgeSwissPairT[];
  bye: string | null;
}

/** What the earlier rounds played: the games between each two members (judgePairKey) and each member's byes. */
export interface JudgeSwissHistoryT {
  games: ReadonlyMap<string, number>;
  byes: ReadonlyMap<string, number>;
}

/** The key of an unordered pair of members. */
export function judgePairKey(a: string, b: string): string {
  return compareCodeUnits(a, b) < 0 ? `${a}:${b}` : `${b}:${a}`;
}

/** The history of `rounds`, in any order. */
export function judgeSwissHistory(rounds: readonly JudgeSwissRoundT[]): JudgeSwissHistoryT {
  const games = new Map<string, number>();
  const byes = new Map<string, number>();
  for (const r of rounds) {
    for (const p of r.pairs) games.set(judgePairKey(p.a, p.b), (games.get(judgePairKey(p.a, p.b)) ?? 0) + 1);
    if (r.bye !== null) byes.set(r.bye, (byes.get(r.bye) ?? 0) + 1);
  }
  return { games, byes };
}

/** The members ranked by E, higher first, ties by sha256. */
function byStanding(standing: ReadonlyMap<string, number>): string[] {
  return [...standing.keys()].sort((x, y) => standing.get(y)! - standing.get(x)! || compareCodeUnits(x, y));
}

/**
 * A pairing of every member of `ranked` (an even count) with no game played before, each member from the top taking
 * the nearest one below it that leaves the rest such a pairing; null when none exists, or when the search spends the
 * budget. Pairs of indices into `ranked`, top first.
 */
function freshPairing(ranked: readonly string[], played: (a: string, b: string) => number, budget: { left: number }): Array<[number, number]> | null {
  const used = new Array<boolean>(ranked.length).fill(false);
  const out: Array<[number, number]> = [];
  const search = (from: number): boolean => {
    let top = from;
    while (top < ranked.length && used[top]) top++;
    if (top === ranked.length) return true;
    used[top] = true;
    for (let c = top + 1; c < ranked.length; c++) {
      if (used[c]) continue;
      if (--budget.left < 0) break;
      if (played(ranked[top]!, ranked[c]!) > 0) continue;
      used[c] = true;
      out.push([top, c]);
      if (search(top + 1)) return true;
      out.pop();
      used[c] = false;
    }
    used[top] = false;
    return false;
  };
  return search(0) ? out : null;
}

/** Each member from the top takes the nearest one below it that it has played least: repeats allowed. */
function leastPlayedPairing(ranked: readonly string[], played: (a: string, b: string) => number): Array<[number, number]> {
  const used = new Array<boolean>(ranked.length).fill(false);
  const out: Array<[number, number]> = [];
  for (let top = 0; top < ranked.length; top++) {
    if (used[top]) continue;
    let best = -1;
    for (let c = top + 1; c < ranked.length; c++) {
      if (!used[c] && (best === -1 || played(ranked[top]!, ranked[c]!) < played(ranked[top]!, ranked[best]!))) best = c;
    }
    used[top] = true;
    used[best] = true;
    out.push([top, best]);
  }
  return out;
}

/**
 * One Swiss round's pairing (the header's Swiss). `standing` is every Swiss member's current expected win rate (round
 * 0 ranks by the seed's order instead), `played` what the earlier rounds played (judgeSwissHistory), and each pair's
 * first slot order is drawn from the seed (judgeSlotOrder, stage `swiss`). RangeError or TypeError on a malformed
 * argument.
 */
export function judgeSwissPairs(standing: ReadonlyMap<string, number>, played: JudgeSwissHistoryT, seed: string, round: number): JudgeSwissRoundT {
  checkSeed(seed);
  checkRound(round);
  checkMembers([...standing.keys()]);
  for (const [m, e] of standing) if (!Number.isFinite(e) || e < 0 || e > 1) throw new RangeError(`${m}'s expected win rate ${e} is not within [0, 1]`);
  const ranked = round === 0 ? judgeHeatOrder(seed, [...standing.keys()]) : byStanding(standing);
  if (ranked.length < 2) return { pairs: [], bye: ranked[0] ?? null };
  const games = (a: string, b: string): number => played.games.get(judgePairKey(a, b)) ?? 0;
  const byes = (m: string): number => played.byes.get(m) ?? 0;
  // The bye's candidates: the fewest byes first, the lowest ranked first among them; none on an even field.
  const candidates =
    ranked.length % 2 === 0
      ? [null]
      : ranked
          .map((m, i) => ({ m, i }))
          .sort((x, y) => byes(x.m) - byes(y.m) || y.i - x.i)
          .map(({ m }) => m);
  const budget = { left: JUDGE_SWISS_SEARCH_STEPS };
  let chosen: { bye: string | null; rest: string[]; pairs: Array<[number, number]> } | null = null;
  for (const bye of candidates) {
    const rest = ranked.filter((m) => m !== bye);
    const pairs = freshPairing(rest, games, budget);
    if (pairs !== null) {
      chosen = { bye, rest, pairs };
      break;
    }
    if (budget.left < 0) break;
  }
  if (chosen === null) {
    const bye = candidates[0] ?? null;
    const rest = ranked.filter((m) => m !== bye);
    chosen = { bye, rest, pairs: leastPlayedPairing(rest, games) };
  }
  const { rest } = chosen;
  return {
    pairs: chosen.pairs.map(([i, j]) => ({ a: rest[i]!, b: rest[j]!, first: judgeSlotOrder(seed, 'swiss', round, rest[i]!, rest[j]!) })),
    bye: chosen.bye,
  };
}

// ---------------------------------------------------------------- the field and the setup

/** An entry of the field: its id, its artifact's sha256 and (a v2 heat's) its size in bytes. */
export interface JudgeHeatEntryInputT {
  entry: string;
  artifact_sha256: string;
  artifact_bytes?: number;
}

/** A house anchor of the field: its path under <judge.dir>/anchors/, its sha256 and (a v2 heat's) its size in bytes. */
export interface JudgeHeatAnchorInputT {
  file: string;
  artifact_sha256: string;
  artifact_bytes?: number;
}

/** A ladder rung of the field (a v3 heat's): its path under <ladder dir>/rungs/, its sha256 and its size in bytes. */
export type JudgeHeatRungInputT = JudgeHeatAnchorInputT;

/**
 * The field (the header's field): one member per distinct artifact sha256, in sha256 order, each holding its size in
 * bytes (when the entries, anchors and rungs name theirs), the anchor files, the rung files (a key only on a member one
 * holds) and the entries whose artifact it is (in code-unit order). TypeError on an entry, anchor or rung file listed
 * twice, on a malformed one, on sizes named for some and not all, or on two sizes for one artifact.
 */
export function judgeHeatField(entries: readonly JudgeHeatEntryInputT[], anchors: readonly JudgeHeatAnchorInputT[], rungs: readonly JudgeHeatRungInputT[] = []): JudgeFieldMemberT[] {
  const members = new Map<string, { bytes: number | undefined; anchor_files: string[]; rung_files: string[]; entries: string[] }>();
  const all = [...entries, ...anchors, ...rungs];
  const sized = all.filter((x) => x.artifact_bytes !== undefined).length;
  if (sized !== 0 && sized !== all.length) throw new TypeError(`${sized} of the field's ${all.length} entries, anchors and rungs name their artifact's bytes: every one does, or none`);
  const member = (sha: string, bytes: number | undefined, who: string) => {
    if (!Sha256Hex.safeParse(sha).success) throw new TypeError(`${JSON.stringify(sha)} is not an artifact's lowercase hex sha256`);
    if (bytes !== undefined && (!Number.isSafeInteger(bytes) || bytes < 0)) throw new TypeError(`${who}'s artifact bytes ${String(bytes)} is not a whole number from 0`);
    let m = members.get(sha);
    if (m === undefined) members.set(sha, (m = { bytes, anchor_files: [], rung_files: [], entries: [] }));
    else if (m.bytes !== bytes) throw new TypeError(`${who}'s artifact ${sha} is ${String(bytes)} bytes, and another's of the same sha256 ${String(m.bytes)}`);
    return m;
  };
  const seen = new Set<string>();
  for (const e of entries) {
    if (!ScrapeEntryId.safeParse(e.entry).success) throw new TypeError(`${JSON.stringify(e.entry)} is not an entry id`);
    if (seen.has(`entry ${e.entry}`)) throw new TypeError(`entry ${e.entry} is listed twice`);
    seen.add(`entry ${e.entry}`);
    member(e.artifact_sha256, e.artifact_bytes, `entry ${e.entry}`).entries.push(e.entry);
  }
  for (const a of anchors) {
    if (!BundlePath.safeParse(a.file).success) throw new TypeError(`${JSON.stringify(a.file)} is not an anchor file's path`);
    if (seen.has(`anchor ${a.file}`)) throw new TypeError(`anchor ${a.file} is listed twice`);
    seen.add(`anchor ${a.file}`);
    member(a.artifact_sha256, a.artifact_bytes, `anchor ${a.file}`).anchor_files.push(a.file);
  }
  for (const r of rungs) {
    if (!BundlePath.safeParse(r.file).success) throw new TypeError(`${JSON.stringify(r.file)} is not a rung file's path`);
    if (seen.has(`rung ${r.file}`)) throw new TypeError(`rung ${r.file} is listed twice`);
    seen.add(`rung ${r.file}`);
    member(r.artifact_sha256, r.artifact_bytes, `rung ${r.file}`).rung_files.push(r.file);
  }
  return [...members]
    .sort((x, y) => compareCodeUnits(x[0], y[0]))
    .map(([sha, m]) => ({
      artifact_sha256: sha,
      ...(m.bytes === undefined ? {} : { artifact_bytes: m.bytes }),
      anchor: m.anchor_files.length > 0,
      anchor_files: m.anchor_files.sort(compareCodeUnits),
      ...(m.rung_files.length === 0 ? {} : { rung_files: m.rung_files.sort(compareCodeUnits) }),
      entries: m.entries.sort(compareCodeUnits),
    }));
}

export interface JudgeHeatSetupOptions {
  stage: JudgeHeatStageT;
  /** The phase's seed, a u64 decimal: the seed its grade runs carry (grader/worker.ts programPlan). */
  phaseSeed: string;
  judge: Pick<ProgramJudgeT, 'agent' | 'judge_sha256' | 'media' | 'artifact' | 'rounds' | 'playoff_places' | 'playoff_repeats' | 'invalid_share_max'>;
  /** A final heat's: the bundle's prizes, for judgePlayoffPlaces. */
  prizes?: readonly Pick<PrizeT, 'kind' | 'place' | 'amount_usd'>[];
  /**
   * A final heat's: every kept entry that passed the gate; a provisional heat's: its one dev entry; a calibration's:
   * none. Each names its artifact's bytes for a v2 or v3 heat (its field records them); a v1 setup drops them, as v1
   * recorded none.
   */
  entries: readonly JudgeHeatEntryInputT[];
  /** The house anchors under <judge.dir>/anchors/, each with its file's bytes likewise. */
  anchors: readonly JudgeHeatAnchorInputT[];
  /** A v3 heat's: the ladder's rungs under <ladder dir>/rungs/, each with its file's bytes. */
  rungs?: readonly JudgeHeatRungInputT[];
  /** A calibration's: the times every pair of members is judged (both slot orders each time), at least 1. */
  repeats?: number;
  /** A provisional heat's on a ladder: what it plays against and rates by (the record's `ladder`). */
  ladder?: JudgeHeatLadderT;
  /** The house text its requests are built from: default JUDGE_HOUSE_TEXT (a live heat); a record's own when one is re-derived. */
  house?: JudgeHouseTextT;
  /**
   * The record's format: by default what a heat run now writes, JUDGE_HEAT_FORMAT_V3 for a calibration and a provisional
   * heat on a ladder and JUDGE_HEAT_FORMAT for any other; a stored record's own when one is re-derived (a v1 record's
   * setup, and so its seed, is v1's).
   */
  format?: JudgeHeatFormatT;
}

/** A heat's setup from its judge and field. JudgeHeatError when it does not hold (judgeHeatSetupIssues). */
export function judgeHeatSetup(o: JudgeHeatSetupOptions): JudgeHeatSetupT {
  const final = o.stage === 'final';
  if (final && o.prizes === undefined) throw new TypeError("a final heat's playoff places follow from the prizes: name them");
  const format = o.format ?? (o.stage === 'calibration' || o.ladder !== undefined ? JUDGE_HEAT_FORMAT_V3 : JUDGE_HEAT_FORMAT);
  const v1 = format === JUDGE_HEAT_FORMAT_V1;
  const rungs = o.rungs ?? [];
  const setup = {
    format,
    stage: o.stage,
    phase_seed: o.phaseSeed,
    seed: judgeHeatSeed(o.phaseSeed, format),
    agent: o.judge.agent,
    judge_sha256: o.judge.judge_sha256,
    media: o.judge.media,
    house_text: { ...(o.house ?? JUDGE_HOUSE_TEXT) },
    artifact: o.judge.artifact,
    rounds: final ? o.judge.rounds : 0,
    playoff_places: final ? judgePlayoffPlaces(o.judge, o.prizes!) : 0,
    playoff_repeats: final ? o.judge.playoff_repeats : 0,
    invalid_share_max: o.judge.invalid_share_max,
    field: v1
      ? judgeHeatField(
          o.entries.map((e) => ({ entry: e.entry, artifact_sha256: e.artifact_sha256 })),
          o.anchors.map((a) => ({ file: a.file, artifact_sha256: a.artifact_sha256 })),
          rungs.map((r) => ({ file: r.file, artifact_sha256: r.artifact_sha256 })),
        )
      : judgeHeatField(o.entries, o.anchors, rungs),
    ...(o.repeats === undefined ? {} : { repeats: o.repeats }),
    ...(o.ladder === undefined ? {} : { ladder: o.ladder }),
  };
  const issues = judgeHeatSetupIssues(setup as JudgeHeatSetupT);
  if (issues.length > 0) throw new JudgeHeatError(`the heat does not hold: ${issues.slice(0, 5).join('; ')}`);
  return JudgeHeatSetup.parse(setup);
}

/** The most rounds a call's round number holds (judgeSlotOrder draws on it as a u32). */
const ROUND_MAX = 0xffff_ffff;

/**
 * What does not hold in a parsed setup: its seed, the field's order and lists, each member's artifact bytes as the
 * format records them (a v2 or v3 member's present, a v1 member's absent) and its rung files (a v3 member's alone), the
 * stage's format (a final heat's v1 or v2, a calibration's v3, a provisional heat's v3 exactly when it plays a ladder),
 * and the stage's numbers and field (judgeLadderIssuesOf for a ladder's).
 */
function setupIssuesOf(setup: JudgeHeatSetupT): string[] {
  const issues: string[] = [];
  if (setup.seed !== judgeHeatSeed(setup.phase_seed, setup.format)) issues.push(`seed: not judgeHeatSeed(${setup.phase_seed}, ${setup.format})`);
  const entries = new Set<string>();
  const files = new Set<string>();
  const rungFiles = new Set<string>();
  const sorted = (list: readonly string[]) => list.every((x, k) => k === 0 || compareCodeUnits(list[k - 1]!, x) < 0);
  const v1 = setup.format === JUDGE_HEAT_FORMAT_V1;
  const v3 = setup.format === JUDGE_HEAT_FORMAT_V3;
  setup.field.forEach((m, i) => {
    if (i > 0 && compareCodeUnits(setup.field[i - 1]!.artifact_sha256, m.artifact_sha256) >= 0) issues.push(`field.${i}: the members are distinct, in sha256 order`);
    if (v1 && m.artifact_bytes !== undefined) issues.push(`field.${i}.artifact_bytes: a ${JUDGE_HEAT_FORMAT_V1} member records no artifact bytes`);
    if (!v1 && m.artifact_bytes === undefined) issues.push(`field.${i}.artifact_bytes: a ${setup.format} member records its artifact's bytes`);
    if (!sorted(m.entries)) issues.push(`field.${i}.entries: distinct, in code-unit order`);
    if (!sorted(m.anchor_files)) issues.push(`field.${i}.anchor_files: distinct, in code-unit order`);
    for (const e of m.entries) {
      if (entries.has(e)) issues.push(`field.${i}.entries: ${e} is another member's too`);
      entries.add(e);
    }
    for (const f of m.anchor_files) {
      if (files.has(f)) issues.push(`field.${i}.anchor_files: ${f} is another member's too`);
      files.add(f);
    }
    if (m.rung_files !== undefined) {
      if (!v3) issues.push(`field.${i}.rung_files: a ${setup.format} member holds no rung: rungs are a ${JUDGE_HEAT_FORMAT_V3} record's`);
      if (!sorted(m.rung_files)) issues.push(`field.${i}.rung_files: distinct, in code-unit order`);
      for (const f of m.rung_files) {
        if (rungFiles.has(f)) issues.push(`field.${i}.rung_files: ${f} is another member's too`);
        rungFiles.add(f);
      }
    }
  });
  const noRounds = (who: string) => {
    if (setup.rounds !== 0 || setup.playoff_places !== 0 || setup.playoff_repeats !== 0) issues.push(`rounds: ${who} plays no Swiss rounds and no playoff (rounds, playoff_places and playoff_repeats 0)`);
  };
  if (setup.repeats !== undefined && setup.stage !== 'calibration') issues.push("repeats: a calibration's alone");
  if (setup.ladder !== undefined && !(v3 && setup.stage === 'provisional')) issues.push(`ladder: a ${JUDGE_HEAT_FORMAT_V3} provisional heat's alone`);
  if (setup.stage === 'final') {
    if (v3) issues.push(`format: a final heat's record is ${JUDGE_HEAT_FINAL_FORMATS.join(' or ')}, never ${JUDGE_HEAT_FORMAT_V3}`);
    if (setup.rounds < PROGRAM_JUDGE_MIN_ROUNDS) issues.push(`rounds: a final heat plays at least ${PROGRAM_JUDGE_MIN_ROUNDS} Swiss rounds`);
    if (setup.playoff_places < PROGRAM_JUDGE_MIN_PLAYOFF_PLACES) issues.push(`playoff_places: a final heat's playoff takes at least ${PROGRAM_JUDGE_MIN_PLAYOFF_PLACES} places`);
    if (setup.playoff_repeats < 1) issues.push("playoff_repeats: a final heat's playoff judges each pair at least once");
  } else if (setup.stage === 'calibration') {
    if (!v3) issues.push(`format: a calibration's record is ${JUDGE_HEAT_FORMAT_V3}`);
    noRounds('a calibration');
    if (setup.repeats === undefined) issues.push('repeats: a calibration judges every pair of its members at least once');
    else if (setup.repeats - 1 > ROUND_MAX) issues.push(`repeats: at most ${ROUND_MAX + 1}`);
    // Every member is an anchor or a rung: a member holds an anchor file, a rung file or an entry (JudgeFieldMember).
    if (setup.field.some((m) => m.entries.length > 0)) issues.push("field: a calibration judges the ladder's members, the anchors and the rungs, never an entry");
    if (setup.field.length < 2) issues.push('field: a calibration takes at least two members');
  } else {
    noRounds('a provisional heat');
    // Every other member is an anchor (or, on a ladder, a rung): a member holds an anchor file, a rung file or an entry.
    const subjects = setup.field.filter((m) => m.entries.length > 0);
    if (subjects.length !== 1 || subjects[0]!.entries.length !== 1) issues.push('field: a provisional heat judges one entry, against the anchors');
    else if (v3) {
      if (setup.ladder === undefined) issues.push(`ladder: a ${JUDGE_HEAT_FORMAT_V3} provisional heat plays a ladder, and names it`);
      else issues.push(...judgeLadderIssuesOf(setup, setup.ladder, subjects[0]!.artifact_sha256));
    }
  }
  return issues;
}

/**
 * What does not hold in a provisional heat's ladder (the header's ladder): the subject (the entry's member) plays every
 * other member, each an anchor or a rung, at least one of them a judge anchor (its E is over them); `strengths` names
 * exactly those members, in sha256 order, each a strength judgeLadderFromFixed9 reads; the dispersion likewise; and its
 * adaptive games' round numbers fit a u32.
 */
function judgeLadderIssuesOf(setup: JudgeHeatSetupT, ladder: JudgeHeatLadderT, subject: string): string[] {
  const issues: string[] = [];
  const others = setup.field.filter((m) => m.artifact_sha256 !== subject);
  others.forEach((m) => {
    if (!m.anchor && m.rung_files === undefined) issues.push(`field: ${m.artifact_sha256} is neither an anchor nor a rung: a ladder heat's entry plays the ladder alone`);
  });
  if (!others.some((m) => m.anchor)) issues.push("field: a ladder heat rates its entry against the judge anchors: at least one other member is an anchor");
  const named = ladder.strengths.map((s) => s.artifact_sha256);
  const want = others.map((m) => m.artifact_sha256);
  if (canonicalJson(named) !== canonicalJson(want)) issues.push("ladder.strengths: one fixed strength for each member but the entry's, in sha256 order");
  ladder.strengths.forEach((s, k) => {
    const off = fixed9Issue(s.strength);
    if (off !== null) issues.push(`ladder.strengths.${k}.strength: ${off}`);
  });
  const off = fixed9Issue(ladder.dispersion);
  if (off !== null) issues.push(`ladder.dispersion: ${off}`);
  if (ladder.rounds * ladder.games > ROUND_MAX) issues.push(`ladder: rounds x games is at most ${ROUND_MAX}, an adaptive game's round`);
  return issues;
}

/** Why a Fixed9 strength or dispersion does not read back as one (judgeLadderFromFixed9), or null when it does. */
function fixed9Issue(s: string): string | null {
  try {
    judgeLadderFromFixed9(s);
    return null;
  } catch (err) {
    if (err instanceof RangeError) return err.message;
    throw err;
  }
}

/** What does not hold in a setup (none when it holds); each issue names where. */
export function judgeHeatSetupIssues(raw: JudgeHeatSetupT): string[] {
  const parsed = JudgeHeatSetup.safeParse(raw);
  if (!parsed.success) return parsed.error.issues.map((i) => `${i.path.join('.') || '(setup)'}: ${i.message}`);
  return setupIssuesOf(parsed.data);
}

// ---------------------------------------------------------------- the cost

/**
 * The calls a final heat makes (the budget preflight's count): two a pair, ⌊n/2⌋ pairs in each of `rounds` Swiss
 * rounds over `n` members (an odd field's bye plays none), and `places` (places - 1) `repeats` in the playoff, which
 * runs with at least two finalists (judgeHeatFinalistCount).
 */
export function judgeHeatCalls(n: number, rounds: number, places: number, repeats: number): number {
  for (const [what, v] of [['members', n], ['rounds', rounds], ['places', places], ['repeats', repeats]] as const) {
    if (!Number.isSafeInteger(v) || v < 0) throw new RangeError(`${what} ${String(v)} is not a whole number from 0`);
  }
  const swiss = 2 * Math.floor(n / 2) * rounds;
  const playoff = places < 2 ? 0 : places * (places - 1) * repeats;
  return swiss + playoff;
}

/** The calls a provisional heat makes: two an anchor it plays. */
export function judgeProvisionalCalls(anchors: number): number {
  if (!Number.isSafeInteger(anchors) || anchors < 0) throw new RangeError(`anchors ${String(anchors)} is not a whole number from 0`);
  return 2 * anchors;
}

/** The finalists a final heat's playoff takes: playoff_places, no more than its entrant members, none below two. */
export function judgeHeatFinalistCount(setup: Pick<JudgeHeatSetupT, 'stage' | 'playoff_places' | 'field'>): number {
  if (setup.stage !== 'final') return 0;
  const p = Math.min(setup.playoff_places, setup.field.filter((m) => !m.anchor).length);
  return p < 2 ? 0 : p;
}

/**
 * The calls a provisional heat on a ladder makes (the header's ladder): two a judge anchor it plays, then two each of its
 * `rounds` x `games` adaptive games.
 */
export function judgeLadderCalls(anchors: number, rounds: number, games: number): number {
  for (const [what, v] of [['anchors', anchors], ['rounds', rounds], ['games', games]] as const) {
    if (!Number.isSafeInteger(v) || v < 0) throw new RangeError(`${what} ${String(v)} is not a whole number from 0`);
  }
  return 2 * anchors + 2 * rounds * games;
}

/** The calls a calibration makes (the header's ladder): every pair of its `members`, both slot orders, `repeats` times. */
export function judgeCalibrationCalls(members: number, repeats: number): number {
  for (const [what, v] of [['members', members], ['repeats', repeats]] as const) {
    if (!Number.isSafeInteger(v) || v < 0) throw new RangeError(`${what} ${String(v)} is not a whole number from 0`);
  }
  return repeats * members * (members - 1 < 0 ? 0 : members - 1);
}

/** The member a provisional heat judges: the one its entry's artifact is (undefined when none is). */
function subjectOf(setup: Pick<JudgeHeatSetupT, 'field'>): string | undefined {
  return setup.field.find((m) => m.entries.length > 0)?.artifact_sha256;
}

/** The judge anchors a provisional heat's subject plays first: every anchor member but the subject's own, in sha256 order. */
function anchorsOf(setup: Pick<JudgeHeatSetupT, 'field'>, subject: string): string[] {
  return setup.field.filter((m) => m.anchor && m.artifact_sha256 !== subject).map((m) => m.artifact_sha256);
}

/** Every call a heat makes, before any is made. */
export function judgeHeatPlannedCalls(setup: JudgeHeatSetupT): number {
  if (setup.stage === 'calibration') return judgeCalibrationCalls(setup.field.length, setup.repeats ?? 0);
  if (setup.stage === 'provisional') {
    const ladder = setup.ladder;
    if (ladder === undefined) return judgeProvisionalCalls(Math.max(0, setup.field.length - 1));
    const subject = subjectOf(setup);
    return judgeLadderCalls(subject === undefined ? 0 : anchorsOf(setup, subject).length, ladder.rounds, ladder.games);
  }
  return judgeHeatCalls(setup.field.length, setup.rounds, judgeHeatFinalistCount(setup), setup.playoff_repeats);
}

// ---------------------------------------------------------------- the schedule

/** A call the heat makes: its stage and round, its pair and its slot order. */
export interface JudgePlannedCallT {
  stage: JudgeCallStageT;
  round: number;
  a: string;
  b: string;
  slot_order: JudgeSlotOrderT;
}

/** A settled call as the schedule reads it: a v2 call's margin with its verdict. */
export type JudgeSettledCallT = Pick<JudgeHeatCallT, 'stage' | 'round' | 'a' | 'b' | 'slot_order' | 'verdict' | 'margin'>;

/** The member a call's verdict names; null with none. */
export function judgeCallWinner(c: Pick<JudgeHeatCallT, 'a' | 'b' | 'slot_order' | 'verdict'>): string | null {
  if (c.verdict === null) return null;
  return (c.verdict === 'A') === (c.slot_order === 'ab') ? c.a : c.b;
}

/**
 * A v2 call's tenths of a win for `member`, its `a` or its `b` (the header's game): 5 + margin to the member its verdict
 * picks, 5 - margin to the other, 5 each when it has no verdict; the two always sum to JUDGE_CALL_TENTHS. RangeError on
 * a member the call does not judge, or a verdict without its margin (a v1 call: its game is the binary fold).
 */
export function judgeCallTenths(c: Pick<JudgeHeatCallT, 'a' | 'b' | 'slot_order' | 'verdict' | 'margin'>, member: string): number {
  if (member !== c.a && member !== c.b) throw new RangeError(`${member} is neither member of the call between ${c.a} and ${c.b}`);
  const half = JUDGE_CALL_TENTHS / 2;
  const winner = judgeCallWinner(c);
  if (winner === null) return half;
  const m = c.margin;
  if (m === undefined || m === null || !Number.isSafeInteger(m) || m < JUDGE_MARGIN_MIN || m > JUDGE_MARGIN_MAX) {
    throw new RangeError(`the call's verdict ${String(c.verdict)} has no margin from ${JUDGE_MARGIN_MIN} to ${JUDGE_MARGIN_MAX} (${String(m)}): only a v2 call's tenths are its own`);
  }
  return winner === member ? half + m : half - m;
}

/** A v2 game's a_points from its two calls (the header's game): `a`'s tenths from each, summed, 0 to JUDGE_GAME_POINTS. */
export function judgeGamePoints(first: Pick<JudgeHeatCallT, 'a' | 'b' | 'slot_order' | 'verdict' | 'margin'>, second: Pick<JudgeHeatCallT, 'a' | 'b' | 'slot_order' | 'verdict' | 'margin'>): number {
  if (first.a !== second.a || first.b !== second.b) throw new RangeError(`a game's two calls judge one pair, not ${first.a}/${first.b} and ${second.a}/${second.b}`);
  return judgeCallTenths(first, first.a) + judgeCallTenths(second, first.a);
}

/**
 * Why a settled call is not one of a `format` record's (null when it is): a v2 call carries its margin, a whole number
 * from JUDGE_MARGIN_MIN to JUDGE_MARGIN_MAX with a verdict and null without one; a v1 call carries none.
 */
function callFormatIssue(format: JudgeHeatFormatT, c: Pick<JudgeHeatCallT, 'verdict' | 'margin'>): string | null {
  if (format === JUDGE_HEAT_FORMAT_V1) return c.margin === undefined ? null : `margin: a ${JUDGE_HEAT_FORMAT_V1} call has no margin`;
  if (c.margin === undefined) return `margin: a ${format} call carries its margin (null with no verdict)`;
  if (c.verdict === null) return c.margin === null ? null : 'margin: a call with no verdict has no margin';
  if (c.margin === null || !Number.isSafeInteger(c.margin) || c.margin < JUDGE_MARGIN_MIN || c.margin > JUDGE_MARGIN_MAX) return `margin: a verdict comes with its margin, ${JUDGE_MARGIN_MIN} to ${JUDGE_MARGIN_MAX}`;
  return null;
}

/** A game's result from a_points: `a` above half, `b` below, a draw at exactly half. */
export function judgeGameResultOf(aPoints: number): JudgeGameResultT {
  const half = JUDGE_GAME_POINTS / 2;
  return aPoints > half ? 'a' : aPoints < half ? 'b' : 'draw';
}

/**
 * A pair's game from its two calls (the header's game): in a v2 record by its points (judgeGamePoints); in a v1 record
 * the binary fold, a win only when both name the same artifact.
 */
function gameOf(format: JudgeHeatFormatT, first: JudgeSettledCallT, second: JudgeSettledCallT): JudgeHeatGameT {
  const game = { stage: first.stage, round: first.round, a: first.a, b: first.b };
  if (format === JUDGE_HEAT_FORMAT_V1) {
    const w1 = judgeCallWinner(first);
    const w2 = judgeCallWinner(second);
    return { ...game, result: w1 !== null && w1 === w2 ? (w1 === first.a ? 'a' : 'b') : 'draw' };
  }
  const aPoints = judgeGamePoints(first, second);
  return { ...game, result: judgeGameResultOf(aPoints), a_points: aPoints };
}

/** The games of settled calls that run two a pair, in their order, folded as `format` folds them. */
function gamesOf(format: JudgeHeatFormatT, calls: readonly JudgeSettledCallT[]): JudgeHeatGameT[] {
  const out: JudgeHeatGameT[] = [];
  for (let k = 0; k + 1 < calls.length; k += 2) out.push(gameOf(format, calls[k]!, calls[k + 1]!));
  return out;
}

/** The finalists after the Swiss games (the header's playoff): entrant members by E, ties by sha256. */
function finalistsOf(setup: JudgeHeatSetupT, swiss: readonly JudgeHeatGameT[]): string[] {
  const count = judgeHeatFinalistCount(setup);
  if (count === 0) return [];
  const fit = judgeFit(
    setup.field.map((m) => m.artifact_sha256),
    swiss,
  );
  const entrants = new Map(setup.field.filter((m) => !m.anchor).map((m) => [m.artifact_sha256, fit.get(m.artifact_sha256)!.e]));
  return byStanding(entrants).slice(0, count);
}

export interface JudgeHeatScheduleT {
  /** The heat's calls as far as the settled ones decide them, in the order they run. */
  planned: JudgePlannedCallT[];
  /** Every call of the heat is planned: none waits on a result still to come. */
  complete: boolean;
  /** The playoff's finalists once the Swiss is settled (empty when none plays); null before. */
  finalists: string[] | null;
  /** The first settled call that is not the call the heat makes at its place, or one past its last; null when none. */
  issue: string | null;
}

/**
 * The heat's calls in the order they run, as far as `settled` (the calls made so far, in their order) decide them
 * (the header's Swiss, playoff, provisional and ladder): each Swiss round is planned from the games before it, the
 * playoff from the Swiss's, each adaptive round of a ladder heat from the estimate over the games before it; a
 * calibration is planned whole. Each settled call is checked against the call planned at its place. The setup is taken
 * as one that holds (judgeHeatSetupIssues).
 */
export function judgeHeatSchedule(setup: JudgeHeatSetupT, settled: readonly JudgeSettledCallT[]): JudgeHeatScheduleT {
  const planned: JudgePlannedCallT[] = [];
  let issue: string | null = null;
  let checked = 0;
  // Checks the settled calls against the planned ones; true when every planned call is settled as planned.
  const settle = (): boolean => {
    for (; issue === null && checked < Math.min(planned.length, settled.length); checked++) {
      const p = planned[checked]!;
      const s = settled[checked]!;
      if (s.stage !== p.stage || s.round !== p.round || s.a !== p.a || s.b !== p.b || s.slot_order !== p.slot_order) {
        issue = `calls.${checked}: the heat's ${p.stage} round ${p.round} judges ${p.a} against ${p.b} in slot order ${p.slot_order} here`;
      } else {
        const off = callFormatIssue(setup.format, s);
        if (off !== null) issue = `calls.${checked}.${off}`;
      }
    }
    return issue === null && settled.length >= planned.length;
  };
  const plan = (stage: JudgeCallStageT, round: number, pairs: readonly JudgeSwissPairT[]): void => {
    for (const p of pairs) {
      planned.push({ stage, round, a: p.a, b: p.b, slot_order: p.first }, { stage, round, a: p.a, b: p.b, slot_order: otherOrder(p.first) });
    }
  };
  const done = (finalists: string[]): JudgeHeatScheduleT => {
    if (!settle()) return { planned, complete: issue === null, finalists, issue };
    if (settled.length > planned.length) issue = `calls.${planned.length}: the heat makes ${planned.length} calls, and this is one more`;
    return { planned, complete: issue === null, finalists, issue };
  };
  const waiting = (): JudgeHeatScheduleT => ({ planned, complete: false, finalists: null, issue });
  const members = setup.field.map((m) => m.artifact_sha256);

  if (setup.stage === 'calibration') {
    // Every pair i < j in sha256 order, both slot orders, the first drawn per repeat.
    for (let repeat = 0; repeat < (setup.repeats ?? 0); repeat++) {
      const pairs: JudgeSwissPairT[] = [];
      for (let i = 0; i < members.length; i++) {
        for (let j = i + 1; j < members.length; j++) pairs.push({ a: members[i]!, b: members[j]!, first: judgeSlotOrder(setup.seed, 'calibration', repeat, members[i]!, members[j]!) });
      }
      plan('calibration', repeat, pairs);
    }
    return done([]);
  }
  if (setup.stage === 'provisional') {
    const subject = subjectOf(setup);
    const ladder = setup.ladder;
    if (subject !== undefined) {
      // Round 0: every other member; on a ladder, the judge anchors alone (the rungs only ever play adaptive games).
      const opponents = ladder === undefined ? members.filter((m) => m !== subject) : anchorsOf(setup, subject);
      plan('provisional', 0, opponents.map((b) => ({ a: subject, b, first: judgeSlotOrder(setup.seed, 'provisional', 0, subject, b) })));
      if (ladder !== undefined) {
        const strengths = judgeLadderStrengths(ladder.strengths);
        for (let round = 0; round < ladder.rounds; round++) {
          // Each round's games go to the members most informative at the estimate over every game before it.
          if (!settle()) return waiting();
          const estimate = judgeLadderEstimate(subject, gamesOf(setup.format, settled.slice(0, planned.length)), strengths);
          const next = judgeLadderNext(estimate, strengths, ladder.spread);
          for (let g = 0; g < ladder.games; g++) {
            const k = round * ladder.games + g + 1;
            const b = next[g % next.length]!;
            plan('adaptive', k, [{ a: subject, b, first: judgeSlotOrder(setup.seed, 'adaptive', k, subject, b) }]);
          }
        }
      }
    }
    return done([]);
  }
  if (members.length < 2) return done([]);

  const rounds: JudgeSwissRoundT[] = [];
  for (let round = 0; round < setup.rounds; round++) {
    if (!settle()) return waiting();
    const fit = judgeFit(members, gamesOf(setup.format, settled.slice(0, planned.length)));
    const standing = new Map(members.map((m) => [m, fit.get(m)!.e]));
    const pairing = judgeSwissPairs(standing, judgeSwissHistory(rounds), setup.seed, round);
    rounds.push(pairing);
    plan('swiss', round, pairing.pairs);
  }
  if (!settle()) return waiting();
  const finalists = finalistsOf(setup, gamesOf(setup.format, settled.slice(0, planned.length)));
  for (let repeat = 0; repeat < (finalists.length === 0 ? 0 : setup.playoff_repeats); repeat++) {
    const pairs: JudgeSwissPairT[] = [];
    for (let i = 0; i < finalists.length; i++) {
      for (let j = i + 1; j < finalists.length; j++) {
        pairs.push({ a: finalists[i]!, b: finalists[j]!, first: judgeSlotOrder(setup.seed, 'playoff', repeat, finalists[i]!, finalists[j]!) });
      }
    }
    plan('playoff', repeat, pairs);
  }
  return done(finalists);
}

/**
 * The call the heat makes next after `settled`, or null when it has made them all. JudgeHeatError when a settled call
 * is not the heat's. It plans the heat from the start each time (a fit a Swiss round so far): a runner may as well walk
 * judgeHeatSchedule's planned calls, planning again once it has made them all.
 */
export function judgeHeatNextCall(setup: JudgeHeatSetupT, settled: readonly JudgeSettledCallT[]): JudgePlannedCallT | null {
  const s = judgeHeatSchedule(setup, settled);
  if (s.issue !== null) throw new JudgeHeatError(`the calls made are not the heat's: ${s.issue}`);
  return s.planned[settled.length] ?? null;
}

/**
 * Why calls kept from an earlier attempt cannot resume the heat (null when they can): the setup does not hold, or a
 * kept call is not the one the heat makes at its place (judgeHeatSchedule), or a kept spare (the partial's `spares`)
 * does not hold or names no kept call (judgeHeatSpareIssues, and the order and count a record's spares keep). Kept calls
 * that pass are a prefix of the heat's: the attempt goes on from the next one.
 */
export function judgeHeatKeptIssue(setup: JudgeHeatSetupT, kept: readonly JudgeHeatCallT[], spares: readonly JudgeHeatSpareT[] = []): string | null {
  const setupIssues = judgeHeatSetupIssues(setup);
  if (setupIssues.length > 0) return setupIssues[0]!;
  for (const [i, c] of kept.entries()) {
    const parsed = JudgeHeatCall.safeParse(c);
    if (!parsed.success) return `calls.${i}: ${parsed.error.issues[0]?.message ?? 'malformed'}`;
    const callIssues = judgeHeatCallIssues(parsed.data);
    if (callIssues.length > 0) return `calls.${i}.${callIssues[0]}`;
  }
  const parsedSpares: JudgeHeatSpareT[] = [];
  for (const [i, s] of spares.entries()) {
    const parsed = JudgeHeatSpare.safeParse(s);
    if (!parsed.success) return `spares.${i}: ${parsed.error.issues.map((x) => `${x.path.join('.') || '(spare)'}: ${x.message}`)[0] ?? 'malformed'}`;
    parsedSpares.push(parsed.data);
  }
  const spareIssues = sparesIssuesOf(setup.format, parsedSpares, kept.length);
  if (spareIssues.length > 0) return spareIssues[0]!;
  return judgeHeatSchedule(setup, kept).issue;
}

/**
 * The key kept calls are resumed under: sha256 of the canonical JSON of the format, the setup and the caller's
 * `plan` (whatever else the calls depend on: grader/worker.ts names the phase, its bundle and the artifacts' bytes).
 * The format is the setup's own, so calls a v1 heat kept never resume a v2 one.
 */
export function judgeHeatResumeKey(setup: JudgeHeatSetupT, plan: unknown): string {
  const parsed = JudgeHeatSetup.parse(setup);
  return sha256Hex(canonicalJson({ format: parsed.format, setup: parsed, plan }));
}

export const JUDGE_HEAT_PARTIAL_FORMAT = 'agent-fun/judge-heat-partial/v1';

/**
 * What an attempt of a heat keeps as it goes (grader/worker.ts judgeHeatPartialPath), so the next attempt sends only
 * the calls still to come: its calls, its spend and its one fault re-sent, and the masq key it holds open.
 */
export const JudgeHeatPartial = z.strictObject({
  format: z.literal(JUDGE_HEAT_PARTIAL_FORMAT),
  /** judgeHeatResumeKey: the calls are this heat's only under it. */
  key: Sha256Hex,
  /** The calls settled so far, in the order they ran: a prefix of the heat's (judgeHeatKeptIssue). */
  calls: z.array(JudgeHeatCall),
  /** The heat's spend so far, µUSD (a u64 decimal): every attempt its keys sent and priced, a faulted call's too. */
  spent_micro_usd: U64,
  /** The calls sent again after a fault: a heat re-sends one; a second fault fails it. */
  resent: z.int().min(0).max(1),
  /** The keys the heat has minted: the next one's attempt number (grader/gateway/masq.ts JudgeKeySpec) is this plus 1. */
  keys: z.int().min(0),
  /** The key the last attempt minted, while not retired, and what it metered: the next attempt retires it first. */
  open_key: z.strictObject({ id: z.string().min(1), label: z.string().min(1), meter_micro_usd: U64 }).nullable(),
  /**
   * The kept calls' other sends (the header's spares), ordered by call, then send, each naming a kept call; absent,
   * never empty, when there are none (a partial kept before spares were has none).
   */
  spares: z.array(JudgeHeatSpare).min(1).optional(),
});
export type JudgeHeatPartialT = z.infer<typeof JudgeHeatPartial>;

// ---------------------------------------------------------------- the calls

const USAGE_KEYS = ['input', 'output', 'cache_read', 'cache_write_5m', 'cache_write_1h', 'reasoning'] as const satisfies readonly (keyof CassetteUsageT)[];

/** Usages summed; null when none carries any (grader/judge-call.ts sums a call's attempts so). */
function usageSum(all: readonly (CassetteUsageT | null)[]): CassetteUsageT | null {
  let sum: CassetteUsageT | null = null;
  for (const u of all) {
    if (u === null) continue;
    sum ??= { input: 0, output: 0, cache_read: 0, cache_write_5m: 0, cache_write_1h: 0, reasoning: 0 };
    for (const k of USAGE_KEYS) sum[k] += u[k];
  }
  return sum;
}

/** Prices summed, an unpriced one adding nothing: micro-USD, a u64 decimal. */
function microUsdSum(all: readonly (string | null)[]): string {
  let sum = 0n;
  for (const m of all) if (m !== null) sum += BigInt(m);
  return sum.toString();
}

/**
 * What does not hold between a parsed call's fields (none when it holds), each issue naming its field: two members;
 * the attempts in grader/judge-call.ts's order (the answer, then a retry its form allows: JUDGE_CALL_RETRY_FORMS), a
 * retry only after an attempt that gave no verdict, and both sent before a call is invalid; the verdict, reason and
 * invalid as the last attempt left them; a margin, where the call carries one (a v2 call: whether it must is the
 * record's format, judgeHeatRecordIssues), null exactly when the verdict is; the last attempt's request, response and
 * model; the attempts' usage and price summed.
 */
export function judgeHeatCallIssues(c: JudgeHeatCallT): string[] {
  const issues: string[] = [];
  const last = c.attempts[c.attempts.length - 1]!;
  const answer = c.attempts[0]!.form;
  const retries = JUDGE_CALL_RETRY_FORMS[answer];
  if (c.a === c.b) issues.push('b: a call compares two field members');
  c.attempts.forEach((t, i) => {
    if (i === 0 && retries === undefined) issues.push(`attempts.0.form: request 1 of a call is its answer, ${Object.keys(JUDGE_CALL_RETRY_FORMS).join(' or ')}`);
    if (i > 0 && retries !== undefined && !retries.includes(t.form)) issues.push(`attempts.${i}.form: request ${i + 1} of a call answered as ${answer} is its retry, ${retries.join(' or ')}`);
    if (i < c.attempts.length - 1 && t.invalid === null) issues.push(`attempts.${i}.invalid: a call is retried only after a request that gave no verdict`);
  });
  if (c.verdict === null) {
    if (last.invalid === null) issues.push(`attempts.${c.attempts.length - 1}.invalid: the last request of a call with no verdict says why it gave none`);
    if (c.attempts.length !== JUDGE_CALL_MAX_ATTEMPTS) issues.push(`attempts: a call is invalid only after its ${JUDGE_CALL_MAX_ATTEMPTS} requests`);
    if (c.reason !== null) issues.push('reason: a call with no verdict has no reason');
    if (c.margin !== undefined && c.margin !== null) issues.push('margin: a call with no verdict has no margin');
    if (c.invalid !== last.invalid) issues.push('invalid: why the last request gave no verdict');
  } else {
    if (last.invalid !== null) issues.push(`attempts.${c.attempts.length - 1}.invalid: the request a verdict was read from is valid`);
    if (last.model_answered === null) issues.push('model_answered: a verdict is read off an answer that names its model');
    if (c.reason === null) issues.push('reason: a verdict comes with its reason');
    if (c.margin === null) issues.push(`margin: a verdict comes with its margin, ${JUDGE_MARGIN_MIN} to ${JUDGE_MARGIN_MAX}`);
    if (c.invalid !== null) issues.push('invalid: a call with a verdict is valid');
  }
  if (c.request_sha256 !== last.request_sha256) issues.push("request_sha256: the last request's");
  if (c.response_body_sha256 !== last.response_body_sha256) issues.push("response_body_sha256: the last request's");
  if (c.model_answered !== last.model_answered) issues.push("model_answered: the last request's");
  const usage = usageSum(c.attempts.map((t) => t.usage));
  if (canonicalJson(usage) !== canonicalJson(c.usage)) issues.push(`usage: the attempts sum to ${canonicalJson(usage)}`);
  const micro = microUsdSum(c.attempts.map((t) => t.micro_usd));
  if (micro !== c.micro_usd) issues.push(`micro_usd: the attempts sum to ${micro}`);
  return issues;
}

/** What the heat keeps of a grader/judge-call.ts JudgeCallResult (structurally: a JudgeCallResult is one). */
export interface JudgeCallResultT {
  /** Entry A's artifact, and Entry B's. */
  a_sha256: string;
  b_sha256: string;
  verdict: JudgeVerdictT | null;
  /** How far the winner is ahead, 1 to 5; null exactly when verdict is. */
  margin: number | null;
  winner_sha256: string | null;
  reason: string | null;
  invalid: string | null;
  request_sha256: string;
  response_body_sha256: string;
  model_answered: string | null;
  usage: CassetteUsageT | null;
  micro_usd: string;
  attempts: readonly JudgeHeatAttemptT[];
}

/**
 * The call the heat keeps for `planned`, from what grader/judge-call.ts answered for it: a v2 call, its margin
 * included (every heat run now writes JUDGE_HEAT_FORMAT). JudgeHeatError when that answer judged another pair or slot
 * order than the planned call's, carries no margin (one 1 to 5 with a verdict, null without), or does not hold
 * (judgeHeatCallIssues).
 */
export function judgeHeatCallOf(planned: JudgePlannedCallT, result: JudgeCallResultT): JudgeHeatCallT {
  const [slotA, slotB] = planned.slot_order === 'ab' ? [planned.a, planned.b] : [planned.b, planned.a];
  if (result.a_sha256 !== slotA || result.b_sha256 !== slotB) {
    throw new JudgeHeatError(`the call judged ${result.a_sha256} (A) against ${result.b_sha256} (B), not the planned ${slotA} against ${slotB}`);
  }
  const winner = result.verdict === null ? null : result.verdict === 'A' ? slotA : slotB;
  if (result.winner_sha256 !== winner) throw new JudgeHeatError(`the call's winner ${String(result.winner_sha256)} is not its verdict ${String(result.verdict)}'s artifact`);
  const margin = (result as { margin?: unknown }).margin;
  if (margin === undefined || (margin === null) !== (result.verdict === null)) {
    throw new JudgeHeatError(`the call's margin ${String(margin)} is not one for its verdict ${String(result.verdict)}: a verdict comes with a margin from ${JUDGE_MARGIN_MIN} to ${JUDGE_MARGIN_MAX}, no verdict with null`);
  }
  const parsed = JudgeHeatCall.safeParse({
    stage: planned.stage,
    round: planned.round,
    a: planned.a,
    b: planned.b,
    slot_order: planned.slot_order,
    verdict: result.verdict,
    margin,
    reason: result.reason,
    invalid: result.invalid,
    request_sha256: result.request_sha256,
    response_body_sha256: result.response_body_sha256,
    model_answered: result.model_answered,
    usage: result.usage,
    micro_usd: result.micro_usd,
    attempts: result.attempts,
  });
  if (!parsed.success) throw new JudgeHeatError(`the call is not one: ${parsed.error.issues.map((i) => `${i.path.join('.') || '(call)'}: ${i.message}`).join('; ')}`);
  const issues = judgeHeatCallIssues(parsed.data);
  if (issues.length > 0) throw new JudgeHeatError(`the call does not hold: ${issues.join('; ')}`);
  return parsed.data;
}

// ---------------------------------------------------------------- the spares

/**
 * What does not hold between a parsed spare's fields (none when it holds), each issue naming its field: ended_at not
 * before sent_at; the attempts in grader/judge-call.ts's order (the answer, then a retry its form allows), a retry only
 * after an attempt that gave no verdict; a verdict, margin and reason exactly when `late`, read off its last attempt (one
 * that gave the verdict and names its model); `invalid` null exactly when `late`, an `invalid` spare's its last
 * attempt's after both its requests; a `cancelled` spare's attempts at most one, which gave no verdict; the attempts'
 * usage and price summed. Where it sits in a record (its call, its send number) is judgeHeatRecordIssues'.
 */
export function judgeHeatSpareIssues(s: JudgeHeatSpareT): string[] {
  const issues: string[] = [];
  if (Date.parse(s.ended_at) < Date.parse(s.sent_at)) issues.push('ended_at: a send ends no earlier than it was sent');
  const last = s.attempts[s.attempts.length - 1];
  const answer = s.attempts[0]?.form;
  const retries = answer === undefined ? undefined : JUDGE_CALL_RETRY_FORMS[answer];
  s.attempts.forEach((t, i) => {
    if (i === 0 && retries === undefined) issues.push(`attempts.0.form: request 1 of a send is its answer, ${Object.keys(JUDGE_CALL_RETRY_FORMS).join(' or ')}`);
    if (i > 0 && retries !== undefined && !retries.includes(t.form)) issues.push(`attempts.${i}.form: request ${i + 1} of a send answered as ${String(answer)} is its retry, ${retries.join(' or ')}`);
    if (i < s.attempts.length - 1 && t.invalid === null) issues.push(`attempts.${i}.invalid: a send is retried only after a request that gave no verdict`);
  });
  if (s.ended === 'late') {
    if (last === undefined) issues.push('attempts: a late spare answered its verdict in at least one request');
    else {
      if (last.invalid !== null) issues.push(`attempts.${s.attempts.length - 1}.invalid: the request a late spare's verdict was read from is valid`);
      if (last.model_answered === null) issues.push("attempts: a late spare's verdict is read off an answer that names its model");
    }
    if (s.verdict === null) issues.push('verdict: a late spare answered with a verdict');
    if (s.margin === null) issues.push(`margin: a late spare's verdict comes with its margin, ${JUDGE_MARGIN_MIN} to ${JUDGE_MARGIN_MAX}`);
    if (s.reason === null) issues.push("reason: a late spare's verdict comes with its reason");
    if (s.invalid !== null) issues.push('invalid: a late spare gave a verdict');
  } else {
    if (s.verdict !== null) issues.push(`verdict: only a late spare carries a verdict, and this one ended ${s.ended}`);
    if (s.margin !== null) issues.push(`margin: only a late spare carries a margin, and this one ended ${s.ended}`);
    if (s.reason !== null) issues.push(`reason: only a late spare carries a reason, and this one ended ${s.ended}`);
    if (s.invalid === null) issues.push(`invalid: a spare that ended ${s.ended} says why it gave no verdict`);
    if (s.ended === 'invalid') {
      if (s.attempts.length !== JUDGE_CALL_MAX_ATTEMPTS) issues.push(`attempts: a send is invalid only after its ${JUDGE_CALL_MAX_ATTEMPTS} requests`);
      if (last !== undefined && last.invalid === null) issues.push(`attempts.${s.attempts.length - 1}.invalid: the last request of an invalid spare says why it gave no verdict`);
      if (last !== undefined && s.invalid !== last.invalid) issues.push('invalid: why the last request gave no verdict');
    } else if (s.ended === 'cancelled') {
      if (s.attempts.length > JUDGE_CALL_MAX_ATTEMPTS - 1) issues.push(`attempts: a cancelled spare was aborted before its last request answered, so holds at most ${JUDGE_CALL_MAX_ATTEMPTS - 1}`);
      s.attempts.forEach((t, i) => {
        if (t.invalid === null) issues.push(`attempts.${i}.invalid: a cancelled spare's request gave no verdict`);
      });
    }
  }
  const usage = usageSum(s.attempts.map((t) => t.usage));
  if (canonicalJson(usage) !== canonicalJson(s.usage)) issues.push(`usage: the attempts sum to ${canonicalJson(usage)}`);
  const micro = microUsdSum(s.attempts.map((t) => t.micro_usd));
  if (micro !== s.micro_usd) issues.push(`micro_usd: the attempts sum to ${micro}`);
  return issues;
}

/**
 * What does not hold in a record's (or a partial's) spares beyond each one's own fields: a v1 record has none; each
 * names one of the `calls` listed; they are ordered by call, then send, so a call's send numbers are distinct (its
 * decision holds the one they leave); a call has at most JUDGE_HEAT_MAX_SENDS - 1. Each issue names where.
 */
function sparesIssuesOf(format: JudgeHeatFormatT, spares: readonly JudgeHeatSpareT[], calls: number): string[] {
  const issues: string[] = [];
  if (spares.length === 0) return issues;
  if (format === JUDGE_HEAT_FORMAT_V1) return [`spares: a ${JUDGE_HEAT_FORMAT_V1} record has none`];
  const perCall = new Map<number, number>();
  spares.forEach((s, k) => {
    issues.push(...judgeHeatSpareIssues(s).map((issue) => `spares.${k}.${issue}`));
    if (s.call >= calls) issues.push(`spares.${k}.call: ${s.call} names no call: ${calls} are listed`);
    const prev = spares[k - 1];
    if (prev !== undefined && (prev.call > s.call || (prev.call === s.call && prev.send >= s.send))) {
      issues.push(`spares.${k}: the spares are ordered by call, then send, each send of a call once (call ${s.call} send ${s.send} after call ${prev.call} send ${prev.send})`);
    }
    const n = (perCall.get(s.call) ?? 0) + 1;
    perCall.set(s.call, n);
    if (n === JUDGE_HEAT_MAX_SENDS) issues.push(`spares.${k}.call: call ${s.call} has at most ${JUDGE_HEAT_MAX_SENDS - 1} spares, its decision the ${JUDGE_HEAT_MAX_SENDS}th of its sends`);
  });
  return issues;
}

/**
 * What a send ended on when it threw (grader/judge-call.ts JudgeCallFault, structurally: its message and the attempts
 * that completed before it; a throw that is no JudgeCallFault, none).
 */
export interface JudgeSendFaultT {
  message: string;
  attempts: readonly JudgeHeatAttemptT[];
}

/** An instant as an ISO date-time: a string kept as handed, epoch milliseconds or a Date as toISOString writes it. */
function isoOf(at: string | number | Date): string {
  if (typeof at === 'string') return at;
  const d = typeof at === 'number' ? new Date(at) : at;
  if (Number.isNaN(d.getTime())) throw new RangeError(`${String(at)} is no instant`);
  return d.toISOString();
}

/**
 * The spare the heat keeps for send `send` of call `index` (the header's spares), sent at `sentAt` and ended at `endedAt`
 * (ISO date-times, epoch milliseconds or Dates), from what it ended on: grader/judge-call.ts's JudgeCallResult (`late`
 * with its verdict, margin and reason, or `invalid` with none) or the JudgeCallFault it threw (`cancelled` or
 * `faulted`, the fault's message its `invalid`, its attempts the fault's). JudgeHeatError when `ended` is not one what it
 * ended on can be, or the spare does not hold (judgeHeatSpareIssues).
 */
export function judgeHeatSpareOf(
  index: number,
  send: number,
  sentAt: string | number | Date,
  endedAt: string | number | Date,
  ended: JudgeSpareEndT,
  from: JudgeCallResultT | JudgeSendFaultT,
): JudgeHeatSpareT {
  let raw: Record<string, unknown>;
  if ('verdict' in from) {
    const result = from;
    const want: JudgeSpareEndT = result.verdict === null ? 'invalid' : 'late';
    if (ended !== want) throw new JudgeHeatError(`a send that answered ${result.verdict === null ? 'with no verdict' : `the verdict ${result.verdict}`} ended ${want}, not ${ended}`);
    raw = {
      verdict: result.verdict,
      margin: result.margin,
      reason: result.reason,
      invalid: result.invalid,
      usage: result.usage,
      micro_usd: result.micro_usd,
      attempts: result.attempts,
    };
  } else {
    if (ended !== 'cancelled' && ended !== 'faulted') throw new JudgeHeatError(`a send that threw ended cancelled or faulted, not ${ended}`);
    raw = {
      verdict: null,
      margin: null,
      reason: null,
      invalid: from.message,
      usage: usageSum(from.attempts.map((t) => t.usage)),
      micro_usd: microUsdSum(from.attempts.map((t) => t.micro_usd)),
      attempts: from.attempts,
    };
  }
  const parsed = JudgeHeatSpare.safeParse({ call: index, send, sent_at: isoOf(sentAt), ended_at: isoOf(endedAt), ended, ...raw });
  if (!parsed.success) throw new JudgeHeatError(`the spare is not one: ${parsed.error.issues.map((i) => `${i.path.join('.') || '(spare)'}: ${i.message}`).join('; ')}`);
  const issues = judgeHeatSpareIssues(parsed.data);
  if (issues.length > 0) throw new JudgeHeatError(`the spare does not hold: ${issues.join('; ')}`);
  return parsed.data;
}

// ---------------------------------------------------------------- the totals and the invalid share

/**
 * The calls' totals: their count, and every attempt the heat sent, its spares' too (the header's spares: the heat paid
 * for them), counted, its usage and price summed.
 */
function totalsOf(calls: readonly JudgeHeatCallT[], spares: readonly JudgeHeatSpareT[] = []): JudgeHeatTotalsT {
  const attempts = [...calls.flatMap((c) => c.attempts), ...spares.flatMap((s) => s.attempts)];
  return {
    calls: calls.length,
    attempts: attempts.length,
    usage: usageSum(attempts.map((t) => t.usage)) ?? { input: 0, output: 0, cache_read: 0, cache_write_5m: 0, cache_write_1h: 0, reasoning: 0 },
    micro_usd: microUsdSum(attempts.map((t) => t.micro_usd)),
  };
}

/** Whether `invalid` calls of `calls` is more than the share `max` (a Fixed9 string) allows: exact, in integers. */
export function judgeHeatInvalidShareOver(invalid: number, calls: number, max: string): boolean {
  if (!Number.isSafeInteger(calls) || calls < 0 || !Number.isSafeInteger(invalid) || invalid < 0 || invalid > calls) {
    throw new RangeError(`${String(invalid)} invalid of ${String(calls)} calls is no count`);
  }
  return BigInt(invalid) * FIXED9_SCALE > BigInt(calls) * parseFixed9(max);
}

// ---------------------------------------------------------------- issues, verdicts, parsing

/**
 * What does not hold in a record (none when it holds): its setup (judgeHeatSetupIssues), every call's place in the
 * schedule re-derived from the seed and the verdicts before it and its shape the format's (a v2 call's margin, a v1
 * call's none), the spares (each one's fields, judgeHeatSpareIssues; each naming a listed call, ordered by call, then
 * send, at most JUDGE_HEAT_MAX_SENDS - 1 a call; none in a v1 record), the games (folded as the format folds them: a v2
 * game's a_points, a v1 game's none), the finalists, the totals (the spares' attempts included) and the invalid calls,
 * and an invalid share within invalid_share_max. Each issue names where.
 */
export function judgeHeatRecordIssues(raw: JudgeHeatRecordT): string[] {
  const parsed = JudgeHeatRecord.safeParse(raw);
  if (!parsed.success) return parsed.error.issues.map((i) => `${i.path.join('.') || '(record)'}: ${i.message}`);
  const record = parsed.data;
  const issues = setupIssuesOf(record);
  record.calls.forEach((c, i) => issues.push(...judgeHeatCallIssues(c).map((issue) => `calls.${i}.${issue}`)));
  issues.push(...sparesIssuesOf(record.format, record.spares ?? [], record.calls.length));
  if (issues.length > 0) return issues;
  // A calibration is planned whole, every repeat at once: its calls are counted first, so a record whose repeats are
  // past the calls it lists is refused before the schedule plans them.
  if (record.stage === 'calibration') {
    const want = judgeHeatPlannedCalls(record);
    if (want !== record.calls.length) return [`calls: the calibration makes ${want} calls, and ${record.calls.length} are listed`];
  }
  const s = judgeHeatSchedule(record, record.calls);
  if (s.issue !== null) return [s.issue];
  if (!s.complete || record.calls.length !== s.planned.length) return [`calls: the heat makes ${s.planned.length}${s.complete ? '' : ' or more'} calls, and ${record.calls.length} are listed`];
  const games = gamesOf(record.format, record.calls);
  if (games.length !== record.games.length) issues.push(`games: the calls make ${games.length} games, and ${record.games.length} are listed`);
  else {
    const at = games.findIndex((g, i) => canonicalJson(g) !== canonicalJson(record.games[i]));
    if (at !== -1) issues.push(`games.${at}: the calls make ${canonicalJson(games[at])} here`);
  }
  if (canonicalJson(s.finalists) !== canonicalJson(record.finalists)) issues.push(`finalists: the Swiss names ${JSON.stringify(s.finalists)}, not ${JSON.stringify(record.finalists)}`);
  const totals = totalsOf(record.calls, record.spares ?? []);
  if (canonicalJson(totals) !== canonicalJson(record.totals)) issues.push(`totals: the calls and their spares total ${canonicalJson(totals)}`);
  const invalid = record.calls.filter((c) => c.verdict === null).length;
  if (invalid !== record.invalid_calls) issues.push(`invalid_calls: ${invalid} calls have no verdict, not ${record.invalid_calls}`);
  else if (judgeHeatInvalidShareOver(invalid, record.calls.length, record.invalid_share_max)) {
    issues.push(`invalid_calls: ${invalid} of ${record.calls.length} calls have no verdict, more than the ${record.invalid_share_max} share the heat allows`);
  }
  return issues;
}

/** Each member's matches by outcome. */
function tallyOf(members: readonly string[], games: readonly JudgeHeatGameT[]): Map<string, { wins: number; draws: number; losses: number }> {
  const out = new Map(members.map((m) => [m, { wins: 0, draws: 0, losses: 0 }]));
  for (const g of games) {
    const a = out.get(g.a)!;
    const b = out.get(g.b)!;
    if (g.result === 'a') {
      a.wins++;
      b.losses++;
    } else if (g.result === 'b') {
      b.wins++;
      a.losses++;
    } else {
      a.draws++;
      b.draws++;
    }
  }
  return out;
}

/** Millionths, rounded (Math.round: exact). */
function micro(x: number): number {
  return Math.round(x * JUDGE_MICRO);
}

/**
 * `member`'s twentieths of a win over the playoff games it played against `peer` (a v2 game's a_points from its side).
 * Swiss games never count: their pairings follow the standing, so two members meet there unevenly.
 */
function playoffPointsOf(games: readonly JudgeHeatGameT[], member: string, peer: string): number {
  let points = 0;
  for (const g of games) {
    if (g.stage !== 'playoff') continue;
    if (g.a === member && g.b === peer) points += g.a_points!;
    else if (g.a === peer && g.b === member) points += JUDGE_GAME_POINTS - g.a_points!;
  }
  return points;
}

/**
 * Every member's score over every game of a record that holds (the header's fit and score). A v2 record's scores also
 * carry what breaks an exact tie (contracts/score.ts ProgramJudgeScore): each its member's artifact_bytes and, for an
 * entrant member of a final heat with exact-tie peers (the other entrant members scored with the same win_rate_micro
 * and the same finalist flag), head_to_head: its playoff points against each, in sha256 order. A v1 record's carry
 * neither, so their bytes are what they were.
 */
function scoresOf(record: JudgeHeatRecordT): Map<string, ProgramJudgeScoreT> {
  if (record.ladder !== undefined) return ladderScoresOf(record, record.ladder);
  const members = record.field.map((m) => m.artifact_sha256);
  const out = new Map<string, ProgramJudgeScoreT>();
  if (members.length < 2) return out;
  const v2 = record.format !== JUDGE_HEAT_FORMAT_V1;
  // A calibration's scores, as a provisional heat's, are shown and never weighed.
  const provisional = record.stage !== 'final';
  const fit = judgeFit(members, record.games);
  const tally = tallyOf(members, record.games);
  const finalists = new Set(record.finalists);
  const bases = new Map<string, Omit<ProgramJudgeScoreT, 'head_to_head'>>();
  for (const m of record.field) {
    const sha = m.artifact_sha256;
    const t = tally.get(sha)!;
    const matches = t.wins + t.draws + t.losses;
    if (matches === 0) continue;
    const { e, se } = fit.get(sha)!;
    const half = JUDGE_Z90 * se;
    bases.set(sha, {
      win_rate_micro: micro(e),
      se_micro: Math.min(JUDGE_MICRO, micro(se)),
      interval_low_micro: micro(Math.max(0, e - half)),
      interval_high_micro: micro(Math.min(1, e + half)),
      wins: t.wins,
      draws: t.draws,
      losses: t.losses,
      matches,
      finalist: finalists.has(sha),
      provisional,
      artifact_sha256: sha,
      ...(v2 ? { artifact_bytes: m.artifact_bytes! } : {}),
    });
  }
  const entrants = record.field.filter((m) => !m.anchor && bases.has(m.artifact_sha256)).map((m) => m.artifact_sha256);
  for (const [sha, base] of bases) {
    let headToHead: { artifact_sha256: string; points: number }[] = [];
    if (v2 && !provisional && entrants.includes(sha)) {
      headToHead = entrants
        .filter((peer) => peer !== sha && bases.get(peer)!.win_rate_micro === base.win_rate_micro && bases.get(peer)!.finalist === base.finalist)
        .map((peer) => ({ artifact_sha256: peer, points: playoffPointsOf(record.games, sha, peer) }));
    }
    out.set(sha, ProgramJudgeScore.parse(headToHead.length === 0 ? base : { ...base, head_to_head: headToHead }));
  }
  return out;
}

/**
 * A provisional heat's score on a ladder (the header's ladder): its entry's member's alone, rated against the record's
 * own fixed strengths and dispersion (grader/judge-ladder.ts judgeLadderScore, E over the judge anchors), its matches
 * every game it played. Shown, never weighed: provisional, never a finalist, no head-to-head.
 */
function ladderScoresOf(record: JudgeHeatRecordT, ladder: JudgeHeatLadderT): Map<string, ProgramJudgeScoreT> {
  const out = new Map<string, ProgramJudgeScoreT>();
  const member = record.field.find((m) => m.entries.length > 0);
  if (member === undefined) return out;
  const subject = member.artifact_sha256;
  const t = tallyOf(
    record.field.map((m) => m.artifact_sha256),
    record.games,
  ).get(subject)!;
  const matches = t.wins + t.draws + t.losses;
  if (matches === 0) return out;
  const s = judgeLadderScore({
    subject,
    games: record.games,
    strengths: judgeLadderStrengths(ladder.strengths),
    anchors: anchorsOf(record, subject),
    phi: judgeLadderFromFixed9(ladder.dispersion),
  });
  out.set(
    subject,
    ProgramJudgeScore.parse({
      win_rate_micro: s.win_rate_micro,
      se_micro: s.se_micro,
      interval_low_micro: s.interval_low_micro,
      interval_high_micro: s.interval_high_micro,
      wins: t.wins,
      draws: t.draws,
      losses: t.losses,
      matches,
      finalist: false,
      provisional: true,
      artifact_sha256: subject,
      artifact_bytes: member.artifact_bytes!,
    }),
  );
  return out;
}

/** A calibration's fit, what a ladder heat rates by: every member's fixed strength in sha256 order, and the dispersion. */
export interface JudgeLadderFitT {
  strengths: JudgeLadderStrengthT[];
  /** phi, Fixed9 (grader/judge-ladder.ts judgeLadderDispersion). */
  dispersion: string;
}

function ladderFitOf(record: JudgeHeatRecordT): JudgeLadderFitT {
  const members = record.field.map((m) => m.artifact_sha256);
  const fit = judgeFit(members, record.games);
  try {
    return {
      strengths: members.map((m) => ({ artifact_sha256: m, strength: judgeLadderToFixed9(fit.get(m)!.p) })),
      dispersion: judgeLadderDispersion(record.games, fit),
    };
  } catch (err) {
    if (err instanceof RangeError) throw new JudgeHeatError(`the calibration's fit is no ladder: ${err.message}`);
    throw err;
  }
}

/**
 * The ladder a calibration record measures (the header's ladder): judgeFit over its games, each member's strength as
 * Fixed9 (grader/judge-ladder.ts judgeLadderToFixed9), and the pooled within-pair dispersion over the same fit. Derived
 * twice, and the two must be the same bytes, as judgeHeatVerdicts derives. JudgeHeatError when the record does not hold
 * (judgeHeatRecordIssues), is not a calibration's, or a fitted strength has no Fixed9 form.
 */
export function judgeLadderFitOf(record: JudgeHeatRecordT): JudgeLadderFitT {
  const issues = judgeHeatRecordIssues(record);
  if (issues.length > 0) throw doesNotHold(issues);
  const parsed = JudgeHeatRecord.parse(record);
  if (parsed.stage !== 'calibration') throw new JudgeHeatError(`a ladder's fit is a calibration's, and this record is a ${parsed.stage} heat's`);
  const first = ladderFitOf(parsed);
  const second = ladderFitOf(parsed);
  const a = canonicalJson(first);
  const b = canonicalJson(second);
  if (a !== b) throw new JudgeHeatError(`the calibration's fit differs across two derivations: ${sha256Hex(a)} against ${sha256Hex(b)}`);
  return first;
}

function doesNotHold(issues: readonly string[]): JudgeHeatError {
  return new JudgeHeatError(`the heat record does not hold: ${issues.slice(0, 5).join('; ')}${issues.length > 5 ? `; and ${issues.length - 5} more` : ''}`);
}

/**
 * Every member's score from a record that holds (the header's score), keyed by artifact sha256, in field order: the
 * anchors' too (the judge breakdown's), none for a member that played no game. Derived twice, and the two must be
 * the same bytes. What a run's performance.judge is built with, by the heat and by a regrade from the stored blob
 * alike. JudgeHeatError when the record does not hold (judgeHeatRecordIssues).
 */
export function judgeHeatVerdicts(record: JudgeHeatRecordT): Map<string, ProgramJudgeScoreT> {
  const issues = judgeHeatRecordIssues(record);
  if (issues.length > 0) throw doesNotHold(issues);
  const parsed = JudgeHeatRecord.parse(record);
  const first = scoresOf(parsed);
  const second = scoresOf(parsed);
  const a = canonicalJson([...first]);
  const b = canonicalJson([...second]);
  if (a !== b) throw new JudgeHeatError(`the heat's scores differ across two derivations: ${sha256Hex(a)} against ${sha256Hex(b)}`);
  return first;
}

/** Each entry's score (judgeHeatVerdicts: its artifact's member's), keyed by entry id, in field order. */
export function judgeHeatEntryVerdicts(record: JudgeHeatRecordT): Map<string, ProgramJudgeScoreT> {
  const scores = judgeHeatVerdicts(record);
  const out = new Map<string, ProgramJudgeScoreT>();
  for (const m of record.field) {
    const score = scores.get(m.artifact_sha256);
    if (score !== undefined) for (const e of m.entries) out.set(e, score);
  }
  return out;
}

/**
 * The record of a heat whose calls are all made: `calls` in the order they ran, the games, finalists, totals and
 * invalid calls derived from them, and `spares`, the calls' other sends ordered by call, then send (the header's
 * spares; the key absent when there are none, so a record without them is the bytes it always was), counted in the
 * totals and never scored. JudgeHeatError when the calls are not the heat's, not all of them, more of them came back
 * invalid than invalid_share_max allows (the heat does not count, and no score is written), or a spare does not hold.
 */
export function judgeHeatRecordOf(setup: JudgeHeatSetupT, calls: readonly JudgeHeatCallT[], spares: readonly JudgeHeatSpareT[] = []): JudgeHeatRecordT {
  const setupIssues = judgeHeatSetupIssues(setup);
  if (setupIssues.length > 0) throw doesNotHold(setupIssues);
  const s = judgeHeatSchedule(setup, calls);
  if (s.issue !== null) throw new JudgeHeatError(`the calls made are not the heat's: ${s.issue}`);
  if (!s.complete || calls.length !== s.planned.length) throw new JudgeHeatError(`the heat is not done: ${calls.length} of its ${s.planned.length}${s.complete ? '' : ' or more'} calls are made`);
  const record: JudgeHeatRecordT = {
    ...JudgeHeatSetup.parse(setup),
    calls: [...calls],
    games: gamesOf(setup.format, calls),
    finalists: s.finalists ?? [],
    totals: totalsOf(calls, spares),
    invalid_calls: calls.filter((c) => c.verdict === null).length,
    ...(spares.length === 0 ? {} : { spares: [...spares] }),
  };
  const issues = judgeHeatRecordIssues(record);
  if (issues.length > 0) throw doesNotHold(issues);
  return JudgeHeatRecord.parse(record);
}

/** The record as stored (canonical JSON text or bytes), parsed and checked: JudgeHeatError when it is no record that holds. */
export function parseJudgeHeatRecord(stored: string | Uint8Array): JudgeHeatRecordT {
  let raw: unknown;
  try {
    raw = JSON.parse(typeof stored === 'string' ? stored : new TextDecoder('utf-8', { fatal: true }).decode(stored));
  } catch (err) {
    throw new JudgeHeatError(`the heat record is not JSON: ${(err as Error).message}`);
  }
  const parsed = JudgeHeatRecord.safeParse(raw);
  if (!parsed.success) throw new JudgeHeatError(`the heat record is not one: ${parsed.error.issues[0]?.message ?? 'malformed'}`);
  const issues = judgeHeatRecordIssues(parsed.data);
  if (issues.length > 0) throw new JudgeHeatError(`the heat record does not hold: ${issues[0]}`);
  return parsed.data;
}
